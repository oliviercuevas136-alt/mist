# Nova Assistant Desktop

Interface desktop IA locale pour Windows 10+.
Combine **Local Assistant V4.8** (cerveau FastAPI) et une **interface Electron** inspirée de Jarvis.

---

## Architecture

```
nova-assistant-desktop/
├── backend/          ← FastAPI V4.8 (cerveau IA, mémoire, caméra, voix)
│   ├── app/
│   │   ├── api/ws.py    ← pont WebSocket pour le frontend
│   │   ├── api/camera.py
│   │   ├── core/llm.py  ← Ollama + fallback Mistral
│   │   └── ...
│   ├── test_camera_indexes.py  ← diagnostic caméra Windows
│   └── requirements.txt
├── frontend/         ← Electron + renderer (HTML/CSS/JS)
│   ├── electron/
│   │   ├── main.js      ← démarre le backend, gère la fenêtre
│   │   └── preload.js   ← bridge IPC sécurisé
│   └── renderer/        ← interface Jarvis adaptée
├── scripts/
│   ├── install.bat
│   ├── start.bat
│   └── start-backend-only.bat
└── .env.example
```

**Communication** : Frontend ↔ Backend via WebSocket (`/ws`) + REST (`/api/*`)  
**Pas de fusion de code** : backend et frontend sont totalement séparés.

---

## Prérequis (Windows 10+)

| Outil | Version | Téléchargement |
|---|---|---|
| Python | **3.11.x recommandé** | https://python.org/downloads/release/python-3119/ |
| Node.js | 18+ | https://nodejs.org |
| Ollama | dernière | https://ollama.com |
| Git | optionnel | https://git-scm.com |

> ⚠️ **Python 3.11.x est la version recommandée.**  
> Python 3.12 est supporté mais non testé en production.  
> **Python 3.13+ est déconseillé** : les modules IA (Whisper, TTS) peuvent être incompatibles.  
> `install.bat` vous avertira automatiquement si votre version n'est pas idéale.

---

## Installation (4 étapes)

### Étape 1 — Lancer Ollama et télécharger le modèle

```bat
ollama serve
ollama pull llama3.2:3b
```

> Laissez `ollama serve` tourner en arrière-plan pendant toute l'utilisation de Nova.

### Étape 2 — Installer Nova

Double-cliquez sur `scripts\install.bat` ou en terminal :

```bat
scripts\install.bat
```

Ce script fait tout automatiquement :
- Vérifie que Python 3.11+ et Node.js sont installés
- Crée un environnement Python isolé (`backend\.venv`)
- Installe toutes les dépendances Python
- Installe Electron via npm
- Copie `.env.example` → `backend\.env` (si absent)

### Étape 3 — Configurer `backend\.env`

Ouvrez `backend\.env` avec un éditeur de texte (Notepad, VS Code…) et vérifiez :

```ini
OLLAMA_MODEL=llama3.2:3b       ← nom exact du modèle téléchargé
OLLAMA_BASE_URL=http://localhost:11434

# Mistral en fallback (optionnel — si Ollama échoue)
USE_MISTRAL_FALLBACK=false
MISTRAL_API_KEY=               ← votre clé si USE_MISTRAL_FALLBACK=true

# Caméra (optionnel)
CAMERA_ENABLED=false
```

### Étape 4 — Lancer Nova

```bat
scripts\start.bat
```

L'interface Electron s'ouvre en ~5–10 secondes (le backend FastAPI démarre automatiquement).

---

## Lancement manuel (développement)

Terminal 1 — Backend uniquement :
```bat
scripts\start-backend-only.bat
```

Terminal 2 — Frontend uniquement :
```bat
cd frontend
npm start
```

API interactive (Swagger) : http://127.0.0.1:8000/docs

---

## Fonctionnalités

### Chat IA
- Streaming en temps réel token par token
- Historique persistant (SQLite)
- Projets et sessions multiples
- Ollama local + fallback Mistral automatique

### Mode vocal
- Microphone → texte (SpeechRecognition navigateur, français)
- Réponse vocale (SpeechSynthesis, voix française)
- Basculement instantané chat ↔ vocal

### Surveillance caméra
- Webcam USB, RTSP, HTTP/MJPEG, GoPro
- Panneau "SURVEILLANCE" avec état en temps réel
- Bouton TEST CAMÉRA (aucun crash si absente)
- Snapshot instantané
- Polling toutes les 5s dans le header

### Interface
- Design arc-reactor animé
- 6 thèmes (Nova, Matrix, Sunset, Violet, Arctic, Gold)
- Sidebar projets/sessions
- Tray Windows (icône barre des tâches)
- Mémorisation position/taille fenêtre

---

## Caméra — Configuration avancée

```ini
# Webcam USB (index 0, 1, 2...)
CAMERA_ENABLED=true
CAMERA_SOURCE=0

# IP/RTSP
CAMERA_TYPE=rtsp
CAMERA_RTSP_URL=rtsp://admin:pass@192.168.1.100:554/live

# GoPro USB (activer mode webcam dans l'app Quik)
CAMERA_SOURCE=1

# GoPro Wi-Fi
CAMERA_TYPE=http
CAMERA_HTTP_URL=http://10.5.5.9:8080/live
```

Pour détecter les indexes webcam disponibles sur votre PC :
```bat
cd backend
.venv\Scripts\python test_camera_indexes.py
```

---

## Sécurité

- Aucune clé API dans le code — uniquement `backend\.env`
- Backend local uniquement (127.0.0.1) — non exposé sur le réseau
- Caméra optionnelle — aucun accès sans `CAMERA_ENABLED=true`
- Pas de snapshot sans `CAMERA_SAVE_SNAPSHOTS=true`
- Liens externes Electron : allowlist stricte (GitHub, Ollama uniquement)

---

## Troubleshooting

| Problème | Solution |
|---|---|
| Interface noire / "Backend non prêt" | Vérifiez que `ollama serve` est bien lancé |
| "Modèle non trouvé" | Lancez `ollama pull llama3.2:3b` |
| Pas de son / micro inactif | Windows → Paramètres → Confidentialité → Microphone → Autoriser |
| Caméra non détectée | `CAMERA_ENABLED=true` dans `.env`, relancez Nova |
| Base de données corrompue | Supprimez `backend\data\nova.db` et relancez |
| Port 8000 déjà occupé | Dans CMD avant `start.bat` : `set NOVA_BACKEND_PORT=8001` |
| Icône tray manquante | Vérifiez que `frontend\renderer\assets\nova-tray.png` existe |
| Erreur install Python | Installez Python 3.11.x et cochez "Add Python to PATH" |
| Erreur install Node | Relancez l'installeur Node.js et cochez "Add to PATH" |

---

## Changelog

### v1.0.0
- Création Nova Assistant Desktop
- Backend : Local Assistant V4.8 (FastAPI, Ollama, Mistral, SQLite, caméra, voix)
- Frontend : Electron + renderer inspiré Jarvis (MIT)
- Pont WebSocket `/ws` : protocole Jarvis mappé sur V4.8
- CORS configuré pour renderer Electron (`origin: null`)
- Streaming LLM via asyncio.Queue (générateur sync → WS async)
- Polling caméra + monitoring dans le frontend
- Scripts Windows : install.bat, start.bat, start-backend-only.bat
- README complet installation Windows 10
- Icônes Windows PNG (tray 32px + fenêtre 256px)
- Outil de diagnostic caméra (`test_camera_indexes.py`)
