"""
app/api/camera.py
─────────────────────────────────────────────────────────────────────────────
Endpoints caméra — Local Assistant V4.8

GET  /api/camera/status    → état courant + dernière erreur + snapshot dispo
POST /api/camera/test      → test une source (body optionnel)
POST /api/camera/start     → démarre le thread caméra
POST /api/camera/stop      → arrête le thread caméra
GET  /api/camera/snapshot  → dernier frame JPEG (200) ou 503 si indisponible
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from app.services.camera_manager import (
    CameraState,
    get_camera_manager,
    init_camera_manager,
)
from app.config import settings
from app.utils.logger import get_logger

logger = get_logger("camera_api")

router = APIRouter(prefix="/api/camera", tags=["camera"])


# ── Schemas ──────────────────────────────────────────────────────────────────


class CameraTestRequest(BaseModel):
    source: Optional[str] = None  # None = utilise la config .env


class CameraStatusResponse(BaseModel):
    enabled: bool
    state: str
    source_active: Optional[str]
    last_error: Optional[str]
    frame_count: int
    fps_measured: float
    snapshot_available: bool
    cv2_available: bool
    is_running: bool


# ── Helpers ───────────────────────────────────────────────────────────────────


def _get_or_init_manager():
    """Retourne le manager global, l'initialise si besoin."""
    mgr = get_camera_manager()
    if mgr is None:
        mgr = init_camera_manager(settings)
    return mgr


# ── Endpoints ─────────────────────────────────────────────────────────────────


@router.get("/status", response_model=CameraStatusResponse)
def camera_status():
    """
    Retourne l'état courant de la caméra.

    - ``state`` : idle / connecting / connected / reconnecting / degraded / stopped
    - ``source_active`` : source actuellement utilisée (index ou URL)
    - ``last_error`` : dernière erreur rencontrée
    - ``snapshot_available`` : true si un frame est disponible
    - ``cv2_available`` : true si opencv-python est installé
    """
    mgr = _get_or_init_manager()
    st = mgr.status
    return CameraStatusResponse(
        enabled=settings.camera_enabled,
        state=st.state.value,
        source_active=st.source_active,
        last_error=st.last_error,
        frame_count=st.frame_count,
        fps_measured=st.fps_measured,
        snapshot_available=st.snapshot_available,
        cv2_available=st.cv2_available,
        is_running=mgr.is_running,
    )


@router.post("/test")
def camera_test(body: CameraTestRequest = CameraTestRequest()):
    """
    Teste une source caméra sans démarrer le thread.

    - Sans ``source`` → utilise la config .env (CAMERA_SOURCE / URLs)
    - Avec ``source`` → teste cette source spécifique (index ou URL)

    Retourne ``{"ok": true, "source": "..."}`` ou ``{"ok": false, "reason": "..."}``.
    """
    mgr = _get_or_init_manager()

    src: str | int | None = None
    if body.source is not None:
        # Convertit en entier si possible (index USB)
        try:
            src = int(body.source)
        except (ValueError, TypeError):
            src = body.source

    result = mgr.test_source(src)
    logger.info("[CAMERA] test endpoint result=%s", result)
    return result


@router.post("/start")
def camera_start():
    """
    Démarre le thread caméra.

    - Si la caméra est désactivée (CAMERA_ENABLED=false), retourne 200 + warning.
    - Si déjà en cours, retourne 200 + message idempotent.
    """
    mgr = _get_or_init_manager()
    if mgr.is_running:
        return {"ok": True, "message": "already_running", "state": mgr.status.state.value}
    started = mgr.start()
    return {
        "ok": started,
        "message": "started" if started else "degraded_mode",
        "state": mgr.status.state.value,
    }


@router.post("/stop")
def camera_stop():
    """Arrête le thread caméra proprement."""
    mgr = _get_or_init_manager()
    mgr.stop()
    return {"ok": True, "message": "stopped"}


@router.get("/snapshot")
def camera_snapshot():
    """
    Retourne le dernier frame capturé en image JPEG.

    - 200 + image/jpeg  si un frame est disponible
    - 503 Service Unavailable si aucune caméra active ou pas encore de frame
    """
    mgr = _get_or_init_manager()
    jpeg = mgr.snapshot_jpeg()
    if jpeg is None:
        raise HTTPException(
            status_code=503,
            detail="Aucun snapshot disponible — caméra non connectée ou désactivée",
        )
    return Response(content=jpeg, media_type="image/jpeg")


# ── Analyse caméra à la demande ────────────────────────────────────────────
#
# Endpoint : POST /api/camera/analyze
#
# Comportement (strict, jamais inventif) :
#   1. Capture un snapshot via le manager caméra existant
#   2. Cherche un module d'analyse local optionnel :
#         app.core.vision_analyzer.analyze_jpeg(jpeg_bytes) -> str
#      (À implémenter par Oli plus tard avec llava, BLIP, ou autre.)
#   3. Si le module existe et fonctionne → renvoie sa description
#   4. Sinon → renvoie littéralement "analyse visuelle non encore disponible"
#
# Important :
#   - Jamais d'invention de contenu visuel
#   - Aucune surveillance permanente activée par cet endpoint
#   - L'appel est ponctuel, sur action utilisateur explicite

import time
from typing import Optional


class _CameraAnalysisResponse(BaseModel):
    ok: bool
    text: str
    snapshot_size: int
    analyzer_used: Optional[str] = None
    elapsed_ms: int


_ANALYSIS_UNAVAILABLE_MSG = "analyse visuelle non encore disponible"


def _try_load_analyzer():
    """
    Tente d'importer un module d'analyse d'image local optionnel.
    Convention recherchée : app.core.vision_analyzer.analyze_jpeg(bytes) -> str
    Renvoie (callable, name) si trouvé, sinon (None, None).
    """
    try:
        from app.core import vision_analyzer  # type: ignore
        fn = getattr(vision_analyzer, "analyze_jpeg", None)
        if callable(fn):
            return fn, "vision_analyzer.analyze_jpeg"
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("[VISION] analyseur présent mais import échoué : %s", exc)
    return None, None


@router.post("/analyze", response_model=_CameraAnalysisResponse)
def camera_analyze_now():
    """
    Analyse ponctuelle d'un snapshot caméra, sur demande utilisateur.

    - Capture le dernier frame disponible (pas de réactivation auto)
    - Délègue à un analyseur local si présent
    - Sinon renvoie : "analyse visuelle non encore disponible"

    Aucun effet de bord : ne démarre pas la caméra, ne lance pas
    de surveillance permanente. Si la caméra n'a aucun frame récent,
    renvoie une erreur claire (caméra non démarrée).
    """
    t0 = time.perf_counter()
    logger.info("[CAMERA_ANALYZE_REQUEST]")

    mgr = _get_or_init_manager()
    jpeg = mgr.snapshot_jpeg()
    if jpeg is None:
        logger.info("[CAMERA_ANALYZE] aucun snapshot — caméra non démarrée")
        raise HTTPException(
            status_code=503,
            detail=(
                "Aucun snapshot disponible. Démarrez la caméra "
                "via /api/camera/start avant d'analyser."
            ),
        )

    snapshot_size = len(jpeg)
    logger.info("[CAMERA_ANALYZE_SNAPSHOT] bytes=%d", snapshot_size)

    analyzer_fn, analyzer_name = _try_load_analyzer()

    if analyzer_fn is None:
        elapsed = int((time.perf_counter() - t0) * 1000)
        logger.info("[CAMERA_ANALYZE_NO_ANALYZER] elapsed_ms=%d", elapsed)
        return _CameraAnalysisResponse(
            ok=False,
            text=_ANALYSIS_UNAVAILABLE_MSG,
            snapshot_size=snapshot_size,
            analyzer_used=None,
            elapsed_ms=elapsed,
        )

    # Analyseur trouvé — délégation stricte (pas de fallback inventif)
    try:
        text = analyzer_fn(jpeg)
        if not isinstance(text, str) or not text.strip():
            raise ValueError("analyseur a renvoyé une réponse vide ou non-string")
        elapsed = int((time.perf_counter() - t0) * 1000)
        logger.info(
            "[CAMERA_ANALYZE_OK] analyzer=%s elapsed_ms=%d chars=%d",
            analyzer_name, elapsed, len(text),
        )
        return _CameraAnalysisResponse(
            ok=True,
            text=text.strip(),
            snapshot_size=snapshot_size,
            analyzer_used=analyzer_name,
            elapsed_ms=elapsed,
        )
    except Exception as exc:
        elapsed = int((time.perf_counter() - t0) * 1000)
        logger.warning(
            "[CAMERA_ANALYZE_FAIL] analyzer=%s err=%s elapsed_ms=%d",
            analyzer_name, exc, elapsed,
        )
        # Erreur de l'analyseur → on revient au message standard
        # (pas d'invention, pas d'extrapolation)
        return _CameraAnalysisResponse(
            ok=False,
            text=_ANALYSIS_UNAVAILABLE_MSG,
            snapshot_size=snapshot_size,
            analyzer_used=analyzer_name,
            elapsed_ms=elapsed,
        )
