from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.assistant import AssistantService
from app.db.database import get_db
from app.utils.logger import get_logger

logger = get_logger("api.chat")
router = APIRouter(prefix="/api/chat", tags=["chat"])

assistant_service = AssistantService()


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, description="Message utilisateur")
    conversation_id: Optional[int] = Field(default=None)


class ChatResponse(BaseModel):
    conversation_id: int
    reply: str
    model: str


@router.post("", response_model=ChatResponse)
def chat_endpoint(payload: ChatRequest, db: Session = Depends(get_db)):
    try:
        # Signal d'activité à l'orchestrateur (non bloquant)
        try:
            from app.core.orchestrator import orchestrator
            orchestrator.signal_user_interaction()
        except Exception:
            pass  # Ne jamais bloquer le chat

        result = assistant_service.chat(
            db=db,
            user_message=payload.message,
            conversation_id=payload.conversation_id,
        )
        return ChatResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Erreur chat local: {str(exc)}",
        ) from exc