from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.db.models import Conversation, Message

router = APIRouter(prefix="/api/conversations", tags=["conversations"])


class ConversationItemResponse(BaseModel):
    id: int
    title: str
    summary: str


class MessageItemResponse(BaseModel):
    id: int
    role: str
    content: str


class ConversationDetailResponse(BaseModel):
    id: int
    title: str
    summary: str
    messages: List[MessageItemResponse]


@router.get("/list", response_model=List[ConversationItemResponse])
def list_conversations(limit: int = 100, db: Session = Depends(get_db)):
    conversations = (
        db.query(Conversation)
        .order_by(Conversation.updated_at.desc(), Conversation.id.desc())
        .limit(limit)
        .all()
    )
    return [
        ConversationItemResponse(
            id=c.id,
            title=c.title,
            summary=c.summary or "",
        )
        for c in conversations
    ]


@router.get("/{conversation_id}", response_model=ConversationDetailResponse)
def get_conversation(conversation_id: int, db: Session = Depends(get_db)):
    conversation = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id)
        .first()
    )
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation introuvable.")

    messages = (
        db.query(Message)
        .filter(Message.conversation_id == conversation_id)
        .order_by(Message.id.asc())
        .all()
    )

    return ConversationDetailResponse(
        id=conversation.id,
        title=conversation.title,
        summary=conversation.summary or "",
        messages=[
            MessageItemResponse(id=m.id, role=m.role, content=m.content)
            for m in messages
        ],
    )