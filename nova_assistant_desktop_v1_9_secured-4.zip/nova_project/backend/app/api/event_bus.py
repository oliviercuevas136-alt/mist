"""
api/event_bus.py — Endpoints d'inspection du bus d'événements.

LECTURE SEULE : aucun moyen de publier depuis le frontend (sécurité).
Le frontend peut consulter le journal central pour debug / monitoring.
"""

from typing import Optional

from fastapi import APIRouter, Query

from app.core.core_decision import get_decision_engine
from app.core.event_bus import EventLevel, get_event_bus

router = APIRouter(prefix="/api/core", tags=["core"])


@router.get("/bus/journal")
def bus_journal(
    limit: int = Query(50, ge=1, le=500),
    level_min: Optional[str] = Query(None, description="info|low|medium|high|critical"),
):
    """N derniers événements du bus, filtrés par niveau minimum."""
    bus = get_event_bus()
    level = None
    if level_min:
        try:
            level = EventLevel(level_min.lower())
        except ValueError:
            level = None
    return {"events": bus.get_journal(limit=limit, level_min=level)}


@router.get("/bus/stats")
def bus_stats():
    """Compteurs du bus (publications, drops anti-spam, erreurs handlers, …)."""
    return get_event_bus().get_stats()


@router.get("/decisions")
def decisions_history(limit: int = Query(50, ge=1, le=200)):
    """N dernières décisions prises par le CoreDecisionEngine."""
    return {"decisions": get_decision_engine().get_history(limit=limit)}
