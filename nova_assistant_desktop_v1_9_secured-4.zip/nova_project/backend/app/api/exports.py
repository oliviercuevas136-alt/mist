from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.export_engine import ExportEngine
from app.db.database import get_db

router = APIRouter(prefix="/api/exports", tags=["exports"])
export_engine = ExportEngine()


class ExportResponse(BaseModel):
    exported_file: str


class ExportAllResponse(BaseModel):
    memories: str
    notes: str
    conversations: str


@router.post("/memories", response_model=ExportResponse)
def export_memories(db: Session = Depends(get_db)):
    path = export_engine.export_memories(db)
    return ExportResponse(exported_file=path)


@router.post("/notes", response_model=ExportResponse)
def export_notes(db: Session = Depends(get_db)):
    path = export_engine.export_notes(db)
    return ExportResponse(exported_file=path)


@router.post("/conversations", response_model=ExportResponse)
def export_conversations(db: Session = Depends(get_db)):
    path = export_engine.export_conversations(db)
    return ExportResponse(exported_file=path)


@router.post("/all", response_model=ExportAllResponse)
def export_all(db: Session = Depends(get_db)):
    data = export_engine.export_all(db)
    return ExportAllResponse(**data)