"""
app/api/file_search.py — Endpoints de recherche fichier locale.

Lecture seule. Aucune primitive d'écriture/suppression exposée.

Endpoints :
    GET  /api/file-search/status            → liste des dossiers autorisés
    POST /api/file-search/by-name           → recherche par nom
    POST /api/file-search/by-content        → recherche par contenu (extensions texte)

Sécurité : voir services/file_search.py
"""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.file_search import (
    FileSearchError,
    get_file_search,
)
from app.utils.logger import get_logger

logger = get_logger("api.file_search")

router = APIRouter(prefix="/api/file-search", tags=["file-search"])


class FileSearchQuery(BaseModel):
    query: str = Field(..., min_length=1, max_length=200, description="Texte à chercher")
    dirs: Optional[List[str]] = Field(
        default=None,
        description="Sous-ensemble de dossiers à parcourir (doit être inclus dans la allowlist)",
    )
    max_results: Optional[int] = Field(default=None, ge=1, le=200)


class FileSearchResultItem(BaseModel):
    path: str
    name: str
    size: int
    modified_iso: str
    snippet: Optional[str] = None


class FileSearchResponse(BaseModel):
    ok: bool
    results: List[FileSearchResultItem]
    allowed_dirs: List[str]


@router.get("/status")
def file_search_status():
    """État du service : liste des dossiers autorisés."""
    fs = get_file_search()
    dirs = [str(d) for d in fs.get_allowed_dirs()]
    return {
        "enabled": bool(dirs),
        "allowed_dirs": dirs,
        "note": (
            "Aucun dossier autorisé — définissez ALLOWED_SEARCH_DIRS dans .env."
            if not dirs else
            f"{len(dirs)} dossier(s) autorisé(s) à la recherche."
        ),
    }


@router.post("/by-name", response_model=FileSearchResponse)
def file_search_by_name(payload: FileSearchQuery):
    """Recherche fichiers par NOM (case-insensitive). Pas d'accès au contenu."""
    fs = get_file_search()
    logger.info("[FILESEARCH_REQUEST] mode=name query=%r", payload.query)
    try:
        results = fs.search_by_name(
            payload.query,
            dirs=payload.dirs,
            max_results=payload.max_results,
        )
    except FileSearchError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return FileSearchResponse(
        ok=True,
        results=[FileSearchResultItem(**r) for r in results],
        allowed_dirs=[str(d) for d in fs.get_allowed_dirs()],
    )


@router.post("/by-content", response_model=FileSearchResponse)
def file_search_by_content(payload: FileSearchQuery):
    """Recherche fichiers TEXTE par CONTENU (extensions whitelistées)."""
    fs = get_file_search()
    logger.info("[FILESEARCH_REQUEST] mode=content query=%r", payload.query)
    try:
        results = fs.search_by_content(
            payload.query,
            dirs=payload.dirs,
            max_results=payload.max_results,
        )
    except FileSearchError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return FileSearchResponse(
        ok=True,
        results=[FileSearchResultItem(**r) for r in results],
        allowed_dirs=[str(d) for d in fs.get_allowed_dirs()],
    )


# ── Lecture sécurisée d'un fichier ─────────────────────────────────────────
#
# Deux endpoints :
#   POST /read-preview  → aperçu rapide (4 Ko par défaut)
#   POST /read-full     → lecture complète bornée (512 Ko max)
#
# Garanties (déléguées au service FileSearch.read_file_safe) :
#   - allowlist obligatoire (settings.allowed_search_dirs)
#   - blocklist absolue (chemins systèmes refusés)
#   - extension whitelistée (.txt .md .json .csv .log .py .js .ts .html .css …)
#   - taille bornée
#   - liens symboliques refusés
#   - LECTURE SEULE : aucune écriture/modification possible


class FileReadRequest(BaseModel):
    path: str = Field(..., min_length=1, description="Chemin absolu du fichier à lire")
    max_bytes: Optional[int] = Field(
        default=None, ge=1, le=524288,
        description="Plafond optionnel de bytes à lire (cap par file_read_full_max_bytes)",
    )


class FileReadResponse(BaseModel):
    ok: bool
    path: str
    name: str
    extension: str
    size: int
    bytes_read: int
    encoding: str
    truncated: bool
    modified_iso: str
    mode: str
    content: str


@router.post("/read-preview", response_model=FileReadResponse)
def file_read_preview(payload: FileReadRequest):
    """
    Aperçu rapide d'un fichier (4 Ko par défaut, configurable via
    file_read_preview_bytes). Conçu pour : montrer le début d'un fichier
    AVANT d'autoriser l'analyse complète. Fichier doit être texte et
    sous un dossier autorisé.
    """
    fs = get_file_search()
    logger.info("[FILE_READ_REQUEST] mode=preview path=%r", payload.path)
    try:
        data = fs.read_file_safe(
            payload.path, mode="preview", max_bytes=payload.max_bytes,
        )
    except FileSearchError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return FileReadResponse(ok=True, **data)


@router.post("/read-full", response_model=FileReadResponse)
def file_read_full(payload: FileReadRequest):
    """
    Lecture complète bornée d'un fichier (512 Ko max par défaut,
    configurable via file_read_full_max_bytes). À utiliser APRÈS un
    aperçu, pour l'analyse complète. Mêmes garanties de sécurité.
    """
    fs = get_file_search()
    logger.info("[FILE_READ_REQUEST] mode=full path=%r", payload.path)
    try:
        data = fs.read_file_safe(
            payload.path, mode="full", max_bytes=payload.max_bytes,
        )
    except FileSearchError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return FileReadResponse(ok=True, **data)
