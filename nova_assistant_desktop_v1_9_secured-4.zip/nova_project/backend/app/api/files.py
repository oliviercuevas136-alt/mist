from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.file_engine import FileEngine
from app.core.safety import SafetyError
from app.db.database import get_db

router = APIRouter(prefix="/api/files", tags=["files"])
file_engine = FileEngine()


class FileListRequest(BaseModel):
    relative_dir: str = Field(..., min_length=1)


class FileItemResponse(BaseModel):
    name: str
    relative_path: str
    is_file: bool
    is_dir: bool
    size: Optional[int] = None


class FileReadRequest(BaseModel):
    relative_path: str = Field(..., min_length=1)


class FileReadResponse(BaseModel):
    filename: str
    relative_path: str
    extension: str
    size: int
    content: str


class FileIndexRequest(BaseModel):
    relative_path: str = Field(..., min_length=1)


class IndexedDocumentResponse(BaseModel):
    id: int
    filename: str
    path: str
    content_preview: str


class DocumentSearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    limit: int = 20


@router.post("/list", response_model=List[FileItemResponse])
def list_files(payload: FileListRequest):
    try:
        items = file_engine.list_files(payload.relative_dir)
        return [FileItemResponse(**item) for item in items]
    except (SafetyError, FileNotFoundError, NotADirectoryError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/read", response_model=FileReadResponse)
def read_file(payload: FileReadRequest):
    try:
        data = file_engine.read_file(payload.relative_path)
        return FileReadResponse(**data)
    except (SafetyError, FileNotFoundError, IsADirectoryError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/index", response_model=IndexedDocumentResponse)
def index_file(payload: FileIndexRequest, db: Session = Depends(get_db)):
    try:
        doc = file_engine.index_file(db=db, relative_path=payload.relative_path)
        return IndexedDocumentResponse(
            id=doc.id,
            filename=doc.filename,
            path=doc.path,
            content_preview=doc.content_preview,
        )
    except (SafetyError, FileNotFoundError, IsADirectoryError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/documents", response_model=List[IndexedDocumentResponse])
def list_documents(limit: int = 100, db: Session = Depends(get_db)):
    docs = file_engine.list_indexed_documents(db=db, limit=limit)
    return [
        IndexedDocumentResponse(
            id=doc.id,
            filename=doc.filename,
            path=doc.path,
            content_preview=doc.content_preview,
        )
        for doc in docs
    ]


@router.post("/documents/search", response_model=List[IndexedDocumentResponse])
def search_documents(payload: DocumentSearchRequest, db: Session = Depends(get_db)):
    docs = file_engine.search_documents(db=db, query=payload.query, limit=payload.limit)
    return [
        IndexedDocumentResponse(
            id=doc.id,
            filename=doc.filename,
            path=doc.path,
            content_preview=doc.content_preview,
        )
        for doc in docs
    ]