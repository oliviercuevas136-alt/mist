from pathlib import Path

from fastapi import APIRouter
from sqlalchemy import text

from app.config import settings
from app.core.llm import OllamaClient
from app.db.database import SessionLocal
from app.utils.startup_checks import run_startup_checks

router = APIRouter(prefix="/api/health", tags=["health"])


@router.get("")
def health_check():
    db_status = "ok"
    db_error = None

    try:
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
    except Exception as exc:
        db_status = "error"
        db_error = str(exc)

    static_exists = Path(settings.static_path).exists()
    log_file_exists = Path(settings.app_log_path).exists()

    ollama = OllamaClient()
    ollama_status = ollama.health_check()

    global_status = "ok"
    if db_status != "ok":
        global_status = "degraded"
    if ollama_status.get("status") != "ok":
        global_status = "degraded"

    return {
        "app_name": settings.app_name,
        "status": global_status,
        "database": db_status,
        "database_error": db_error,
        "static_dir_exists": static_exists,
        "log_file_exists": log_file_exists,
        "startup_checks": run_startup_checks(),
        "debug": settings.debug,
        "ollama": ollama_status,
    }