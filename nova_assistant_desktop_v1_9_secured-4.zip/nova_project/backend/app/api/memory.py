from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.memory_engine import MemoryEngine
from app.db.database import get_db

router = APIRouter(prefix="/api/memory", tags=["memory"])
memory_engine = MemoryEngine()


class MemoryAddRequest(BaseModel):
    content: str = Field(..., min_length=1)
    category: str = "general"
    importance: int = 3
    source: str = "manual"


class MemoryItemResponse(BaseModel):
    id: int
    content: str
    category: str
    importance: int
    source: str


class MemorySearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    limit: int = 10


class MemoryDeleteResponse(BaseModel):
    deleted: bool


@router.post("/add", response_model=MemoryItemResponse)
def add_memory(payload: MemoryAddRequest, db: Session = Depends(get_db)):
    try:
        memory = memory_engine.add_memory(
            db=db,
            content=payload.content,
            category=payload.category,
            importance=payload.importance,
            source=payload.source,
        )
        return MemoryItemResponse(
            id=memory.id,
            content=memory.content,
            category=memory.category,
            importance=memory.importance,
            source=memory.source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/list", response_model=List[MemoryItemResponse])
def list_memories(limit: int = 50, db: Session = Depends(get_db)):
    memories = memory_engine.list_memories(db=db, limit=limit)
    return [
        MemoryItemResponse(
            id=m.id,
            content=m.content,
            category=m.category,
            importance=m.importance,
            source=m.source,
        )
        for m in memories
    ]


@router.post("/search", response_model=List[MemoryItemResponse])
def search_memories(payload: MemorySearchRequest, db: Session = Depends(get_db)):
    memories = memory_engine.search_memories(
        db=db,
        query=payload.query,
        limit=payload.limit,
    )
    return [
        MemoryItemResponse(
            id=m.id,
            content=m.content,
            category=m.category,
            importance=m.importance,
            source=m.source,
        )
        for m in memories
    ]


@router.delete("/{memory_id}", response_model=MemoryDeleteResponse)
def delete_memory(memory_id: int, db: Session = Depends(get_db)):
    deleted = memory_engine.delete_memory(db=db, memory_id=memory_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Mémoire introuvable.")
    return MemoryDeleteResponse(deleted=True)