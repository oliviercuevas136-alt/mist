"""
app/api/monitoring.py — Endpoints de surveillance V4.
Ajouts V4 : /api/monitoring/history (SQLite consultable), /respond, /incident
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from app.core.orchestrator import orchestrator
from app.core.monitoring_engine import monitoring_engine
from app.core.vision_engine import vision_engine
from app.core.comms_engine import comms_engine
from app.utils.logger import get_logger

logger = get_logger("api.monitoring")
router = APIRouter(tags=["monitoring"])


# ------------------------------------------------------------------
# Lifecycle
# ------------------------------------------------------------------

class StartMonitoringRequest(BaseModel):
    enable_vision: bool = False
    camera_index:  int  = 0


@router.post("/api/monitoring/start")
def start_monitoring(req: StartMonitoringRequest):
    return orchestrator.start(
        enable_vision=req.enable_vision,
        camera_index=req.camera_index,
    )


@router.post("/api/monitoring/stop")
def stop_monitoring():
    return orchestrator.stop()


@router.get("/api/monitoring/status")
def monitoring_status():
    return orchestrator.get_status()


@router.get("/api/monitoring/incident")
def get_incident():
    """Etat courant de la machine a etats d'incident."""
    return monitoring_engine.get_incident()


@router.post("/api/monitoring/respond")
def user_response():
    """
    L'utilisateur confirme qu'il va bien.
    Résout l'incident en cours si en phase CHECK.
    Utilisable depuis le bouton frontend "Je vais bien".
    """
    return orchestrator.signal_user_response()


@router.get("/api/monitoring/probe")
def get_vocal_probe():
    """Frontend poll — prochain message TTS à prononcer."""
    result = orchestrator.get_pending_vocal_probe()
    return result if result else {"probe": False}


# ------------------------------------------------------------------
# Vision
# ------------------------------------------------------------------

# ------------------------------------------------------------------
# Mode Safe
# ------------------------------------------------------------------

class SafeModeRequest(BaseModel):
    enabled: bool
    reason: Optional[str] = ""


@router.get("/api/monitoring/safe-mode")
def get_safe_mode():
    """Retourne l'état actuel du mode safe."""
    state = monitoring_engine.get_state()
    return {
        "safe_mode":            state["safe_mode"],
        "safe_mode_since":      state["safe_mode_since"],
        "confirm_window_s":     state["confirm_window_s"],
        "silence_threshold_m":  state["silence_threshold_m"],
        "absence_threshold_m":  state["absence_threshold_m"],
        "inactivity_threshold_h": state["inactivity_threshold_h"],
    }


@router.post("/api/monitoring/safe-mode")
def set_safe_mode(req: SafeModeRequest):
    """
    Active ou désactive le mode safe (vigilance renforcée).

    En mode safe :
      - Fenêtre de confirmation : 12s → 15s
      - Alerte silence : 2h → 1h
      - Alerte absence : 45min → 20min
      - Alerte inactivité : 8h → 4h
    """
    if req.enabled:
        monitoring_engine.enable_safe_mode(reason=req.reason or "")
    else:
        monitoring_engine.disable_safe_mode()
    return {"safe_mode": monitoring_engine.safe_mode, "reason": req.reason}


# ------------------------------------------------------------------
# Journal des événements (logs consultables)
# ------------------------------------------------------------------

@router.get("/api/monitoring/events")
def get_monitoring_events(
    limit: int = 100,
    offset: int = 0,
    source: Optional[str] = None,
):
    """
    Journal complet des événements système — lecture depuis SQLite.
    Sources : vision | voice | system | alert | response | emergency | error

    Permet aux aidants ou aux proches de consulter l'activité du système.
    """
    try:
        from app.db.database import SessionLocal
        from app.db.models import MonitoringEvent
        import json as _json

        with SessionLocal() as db:
            query = db.query(MonitoringEvent).order_by(
                MonitoringEvent.timestamp.desc()
            )
            if source:
                query = query.filter(MonitoringEvent.source == source)

            total = query.count()
            rows  = query.offset(offset).limit(limit).all()

            events = []
            for r in rows:
                extra = {}
                try:
                    extra = _json.loads(r.extra_json) if r.extra_json else {}
                except Exception:
                    extra = {}
                events.append({
                    "id":          r.id,
                    "source":      r.source,
                    "description": r.description,
                    "timestamp":   r.timestamp.isoformat() if r.timestamp else None,
                    "extra":       extra,
                })

        return {
            "total":  total,
            "limit":  limit,
            "offset": offset,
            "events": events,
        }

    except Exception as exc:
        logger.error("Events DB error | %s", exc)
        return {
            "total":  0,
            "limit":  limit,
            "offset": offset,
            "events": [],
            "error":  str(exc),
        }


# ------------------------------------------------------------------
# Vision
# ------------------------------------------------------------------

@router.get("/api/vision/status")
def vision_status():
    return vision_engine.get_state()


# ------------------------------------------------------------------
# Alerts — RAM (temps réel) + DB (historique)
# ------------------------------------------------------------------

@router.get("/api/alerts")
def get_alerts(limit: int = 50):
    """Alertes en RAM (dernières alertes de la session en cours)."""
    return {"alerts": monitoring_engine.get_alerts(limit=limit)}


@router.get("/api/monitoring/history")
def get_alert_history(
    limit: int = 100,
    offset: int = 0,
    alert_type: Optional[str] = None,
    alert_level: Optional[str] = None,
):
    """
    Historique persisté des alertes — lecture depuis SQLite.
    Consultable par la personne âgée ou ses proches.

    Filtres optionnels :
      alert_type  : fall | fall_escalated | fall_confirmed | prolonged_absence |
                    prolonged_silence | inactivity | manual | test
      alert_level : info | warning | urgent | critical
    """
    try:
        from app.db.database import SessionLocal
        from app.db.models import MonitoringAlert
        import json as _json

        with SessionLocal() as db:
            query = db.query(MonitoringAlert).order_by(
                MonitoringAlert.timestamp.desc()
            )
            if alert_type:
                query = query.filter(MonitoringAlert.alert_type == alert_type)
            if alert_level:
                query = query.filter(MonitoringAlert.alert_level == alert_level)

            total = query.count()
            rows  = query.offset(offset).limit(limit).all()

            alerts = []
            for r in rows:
                extra = {}
                try:
                    extra = _json.loads(r.extra_json) if r.extra_json else {}
                except Exception:
                    extra = {}
                alerts.append({
                    "id":           r.id,
                    "type":         r.alert_type,
                    "level":        r.alert_level,
                    "message":      r.message,
                    "timestamp":    r.timestamp.isoformat() if r.timestamp else None,
                    "acknowledged": r.acknowledged,
                    "extra":        extra,
                })

        return {
            "total":   total,
            "limit":   limit,
            "offset":  offset,
            "alerts":  alerts,
        }

    except Exception as exc:
        logger.error("History DB error | %s", exc)
        # Fallback gracieux — jamais de crash
        return {
            "total":  0,
            "limit":  limit,
            "offset": offset,
            "alerts": [],
            "error":  str(exc),
        }


@router.post("/api/alerts/test")
def test_alert():
    monitoring_engine.signal_test()
    result = comms_engine.test()
    return {"status": "ok", "result": result}


@router.post("/api/alerts/emergency")
def trigger_emergency():
    return orchestrator.trigger_emergency()


@router.post("/api/alerts/{alert_id}/acknowledge")
def acknowledge_alert(alert_id: int):
    ok = monitoring_engine.acknowledge_alert(alert_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Alerte {alert_id} introuvable")
    return {"acknowledged": True, "alert_id": alert_id}


# ------------------------------------------------------------------
# Comms
# ------------------------------------------------------------------

class CommsConfig(BaseModel):
    email_enabled:          bool          = False
    smtp_host:              Optional[str] = None
    smtp_port:              int           = 587
    smtp_user:              Optional[str] = None
    smtp_password:          Optional[str] = None
    recipient:              Optional[str] = None
    sender_name:            str           = "Assistant Personnel"
    webhook_enabled:        bool          = False
    webhook_url:            Optional[str] = None
    resident_name:          str           = "Resident"
    emergency_contact_name: str           = "Contact d'urgence"


@router.post("/api/monitoring/configure-comms")
def configure_comms(cfg: CommsConfig):
    config = {
        "email": {
            "enabled":       cfg.email_enabled,
            "smtp_host":     cfg.smtp_host,
            "smtp_port":     cfg.smtp_port,
            "smtp_user":     cfg.smtp_user,
            "smtp_password": cfg.smtp_password,
            "recipient":     cfg.recipient,
            "sender_name":   cfg.sender_name,
        },
        "webhook": {
            "enabled": cfg.webhook_enabled,
            "url":     cfg.webhook_url,
        },
        "resident_name":          cfg.resident_name,
        "emergency_contact_name": cfg.emergency_contact_name,
    }
    orchestrator.configure_comms(config)
    email_ok,   email_msg   = comms_engine.validate_email_config()
    webhook_ok, webhook_msg = comms_engine.validate_webhook_config()
    return {
        "status": "configured",
        "validation": {
            "email":   {"ok": email_ok,   "detail": email_msg},
            "webhook": {"ok": webhook_ok, "detail": webhook_msg},
        }
    }


@router.get("/api/monitoring/comms-status")
def comms_status():
    email_ok,   email_msg   = comms_engine.validate_email_config()
    webhook_ok, webhook_msg = comms_engine.validate_webhook_config()
    return {
        "email":   {"configured": email_ok,   "detail": email_msg},
        "webhook": {"configured": webhook_ok, "detail": webhook_msg},
        "log":     {"configured": True,        "detail": "Toujours actif"},
    }


@router.get("/api/monitoring/comms-history")
def get_comms_history(limit: int = 20):
    return {"history": comms_engine.get_history(limit=limit)}


# ── Métriques de performance IA ───────────────────────────────────────────

from app.utils.perf_logger import perf as _perf


@router.get("/api/perf/stats")
def perf_stats_last():
    """
    Métriques de la dernière inférence IA.
    Retourne 204 si aucune inférence n'a encore eu lieu.
    """
    last = _perf.get_last()
    if last is None:
        from fastapi.responses import Response
        return Response(status_code=204)
    return last


@router.get("/api/perf/history")
def perf_stats_history(n: int = 20):
    """
    Historique des n dernières inférences (max 100).
    Plus récente en dernier.
    """
    n = max(1, min(n, 100))
    return {"history": _perf.get_history(n)}


@router.get("/api/perf/summary")
def perf_stats_summary():
    """
    Statistiques agrégées (avg / min / max) sur toutes les inférences
    de la session courante.
    """
    return _perf.get_summary()
