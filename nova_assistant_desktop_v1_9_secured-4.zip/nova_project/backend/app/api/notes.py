from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.note_engine import NoteEngine
from app.db.database import get_db

router = APIRouter(prefix="/api/notes", tags=["notes"])
note_engine = NoteEngine()


class NoteCreateRequest(BaseModel):
    title: str = Field(..., min_length=1)
    content: str = Field(..., min_length=1)
    tags: str = ""


class NoteUpdateRequest(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    tags: Optional[str] = None


class NoteItemResponse(BaseModel):
    id: int
    title: str
    content: str
    tags: str


class NoteSearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    limit: int = 20


class NoteDeleteResponse(BaseModel):
    deleted: bool


@router.post("/create", response_model=NoteItemResponse)
def create_note(payload: NoteCreateRequest, db: Session = Depends(get_db)):
    try:
        note = note_engine.create_note(
            db=db,
            title=payload.title,
            content=payload.content,
            tags=payload.tags,
        )
        return NoteItemResponse(
            id=note.id,
            title=note.title,
            content=note.content,
            tags=note.tags,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/list", response_model=List[NoteItemResponse])
def list_notes(limit: int = 100, db: Session = Depends(get_db)):
    notes = note_engine.list_notes(db=db, limit=limit)
    return [
        NoteItemResponse(
            id=n.id,
            title=n.title,
            content=n.content,
            tags=n.tags,
        )
        for n in notes
    ]


@router.post("/search", response_model=List[NoteItemResponse])
def search_notes(payload: NoteSearchRequest, db: Session = Depends(get_db)):
    notes = note_engine.search_notes(
        db=db,
        query=payload.query,
        limit=payload.limit,
    )
    return [
        NoteItemResponse(
            id=n.id,
            title=n.title,
            content=n.content,
            tags=n.tags,
        )
        for n in notes
    ]


@router.put("/{note_id}", response_model=NoteItemResponse)
def update_note(note_id: int, payload: NoteUpdateRequest, db: Session = Depends(get_db)):
    try:
        note = note_engine.update_note(
            db=db,
            note_id=note_id,
            title=payload.title,
            content=payload.content,
            tags=payload.tags,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not note:
        raise HTTPException(status_code=404, detail="Note introuvable.")

    return NoteItemResponse(
        id=note.id,
        title=note.title,
        content=note.content,
        tags=note.tags,
    )


@router.delete("/{note_id}", response_model=NoteDeleteResponse)
def delete_note(note_id: int, db: Session = Depends(get_db)):
    deleted = note_engine.delete_note(db=db, note_id=note_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Note introuvable.")
    return NoteDeleteResponse(deleted=True)