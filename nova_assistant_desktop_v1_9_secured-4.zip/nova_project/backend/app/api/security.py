"""
api/security.py — Endpoints du système de sécurité et prévention.

Routes :
    GET  /api/security/system/latest      → dernier snapshot SystemMonitor
    GET  /api/security/system/history     → historique snapshots
    GET  /api/security/system/thresholds  → seuils configurés
    POST /api/security/system/thresholds  → ajuster seuils
    GET  /api/security/risk               → 3 scores danger/anomaly/confidence
    GET  /api/security/permissions        → permissions effectives
    POST /api/security/action/propose     → proposer une action
    POST /api/security/action/confirm     → confirmer (avec token)
    POST /api/security/action/execute     → exécuter (avec token)
    GET  /api/security/action/audit       → audit log
    GET  /api/security/action/pending     → actions en attente
"""

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app.services.action_manager import get_action_manager
from app.services.risk_engine import get_risk_engine
from app.services.system_monitor import get_system_monitor
from app.utils.logger import get_logger

logger = get_logger("api.security")

router = APIRouter(prefix="/api/security", tags=["security"])


# ── SystemMonitor ──────────────────────────────────────────────────────────

@router.get("/system/latest")
def system_latest():
    sm = get_system_monitor()
    snap = sm.get_latest()
    return {
        "running": sm.is_running(),
        "snapshot": snap,
    }


@router.get("/system/history")
def system_history(limit: int = Query(60, ge=1, le=720)):
    sm = get_system_monitor()
    return {"history": sm.get_history(limit=limit)}


@router.get("/system/thresholds")
def system_thresholds_get():
    return get_system_monitor().get_thresholds()


class ThresholdUpdate(BaseModel):
    cpu_high:      Optional[float] = Field(None, ge=0, le=100)
    cpu_critical:  Optional[float] = Field(None, ge=0, le=100)
    ram_high:      Optional[float] = Field(None, ge=0, le=100)
    ram_critical:  Optional[float] = Field(None, ge=0, le=100)
    disk_high:     Optional[float] = Field(None, ge=0, le=100)
    disk_critical: Optional[float] = Field(None, ge=0, le=100)
    swap_high:     Optional[float] = Field(None, ge=0, le=100)


@router.post("/system/thresholds")
def system_thresholds_set(payload: ThresholdUpdate):
    sm = get_system_monitor()
    update = {k: v for k, v in payload.model_dump().items() if v is not None}
    return sm.set_thresholds(**update)


# ── RiskEngine ─────────────────────────────────────────────────────────────

@router.get("/risk")
def risk_scores():
    return get_risk_engine().compute().to_dict()


# ── ActionManager ──────────────────────────────────────────────────────────

@router.get("/permissions")
def list_permissions():
    return get_action_manager().list_permissions()


class ProposeRequest(BaseModel):
    action: str = Field(..., min_length=1, max_length=50)
    params: Dict[str, Any] = Field(default_factory=dict)


@router.post("/action/propose")
def action_propose(payload: ProposeRequest):
    result = get_action_manager().propose_action(payload.action, payload.params)
    if not result.get("ok"):
        raise HTTPException(status_code=403, detail=result.get("denied_reason", "refusé"))
    return result


class ConfirmRequest(BaseModel):
    confirmation_token: str = Field(..., min_length=10, max_length=64)


@router.post("/action/confirm")
def action_confirm(payload: ConfirmRequest):
    result = get_action_manager().confirm_action(payload.confirmation_token)
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("denied_reason", "invalide"))
    return result


class ExecuteRequest(BaseModel):
    execution_token: str = Field(..., min_length=10, max_length=64)


@router.post("/action/execute")
def action_execute(payload: ExecuteRequest):
    result = get_action_manager().execute_action(payload.execution_token)
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("denied_reason", "échec"))
    return result


@router.get("/action/audit")
def action_audit(limit: int = Query(50, ge=1, le=500)):
    return {"audit": get_action_manager().get_audit_log(limit=limit)}


@router.get("/action/pending")
def action_pending():
    return {"pending": get_action_manager().get_pending()}


# ── Surveillances sécurité ────────────────────────────────────────────────

@router.get("/watch/processes")
def watch_processes():
    """Snapshot des processus + diff par rapport au dernier scan."""
    from app.services.security_watch import get_process_watcher
    return get_process_watcher().scan()


@router.get("/watch/network")
def watch_network():
    """Connexions réseau actives + listeners (nécessite parfois admin)."""
    from app.services.security_watch import get_network_watcher
    return get_network_watcher().scan()


@router.get("/watch/startup")
def watch_startup():
    """Entrées de démarrage Windows. Sur autres OS : available=false."""
    from app.services.security_watch import get_startup_watcher
    return get_startup_watcher().scan()


@router.get("/watch/files")
def watch_files(max_age_sec: float = Query(86400.0, ge=60, le=2592000)):
    """Fichiers exécutables récents dans ALLOWED_SEARCH_DIRS."""
    from app.services.security_watch import get_suspicious_file_watcher
    return get_suspicious_file_watcher().scan(max_age_sec=max_age_sec)


@router.get("/watch/devices")
def watch_devices():
    """Processus accédant webcam/micro (best-effort)."""
    from app.services.security_watch import get_device_watcher
    return get_device_watcher().scan()


@router.get("/watch/all")
def watch_all():
    """Cycle complet de toutes les surveillances."""
    from app.services.security_watch import scan_all
    return scan_all()


# ── Modification contrôlée v1.9.7 ─────────────────────────────────────────

@router.get("/file-edit/write-dirs")
def file_edit_write_dirs():
    """Liste les dossiers où Nova peut modifier des fichiers."""
    from app.services.file_editor import get_allowed_write_dirs
    dirs = [str(d) for d in get_allowed_write_dirs()]
    return {
        "dirs": dirs,
        "count": len(dirs),
        "info": (
            "Vide = aucune modification possible. "
            "Configurer via ALLOWED_WRITE_DIRS dans .env."
        ),
    }


@router.get("/file-edit/backups")
def file_edit_backups(limit: int = Query(50, ge=1, le=200)):
    """Liste les backups automatiques. Les plus récents en premier."""
    from app.services.file_editor import list_backups, get_backup_dir
    return {
        "backup_dir": str(get_backup_dir()),
        "backups": list_backups(limit=limit),
    }
