"""
api/semantic_index.py — Endpoints v1.9.8 pour l'index local.

Routes :
    POST /api/index/file              → indexer un fichier
    POST /api/index/directory         → indexer un dossier
    POST /api/index/cleanup           → supprimer les docs disparus
    GET  /api/index/stats             → stats globales
    GET  /api/index/recent            → docs récemment consultés
    GET  /api/index/search            → recherche hybride
    GET  /api/index/categories        → catégories + comptes
    GET  /api/index/document/{id}     → infos détaillées
    POST /api/index/document/{id}/summarize        → résumé fichier
    POST /api/index/folder/summarize  → résumé dossier
    POST /api/index/conversation/{id}/summarize    → résumé conversation
    GET  /api/index/embedding-status  → état du backend embeddings
"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.services.semantic_index import get_semantic_index, get_allowed_index_dirs
from app.services.summarizer import get_summarizer
from app.services.embedding_client import get_embedding_client
from app.utils.logger import get_logger

logger = get_logger("api.semantic_index")

router = APIRouter(prefix="/api/index", tags=["index"])


# ── Payloads ───────────────────────────────────────────────────────────────

class IndexFilePayload(BaseModel):
    path: str = Field(..., min_length=1, max_length=600)
    force: bool = False


class IndexDirPayload(BaseModel):
    path: str = Field(..., min_length=1, max_length=600)
    force: bool = False
    max_files: int = Field(500, ge=1, le=5000)


class FolderSummarizePayload(BaseModel):
    path: str = Field(..., min_length=1, max_length=600)
    max_files: int = Field(20, ge=1, le=100)


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.get("/stats")
def index_stats(db: Session = Depends(get_db)):
    """Stats globales : nb docs, chunks, catégories, état embeddings."""
    return get_semantic_index().stats(db)


@router.get("/allowed-dirs")
def index_allowed_dirs():
    """Dossiers configurés pour l'indexation."""
    dirs = [str(d) for d in get_allowed_index_dirs()]
    return {
        "dirs": dirs,
        "count": len(dirs),
        "info": "Vide = aucune indexation possible. ALLOWED_INDEX_DIRS dans .env.",
    }


@router.get("/embedding-status")
def embedding_status():
    """État du backend d'embeddings."""
    from dataclasses import asdict
    return asdict(get_embedding_client().get_status(force_recheck=True))


@router.post("/file")
def index_file(payload: IndexFilePayload, db: Session = Depends(get_db)):
    return get_semantic_index().index_file(db, payload.path, force=payload.force)


@router.post("/directory")
def index_directory(payload: IndexDirPayload, db: Session = Depends(get_db)):
    return get_semantic_index().index_directory(
        db, payload.path, force=payload.force, max_files=payload.max_files,
    )


@router.post("/cleanup")
def index_cleanup(db: Session = Depends(get_db)):
    """Supprime de l'index les fichiers qui n'existent plus sur disque."""
    return get_semantic_index().remove_missing(db)


@router.get("/recent")
def index_recent(limit: int = Query(20, ge=1, le=100),
                  db: Session = Depends(get_db)):
    return {"recent": get_semantic_index().recent(db, limit=limit)}


@router.get("/categories")
def index_categories(db: Session = Depends(get_db)):
    stats = get_semantic_index().stats(db)
    return {
        "categories": stats.get("by_category", {}),
        "total_documents": stats.get("documents", 0),
    }


@router.get("/search")
def index_search(
    q: str = Query(..., min_length=1, max_length=500),
    k: int = Query(5, ge=1, le=50),
    semantic_weight: float = Query(0.6, ge=0.0, le=1.0),
    category: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """
    Recherche hybride : sémantique (si embeddings dispo) + lexical (BM25).
    Filtrable par catégorie.
    """
    return get_semantic_index().search(
        db, q, k=k,
        semantic_weight=semantic_weight,
        category=category,
    )


@router.get("/document/{doc_id}")
def index_document(doc_id: int, db: Session = Depends(get_db)):
    from app.db.models import IndexedDocument, IndexedChunk
    doc = db.query(IndexedDocument).get(doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="document inconnu")
    # Enregistrer l'accès
    from app.services.semantic_index import _record_access
    _record_access(db, doc_id)
    chunks_count = db.query(IndexedChunk).filter_by(document_id=doc_id).count()
    return {
        "id":           doc.id,
        "source_type":  doc.source_type,
        "source_path":  doc.source_path,
        "title":        doc.title,
        "extension":    doc.extension,
        "category":     doc.category,
        "size_bytes":   doc.size_bytes,
        "content_hash": doc.content_hash,
        "chunk_count":  chunks_count,
        "summary":      doc.summary or None,
        "summary_at":   doc.summary_at.timestamp() if doc.summary_at else None,
        "indexed_at":   doc.indexed_at.timestamp() if doc.indexed_at else None,
        "accessed_at":  doc.accessed_at.timestamp() if doc.accessed_at else None,
        "access_count": doc.access_count,
    }


@router.post("/document/{doc_id}/summarize")
def index_document_summarize(doc_id: int, force: bool = False,
                              db: Session = Depends(get_db)):
    res = get_summarizer().summarize_document(db, doc_id, force=force)
    if not res.ok:
        raise HTTPException(status_code=503, detail=res.reason)
    return {
        "ok":         True,
        "summary":    res.summary,
        "cached":     res.cached,
        "elapsed_ms": res.elapsed_ms,
        "model":      res.model,
    }


@router.post("/folder/summarize")
def index_folder_summarize(payload: FolderSummarizePayload,
                            db: Session = Depends(get_db)):
    res = get_summarizer().summarize_folder(
        db, payload.path, max_files=payload.max_files,
    )
    if not res.ok:
        raise HTTPException(status_code=503, detail=res.reason)
    return {
        "ok":         True,
        "summary":    res.summary,
        "elapsed_ms": res.elapsed_ms,
        "model":      res.model,
    }


@router.post("/conversation/{conv_id}/summarize")
def index_conversation_summarize(conv_id: int, db: Session = Depends(get_db)):
    res = get_summarizer().summarize_conversation(db, conv_id)
    if not res.ok:
        raise HTTPException(status_code=503, detail=res.reason)
    return {
        "ok":         True,
        "summary":    res.summary,
        "cached":     res.cached,
        "elapsed_ms": res.elapsed_ms,
        "model":      res.model,
    }


# ── Suggestions contextuelles ──────────────────────────────────────────────

@router.get("/suggestions")
def index_suggestions(db: Session = Depends(get_db)):
    """
    Suggestions de "documents susceptibles d'intéresser maintenant" :
    récents + fréquents + par catégorie.
    """
    si = get_semantic_index()
    recent = si.recent(db, limit=5)
    from app.db.models import IndexedDocument
    frequent = (db.query(IndexedDocument)
                  .order_by(IndexedDocument.access_count.desc())
                  .limit(5).all())
    return {
        "recent":   recent,
        "frequent": [{
            "id": d.id, "title": d.title, "path": d.source_path,
            "category": d.category, "access_count": d.access_count,
        } for d in frequent],
    }


@router.get("/related/{doc_id}")
def index_related(doc_id: int, k: int = Query(5, ge=1, le=20),
                   db: Session = Depends(get_db)):
    """
    Documents les plus similaires à `doc_id`.
    Utilise les embeddings du premier chunk comme requête.
    """
    from app.db.models import IndexedDocument, IndexedChunk
    from app.services.embedding_client import bytes_to_vec, cosine_similarity

    doc = db.query(IndexedDocument).get(doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="document inconnu")
    first_chunk = (db.query(IndexedChunk)
                     .filter_by(document_id=doc_id)
                     .order_by(IndexedChunk.chunk_index).first())
    if not first_chunk or not first_chunk.embedding_dim:
        return {"ok": False, "reason": "pas d'embedding pour ce document",
                "related": []}
    qv = bytes_to_vec(first_chunk.embedding, first_chunk.embedding_dim)
    if qv is None:
        return {"ok": False, "reason": "embedding corrompu", "related": []}

    # Scorer tous les autres docs
    scored = []
    seen_docs = set()
    for chunk in db.query(IndexedChunk).filter(
        IndexedChunk.document_id != doc_id,
        IndexedChunk.embedding_dim == first_chunk.embedding_dim,
    ).all():
        if chunk.document_id in seen_docs:
            continue
        v = bytes_to_vec(chunk.embedding, chunk.embedding_dim)
        if v is None:
            continue
        sim = cosine_similarity(qv, v)
        scored.append((chunk.document_id, sim))
        seen_docs.add(chunk.document_id)

    scored.sort(key=lambda x: x[1], reverse=True)
    out = []
    for did, sim in scored[:k]:
        d = db.query(IndexedDocument).get(did)
        if not d:
            continue
        out.append({
            "id": d.id, "title": d.title, "source_path": d.source_path,
            "category": d.category, "similarity": round(float(sim), 4),
        })
    return {"ok": True, "related": out}
