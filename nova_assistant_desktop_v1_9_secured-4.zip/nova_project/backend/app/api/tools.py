"""
api/tools.py — Endpoints de gestion des outils agentiques.

GET  /api/tools/status    → état de chaque outil (disponible ou non)
POST /api/tools/test      → test manuel d'un outil spécifique
GET  /api/tools/weather   → météo directe (sans passer par le chat)
GET  /api/tools/system    → état système direct
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from app.utils.logger import get_logger

logger = get_logger("api.tools")
router = APIRouter(prefix="/api/tools", tags=["tools"])


@router.get("/status")
def tools_status():
    """Vérifie quels outils sont disponibles."""
    status = {}

    # Météo (Open-Meteo — toujours dispo si Internet)
    try:
        import urllib.request
        urllib.request.urlopen("https://api.open-meteo.com/", timeout=3)
        status["weather"] = {"available": True, "provider": "Open-Meteo (gratuit, sans clé)"}
    except Exception:
        status["weather"] = {"available": False, "reason": "Pas d'accès Internet"}

    # Système
    try:
        import psutil  # noqa
        status["system"] = {"available": True, "provider": "psutil"}
    except ImportError:
        status["system"] = {"available": False, "reason": "pip install psutil"}

    # Web search
    status["web_search"] = {
        "available": True,
        "provider": "DuckDuckGo Instant Answer (sans clé)",
        "note": "Résultats limités — idéal pour faits simples"
    }

    # Datetime
    status["datetime"] = {"available": True, "provider": "local"}

    # Futurs modules (placeholders)
    status["_future"] = {
        "email":       "SMTP — configurer SMTP_HOST, SMTP_USER, SMTP_PASS",
        "phone":       "Twilio — configurer TWILIO_SID, TWILIO_TOKEN",
        "vision":      "OpenCV — vision_engine.py disponible, caméra requise",
        "calendar":    "Non implémenté",
        "spotify":     "Non implémenté",
    }

    return {"tools": status}


@router.get("/weather")
def weather_direct(city: str = "Paris"):
    """Météo directe sans passer par le chat."""
    from app.core.tools.weather_tool import get_weather
    return get_weather(city=city)


@router.get("/system")
def system_direct():
    """État système direct."""
    from app.core.tools.system_tool import get_system_status
    return get_system_status()


@router.get("/system/processes")
def processes_direct():
    """Top processus."""
    from app.core.tools.system_tool import get_top_processes
    return get_top_processes(n=10)


class SearchRequest(BaseModel):
    query: str
    city: Optional[str] = None


@router.post("/test")
def test_tool(payload: SearchRequest):
    """
    Test manuel d'un outil via le router.
    Envoyer {"query": "météo à Lyon"} pour tester la météo.
    """
    from app.core import tool_router
    intent = tool_router.route(payload.query)
    if intent is None:
        return {
            "matched":  False,
            "message":  "Aucun outil ne correspond à cette requête.",
            "query":    payload.query,
        }
    result = tool_router.execute(intent)
    return {
        "matched":  True,
        "intent":   intent,
        "result":   result,
    }
