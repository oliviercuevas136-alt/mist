"""
api/voice.py — Pipeline vocal V5

Pipeline SSE avec ACK immédiat + streaming LLM + TTS parallèle :

  POST /api/voice/transcribe  → STT
  POST /api/voice/stream      → ACK + LLM stream + TTS (pipeline principal)
  POST /api/voice/speak       → TTS seul (compatibilité)
  POST /api/voice/stop        → Arrêt TTS immédiat
  POST /api/voice/chat        → LLM non-stream (compatibilité)

Métriques émises :
  time_to_first_feedback_ms   < 300ms  cible
  time_to_first_spoken_audio_ms < 2500ms cible
  full_turn_total_ms          < 5000ms cible
"""
import asyncio
import json
import queue as _queue_mod
import re
import threading
import time
from datetime import datetime, timezone
from typing import AsyncGenerator, Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.config import settings
from app.core.llm import OllamaClient
from app.core.voice_memory import voice_memory
from app.core import voice_commands
from app.core.tts_engine import TTSEngine
from app.core.voice_engine import VoiceEngine
from app.db.database import get_db
from app.utils.logger import get_logger


logger = get_logger("api.voice")

router = APIRouter(prefix="/api/voice", tags=["voice"])

# Singletons — initialisés une seule fois au démarrage
voice_engine = VoiceEngine()
tts_engine   = TTSEngine()
_llm         = OllamaClient()

_TTS_TIMEOUT_SEC = 8
_TTS_MAX_CHARS   = 500
_LLM_TIMEOUT_SEC = 8.0  # 3b sur CPU peut prendre 3-5s — fallback à 8s

# ── Prompt compagnon ──────────────────────────────────────────────────────────
_VOICE_SYSTEM = (
    "Tu es une IA compagnon francophone pour personne âgée. "
    "Réponds naturellement, clairement et simplement. "
    "Sois bref mais utile. "
    "Ne réponds jamais en anglais. "
    "Ne fais pas de liste sauf si demandé."
)

# ── ACK contextuels (réponse immédiate pendant LLM) ──────────────────────────
_ACK_MAP = [
    (["aide", "aidez", "besoin", "urgence"], "Je suis là."),
    (["bien", "mal", "sens", "santé", "douleur"], "Je vous écoute."),
    (["rappelle", "rappeler", "souviens", "oublie"], "D'accord."),
    (["bonjour", "salut", "coucou", "bonsoir"], "Bonjour !"),
    (["merci"], "Avec plaisir."),
    (["au revoir", "bonne nuit", "à bientôt"], "À bientôt !"),
    (["quoi", "comment", "pourquoi", "qu'est"], "Voyons ça."),
]

# ── Pré-réponses instantanées (bypass LLM complet) ───────────────────────────
_INSTANT_REPLIES = [
    (["tu m'entends", "tu mentends", "entends-tu", "m'entends-tu"],
     "Oui, je vous entends parfaitement."),
    (["ça va", "ca va", "comment tu vas", "comment vas-tu", "comment ça va"],
     "Ça va bien, merci. Et vous ?"),
    (["bonjour", "salut", "coucou", "bonsoir"],
     "Bonjour ! Je suis là pour vous."),
    (["au revoir", "bonne nuit", "bonne journée", "à bientôt"],
     "Au revoir, prenez soin de vous."),
    (["merci beaucoup", "merci bien"],
     "Avec plaisir, c'est pour ça que je suis là."),
]

# ── Fallbacks locaux si LLM timeout ──────────────────────────────────────────
_FALLBACKS = [
    "Je réfléchis encore, restez avec moi.",
    "Je suis là, donnez-moi un instant.",
    "Je vous écoute, pouvez-vous répéter ?",
]
_fallback_idx      = 0
_fallback_idx_lock = threading.Lock()  # thread-safe : plusieurs requêtes simultanées

# ── Segmentation pour TTS progressif ─────────────────────────────────────────
# v4.6 : … (ellipse) ajouté ; max_chars=140 par défaut (segments plus naturels)
_SEGMENT_RE       = re.compile(r'[.!?…](?:\s|$)')
_SEGMENT_MAX_CHARS = 140  # v4.6 : plus grand que 80 → moins de micro-segments

# ── Interruption inter-requêtes ───────────────────────────────────────────────
_request_counter      = 0
_request_counter_lock = threading.Lock()


def _vlog(event: str, **kwargs) -> None:
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]
    extras = "  ".join(f"{k}={v}" for k, v in kwargs.items())
    logger.info("[%s] ts=%s  %s", event, ts, extras)


def _pick_ack(text: str) -> str:
    lower = text.lower()
    for triggers, ack in _ACK_MAP:
        if any(t in lower for t in triggers):
            return ack
    return "Je comprends."


def _get_instant(text: str) -> Optional[str]:
    lower = text.lower()
    for triggers, reply in _INSTANT_REPLIES:
        if any(t in lower for t in triggers):
            return reply
    return None


def _find_segment(buf: str, min_chars: int = 4, max_chars: int = 80) -> tuple[str, str]:
    """
    Extrait la première phrase complète. Retourne (segment, reste).

    v4.6 :
    - `max_chars` configurable (default=80 pour compat, pipeline=140)
    - Fallback virgule : coupe à la dernière virgule avant max_chars (pause naturelle)
    - Fallback espace  : coupe au dernier espace (jamais en milieu de mot)
    - `…` reconnu comme fin de phrase via _SEGMENT_RE
    """
    if len(buf) < min_chars:
        return "", buf
    m = _SEGMENT_RE.search(buf)
    if m:
        return buf[:m.end()].strip(), buf[m.end():].strip()
    if len(buf) > max_chars:
        # 1. Pause naturelle : virgule dans la 2ème moitié de la fenêtre
        comma_pos = buf[:max_chars].rfind(",")
        if comma_pos > max_chars // 3:
            return buf[:comma_pos].strip(), buf[comma_pos + 1:].strip()
        # 2. Dernier espace (jamais couper un mot)
        last_space = buf[:max_chars].rfind(" ")
        if last_space > max_chars // 3:
            return buf[:last_space].strip(), buf[last_space + 1:]
    return "", buf


# ── Modèles Pydantic ──────────────────────────────────────────────────────────

class TTSRequest(BaseModel):
    text: str


class VoiceChatRequest(BaseModel):
    message: str
    conversation_id: Optional[int] = None
    fast_mode: bool = True


# ── /transcribe ───────────────────────────────────────────────────────────────

@router.post("/transcribe")
async def transcribe_audio(
    file: UploadFile = File(...),
    turn_id: Optional[str] = None,
):
    """
    STT avec logs granulaires. Aliases ajoutés pour debug mode vocal.

    v1.9.9 : si `turn_id` est fourni (query param), enregistre stt_ms dans
    voice_metrics pour ce tour. Sans turn_id, ouvre un tour automatiquement.
    """
    _vlog("VOICE_REQUEST_RECEIVED",
          endpoint="/api/voice/transcribe",
          filename=file.filename or "input.webm",
          content_type=file.content_type or "?",
          turn_id=turn_id or "auto")

    # v1.9.9 — démarrer/récupérer un tour mesuré
    auto_turn = False
    if not turn_id:
        try:
            from app.services.voice_metrics import get_voice_metrics
            turn_id = get_voice_metrics().start_turn()
            auto_turn = True
        except Exception:
            turn_id = None

    if not settings.enable_stt:
        _vlog("VOICE_REJECTED", reason="stt_disabled")
        raise HTTPException(status_code=400, detail="STT désactivé.")

    _vlog("VOICE_UPLOAD_START", file=file.filename or "input.webm")
    t_upload = time.perf_counter()

    try:
        data = await file.read()
        upload_ms = int((time.perf_counter() - t_upload) * 1000)
        _vlog("VOICE_UPLOAD_END", upload_ms=upload_ms, bytes=len(data))
        _vlog("AUDIO_FILE_SIZE", bytes=len(data), upload_ms=upload_ms)

        if not data or len(data) < 500:
            _vlog("VOICE_AUDIO_TOO_SHORT", bytes=len(data))
            return {"text": "", "is_empty": True, "confidence": 0,
                    "file_size": len(data), "upload_time_ms": upload_ms, "stt_time_ms": 0}

        _vlog("STT_START", bytes=len(data))            # alias demandé
        _vlog("VOICE_STT_START", bytes=len(data))
        result = await run_in_threadpool(
            voice_engine.transcribe_bytes, data, file.filename or "input.webm"
        )

        text = result["text"].strip()
        is_empty = result["is_empty"] or not text
        stt_too_slow = result["stt_time_ms"] > settings.stt_slow_threshold_ms

        _vlog("STT_RESULT",                              # alias demandé
              is_empty=is_empty,
              chars=len(text),
              stt_ms=result["stt_time_ms"],
              preview=repr(text[:60]) if text else "empty")
        _vlog("VOICE_STT_END",
              stt_ms=result["stt_time_ms"],
              convert_ms=result.get("convert_ms", 0),
              transcribe_ms=result.get("transcribe_ms", 0),
              is_empty=is_empty,
              preview=repr(text[:40]) if text else "empty")

        # ── v1.9.5 : améliorateurs de pipeline ──────────────────────────────
        # 1) Post-correction (filtre hallucinations + fixes FR + capitalisation)
        wake_matched: Optional[bool] = None
        wake_command: Optional[str] = None
        correction_info: Dict[str, Any] = {}
        try:
            from app.services.voice_enhancers import (
                get_post_corrector, get_wake_detector, get_vad_calibrator,
            )
            corrector = get_post_corrector()
            corrected, correction_info = corrector.correct(text)
            if correction_info.get("reason") == "hallucination_filtered":
                _vlog("VOICE_HALLUC_FILTERED", original=text[:50])
                text = ""
                is_empty = True
            elif corrected != text:
                _vlog("VOICE_POST_CORRECTED", original=text[:50], fixed=corrected[:50])
                text = corrected

            # 2) Calibration VAD (record résultat)
            get_vad_calibrator().record_result(
                text=text,
                duration_s=float(result.get("audio_duration_s", 0) or 0),
                transcribe_ms=int(result.get("transcribe_ms", 0)),
            )

            # 3) Wake word texte (si activé)
            if not is_empty:
                detector = get_wake_detector()
                wake_matched, wake_command = detector.matches(text)
                if detector.is_enabled() and not wake_matched:
                    _vlog("VOICE_WAKE_MISS", text=text[:50])
        except Exception as exc:
            _vlog("VOICE_ENHANCERS_ERROR", error=str(exc))

        # 4) Publier sur le CORE (point d'entrée unique)
        try:
            from app.core.event_bus import CoreEvent, EventLevel
            from app.core.orchestrator import orchestrator
            orchestrator.submit_event(CoreEvent(
                type="voice.transcribed",
                source="voice_api",
                level=EventLevel.LOW,
                message=f"Transcription : {text[:60]}" if text else "Audio vide",
                payload={
                    "text":           text,
                    "is_empty":       is_empty,
                    "stt_ms":         result["stt_time_ms"],
                    "wake_matched":   wake_matched,
                    "correction":     correction_info,
                },
            ))
        except Exception as _exc:
            pass

        # v1.9.9 — enregistrer stt_ms dans voice_metrics
        if turn_id:
            try:
                from app.services.voice_metrics import get_voice_metrics
                m = get_voice_metrics()
                m.mark(turn_id, "stt_ms", int(result["stt_time_ms"]),
                        meta={"is_empty": is_empty, "chars": len(text)})
                # Si auto_turn, c'est nous qui sommes responsables de fermer le tour
                # quand on n'a pas LLM/TTS derrière (cas du transcribe one-shot)
            except Exception:
                pass

        base = {
            "file_size":      result["file_size"],
            "upload_time_ms": upload_ms,
            "stt_time_ms":    result["stt_time_ms"],
            "convert_ms":     result.get("convert_ms", 0),
            "transcribe_ms":  result.get("transcribe_ms", 0),
            "stt_too_slow":   stt_too_slow,
            "wake_matched":   wake_matched,        # None si désactivé
            "wake_command":   wake_command,         # texte après le wake-word
            "correction":     correction_info,
            "turn_id":        turn_id,              # v1.9.9 — corrélation latence
        }
        if is_empty:
            # Auto-clôturer le tour vide
            if turn_id and auto_turn:
                try:
                    from app.services.voice_metrics import get_voice_metrics
                    get_voice_metrics().complete(turn_id, meta={"empty_stt": True})
                except Exception:
                    pass
            return {"text": "", "is_empty": True, "confidence": 0, **base}
        return {"text": text, "is_empty": False, **base}

    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Erreur STT: {str(exc)}") from exc


# ── /stream (pipeline vocal principal) ───────────────────────────────────────

@router.post("/stream")
async def voice_stream(payload: VoiceChatRequest):
    """
    Pipeline SSE temps réel :
    1. Pré-réponse instantanée (si connue) → event:instant
    OU
    1. ACK immédiat + TTS ACK en parallèle → event:ack
    2. LLM streaming → event:token
    3. TTS segments au fil des phrases → transparent
    4. Métriques finales → event:metrics
    """
    global _fallback_idx

    message = (payload.message or "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message vide.")

    async def generate() -> AsyncGenerator[str, None]:
        global _fallback_idx, _request_counter

        def sse(event: str, data: dict) -> str:
            return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"

        t0 = time.perf_counter()

        # ── Interruption de la requête précédente (anti-overlap) ─────────────
        with _request_counter_lock:
            _request_counter += 1
            req_num = _request_counter
        if req_num > 1:
            # Couper le TTS en cours si l'utilisateur a reparlé
            _vlog("VOICE_INTERRUPTED", reason="new_request", req_num=req_num)
            tts_engine.stop()
            tts_engine._stop_event.clear()  # on repart proprement

        # ── 0. Commandes locales prioritaires (< 10ms, pas de LLM) ─────────────
        local_key = voice_commands.match_local(message)
        if local_key is not None:
            local_result = voice_commands.execute_local(local_key, message)
            local_reply  = local_result["reply"]
            local_action = local_result["action"]
            t_fb = int((time.perf_counter() - t0) * 1000)
            _vlog("VOICE_LOCAL_CMD", key=local_action, feedback_ms=t_fb)
            yield sse("instant", {"reply": local_reply, "time_to_feedback_ms": t_fb,
                                  "source": "local_command"})
            if local_action != "stop":  # stop → pas de TTS
                try:
                    await asyncio.wait_for(
                        run_in_threadpool(tts_engine.speak_voice_mode, local_reply),
                        timeout=_TTS_TIMEOUT_SEC,
                    )
                except asyncio.TimeoutError:
                    pass
            total_ms = int((time.perf_counter() - t0) * 1000)
            yield sse("metrics", {
                "time_to_first_feedback_ms":     t_fb,
                "time_to_first_token_ms":        0,
                "time_to_first_spoken_audio_ms": t_fb,
                "full_turn_total_ms":            total_ms,
                "llm_ms": 0, "tts_ms": total_ms - t_fb,
                "mode": "local_command",
            })
            _vlog("VOICE_TOTAL_END", mode="local_cmd", action=local_action, total_ms=total_ms)
            return

        # ── 1. Pré-réponse instantanée ────────────────────────────────────────
        instant = _get_instant(message)
        if instant:
            t_fb = int((time.perf_counter() - t0) * 1000)
            _vlog("VOICE_INSTANT", feedback_ms=t_fb, reply=instant[:40])
            yield sse("instant", {"reply": instant, "time_to_feedback_ms": t_fb})

            t_tts = time.perf_counter()
            try:
                await asyncio.wait_for(
                    run_in_threadpool(tts_engine.speak_voice_mode, instant),
                    timeout=_TTS_TIMEOUT_SEC,
                )
            except asyncio.TimeoutError:
                pass
            tts_ms   = int((time.perf_counter() - t_tts) * 1000)
            total_ms = int((time.perf_counter() - t0) * 1000)

            yield sse("metrics", {
                "time_to_first_feedback_ms":     t_fb,
                "time_to_first_token_ms":        0,
                "time_to_first_spoken_audio_ms": t_fb,
                "full_turn_total_ms":            total_ms,
                "llm_ms":  0,
                "tts_ms":  tts_ms,
                "mode":    "instant",
            })
            _vlog("VOICE_TOTAL_END", mode="instant", total_ms=total_ms)
            return

        # ── 2. ACK immédiat ───────────────────────────────────────────────────
        ack = _pick_ack(message)
        t_ack = int((time.perf_counter() - t0) * 1000)
        _vlog("VOICE_ACK", ack=ack, feedback_ms=t_ack)
        yield sse("ack", {"text": ack, "time_to_feedback_ms": t_ack})

        # TTS de l'ACK en parallèle du LLM
        t_first_audio = time.perf_counter()
        ack_task = asyncio.create_task(
            run_in_threadpool(tts_engine.speak_voice_mode, ack)
        )

        # ── 3. LLM streaming (vrai token par token) ──────────────────────────
        # Mémoire conversationnelle courte : system + historique court + message actuel
        messages_llm = voice_memory.as_messages(
            system_prompt=_VOICE_SYSTEM,
            current_user_message=message,
        )
        logger.debug("VoiceMemory | %s | messages=%d", voice_memory.summary(), len(messages_llm))

        _vlog("VOICE_LLM_START", model=_llm.model, preview=repr(message[:50]))
        t_llm_start      = time.perf_counter()
        t_first_token_ms: Optional[int] = None
        llm_ms           = 0

        full_reply   = ""
        sentence_buf = ""
        llm_ok       = True

        # ── Queue phrases → thread TTS (lecture progressive) ─────────────────
        # Le thread TTS draine la queue et joue chaque phrase dès qu'elle arrive.
        # Le verrou _lock garantit qu'il attend la fin de l'ACK avant de parler.
        tts_q: _queue_mod.Queue = _queue_mod.Queue()
        tts_engine._stop_event.clear()  # reset interruption éventuelle
        tts_thread = threading.Thread(
            target=tts_engine.speak_sentence_queue,
            args=(tts_q,),
            kwargs={"timeout_total": float(_LLM_TIMEOUT_SEC + _TTS_TIMEOUT_SEC + 5)},
            daemon=True,
            name="tts-stream",
        )
        tts_thread.start()

        # ── Bridge générateur sync → asyncio (call_soon_threadsafe) ──────────
        # chat_stream() est un générateur bloquant → tourne dans un thread dédié.
        # Chaque token est envoyé vers l'event loop via call_soon_threadsafe
        # (non-bloquant, thread-safe, sans tampon intermédiaire).
        loop   = asyncio.get_running_loop()
        tok_q: asyncio.Queue = asyncio.Queue()

        def _push_tokens() -> None:
            """Thread LLM : push chaque token dans tok_q dès réception d'Ollama."""
            try:
                for _tok in _llm.chat_stream(messages_llm, voice_mode=True):
                    loop.call_soon_threadsafe(tok_q.put_nowait, ("tok", _tok))
            except Exception as _exc:
                loop.call_soon_threadsafe(tok_q.put_nowait, ("err", str(_exc)[:120]))
            finally:
                loop.call_soon_threadsafe(tok_q.put_nowait, ("end", None))

        llm_thread = threading.Thread(
            target=_push_tokens, daemon=True, name="llm-stream"
        )
        llm_thread.start()

        # ── Consommation tokens + segmentation phrases ────────────────────────
        try:
            while True:
                try:
                    kind, val = await asyncio.wait_for(
                        tok_q.get(), timeout=_LLM_TIMEOUT_SEC
                    )
                except asyncio.TimeoutError:
                    llm_ms = int((time.perf_counter() - t_llm_start) * 1000)
                    _vlog("VOICE_LLM_END", result="timeout", llm_ms=llm_ms)
                    logger.warning("[LLM_TOO_SLOW] llm_ms=%d → fallback local", llm_ms)
                    llm_ok = False
                    with _fallback_idx_lock:
                        full_reply = _FALLBACKS[_fallback_idx % len(_FALLBACKS)]
                        _fallback_idx += 1
                    yield sse("fallback", {"text": full_reply})
                    break

                if kind == "end":
                    llm_ms = int((time.perf_counter() - t_llm_start) * 1000)
                    _vlog("VOICE_LLM_END", llm_ms=llm_ms, chars=len(full_reply))
                    break

                if kind == "err":
                    llm_ms = int((time.perf_counter() - t_llm_start) * 1000)
                    _vlog("VOICE_LLM_END", result="error", llm_ms=llm_ms,
                          error=str(val)[:60])
                    logger.error("LLM stream error: %s", val)
                    llm_ok = False
                    with _fallback_idx_lock:
                        full_reply = _FALLBACKS[_fallback_idx % len(_FALLBACKS)]
                        _fallback_idx += 1
                    break

                # "tok" — token LLM reçu
                if t_first_token_ms is None:
                    t_first_token_ms = int((time.perf_counter() - t_llm_start) * 1000)
                    _vlog("VOICE_LLM_FIRST_TOKEN", ms=t_first_token_ms)

                full_reply   += val
                sentence_buf += val
                yield sse("token", {"t": val})

                # Phrase complète → TTS immédiat (sans attendre fin LLM)
                # v4.6 : max_chars=140 → segments plus naturels, moins de micro-coupures
                seg, sentence_buf = _find_segment(sentence_buf, min_chars=4,
                                                   max_chars=_SEGMENT_MAX_CHARS)
                if seg:
                    _vlog("VOICE_SEGMENT_READY", len=len(seg), preview=seg[:30])
                    tts_q.put(seg)
                    _vlog("VOICE_QUEUE_SIZE", size=tts_q.qsize())

        except Exception as exc:
            llm_ms = int((time.perf_counter() - t_llm_start) * 1000)
            logger.error("[LLM_STREAM] erreur inattendue: %s", exc)
            llm_ok = False
            with _fallback_idx_lock:
                full_reply = _FALLBACKS[_fallback_idx % len(_FALLBACKS)]
                _fallback_idx += 1

        # Flush buffer résiduel (dernière phrase sans ponctuation finale)
        if sentence_buf.strip() and llm_ok:
            tts_q.put(sentence_buf.strip())

        # Fallback : passer le message de fallback au thread TTS
        if not llm_ok and full_reply:
            tts_q.put(full_reply)

        # Sentinel → fin propre du thread TTS
        tts_q.put(None)

        # ── 4. Attendre ACK vocal + fin thread TTS ────────────────────────────
        await ack_task  # ACK vocal terminé (lock libéré → phrases LLM peuvent jouer)

        t_first_spoken = int((time.perf_counter() - t_first_audio) * 1000)
        t_tts = time.perf_counter()

        # Attendre fin du thread TTS (timeout de sécurité)
        await run_in_threadpool(tts_thread.join, float(_TTS_TIMEOUT_SEC + 5))
        tts_total_ms = int((time.perf_counter() - t_tts) * 1000)
        total_ms     = int((time.perf_counter() - t0) * 1000)

        # Mémoriser l'échange pour la prochaine requête
        if full_reply and llm_ok:
            voice_memory.add("user", message)
            voice_memory.add("assistant", full_reply)

        yield sse("done", {"reply": full_reply, "fallback": not llm_ok})
        yield sse("metrics", {
            "time_to_first_feedback_ms":     t_ack,
            "time_to_first_token_ms":        t_first_token_ms or llm_ms,
            "time_to_first_spoken_audio_ms": t_first_spoken,
            "full_turn_total_ms":            total_ms,
            "llm_ms":                        llm_ms,
            "tts_ms":                        tts_total_ms,
            "mode":                          "stream" if llm_ok else "fallback",
        })
        _vlog("VOICE_TOTAL_END",
              feedback_ms=t_ack,
              first_token_ms=t_first_token_ms,
              first_audio_ms=t_first_spoken,
              llm_ms=llm_ms,
              total_ms=total_ms)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── /speak ────────────────────────────────────────────────────────────────────

@router.post("/speak")
async def speak_text(payload: TTSRequest):
    text = (payload.text or "").strip()
    if not text:
        return JSONResponse(content={"spoken": False, "error": "vide"})
    if len(text) > _TTS_MAX_CHARS:
        text = text[:_TTS_MAX_CHARS]

    _vlog("VOICE_TTS_START", len=len(text))
    t0 = time.perf_counter()
    try:
        tts_ms = await asyncio.wait_for(
            run_in_threadpool(tts_engine.speak_voice_mode, text),
            timeout=_TTS_TIMEOUT_SEC,
        )
        tts_ms = tts_ms or int((time.perf_counter() - t0) * 1000)
        _vlog("VOICE_TTS_END", tts_ms=tts_ms)
        return {"spoken": True, "text_length": len(text), "tts_time_ms": tts_ms}
    except asyncio.TimeoutError:
        tts_ms = int((time.perf_counter() - t0) * 1000)
        return JSONResponse(status_code=200,
            content={"spoken": False, "tts_time_ms": tts_ms,
                     "warning": f"TTS timeout ({_TTS_TIMEOUT_SEC}s)"})
    except Exception as exc:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(exc)})


# ── /stop ─────────────────────────────────────────────────────────────────────

@router.post("/stop")
async def stop_voice():
    """Arrête le TTS en cours. Appelé quand l'utilisateur clique Arrêter."""
    tts_engine.stop()
    _vlog("VOICE_STOP_REQUESTED")
    return {"stopped": True}


# ── /interrupt (alias v1.9.6 — utilisé par le frontend continu) ───────────────

@router.post("/interrupt")
async def interrupt_voice():
    """
    Interruption immédiate du tour vocal en cours.
      - Stoppe le TTS local (pyttsx3) si actif
      - Passe la VoiceSession à INTERRUPTED (publie sur le CORE)
    Appelé par le frontend quand l'utilisateur parle pendant que Nova répond.
    Alias plus simple de /api/voice-extras/interrupt.
    """
    stopped_tts = False
    try:
        tts_engine.stop()
        stopped_tts = True
    except Exception as exc:
        _vlog("VOICE_INTERRUPT_TTS_STOP_FAIL", error=str(exc))

    session_ok = False
    try:
        from app.services.voice_session import get_voice_session, VoiceState
        ok = get_voice_session().transition(VoiceState.INTERRUPTED, force=True)
        session_ok = bool(ok)
    except Exception as exc:
        _vlog("VOICE_INTERRUPT_SESSION_FAIL", error=str(exc))

    _vlog("VOICE_INTERRUPT_DONE", stopped_tts=stopped_tts, session_ok=session_ok)
    return {"ok": True, "stopped_tts": stopped_tts, "session_transitioned": session_ok}


# ── /chat (compatibilité chat texte) ─────────────────────────────────────────

@router.post("/chat")
async def voice_chat(payload: VoiceChatRequest, db: Session = Depends(get_db)):
    """Endpoint non-stream — maintenu pour compatibilité."""
    global _fallback_idx

    message = (payload.message or "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message vide.")

    instant = _get_instant(message)
    if instant:
        _vlog("VOICE_LLM_INSTANT", reply=instant[:40])
        return {"reply": instant, "model": "instant_local",
                "llm_time_ms": 0, "fallback": False, "instant": True}

    messages_llm = [
        {"role": "system", "content": _VOICE_SYSTEM},
        {"role": "user",   "content": message},
    ]

    _vlog("VOICE_LLM_START", model=_llm.model, preview=repr(message[:50]))
    t0 = time.perf_counter()

    try:
        reply = await asyncio.wait_for(
            run_in_threadpool(_llm.chat, messages_llm, True),
            timeout=_LLM_TIMEOUT_SEC,
        )
        llm_ms = int((time.perf_counter() - t0) * 1000)
        reply  = (reply or "").strip()
        _vlog("VOICE_LLM_END", llm_ms=llm_ms, chars=len(reply))
        voice_memory.add("user", message)
        voice_memory.add("assistant", reply)
        return {"reply": reply, "model": _llm.model,
                "llm_time_ms": llm_ms, "fallback": False, "instant": False}

    except Exception:
        llm_ms   = int((time.perf_counter() - t0) * 1000)
        with _fallback_idx_lock:
            fallback = _FALLBACKS[_fallback_idx % len(_FALLBACKS)]
            _fallback_idx += 1
        _vlog("VOICE_LLM_END", result="fallback", llm_ms=llm_ms)
        return {"reply": fallback, "model": "fallback_local",
                "llm_time_ms": llm_ms, "fallback": True, "instant": False}
