"""
api/voice_extras.py — Endpoints d'observation et configuration vocale (v1.9.5).

NE TOUCHE PAS aux endpoints /api/voice/* existants.

Routes :
    GET  /api/voice-extras/state           → état machine vocale (idle/listening/...)
    POST /api/voice-extras/state           → forcer transition (debug/interruption)
    GET  /api/voice-extras/memory          → derniers échanges vocaux
    DELETE /api/voice-extras/memory        → vider mémoire vocale
    GET  /api/voice-extras/vad             → stats VAD + paramètres courants
    GET  /api/voice-extras/wake-word       → config wake word
    POST /api/voice-extras/wake-word       → reconfigurer wake word
    POST /api/voice-extras/interrupt       → demander interruption immédiate

Toutes les opérations passent par voice_session ou voice_enhancers,
qui publient les events appropriés sur le CORE.
"""

from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.voice_session import VoiceState, get_voice_session
from app.services.voice_enhancers import (
    get_vad_calibrator, get_wake_detector,
)
from app.utils.logger import get_logger

logger = get_logger("api.voice_extras")

router = APIRouter(prefix="/api/voice-extras", tags=["voice"])


# ── État de la session vocale ──────────────────────────────────────────────

@router.get("/state")
def voice_state():
    return get_voice_session().get_state()


class StateTransition(BaseModel):
    state: str = Field(..., min_length=3, max_length=20)
    force: bool = False


@router.post("/state")
def voice_state_set(payload: StateTransition):
    try:
        new_state = VoiceState(payload.state)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"État invalide : {payload.state}")
    ok = get_voice_session().transition(new_state, force=payload.force)
    return {"ok": ok, "state": new_state.value}


# ── Mémoire conversationnelle ──────────────────────────────────────────────

@router.get("/memory")
def voice_memory(limit: int = 4):
    limit = max(1, min(limit, 20))
    return {"turns": get_voice_session().get_recent_turns(n=limit)}


@router.delete("/memory")
def voice_memory_clear():
    n = get_voice_session().clear_memory()
    return {"cleared": n}


# ── VAD ────────────────────────────────────────────────────────────────────

@router.get("/vad")
def vad_stats():
    return get_vad_calibrator().get_stats()


# ── Wake word ──────────────────────────────────────────────────────────────

@router.get("/wake-word")
def wake_word_config():
    return get_wake_detector().get_config()


class WakeWordUpdate(BaseModel):
    words: List[str] = Field(..., min_length=1, max_length=10)
    enabled: bool = True


@router.post("/wake-word")
def wake_word_set(payload: WakeWordUpdate):
    detector = get_wake_detector()
    detector.configure(payload.words, enabled=payload.enabled)
    return {"ok": True, "config": detector.get_config()}


# ── Interruption immédiate ─────────────────────────────────────────────────

@router.post("/interrupt")
def voice_interrupt():
    """
    Demande l'interruption immédiate de l'état SPEAKING/THINKING.
    Publie un event 'voice.state.interrupted' sur le CORE.
    Le frontend doit écouter cet état et stopper TTS local.
    """
    session = get_voice_session()
    ok = session.transition(VoiceState.INTERRUPTED, force=True)
    return {"ok": ok, "state": session.get_state()["state"]}


# ── Métriques de latence v1.9.9 ────────────────────────────────────────────

@router.get("/metrics")
def voice_metrics_agg(last_n: int = 50):
    """Agrégations latence sur les N derniers tours (moyennes, p95)."""
    from app.services.voice_metrics import get_voice_metrics
    last_n = max(1, min(int(last_n or 50), 500))
    return get_voice_metrics().aggregate(last_n=last_n)


@router.get("/metrics/history")
def voice_metrics_history(limit: int = 50, completed_only: bool = True):
    """Détail des derniers tours mesurés."""
    from app.services.voice_metrics import get_voice_metrics
    limit = max(1, min(int(limit or 50), 200))
    return {
        "turns": get_voice_metrics().get_history(
            limit=limit, completed_only=completed_only,
        )
    }


@router.get("/metrics/inflight")
def voice_metrics_inflight():
    """Tours actuellement en cours (utile pour debug blocage)."""
    from app.services.voice_metrics import get_voice_metrics
    return {"inflight": get_voice_metrics().get_inflight()}


@router.delete("/metrics")
def voice_metrics_clear():
    from app.services.voice_metrics import get_voice_metrics
    n = get_voice_metrics().clear()
    return {"cleared": n}


# ── Watchdog v1.9.9 ────────────────────────────────────────────────────────

@router.get("/watchdog")
def voice_watchdog_status():
    """État du watchdog vocal + compteurs de timeouts."""
    from app.services.voice_watchdog import get_voice_watchdog
    return get_voice_watchdog().get_stats()


class WatchdogControl(BaseModel):
    action: str = Field(..., pattern="^(start|stop)$")


@router.post("/watchdog")
def voice_watchdog_control(payload: WatchdogControl):
    """start/stop du watchdog (start automatique au boot via main.py)."""
    from app.services.voice_watchdog import get_voice_watchdog
    wd = get_voice_watchdog()
    if payload.action == "start":
        ok = wd.start()
        return {"ok": ok, "running": wd.is_running()}
    else:
        ok = wd.stop()
        return {"ok": ok, "running": wd.is_running()}
