"""
ws.py — Pont WebSocket Nova ↔ Frontend Electron

Protocole compatible Jarvis frontend (messages JSON type/payload).

Messages Client → Serveur :
  user_message   {chatId, projectId, text}
  create_chat    {projectId, title}
  create_project {name}
  load_chat      {projectId, chatId}
  load_project   {projectId}
  settings_update {provider, model, theme, ...}
  detect_models  {provider, api_key}

Messages Serveur → Client :
  bootstrap       {settings, projects, chats, messages, currentProjectId, currentChatId}
  project_created {project, chat}
  chat_created    {id, title, project_id}
  chat_loaded     {projectId, chatId, chats, messages}
  settings        {provider, model, ...}
  assistant_start {}
  assistant_token {token}
  assistant_end   {chats, messages}
  models_detected {ok, models, error}
  error           {message}
"""

import asyncio
import json
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.core.llm import OllamaClient
from app.db.database import SessionLocal
from app.db import models as db_models
from app.utils.logger import get_logger
from app.utils.perf_logger import perf as _perf

router = APIRouter()
logger = get_logger("ws")

# LLM partagé (singleton par processus)
_llm = OllamaClient()
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="nova_ws")


# ── Stores JSON simples (projects + settings) ─────────────────────────────

def _data_dir() -> str:
    base = os.environ.get("NOVA_DATA_DIR", "data")
    os.makedirs(base, exist_ok=True)
    return base


def _load_json(filename: str, default) -> Any:
    path = os.path.join(_data_dir(), filename)
    try:
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return default


def _save_json(filename: str, data: Any) -> None:
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as exc:
        logger.warning("[WS] save_json failed: %s", exc)


_DEFAULT_SETTINGS: Dict[str, Any] = {
    "provider": "ollama",
    "model": "",
    "theme": "jarvis",
    "voice": "fr-FR",
    "onboarding_completed": "true",
}

_DEFAULT_PROJECT = {"id": 1, "name": "Assistant Principal"}


def load_settings() -> Dict:
    return {**_DEFAULT_SETTINGS, **_load_json("nova_settings.json", {})}


def save_settings(s: Dict) -> None:
    _save_json("nova_settings.json", s)


def load_projects() -> List[Dict]:
    projects = _load_json("nova_projects.json", None)
    if not projects:
        projects = [_DEFAULT_PROJECT]
        _save_json("nova_projects.json", projects)
    return projects


def save_projects(projects: List[Dict]) -> None:
    _save_json("nova_projects.json", projects)


# ── Helpers DB ────────────────────────────────────────────────────────────

def _now() -> datetime:
    return datetime.now(timezone.utc)


def db_get_chats(project_id: int = 1) -> List[Dict]:
    db = SessionLocal()
    try:
        convs = (
            db.query(db_models.Conversation)
            .order_by(db_models.Conversation.updated_at.desc())
            .limit(50)
            .all()
        )
        return [
            {
                "id": c.id,
                "title": c.title,
                "project_id": project_id,
                "created_at": str(c.created_at),
            }
            for c in convs
        ]
    finally:
        db.close()


def db_get_messages(chat_id: int) -> List[Dict]:
    db = SessionLocal()
    try:
        msgs = (
            db.query(db_models.Message)
            .filter(db_models.Message.conversation_id == chat_id)
            .order_by(db_models.Message.created_at)
            .limit(100)
            .all()
        )
        return [
            {"id": m.id, "role": m.role, "content": m.content}
            for m in msgs
        ]
    finally:
        db.close()


def db_create_conversation(title: str) -> db_models.Conversation:
    db = SessionLocal()
    try:
        conv = db_models.Conversation(title=title or "Nouvelle session")
        db.add(conv)
        db.commit()
        db.refresh(conv)
        return conv
    finally:
        db.close()


def db_save_message(conv_id: int, role: str, content: str) -> None:
    db = SessionLocal()
    try:
        msg = db_models.Message(
            conversation_id=conv_id, role=role, content=content
        )
        db.add(msg)
        conv = (
            db.query(db_models.Conversation)
            .filter(db_models.Conversation.id == conv_id)
            .first()
        )
        if conv:
            conv.updated_at = _now()
        db.commit()
    finally:
        db.close()


# Limite de troncature par message d'historique (chars).
# Évite l'explosion du contexte si un message précédent est très long.
# num_ctx=2048 tokens ≈ ~6000 chars — on garde 400 chars/msg max en historique.
_MAX_HISTORY_MSG_CHARS = 400


def _build_camera_context() -> str:
    """
    Construit un bloc de texte décrivant l'état RÉEL de la caméra, à injecter
    dans le prompt système. Permet à Nova de répondre correctement aux questions
    « est-ce que tu peux voir », « as-tu une caméra », « que vois-tu ».

    Format produit (ASCII, compact, ≤ 200 chars en pratique) :
        [CAMÉRA]
        CAMERA_ENABLED=true
        CAMERA_STATUS=active
        CAMERA_SOURCE=0
        CAMERA_LAST_ERROR=none
        CAMERA_LAST_FRAME_TIME=2026-05-14T21:12:03

    Plus un guide concis indiquant à Nova quoi dire selon l'état.

    Aucune modification du module caméra. Lecture seule via .status().
    En cas d'erreur (manager non initialisé, etc.) : retourne un bloc
    minimal "désactivé" — jamais d'exception remontée à _build_llm_messages.
    """
    try:
        from app.services.camera_manager import get_camera_manager, CameraState
        from app.config import settings as _s

        enabled = bool(_s.camera_enabled)
        mgr = get_camera_manager()

        if mgr is None:
            # Manager pas encore instancié — caméra effectivement désactivée
            return (
                "[CAMÉRA]\n"
                "CAMERA_ENABLED=" + ("true" if enabled else "false") + "\n"
                "CAMERA_STATUS=inactive\n"
                "CAMERA_SOURCE=none\n"
                "CAMERA_LAST_ERROR=none\n"
                "CAMERA_LAST_FRAME_TIME=never\n"
                "Guide : la caméra n'est pas démarrée. Tu ne peux pas voir actuellement. "
                "Pour analyser une image, l'utilisateur doit démarrer la caméra "
                "puis cliquer ANALYSER MAINTENANT dans le panneau caméra."
            )

        st = mgr.status  # @property, accès sans parenthèses
        state_str = st.state.value if hasattr(st.state, "value") else str(st.state)
        source    = st.source_active or "none"
        err       = st.last_error or "none"

        if st.last_frame_ts:
            import datetime as _dt
            frame_time = _dt.datetime.fromtimestamp(st.last_frame_ts).strftime("%Y-%m-%dT%H:%M:%S")
        else:
            frame_time = "never"

        # Guide selon l'état réel
        if state_str == CameraState.CONNECTED.value and st.snapshot_available:
            guide = (
                "Guide : la caméra est CONNECTÉE et fournit des images. "
                "Tu peux dire à l'utilisateur que tu disposes d'une caméra fonctionnelle. "
                "Pour analyser ce qu'elle voit à l'instant, propose-lui le bouton "
                "ANALYSER MAINTENANT dans le panneau caméra. "
                "Ne décris JAMAIS ce que la caméra voit sans qu'une analyse ait été demandée."
            )
        elif state_str in (CameraState.CONNECTING.value, CameraState.RECONNECTING.value):
            guide = (
                "Guide : la caméra est en cours de connexion (" + state_str + "). "
                "Indique à l'utilisateur d'attendre quelques secondes."
            )
        elif state_str == CameraState.DEGRADED.value:
            guide = (
                "Guide : la caméra est en mode DEGRADED — matériel ou pilote "
                "non opérationnel (erreur : " + err + "). "
                "Explique-le clairement à l'utilisateur et suggère de vérifier "
                "la connexion, les permissions caméra, ou l'installation OpenCV."
            )
        elif state_str == CameraState.STOPPED.value:
            guide = (
                "Guide : la caméra est ARRÊTÉE. "
                "Indique que l'utilisateur peut la redémarrer depuis le panneau caméra."
            )
        elif not enabled:
            guide = (
                "Guide : la caméra est DÉSACTIVÉE par configuration "
                "(CAMERA_ENABLED=false). Explique à l'utilisateur qu'il faut "
                "activer CAMERA_ENABLED=true dans .env pour l'utiliser."
            )
        else:
            # IDLE ou état non reconnu
            guide = (
                "Guide : la caméra est présente mais inactive. "
                "Indique que l'utilisateur peut la démarrer via le panneau caméra "
                "(bouton DÉMARRER)."
            )

        return (
            "[CAMÉRA]\n"
            "CAMERA_ENABLED=" + ("true" if enabled else "false") + "\n"
            "CAMERA_STATUS=" + state_str + "\n"
            "CAMERA_SOURCE=" + str(source) + "\n"
            "CAMERA_LAST_ERROR=" + err + "\n"
            "CAMERA_LAST_FRAME_TIME=" + frame_time + "\n"
            + guide
        )

    except Exception as exc:
        # Robustesse : jamais d'exception dans le build du prompt
        logger.warning("[WS] camera context build failed : %s", exc)
        return (
            "[CAMÉRA]\n"
            "CAMERA_ENABLED=unknown\n"
            "CAMERA_STATUS=unknown\n"
            "Guide : impossible de lire l'état caméra actuellement. "
            "Ne fais pas d'hypothèses sur ses capacités visuelles."
        )


# ── Détection commandes recherche fichier ─────────────────────────────────
#
# Patterns français déclencheurs reconnus (case-insensitive) :
#   "cherche un fichier nommé X"           → by-name
#   "cherche fichier nommé X"
#   "trouve un fichier nommé X"
#   "trouve fichier nommé X"
#   "cherche un fichier appelé X"
#   "trouve les documents contenant X"     → by-content
#   "cherche les documents contenant X"
#   "trouve les fichiers contenant X"
#   "cherche les fichiers contenant X"
#
# Tout autre message → flux LLM normal (pas d'interception).

import re as _re

_FILE_SEARCH_BY_NAME_RE = _re.compile(
    r"^(?:cherche|trouve|recherche)\s+(?:un\s+|le\s+)?fichier\s+"
    r"(?:nomm[ée]|appel[ée]|qui\s+s['']appelle)\s+(.+?)\s*\.?\s*$",
    _re.IGNORECASE,
)

_FILE_SEARCH_BY_CONTENT_RE = _re.compile(
    r"^(?:cherche|trouve|recherche)\s+(?:les\s+)?(?:documents?|fichiers?)\s+"
    r"(?:contenant|qui\s+contiennent|avec)\s+(.+?)\s*\.?\s*$",
    _re.IGNORECASE,
)


def _format_file_search_results(query: str, mode: str, results: list) -> str:
    """Formate les résultats en réponse texte brute pour le chat."""
    if not results:
        return (
            f"Aucun résultat pour « {query} ». "
            "Vérifie l'orthographe, ou élargis ALLOWED_SEARCH_DIRS dans .env."
        )

    label = "Fichier(s) trouvé(s)" if mode == "name" else "Document(s) contenant le texte"
    lines = [f"{label} pour « {query} » : {len(results)} résultat(s)\n"]
    for i, r in enumerate(results[:10], 1):
        size_kb = max(1, r.get("size", 0) // 1024)
        line = f"{i}. {r['name']}\n   chemin : {r['path']}\n   taille : {size_kb} Ko · modifié : {r.get('modified_iso', '?')}"
        if r.get("snippet"):
            line += f"\n   extrait : {r['snippet']}"
        lines.append(line)
    if len(results) > 10:
        lines.append(f"\n(+ {len(results) - 10} autre(s) résultat(s) non affiché(s))")
    return "\n".join(lines)


def _try_handle_file_search_command(text: str) -> Optional[str]:
    """
    Si `text` matche un pattern de commande recherche fichier, exécute le service
    et retourne la réponse formatée. Sinon retourne None → flux LLM normal.

    Lecture seule : ne modifie/supprime jamais aucun fichier.
    """
    text = text.strip()

    m = _FILE_SEARCH_BY_NAME_RE.match(text)
    if m:
        query = m.group(1).strip().strip('"\'«»')
        if not query:
            return None
        try:
            from app.services.file_search import get_file_search, FileSearchError
            fs = get_file_search()
            results = fs.search_by_name(query)
            return _format_file_search_results(query, "name", results)
        except FileSearchError as exc:
            logger.info("[WS] file_search by-name refusé : %s", exc)
            return f"Recherche impossible : {exc}"
        except Exception as exc:
            logger.error("[WS] file_search by-name erreur : %s", exc)
            return "Erreur interne lors de la recherche fichier."

    m = _FILE_SEARCH_BY_CONTENT_RE.match(text)
    if m:
        query = m.group(1).strip().strip('"\'«»')
        if not query:
            return None
        try:
            from app.services.file_search import get_file_search, FileSearchError
            fs = get_file_search()
            results = fs.search_by_content(query)
            return _format_file_search_results(query, "content", results)
        except FileSearchError as exc:
            logger.info("[WS] file_search by-content refusé : %s", exc)
            return f"Recherche impossible : {exc}"
        except Exception as exc:
            logger.error("[WS] file_search by-content erreur : %s", exc)
            return "Erreur interne lors de la recherche fichier."

    return None


def _build_llm_messages(chat_id: int, user_text: str) -> List[Dict[str, str]]:
    """
    Construit l'historique messages pour Ollama (system + history + new).

    Optimisations mémoire/vitesse :
    - Prompt système compact (< 200 chars de base) + contexte caméra dynamique
    - max_context_messages configurable (défaut 4 depuis config)
    - Troncature des longs messages d'historique à _MAX_HISTORY_MSG_CHARS
    """
    history = db_get_messages(chat_id)

    # Prompt système = prompt de base + état caméra réel (lecture seule)
    base_prompt = (
        "Tu es Nova, assistant IA local francophone. "
        "Réponds en français, clairement, chaleureusement et brièvement."
    )
    camera_context = _build_camera_context()
    system_content = base_prompt + "\n\n" + camera_context

    result: List[Dict[str, str]] = [
        {"role": "system", "content": system_content}
    ]

    try:
        from app.config import settings as _s
        max_ctx = int(_s.max_context_messages)
    except Exception:
        max_ctx = 4  # fallback conservateur pour 8 Go RAM
    for m in history[-max_ctx:]:
        raw = m["content"] or ""
        # Tronquer les longs messages : évite de saturer le contexte Ollama
        trimmed = raw[:_MAX_HISTORY_MSG_CHARS] + "…" if len(raw) > _MAX_HISTORY_MSG_CHARS else raw
        result.append({"role": m["role"], "content": trimmed})
    result.append({"role": "user", "content": user_text})
    logger.debug(
        "[WS] LLM context | msgs=%d  history=%d  user_chars=%d  sys_chars=%d",
        len(result), len(result) - 2, len(user_text), len(system_content),
    )
    return result


# ── Streaming async depuis générateur synchrone ───────────────────────────

async def _stream_tokens(
    websocket: WebSocket,
    llm_messages: List[Dict[str, str]],
) -> str:
    """
    Exécute chat_stream() (synchrone) dans un thread et envoie
    chaque token au WebSocket en temps réel.
    Retourne la réponse complète assemblée.
    """
    loop = asyncio.get_event_loop()
    queue: asyncio.Queue = asyncio.Queue()

    def _producer() -> None:
        try:
            for token in _llm.chat_stream(llm_messages, voice_mode=False):
                asyncio.run_coroutine_threadsafe(queue.put(token), loop).result(timeout=10)
        except Exception as exc:
            logger.error("[WS] stream_producer error: %s", exc)
        finally:
            asyncio.run_coroutine_threadsafe(queue.put(None), loop).result(timeout=5)

    loop.run_in_executor(_executor, _producer)

    buffer = ""
    while True:
        token = await queue.get()
        if token is None:
            break
        buffer += token
        await websocket.send_json(
            {"type": "assistant_token", "payload": {"token": token}}
        )
    return buffer


async def _send_perf_stats(websocket: WebSocket) -> None:
    """
    Envoie les métriques de performance de la dernière inférence au frontend.
    Message optionnel : le frontend peut ignorer si le panneau debug est fermé.
    """
    try:
        last = _perf.get_last()
        if last:
            await websocket.send_json(
                {"type": "perf_stats", "payload": last}
            )
    except Exception as exc:
        logger.debug("[WS] perf_stats send skipped: %s", exc)


# ── Point d'entrée WebSocket ──────────────────────────────────────────────

@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    await websocket.accept()
    logger.info("[WS] Client connecté addr=%s", websocket.client)

    # ── État de session ────────────────────────────────────────────────
    settings_data = load_settings()
    projects = load_projects()
    current_project_id: int = projects[0]["id"] if projects else 1
    chats = db_get_chats(current_project_id)

    # Créer un chat par défaut s'il n'en existe aucun
    if not chats:
        conv = db_create_conversation("Session 1")
        chats = db_get_chats(current_project_id)
    current_chat_id: int = chats[0]["id"] if chats else 1

    # ── Bootstrap ──────────────────────────────────────────────────────
    await websocket.send_json(
        {
            "type": "bootstrap",
            "payload": {
                "settings": settings_data,
                "projects": projects,
                "chats": chats,
                "messages": db_get_messages(current_chat_id),
                "currentProjectId": current_project_id,
                "currentChatId": current_chat_id,
            },
        }
    )

    # ── Boucle principale ──────────────────────────────────────────────
    try:
        while True:
            raw = await websocket.receive_json()
            msg_type: str = raw.get("type", "")
            payload: Dict = raw.get("payload", {})

            # ── user_message ───────────────────────────────────────────
            if msg_type == "user_message":
                text: str = (payload.get("text") or "").strip()
                chat_id: int = int(payload.get("chatId") or current_chat_id)
                if not text:
                    continue

                # Sauvegarder message utilisateur
                db_save_message(chat_id, "user", text)

                # ── Interception commande recherche fichier ───────────
                # Avant Ollama : détecter "cherche un fichier nommé X"
                # ou "trouve les documents contenant Y". Si match → exécuter
                # le service local et renvoyer la réponse formatée sans LLM.
                file_search_reply = _try_handle_file_search_command(text)
                if file_search_reply is not None:
                    db_save_message(chat_id, "assistant", file_search_reply)
                    await websocket.send_json({"type": "assistant_start", "payload": {}})
                    await websocket.send_json(
                        {"type": "assistant_token",
                         "payload": {"token": file_search_reply}}
                    )
                    updated_chats = db_get_chats(current_project_id)
                    updated_msgs = db_get_messages(chat_id)
                    await websocket.send_json(
                        {"type": "assistant_end",
                         "payload": {"chats": updated_chats, "messages": updated_msgs}}
                    )
                    continue

                # Construire historique LLM
                llm_messages = _build_llm_messages(chat_id, text)

                # Streaming
                await websocket.send_json({"type": "assistant_start", "payload": {}})
                try:
                    response = await _stream_tokens(websocket, llm_messages)
                except Exception as exc:
                    logger.error("[WS] LLM stream error: %s", exc)
                    response = "Je suis désolé, je ne peux pas répondre pour l'instant."
                    await websocket.send_json(
                        {"type": "assistant_token", "payload": {"token": response}}
                    )

                if response:
                    db_save_message(chat_id, "assistant", response)

                updated_chats = db_get_chats(current_project_id)
                updated_msgs = db_get_messages(chat_id)
                await websocket.send_json(
                    {
                        "type": "assistant_end",
                        "payload": {
                            "chats": updated_chats,
                            "messages": updated_msgs,
                        },
                    }
                )
                # Envoyer métriques de performance au frontend (panneau debug)
                await _send_perf_stats(websocket)

            # ── create_chat ────────────────────────────────────────────
            elif msg_type == "create_chat":
                title = payload.get("title") or "Nouvelle session"
                conv = db_create_conversation(title)
                current_chat_id = conv.id
                await websocket.send_json(
                    {
                        "type": "chat_created",
                        "payload": {
                            "id": conv.id,
                            "title": conv.title,
                            "project_id": current_project_id,
                        },
                    }
                )

            # ── create_project ─────────────────────────────────────────
            elif msg_type == "create_project":
                name = payload.get("name") or "Nouveau projet"
                new_id = max(p["id"] for p in projects) + 1 if projects else 2
                project = {"id": new_id, "name": name}
                projects.append(project)
                save_projects(projects)
                conv = db_create_conversation("Session 1")
                current_project_id = new_id
                current_chat_id = conv.id
                await websocket.send_json(
                    {
                        "type": "project_created",
                        "payload": {
                            "project": project,
                            "chat": {
                                "id": conv.id,
                                "title": conv.title,
                                "project_id": new_id,
                            },
                        },
                    }
                )

            # ── load_chat ──────────────────────────────────────────────
            elif msg_type == "load_chat":
                chat_id = payload.get("chatId")
                project_id = payload.get("projectId")
                if chat_id:
                    current_chat_id = int(chat_id)
                if project_id:
                    current_project_id = int(project_id)
                await websocket.send_json(
                    {
                        "type": "chat_loaded",
                        "payload": {
                            "projectId": current_project_id,
                            "chatId": current_chat_id,
                            "chats": db_get_chats(current_project_id),
                            "messages": db_get_messages(current_chat_id),
                        },
                    }
                )

            # ── load_project ───────────────────────────────────────────
            elif msg_type == "load_project":
                project_id = payload.get("projectId")
                if project_id:
                    current_project_id = int(project_id)
                chats = db_get_chats(current_project_id)
                if not chats:
                    conv = db_create_conversation("Session 1")
                    chats = db_get_chats(current_project_id)
                current_chat_id = chats[0]["id"] if chats else 1
                await websocket.send_json(
                    {
                        "type": "chat_loaded",
                        "payload": {
                            "projectId": current_project_id,
                            "chatId": current_chat_id,
                            "chats": chats,
                            "messages": db_get_messages(current_chat_id),
                        },
                    }
                )

            # ── settings_update ────────────────────────────────────────
            elif msg_type == "settings_update":
                settings_data.update(payload)
                save_settings(settings_data)
                await websocket.send_json(
                    {"type": "settings", "payload": settings_data}
                )

            # ── detect_models ──────────────────────────────────────────
            elif msg_type == "detect_models":
                provider = payload.get("provider", "ollama")
                if provider == "ollama":
                    health = _llm.health_check()
                    models_list = health.get("available_models", [])
                    if not models_list:
                        models_list = ["llama3.2:3b"]
                    await websocket.send_json(
                        {
                            "type": "models_detected",
                            "payload": {"ok": True, "models": models_list},
                        }
                    )
                else:
                    await websocket.send_json(
                        {
                            "type": "models_detected",
                            "payload": {
                                "ok": False,
                                "error": f"Provider '{provider}' non supporté. Utilisez Ollama local.",
                            },
                        }
                    )

            else:
                logger.debug("[WS] Message inconnu: %s", msg_type)

    except WebSocketDisconnect:
        logger.info("[WS] Client déconnecté")
    except Exception as exc:
        logger.error("[WS] Erreur inattendue: %s", exc, exc_info=True)
