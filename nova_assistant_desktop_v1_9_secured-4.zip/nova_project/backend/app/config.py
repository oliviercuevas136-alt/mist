from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    app_name: str = "Nova Assistant Desktop"
    app_host: str = "127.0.0.1"
    app_port: int = 8000
    debug: bool = True
    stt_engine: str = "faster_whisper"
    stt_model: str = "tiny"
    stt_device: str = "cpu"
    stt_compute_type: str = "int8"
    stt_language: str = "fr"
    database_url: str = "sqlite:///./data/nova.db"

    static_dir: str = "app/static"
    log_dir: str = "logs"
    data_dir: str = "data"
    notes_dir: str = "data/notes"
    uploads_dir: str = "data/uploads"
    memory_exports_dir: str = "data/memory_exports"
    export_dir: str = "data/exports"
    voice_input_dir: str = "data/voice_inputs"
    voice_output_dir: str = "data/voice_outputs"
    app_log_file: str = "logs/assistant.log"

    ollama_base_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "llama3.2:3b"
    ollama_timeout: int = 120
    ollama_warmup: bool = True            # warmup LLM au démarrage (évite cold start — ~2-4s gagnées)

    # ── Mistral API (fallback LLM) ───────────────────────────────────────────
    # Activé uniquement si USE_MISTRAL_FALLBACK=true ET MISTRAL_API_KEY renseigné.
    # Jamais prioritaire sur Ollama local.
    mistral_api_key: str = ""                      # MISTRAL_API_KEY dans .env
    mistral_model: str = "mistral-small-latest"    # modèle Mistral utilisé en fallback
    mistral_timeout: int = 30                      # timeout secondes appel Mistral
    use_mistral_fallback: bool = False             # false par défaut : Ollama seul
    system_language: str = "fr"
    max_context_messages: int = 4     # 4 échanges = contexte suffisant, RAM préservée

    allowed_base_dirs: str = "data/notes,data/uploads"
    max_file_size_bytes: int = 1048576
    max_document_preview_chars: int = 5000

    # ── Recherche fichiers sur disque (FileSearch service) ────────────────────
    # CSV de chemins absolus autorisés à la recherche. Vide par défaut → recherche
    # disque DÉSACTIVÉE. Aucun accès aux chemins systèmes même si l'utilisateur
    # tente de les ajouter (filtrage par allowlist en plus, blocklist absolue).
    # Exemple : ALLOWED_SEARCH_DIRS=C:\Users\Oli\Documents,C:\Users\Oli\Desktop
    allowed_search_dirs: str = ""
    file_search_max_results: int = 50          # plafond global de résultats
    file_search_max_scan_files: int = 5000     # plafond de fichiers parcourus / requête
    file_search_max_content_bytes: int = 524288  # 512 Ko max scannés / fichier pour recherche contenu
    file_search_text_extensions: str = ".txt,.md,.log,.csv,.json,.xml,.html,.htm,.py,.js,.ts,.css,.yaml,.yml,.ini,.cfg,.rst"
    # Limites lecture fichier (endpoint /api/file-search/read-*)
    file_read_preview_bytes: int = 4096        # 4 Ko pour aperçu rapide
    file_read_full_max_bytes: int = 524288     # 512 Ko max pour lecture complète

    # ── Actions PC autorisées (ActionManager) ─────────────────────────────────
    # CSV de permissions accordées à Nova pour agir sur le PC.
    # Vide par défaut → AUCUNE action autorisée. Sécurité avant ergonomie.
    # Valeurs possibles : open_file, launch_application, kill_process,
    #                     move_files, cleanup_folder, backup_files
    # Chaque action propose → confirme → exécute, avec token à TTL court.
    allowed_pc_actions: str = ""

    # ── Surveillance système (SystemMonitor) ──────────────────────────────────
    system_monitor_enabled: bool = True
    system_monitor_interval_sec: float = 5.0     # cadence des snapshots
    system_monitor_history_size: int = 720       # 720 × 5s = 1h
    system_monitor_top_n: int = 5                # top N processus par CPU

    # ── Voix Nova v1.9.5 ──────────────────────────────────────────────────────
    # Wake word texte (filtre post-STT). Voir voice_enhancers.py pour les limites.
    # Désactivé par défaut : Nova répond à tout. Si activé : Nova ne répond
    # que si la transcription commence par un des mots configurés.
    wake_word_enabled: bool = False
    wake_words: str = "nova,hey nova,ok nova"
    # Tuning Faster-Whisper
    stt_beam_size: int = 1          # 1 = rapide ; 5 = précis (3× plus lent)
    stt_num_workers: int = 1
    stt_max_audio_chars: int = 1000  # rejet automatique si transcript > N (hallucination)

    # v1.9.9 — Watchdog vocal (surveillance sessions bloquées)
    voice_watchdog_enabled: bool = True

    # ── Modification contrôlée de fichiers v1.9.7 ─────────────────────────────
    # ALLOWLIST stricte des dossiers où Nova peut MODIFIER des fichiers
    # (séparé de allowed_search_dirs qui n'est que lecture).
    # Vide par défaut = AUCUNE modification possible.
    allowed_write_dirs: str = ""
    # Dossier de stockage des backups automatiques (créé à la demande).
    # Si vide, fallback sur <cwd>/data/edit_backups/
    file_edit_backup_dir: str = ""
    # Taille max d'un fichier modifiable (octets). Au-delà : refus.
    file_edit_max_bytes: int = 1048576       # 1 Mo par défaut

    # ── Index sémantique local v1.9.8 ────────────────────────────────────────
    # ALLOWLIST stricte des dossiers indexables. Vide = aucune indexation.
    # Séparé de allowed_search_dirs et allowed_write_dirs (3 surfaces distinctes).
    allowed_index_dirs: str = ""
    # Taille max d'un fichier indexable (octets). Au-delà : skip.
    index_max_bytes_per_file: int = 2000000   # 2 Mo
    # Modèle d'embeddings local via Ollama. Doit être `ollama pull <name>` côté Oli.
    # nomic-embed-text recommandé (270 Mo). Si indispo : fallback BM25 lexical pur.
    embedding_model: str = "nomic-embed-text"
    # Modèle LLM pour résumés. Par défaut = même que llm_model.
    summary_model: str = ""

    whisper_model_size: str = "tiny"     # tiny=39M params ~1s/phrase CPU | small=244M (trop lent)
    enable_tts: bool = True
    enable_stt: bool = True

    # Paramètres STT performance
    stt_fast_mode: bool = True            # beam_size=1, without_timestamps — optimisations vitesse
    stt_warmup: bool = True               # chauffage modèle au démarrage (évite cold start)
    stt_slow_threshold_ms: int = 4000     # log [STT_TOO_SLOW] si dépassé

    # Paramètres mode vocal
    voice_fast_mode: bool = True          # réponses courtes et orales en mode vocal
    voice_silence_ms: int = 800           # silence détecté → fin d'énoncé
    voice_max_recording_sec: int = 15     # durée max enregistrement
    voice_min_recording_sec: float = 0.4  # durée min pour accepter un audio
    voice_keep_audio_files: int = 20      # nombre de fichiers audio à conserver

    # ── Caméra (optionnelle) ──────────────────────────────────────────────────
    # La caméra est entièrement optionnelle.  Si CAMERA_ENABLED=false ou si
    # aucune source n'est joignable, l'application démarre normalement.
    camera_enabled: bool = False               # CAMERA_ENABLED dans .env
    camera_source: str = "0"                   # "0","1","2" = index USB ; ou URL
    camera_type: str = "auto"                  # auto | usb | rtsp | http | file
    camera_rtsp_url: str = ""                  # rtsp://user:pass@ip:port/...
    camera_http_url: str = ""                  # http://ip:port/video ou /stream
    camera_reconnect_delay_sec: int = 5        # délai entre deux tentatives
    camera_frame_width: int = 640
    camera_frame_height: int = 480
    camera_fps_limit: int = 10                 # limite CPU (frames/sec lues)
    camera_save_snapshots: bool = False        # stockage snapshots sur disque
    camera_snapshot_dir: str = "data/snapshots"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def base_dir(self) -> Path:
        return BASE_DIR

    @property
    def static_path(self) -> Path:
        return self.base_dir / self.static_dir

    @property
    def log_path(self) -> Path:
        return self.base_dir / self.log_dir

    @property
    def data_path(self) -> Path:
        return self.base_dir / self.data_dir

    @property
    def notes_path(self) -> Path:
        return self.base_dir / self.notes_dir

    @property
    def uploads_path(self) -> Path:
        return self.base_dir / self.uploads_dir

    @property
    def memory_exports_path(self) -> Path:
        return self.base_dir / self.memory_exports_dir

    @property
    def export_path(self) -> Path:
        return self.base_dir / self.export_dir

    @property
    def voice_input_path(self) -> Path:
        return self.base_dir / self.voice_input_dir

    @property
    def voice_output_path(self) -> Path:
        return self.base_dir / self.voice_output_dir

    @property
    def app_log_path(self) -> Path:
        return self.base_dir / self.app_log_file

    @property
    def allowed_base_paths(self) -> list[Path]:
        items = [x.strip() for x in self.allowed_base_dirs.split(",") if x.strip()]
        return [self.base_dir / item for item in items]


settings = Settings()