from typing import Dict, List, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.core.conversation_engine import ConversationEngine
from app.core.export_engine import ExportEngine
from app.core.file_engine import FileEngine
from app.core.intent_parser import detect_intent
from app.core import tool_router
from app.core.llm import OllamaClient
from app.core.memory_engine import MemoryEngine
from app.core.note_engine import NoteEngine
from app.core.prompts import build_system_prompt
from app.core.safety import SafetyError
from app.db.models import Conversation, Message
from app.utils.logger import get_logger


logger = get_logger("assistant")


class AssistantService:
    def __init__(self) -> None:
        self.llm = OllamaClient()
        self.memory_engine = MemoryEngine()
        self.note_engine = NoteEngine()
        self.file_engine = FileEngine()
        self.export_engine = ExportEngine()
        self.conversation_engine = ConversationEngine()

    def _create_conversation(self, db: Session, first_message: str) -> Conversation:
        title = first_message.strip()[:60] or "Nouvelle conversation"
        conversation = Conversation(title=title)
        db.add(conversation)
        db.commit()
        db.refresh(conversation)
        return conversation

    def _get_or_create_conversation(
        self,
        db: Session,
        conversation_id: Optional[int],
        first_message: str,
    ) -> Conversation:
        if conversation_id is not None:
            conversation = db.query(Conversation).filter(Conversation.id == conversation_id).first()
            if conversation:
                return conversation
        return self._create_conversation(db, first_message)

    def _save_message(
        self,
        db: Session,
        conversation_id: int,
        role: str,
        content: str,
    ) -> Message:
        message = Message(
            conversation_id=conversation_id,
            role=role,
            content=content,
        )
        db.add(message)
        db.commit()
        db.refresh(message)
        return message

    def _load_context_messages(
        self,
        db: Session,
        conversation: Conversation,
        user_message: str,
    ) -> List[Dict[str, str]]:
        memory_texts = self.memory_engine.get_relevant_memory_texts(
            db=db,
            query=user_message,
            limit=5,
        )

        documents = self.file_engine.search_documents(
            db=db,
            query=user_message,
            limit=3,
        )
        document_texts = [
            f"{doc.filename} ({doc.path}) : {doc.content_preview[:800]}"
            for doc in documents
        ]

        db_messages = (
            db.query(Message)
            .filter(Message.conversation_id == conversation.id)
            .order_by(Message.id.desc())
            .limit(settings.max_context_messages)
            .all()
        )
        db_messages = list(reversed(db_messages))

        all_messages = self.conversation_engine.list_messages(db, conversation.id)
        summary = self.conversation_engine.maybe_refresh_summary(
            db=db,
            conversation=conversation,
            messages=all_messages,
            threshold=8,
        )

        messages: List[Dict[str, str]] = [
            {
                "role": "system",
                "content": build_system_prompt(
                    memory_items=memory_texts,
                    document_items=document_texts,
                    conversation_summary=summary,
                ),
            }
        ]

        for msg in db_messages:
            if msg.role in {"user", "assistant", "system"}:
                messages.append(
                    {
                        "role": msg.role,
                        "content": msg.content,
                    }
                )

        return messages

    def _handle_structured_intent(
        self,
        db: Session,
        conversation: Conversation,
        intent_data: Dict[str, object],
    ) -> Optional[str]:
        intent = intent_data.get("intent")

        if intent == "memory_add":
            memory = self.memory_engine.add_memory(
                db=db,
                content=str(intent_data.get("content", "")),
                category=str(intent_data.get("category", "general")),
                importance=int(intent_data.get("importance", 3)),
                source="chat_command",
            )
            return f"Mémoire enregistrée (id={memory.id}) : {memory.content}"

        if intent == "memory_search":
            query = str(intent_data.get("query", "")).strip()
            results = self.memory_engine.search_memories(db=db, query=query, limit=10)
            if not results:
                return f"Aucun souvenir trouvé pour : {query}"
            lines = ["Souvenirs trouvés :"]
            for item in results:
                lines.append(f"- [id={item.id}] ({item.category}, importance={item.importance}) {item.content}")
            return "\n".join(lines)

        if intent == "memory_list":
            results = self.memory_engine.list_memories(db=db, limit=20)
            if not results:
                return "Aucun souvenir enregistré."
            lines = ["Derniers souvenirs :"]
            for item in results:
                lines.append(f"- [id={item.id}] ({item.category}, importance={item.importance}) {item.content}")
            return "\n".join(lines)

        if intent == "memory_delete":
            memory_id = int(intent_data.get("memory_id", 0))
            deleted = self.memory_engine.delete_memory(db=db, memory_id=memory_id)
            return f"Mémoire supprimée : {memory_id}" if deleted else f"Mémoire introuvable : {memory_id}"

        if intent == "note_create":
            note = self.note_engine.create_note(
                db=db,
                title=str(intent_data.get("title", "")),
                content=str(intent_data.get("content", "")),
                tags=str(intent_data.get("tags", "")),
            )
            return f"Note créée (id={note.id}) : {note.title}"

        if intent == "note_list":
            notes = self.note_engine.list_notes(db=db, limit=50)
            if not notes:
                return "Aucune note enregistrée."
            lines = ["Notes disponibles :"]
            for note in notes:
                lines.append(f"- [id={note.id}] {note.title} | tags={note.tags}")
            return "\n".join(lines)

        if intent == "note_search":
            query = str(intent_data.get("query", "")).strip()
            notes = self.note_engine.search_notes(db=db, query=query, limit=20)
            if not notes:
                return f"Aucune note trouvée pour : {query}"
            lines = ["Notes trouvées :"]
            for note in notes:
                preview = note.content[:120].replace("\n", " ")
                lines.append(f"- [id={note.id}] {note.title} | {preview}")
            return "\n".join(lines)

        if intent == "note_read":
            note_id = int(intent_data.get("note_id", 0))
            note = self.note_engine.get_note_by_id(db=db, note_id=note_id)
            if not note:
                return f"Note introuvable : {note_id}"
            return f"Note {note.id} : {note.title}\nTags: {note.tags}\n---\n{note.content}"

        if intent == "note_update":
            note = self.note_engine.update_note(
                db=db,
                note_id=int(intent_data.get("note_id", 0)),
                title=str(intent_data.get("title", "")),
                content=str(intent_data.get("content", "")),
                tags=intent_data.get("tags"),
            )
            if not note:
                return "Note introuvable."
            return f"Note modifiée (id={note.id}) : {note.title}"

        if intent == "note_delete":
            note_id = int(intent_data.get("note_id", 0))
            deleted = self.note_engine.delete_note(db=db, note_id=note_id)
            return f"Note supprimée : {note_id}" if deleted else f"Note introuvable : {note_id}"

        if intent == "file_list":
            relative_dir = str(intent_data.get("relative_dir", "")).strip()
            items = self.file_engine.list_files(relative_dir)
            if not items:
                return f"Aucun élément trouvé dans : {relative_dir}"
            lines = [f"Contenu de {relative_dir} :"]
            for item in items:
                kind = "DIR" if item["is_dir"] else "FILE"
                lines.append(f"- [{kind}] {item['relative_path']}")
            return "\n".join(lines)

        if intent == "file_read":
            relative_path = str(intent_data.get("relative_path", "")).strip()
            data = self.file_engine.read_file(relative_path)
            return f"Lecture du fichier : {data['relative_path']}\n--- DÉBUT ---\n{data['content']}\n--- FIN ---"

        if intent == "file_index":
            relative_path = str(intent_data.get("relative_path", "")).strip()
            doc = self.file_engine.index_file(db=db, relative_path=relative_path)
            return f"Document indexé (id={doc.id}) : {doc.filename} | {doc.path}"

        if intent == "document_list":
            docs = self.file_engine.list_indexed_documents(db=db, limit=50)
            if not docs:
                return "Aucun document indexé."
            lines = ["Documents indexés :"]
            for doc in docs:
                lines.append(f"- [id={doc.id}] {doc.filename} | {doc.path}")
            return "\n".join(lines)

        if intent == "document_search":
            query = str(intent_data.get("query", "")).strip()
            docs = self.file_engine.search_documents(db=db, query=query, limit=20)
            if not docs:
                return f"Aucun document trouvé pour : {query}"
            lines = ["Documents trouvés :"]
            for doc in docs:
                preview = doc.content_preview[:160].replace("\n", " ")
                lines.append(f"- [id={doc.id}] {doc.filename} | {doc.path} | {preview}")
            return "\n".join(lines)

        if intent == "conversation_list":
            conversations = (
                db.query(Conversation)
                .order_by(Conversation.updated_at.desc(), Conversation.id.desc())
                .limit(50)
                .all()
            )
            if not conversations:
                return "Aucune conversation enregistrée."
            lines = ["Conversations :"]
            for conv in conversations:
                extra = f" | résumé présent" if (conv.summary or "").strip() else ""
                lines.append(f"- [id={conv.id}] {conv.title}{extra}")
            return "\n".join(lines)

        if intent == "conversation_read":
            conv_id = int(intent_data.get("conversation_id", 0))
            target = db.query(Conversation).filter(Conversation.id == conv_id).first()
            if not target:
                return f"Conversation introuvable : {conv_id}"
            messages = (
                db.query(Message)
                .filter(Message.conversation_id == conv_id)
                .order_by(Message.id.asc())
                .all()
            )
            lines = [f"Conversation {target.id} : {target.title}"]
            if (target.summary or "").strip():
                lines.append(f"Résumé: {target.summary}")
            for msg in messages:
                lines.append(f"[{msg.role}] {msg.content}")
            return "\n".join(lines)

        if intent == "export_memories":
            path = self.export_engine.export_memories(db)
            return f"Export mémoires créé : {path}"

        if intent == "export_notes":
            path = self.export_engine.export_notes(db)
            return f"Export notes créé : {path}"

        if intent == "export_conversations":
            path = self.export_engine.export_conversations(db)
            return f"Export conversations créé : {path}"

        if intent in {"invalid_note_format", "invalid_note_update_format"}:
            return str(intent_data.get("error", "Commande invalide."))

        return None

    def chat(
        self,
        db: Session,
        user_message: str,
        conversation_id: Optional[int] = None,
    ) -> Dict[str, object]:
        cleaned_message = user_message.strip()
        if not cleaned_message:
            raise ValueError("Le message utilisateur est vide.")

        logger.info("Message reçu | conversation_id=%s | contenu=%s", conversation_id, cleaned_message[:200])

        conversation = self._get_or_create_conversation(
            db=db,
            conversation_id=conversation_id,
            first_message=cleaned_message,
        )

        self._save_message(
            db=db,
            conversation_id=conversation.id,
            role="user",
            content=cleaned_message,
        )

        # ── Tool router (outils agentiques) ──────────────────────────────────
        # Priorité : outils déterministes > intents structurés > LLM
        tool_intent = tool_router.route(cleaned_message)
        if tool_intent is not None:
            tool_result = tool_router.execute(tool_intent)
            tool_reply  = tool_result.get("text", "Je n'ai pas pu obtenir cette information.")
            self._save_message(
                db=db,
                conversation_id=conversation.id,
                role="assistant",
                content=tool_reply,
            )
            self.conversation_engine.update_conversation_timestamp(db, conversation)
            logger.info("Outil exécuté | tool=%s | ok=%s", tool_intent.get("tool"), tool_result.get("ok"))
            return {
                "conversation_id": conversation.id,
                "reply": tool_reply,
                "model": f"tool:{tool_intent.get('tool')}",
                "tool_used": tool_intent.get("tool"),
                "tool_ok": tool_result.get("ok", False),
            }
        # ─────────────────────────────────────────────────────────────────────

        intent_data = detect_intent(cleaned_message)

        try:
            structured_reply = self._handle_structured_intent(
                db=db,
                conversation=conversation,
                intent_data=intent_data,
            )
        except (SafetyError, FileNotFoundError, NotADirectoryError, IsADirectoryError, ValueError) as exc:
            structured_reply = f"Erreur outil local : {str(exc)}"
            logger.warning("Erreur outil local | %s", str(exc))

        if structured_reply is not None:
            self.conversation_engine.update_conversation_timestamp(db, conversation)
            self._save_message(
                db=db,
                conversation_id=conversation.id,
                role="assistant",
                content=structured_reply,
            )
            logger.info("Réponse structurée envoyée | conversation_id=%s", conversation.id)
            return {
                "conversation_id": conversation.id,
                "reply": structured_reply,
                "model": "local-structured-handler",
            }

        llm_messages = self._load_context_messages(
            db=db,
            conversation=conversation,
            user_message=cleaned_message,
        )
        assistant_reply = self.llm.chat(llm_messages)

        self._save_message(
            db=db,
            conversation_id=conversation.id,
            role="assistant",
            content=assistant_reply,
        )
        self.conversation_engine.update_conversation_timestamp(db, conversation)

        logger.info("Réponse LLM envoyée | conversation_id=%s | model=%s", conversation.id, settings.ollama_model)

        return {
            "conversation_id": conversation.id,
            "reply": assistant_reply,
            "model": settings.ollama_model,
        }