"""
assistant_extension.py — Assistant central V4.

Tous les événements de surveillance passent par decide(event, context).
Retourne toujours un dict {action, message, tts, notify, reasoning, source}.
Fallback rule-based si LLM indisponible — jamais de crash.
"""

from typing import Dict, Optional
from sqlalchemy.orm import Session

from app.core.assistant import AssistantService
from app.core.monitoring_engine import AlertType
from app.utils.logger import get_logger

logger = get_logger("assistant_extension")


# Messages TTS par type d'événement — adapté pour personne âgée
_TTS_MESSAGES: Dict[str, str] = {
    AlertType.FALL.value: (
        "Tu es tombé ? Réponds-moi s'il te plaît."          # géré par monitoring_engine
    ),
    AlertType.FALL_CONFIRMED.value: (
        "Bien, je suis là si vous avez besoin. Tout va bien ?"
    ),
    AlertType.FALL_ESCALATED.value: (
        "Je n'ai pas de réponse. J'appelle les secours."    # géré par monitoring_engine
    ),
    AlertType.PROLONGED_SILENCE.value: (
        "Bonjour ! Je ne vous ai pas entendu depuis un moment. Tout va bien ?"
    ),
    AlertType.PROLONGED_ABSENCE.value: (
        "Je ne vous vois plus depuis un moment. Êtes-vous là ?"
    ),
    AlertType.INACTIVITY.value: (
        "Bonjour ! Je suis là si vous avez besoin. Tout va bien ?"
    ),
    AlertType.MANUAL.value: (
        "J'ai reçu votre appel. Restez calme, les secours sont prévenus."  # géré par engine
    ),
    AlertType.TEST.value: "",
}

# Règles de décision par type d'événement
# Structure : {action, tts, notify, reasoning}
# "message" est résolu dynamiquement depuis _TTS_MESSAGES
_RULES: Dict[str, Dict] = {
    AlertType.FALL.value: {
        "action":    "confirm",
        "tts":       False,    # TTS géré par monitoring_engine.signal_fall()
        "notify":    False,    # attendre la confirmation avant de notifier
        "reasoning": "Chute détectée — fenêtre de confirmation ouverte",
    },
    AlertType.FALL_CONFIRMED.value: {
        "action":    "speak",
        "tts":       True,
        "notify":    False,    # réponse reçue — pas besoin d'alerter la famille
        "reasoning": "Chute confirmée benigne — soutien vocal",
    },
    AlertType.FALL_ESCALATED.value: {
        "action":    "escalate",
        "tts":       False,    # TTS géré par monitoring_engine
        "notify":    True,     # pas de réponse → alerter famille
        "reasoning": "Chute sans réponse — escalade immédiate",
    },
    AlertType.PROLONGED_SILENCE.value: {
        "action":    "speak",
        "tts":       False,    # TTS géré par _maybe_alert_silence()
        "notify":    False,
        "reasoning": "Silence prolongé — TTS déjà envoyé",
    },
    AlertType.PROLONGED_ABSENCE.value: {
        "action":    "alert",
        "tts":       True,
        "notify":    True,
        "reasoning": "Absence prolongée — notification contact",
    },
    AlertType.INACTIVITY.value: {
        "action":    "speak",
        "tts":       True,
        "notify":    False,
        "reasoning": "Inactivité — rappel de présence",
    },
    AlertType.MANUAL.value: {
        "action":    "escalate",
        "tts":       False,    # TTS géré par signal_manual_emergency()
        "notify":    True,
        "reasoning": "Urgence manuelle — notification immédiate",
    },
    AlertType.TEST.value: {
        "action":    "log",
        "tts":       False,
        "notify":    False,
        "reasoning": "Test — aucune action",
    },
}

# Valeur par défaut pour un événement inconnu
_DEFAULT_RULE = {
    "action":    "log",
    "tts":       False,
    "notify":    False,
    "reasoning": "Événement inconnu",
}


class ExtendedAssistantService(AssistantService):
    """
    Étend AssistantService avec decide().
    chat() est identique, non modifié.
    decide() est le point d'entrée central pour tous les événements surveillance.
    """

    CARE_PROMPT = (
        "Tu es un assistant de compagnie bienveillant pour une personne âgée vivant seule.\n"
        "Règles absolues :\n"
        "- Calme et rassurant, jamais alarmiste\n"
        "- Phrases courtes (max 2), mots simples\n"
        "- Proposer une action concrète si nécessaire\n"
        "- Si danger réel : rester factuel et direct\n"
    )

    def decide(
        self,
        db: Session,
        event: str,
        context: Optional[Dict] = None,
    ) -> Dict:
        """
        Point d'entrée central — tous les événements passent ici.
        Toujours disponible même si LLM hors ligne.
        Retourne : {action, message, tts, notify, reasoning, source}
        """
        ctx    = context or {}
        result = self._apply_rule(event, ctx)
        result["source"] = "rule-based"
        logger.info("decide() | event=%s | action=%s | tts=%s | notify=%s",
                    event, result["action"], result["tts"], result["notify"])
        return result

    def decide_with_llm(
        self,
        db: Session,
        event: str,
        context: Optional[Dict] = None,
    ) -> Dict:
        """
        Version LLM avec fallback sur decide().
        Jamais utilisée pour FALL, FALL_ESCALATED, MANUAL (urgences → règle immédiate).
        """
        ctx = context or {}

        # Urgences : règle immédiate, pas de LLM
        if event in (AlertType.FALL.value, AlertType.FALL_ESCALATED.value, AlertType.MANUAL.value):
            result         = self._apply_rule(event, ctx)
            result["source"] = "rule-based (urgence)"
            return result

        # Tentative LLM
        base = self._apply_rule(event, ctx)
        try:
            memories = self.memory_engine.get_relevant_memory_texts(
                db=db, query=event, limit=3
            )
            mem_block = (
                "\n".join(f"- {m}" for m in memories)
                if memories else "Aucune mémoire disponible."
            )
            prompt = (
                f"{self.CARE_PROMPT}\n"
                f"Événement : {event}\n"
                f"Contexte : {ctx}\n"
                f"Ce que je sais de la personne :\n{mem_block}\n\n"
                "Génère un message vocal (2 phrases max). Message uniquement, sans intro."
            )
            llm_msg = self.llm.chat([{"role": "user", "content": prompt}])
            if llm_msg and len(llm_msg.strip()) > 10:
                base["message"] = llm_msg.strip()
                base["source"]  = "llm"
            else:
                base["source"] = "rule-based (llm vide)"
        except Exception as exc:
            logger.warning("LLM indisponible | %s", exc)
            base["source"] = "rule-based (llm error)"

        return base

    def _apply_rule(self, event: str, ctx: Dict) -> Dict:
        """
        Applique la règle fixe pour cet événement.
        Retourne toujours un dict complet.
        """
        rule    = _RULES.get(event, _DEFAULT_RULE)
        message = _TTS_MESSAGES.get(event, "")

        # Enrichissement contextuel
        if "minutes" in ctx and message:
            message = message.replace("un moment", f"{round(ctx['minutes'])} minutes")

        return {
            "action":    rule["action"],
            "message":   message,
            "tts":       rule["tts"],
            "notify":    rule["notify"],
            "reasoning": rule["reasoning"],
        }


# Singleton
extended_assistant = ExtendedAssistantService()
