"""
comms_engine.py — Envoi de notifications d'urgence.
V2.1 — Corrections :
  - validate_config() avant envoi — message clair si incomplet
  - Masquage password dans les logs
  - test() retourne détail par canal
  - _log_to_file() toujours actif (fallback garanti)
  - Pas de KeyError sur cfg manquante
"""

import json
import smtplib
import threading
import urllib.request
from datetime import datetime, timezone
from email.mime.text import MIMEText
from typing import List, Optional, Tuple

from app.core.monitoring_engine import Alert, AlertLevel
from app.utils.logger import get_logger

logger = get_logger("comms_engine")


class CommsConfigError(ValueError):
    """Configuration comms incomplète ou invalide."""


class CommsEngine:
    """
    Envoie des alertes par :
      1. Journal fichier  (toujours actif — fallback garanti)
      2. Email SMTP       (si configuré et validé)
      3. Webhook HTTP     (si configuré et validé)

    Appeler configure() avant notify() pour activer email/webhook.
    Sans configuration, seul le log fichier fonctionne.
    """

    def __init__(self) -> None:
        self._lock    = threading.Lock()
        self._history: List[dict] = []
        self._config:  dict       = {}

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def configure(self, config: dict) -> None:
        """
        Accepte un dict de configuration.
        Valide les champs requis et logue (sans exposer les mots de passe).
        """
        with self._lock:
            self._config = config

        email_cfg   = config.get("email",   {})
        webhook_cfg = config.get("webhook", {})

        logger.info(
            "CommsEngine configuré | email_enabled=%s | smtp_host=%s | recipient=%s | webhook_enabled=%s",
            email_cfg.get("enabled",   False),
            email_cfg.get("smtp_host", "—"),
            email_cfg.get("recipient", "—"),
            webhook_cfg.get("enabled", False),
            # password NON loggué intentionnellement
        )

    def validate_email_config(self) -> Tuple[bool, str]:
        """Retourne (ok, message). Appeler avant envoi email."""
        cfg = self._config.get("email", {})
        if not cfg.get("enabled"):
            return False, "Email non activé dans la configuration."
        for field in ("smtp_host", "smtp_user", "smtp_password", "recipient"):
            if not cfg.get(field):
                return False, f"Champ manquant pour email : {field}"
        return True, "ok"

    def validate_webhook_config(self) -> Tuple[bool, str]:
        """Retourne (ok, message)."""
        cfg = self._config.get("webhook", {})
        if not cfg.get("enabled"):
            return False, "Webhook non activé dans la configuration."
        if not cfg.get("url"):
            return False, "URL webhook manquante."
        return True, "ok"

    # ------------------------------------------------------------------
    # Notify
    # ------------------------------------------------------------------

    def notify(self, alert: Alert) -> dict:
        """
        Envoie une notification pour une alerte.
        Toujours log fichier. Email/webhook si configurés et valides.
        Retourne le résultat par canal.
        """
        results = {
            "alert_type":  alert.type.value,
            "alert_level": alert.level.value,
            "timestamp":   datetime.now(timezone.utc).isoformat(),
            "channels":    {},
        }

        # Canal 1 : log fichier — toujours
        self._log_to_file(alert)
        results["channels"]["log"] = "ok"

        # Canal 2 : email
        email_ok, email_msg = self.validate_email_config()
        if email_ok and alert.level in (AlertLevel.WARNING, AlertLevel.URGENT, AlertLevel.CRITICAL):
            try:
                self._send_email(alert, self._config["email"])
                results["channels"]["email"] = "ok"
                logger.info("Email envoyé | type=%s", alert.type.value)
            except Exception as exc:
                results["channels"]["email"] = f"error: {exc}"
                logger.error("Erreur email | %s", exc)
        elif not email_ok:
            results["channels"]["email"] = f"skipped: {email_msg}"

        # Canal 3 : webhook
        webhook_ok, webhook_msg = self.validate_webhook_config()
        if webhook_ok:
            try:
                self._send_webhook(alert, self._config["webhook"])
                results["channels"]["webhook"] = "ok"
                logger.info("Webhook envoyé | type=%s", alert.type.value)
            except Exception as exc:
                results["channels"]["webhook"] = f"error: {exc}"
                logger.error("Erreur webhook | %s", exc)
        elif not webhook_ok:
            results["channels"]["webhook"] = f"skipped: {webhook_msg}"

        with self._lock:
            self._history.append(results)
            if len(self._history) > 200:
                self._history = self._history[-200:]

        return results

    def get_history(self, limit: int = 50) -> List[dict]:
        with self._lock:
            return list(reversed(self._history[-limit:]))

    def test(self) -> dict:
        """
        Envoie une alerte de test sur tous les canaux configurés.
        Retourne le détail par canal avec les erreurs de config explicites.
        """
        from app.core.monitoring_engine import Alert, AlertType, AlertLevel
        test_alert = Alert(
            type    = AlertType.TEST,
            level   = AlertLevel.INFO,
            message = "🧪 Test de notification — Le système de communication fonctionne.",
        )

        result = self.notify(test_alert)

        # Ajouter le statut de configuration pour le feedback UI
        email_ok,   email_msg   = self.validate_email_config()
        webhook_ok, webhook_msg = self.validate_webhook_config()
        result["config_status"] = {
            "email":   {"configured": email_ok,   "detail": email_msg},
            "webhook": {"configured": webhook_ok, "detail": webhook_msg},
            "log":     {"configured": True,        "detail": "Toujours actif"},
        }
        return result

    # ------------------------------------------------------------------
    # Channels (privés)
    # ------------------------------------------------------------------

    def _log_to_file(self, alert: Alert) -> None:
        """Écriture dans data/alerts.log — fallback garanti, ne lève jamais."""
        try:
            from app.config import settings
            log_path = settings.data_path / "alerts.log"
            resident = self._config.get("resident_name", "Résident")
            line = (
                f"[{alert.timestamp.isoformat()}] "
                f"[{alert.level.value.upper()}] "
                f"[{alert.type.value}] "
                f"{resident} — {alert.message}\n"
            )
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception as exc:
            logger.error("Erreur log alerte fichier | %s", exc)

    def _send_email(self, alert: Alert, cfg: dict) -> None:
        resident = self._config.get("resident_name", "Le résident")
        contact  = self._config.get("emergency_contact_name", "Contact d'urgence")

        subject = f"[{alert.level.value.upper()}] Alerte assistant — {resident}"
        body = (
            f"Bonjour {contact},\n\n"
            f"L'assistant personnel de {resident} a émis une alerte :\n\n"
            f"  Type     : {alert.type.value}\n"
            f"  Niveau   : {alert.level.value}\n"
            f"  Message  : {alert.message}\n"
            f"  Heure    : {alert.timestamp.strftime('%d/%m/%Y %H:%M:%S')}\n"
        )
        if alert.extra:
            body += f"\n  Détails  : {json.dumps(alert.extra, ensure_ascii=False)}\n"
        body += "\n\nCe message a été envoyé automatiquement par l'assistant personnel.\n"

        msg           = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"]    = f"{cfg.get('sender_name', 'Assistant')} <{cfg['smtp_user']}>"
        msg["To"]      = cfg["recipient"]

        # password accédé directement depuis cfg, jamais loggué
        with smtplib.SMTP(cfg["smtp_host"], cfg.get("smtp_port", 587), timeout=10) as server:
            server.ehlo()
            server.starttls()
            server.login(cfg["smtp_user"], cfg["smtp_password"])
            server.sendmail(cfg["smtp_user"], [cfg["recipient"]], msg.as_string())

    def _send_webhook(self, alert: Alert, cfg: dict) -> None:
        resident = self._config.get("resident_name", "Résident")
        payload  = {
            "text":     f"🚨 *{alert.level.value.upper()}* — {resident} : {alert.message}",
            "alert":    alert.to_dict(),
            "resident": resident,
        }
        data = json.dumps(payload, default=str).encode("utf-8")
        req  = urllib.request.Request(
            cfg["url"],
            data    = data,
            headers = {"Content-Type": "application/json"},
            method  = cfg.get("method", "POST"),
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            status = resp.getcode()
            if status not in (200, 201, 202, 204):
                raise RuntimeError(f"Webhook HTTP {status}")


# Singleton
comms_engine = CommsEngine()
