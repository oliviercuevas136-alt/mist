from datetime import datetime, timezone
from typing import List

from sqlalchemy.orm import Session

from app.db.models import Conversation, Message


class ConversationEngine:
    def list_messages(self, db: Session, conversation_id: int) -> List[Message]:
        return (
            db.query(Message)
            .filter(Message.conversation_id == conversation_id)
            .order_by(Message.id.asc())
            .all()
        )

    def update_conversation_timestamp(self, db: Session, conversation: Conversation) -> Conversation:
        conversation.updated_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(conversation)
        return conversation

    def build_conversation_summary_text(self, messages: List[Message], max_items: int = 12) -> str:
        if not messages:
            return ""

        selected = messages[-max_items:]
        lines = []
        for msg in selected:
            role = "Utilisateur" if msg.role == "user" else "Assistant"
            content = (msg.content or "").strip().replace("\n", " ")
            content = content[:200]
            lines.append(f"{role}: {content}")

        return "\n".join(lines)

    def maybe_refresh_summary(
        self,
        db: Session,
        conversation: Conversation,
        messages: List[Message],
        threshold: int = 8,
    ) -> str:
        if len(messages) < threshold:
            return conversation.summary or ""

        summary = self.build_conversation_summary_text(messages)
        conversation.summary = summary
        conversation.updated_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(conversation)
        return summary