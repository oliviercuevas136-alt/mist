"""
core_decision.py — Logique de décision centrale du CORE.

Consomme les événements du EventBus et décide :
    - IGNORE              : log seul, rien d'autre
    - REMEMBER            : log + persistance dans le journal central
    - NOTIFY              : log + affichage utilisateur (TTS / chat / UI)
    - REQUEST_CONFIRM     : log + demande explicite de confirmation
    - TRIGGER_ACTION      : log + déclenchement d'une action autorisée

Les modules n'agissent JAMAIS directement : ils signalent via le bus,
le CORE décide. Tout ce qui sort du CORE est tracé.

Cette logique est volontairement RULE-BASED (déterministe) pour rester :
  - testable
  - prévisible
  - non dépendant d'un LLM (qui peut être indisponible)

Une couche optionnelle (extended_assistant.decide() existant) peut être
appelée plus tard pour les cas ambigus, mais le fallback est garanti.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from app.core.event_bus import CoreEvent, EventLevel, CoreDecision
from app.utils.logger import get_logger

logger = get_logger("core_decision")


@dataclass
class Decision:
    """Trace d'une décision prise par le CORE."""
    event_id:        str
    event_type:      str
    event_level:     str
    decision:        CoreDecision
    reason:          str
    action_name:     Optional[str] = None
    action_payload:  Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["decision"] = self.decision.value
        return d


# ── Liste blanche d'actions autorisées ─────────────────────────────────────
_ALLOWED_AUTO_ACTIONS: Dict[str, str] = {
    "vision.fall":         "trigger_emergency_protocol",
    "system.shutdown":     "graceful_shutdown",
}

_REQUIRES_CONFIRMATION = {
    "file.delete_requested",
    "file.modify_requested",
    "camera.snapshot_share",
    "user.action_proposed",
}

_REMEMBER_TYPES = {
    "vision.fall", "vision.absence_prolonged",
    "user.command", "user.confirmation",
    "system.start", "system.stop",
    "comms.sent",
}


class CoreDecisionEngine:
    """
    Moteur de décision rule-based.
    Méthode unique : decide(event) -> Decision.
    """

    def __init__(self) -> None:
        self._history: List[Decision] = []
        self._history_cap = 200

    def decide(self, event: CoreEvent) -> Decision:
        d = self._apply_rules(event)
        self._record(d)
        logger.info(
            "[CORE_DECISION] event=%s level=%s prio=%s → %s (%s)",
            event.type, event.level.value, event.priority,
            d.decision.value, d.reason,
        )
        return d

    def _apply_rules(self, event: CoreEvent) -> Decision:
        # Règle 1 — CRITICAL → toujours notifier + déclencher si auto-action listée
        if event.level == EventLevel.CRITICAL:
            action = _ALLOWED_AUTO_ACTIONS.get(event.type)
            if action:
                return Decision(
                    event_id=event.id, event_type=event.type,
                    event_level=event.level.value,
                    decision=CoreDecision.EXECUTE_AUTHORIZED_ACTION,
                    reason=f"critical+whitelisted action {action}",
                    action_name=action,
                    action_payload=dict(event.payload),
                )
            return Decision(
                event_id=event.id, event_type=event.type,
                event_level=event.level.value,
                decision=CoreDecision.NOTIFY,
                reason="critical → notify",
            )

        # Règle 2 — requires_action ou type listé pour confirmation
        if event.requires_action or event.type in _REQUIRES_CONFIRMATION:
            return Decision(
                event_id=event.id, event_type=event.type,
                event_level=event.level.value,
                decision=CoreDecision.ASK_CONFIRMATION,
                reason="requires_action ou liste confirmation",
            )

        # Règle 3 — HIGH → notifier
        if event.level == EventLevel.HIGH:
            return Decision(
                event_id=event.id, event_type=event.type,
                event_level=event.level.value,
                decision=CoreDecision.NOTIFY,
                reason="high → notify",
            )

        # Règle 4 — type à mémoriser
        if event.type in _REMEMBER_TYPES:
            return Decision(
                event_id=event.id, event_type=event.type,
                event_level=event.level.value,
                decision=CoreDecision.MEMORIZE,
                reason="type listé mémorisation",
            )

        # Règle 5 — MEDIUM → mémoriser
        if event.level == EventLevel.MEDIUM:
            return Decision(
                event_id=event.id, event_type=event.type,
                event_level=event.level.value,
                decision=CoreDecision.MEMORIZE,
                reason="medium → memorize",
            )

        # Règle 6 — INFO/LOW → log seul (pas ignore complet, on garde trace)
        # Nuance vs ignore : log = entrée journal mais pas d'action ; ignore = vraiment rien.
        # On choisit LOG par défaut pour les events de niveau bas → traçabilité.
        return Decision(
            event_id=event.id, event_type=event.type,
            event_level=event.level.value,
            decision=CoreDecision.LOG,
            reason="low priority → log seul",
        )

    # ── Historique ─────────────────────────────────────────────────────────

    def _record(self, d: Decision) -> None:
        self._history.append(d)
        if len(self._history) > self._history_cap:
            self._history = self._history[-self._history_cap:]

    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        return [d.to_dict() for d in self._history[-limit:]]


# ── Singleton ──────────────────────────────────────────────────────────────

_engine: Optional[CoreDecisionEngine] = None


def get_decision_engine() -> CoreDecisionEngine:
    global _engine
    if _engine is None:
        _engine = CoreDecisionEngine()
    return _engine
