"""
event_bus.py — Bus d'événements central du CORE Nova.

Rôle : standardiser et tracer TOUS les événements qui transitent dans Nova.
Les modules (vision_engine, monitoring_engine, voice_engine, file_search, etc.)
publient des Event ; le CORE Orchestrator consomme et décide.

Principes :
  - LES MODULES OBSERVENT ET SIGNALENT (publish)
  - LE CORE DÉCIDE (subscribe via Orchestrator)
  - Aucun module ne décide d'une action à la place du CORE.

Architecture :
                ┌──────────────┐
                │  Orchestrator│  ← seul décisionnaire
                └──────▲───────┘
                       │ subscribe(handler)
        ┌──────────────┴──────────────┐
        │       EventBus              │
        │   - queue (FIFO + prio)     │
        │   - cooldown anti-spam      │
        │   - journal central         │
        │   - log structuré           │
        └──▲─────▲─────▲─────▲────────┘
           │ publish() depuis :
   vision_engine  monitoring  voice  file_search  …

Thread-safe via threading.RLock.
Aucune dépendance externe.
"""

from __future__ import annotations

import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Callable, Deque, Dict, List, Optional

from app.utils.logger import get_logger

logger = get_logger("event_bus")


# ── Niveaux de priorité (consigne) ─────────────────────────────────────────

class EventLevel(str, Enum):
    INFO     = "info"
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    CRITICAL = "critical"


_LEVEL_ORDER = {
    EventLevel.INFO:     0,
    EventLevel.LOW:      1,
    EventLevel.MEDIUM:   2,
    EventLevel.HIGH:     3,
    EventLevel.CRITICAL: 4,
}


# ── Décisions possibles du CORE (consigne) ─────────────────────────────────
#
# Noms canoniques (consigne v1.9.2). Les anciens noms (REMEMBER, REQUEST_CONFIRM,
# TRIGGER_ACTION) sont conservés comme alias pour compat ascendante stricte.

class CoreDecision(str, Enum):
    IGNORE                     = "ignore"
    LOG                        = "log"
    MEMORIZE                   = "memorize"
    NOTIFY                     = "notify"
    ASK_CONFIRMATION           = "ask_confirmation"
    EXECUTE_AUTHORIZED_ACTION  = "execute_authorized_action"

    # ── Alias historiques (NE PAS UTILISER en nouveau code) ──
    # Garantissent que les anciens handlers continuent de fonctionner.
    REMEMBER         = "memorize"             # alias → MEMORIZE
    REQUEST_CONFIRM  = "ask_confirmation"     # alias → ASK_CONFIRMATION
    TRIGGER_ACTION   = "execute_authorized_action"  # alias → EXECUTE_AUTHORIZED_ACTION


# ── Événement standardisé (consigne v1.9.2) ────────────────────────────────

@dataclass
class CoreEvent:
    """
    Format CANONIQUE pour tout événement transitant dans Nova.
    Point d'entrée unique : Orchestrator.submit_event(CoreEvent).

    Champs (consigne) :
        type             — identifiant court (ex: "vision.fall", "voice.activity")
        source           — module émetteur (ex: "vision_engine")
        level            — EventLevel : info/low/medium/high/critical
        message          — phrase courte humaine
        timestamp        — secondes epoch (auto)
        payload          — données structurées arbitraires
        requires_action  — True si une décision CORE explicite est requise
        priority         — score numérique 0..100 ; surchargeable indépendamment
                           du level pour cas particuliers. Défaut : aligné sur level.
        id               — UUID court (auto)
    """
    type:            str
    source:          str
    level:           EventLevel
    message:         str = ""
    payload:         Dict[str, Any] = field(default_factory=dict)
    requires_action: bool           = False
    timestamp:       float          = field(default_factory=time.time)
    priority:        Optional[int]  = None
    id:              str            = field(default_factory=lambda: uuid.uuid4().hex[:12])

    def __post_init__(self):
        # Si priority n'est pas fournie, déduire du level :
        # info=10 low=20 medium=40 high=70 critical=95
        if self.priority is None:
            self.priority = _LEVEL_DEFAULT_PRIORITY[self.level]
        # Clamp 0..100
        self.priority = max(0, min(100, int(self.priority)))

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["level"] = self.level.value
        return d


# Alias rétrocompatible : ancien code utilisant Event continue de marcher.
# Event est désormais un alias direct de CoreEvent.
Event = CoreEvent


_LEVEL_DEFAULT_PRIORITY = {
    EventLevel.INFO:     10,
    EventLevel.LOW:      20,
    EventLevel.MEDIUM:   40,
    EventLevel.HIGH:     70,
    EventLevel.CRITICAL: 95,
}


# ── Anti-spam / cooldown (consigne) ────────────────────────────────────────

class CooldownTracker:
    """
    Empêche la diffusion répétée d'un MÊME type d'événement pendant
    une fenêtre `cooldown_sec`. Différencié par clé (type+source par défaut).
    Les niveaux CRITICAL ne sont JAMAIS bloqués (sécurité).
    """

    def __init__(self, default_cooldown_sec: float = 5.0):
        self._last_seen: Dict[str, float] = {}
        self._lock = threading.Lock()
        self._default = default_cooldown_sec
        # Cooldowns spécifiques par préfixe de type
        self._overrides: Dict[str, float] = {
            "voice.activity":  2.0,
            "vision.presence": 30.0,
            "info":            10.0,
        }

    def _cooldown_for(self, event_type: str) -> float:
        for prefix, sec in self._overrides.items():
            if event_type.startswith(prefix):
                return sec
        return self._default

    def should_emit(self, event: CoreEvent) -> bool:
        if event.level == EventLevel.CRITICAL:
            return True
        key = f"{event.type}|{event.source}"
        cooldown = self._cooldown_for(event.type)
        with self._lock:
            last = self._last_seen.get(key, 0.0)
            now = time.time()
            if now - last < cooldown:
                return False
            self._last_seen[key] = now
            return True


# ── Bus principal ──────────────────────────────────────────────────────────

class EventBus:
    """
    Bus central — publish/subscribe avec :
      - file FIFO par priorité (CRITICAL traitée avant INFO)
      - dispatch synchrone vers handlers enregistrés
      - journal central des N derniers événements (capé)
      - anti-spam par cooldown
      - logs structurés [EVENT_BUS]
    """

    def __init__(self, journal_size: int = 500):
        self._handlers:  List[Callable[[Event], None]] = []
        self._lock = threading.RLock()
        self._cooldown = CooldownTracker()
        self._journal: Deque[CoreEvent] = deque(maxlen=journal_size)
        # File priorisée : niveau CRITICAL → traitée d'abord
        # Implémentée comme 5 deques (1 par niveau).
        self._queues: Dict[EventLevel, Deque[CoreEvent]] = {
            lvl: deque() for lvl in EventLevel
        }
        # Stats
        self._stats = {
            "published":    0,
            "dropped_spam": 0,
            "processed":    0,
            "handler_errors": 0,
        }

    # ── Subscription ───────────────────────────────────────────────────────

    def subscribe(self, handler: Callable[[Event], None]) -> None:
        """Enregistre un handler appelé pour chaque événement traité."""
        with self._lock:
            if handler not in self._handlers:
                self._handlers.append(handler)
        logger.info("[EVENT_BUS] handler enregistré : %s", getattr(handler, "__name__", repr(handler)))

    def unsubscribe(self, handler: Callable[[Event], None]) -> None:
        with self._lock:
            if handler in self._handlers:
                self._handlers.remove(handler)

    # ── Publication ────────────────────────────────────────────────────────

    def publish(self, event: CoreEvent, dispatch: bool = True) -> bool:
        """
        Publie un événement. Retourne True si accepté, False si bloqué
        par cooldown anti-spam.

        Si dispatch=True (défaut), les handlers sont appelés immédiatement
        en séquence (synchrone). dispatch=False = mise en file uniquement.
        """
        # Cooldown
        if not self._cooldown.should_emit(event):
            with self._lock:
                self._stats["dropped_spam"] += 1
            logger.debug("[EVENT_BUS] DROPPED (cooldown) type=%s source=%s",
                         event.type, event.source)
            return False

        with self._lock:
            self._stats["published"] += 1
            self._queues[event.level].append(event)
            self._journal.append(event)

        logger.info(
            "[EVENT_BUS] PUBLISH type=%s source=%s level=%s requires_action=%s id=%s",
            event.type, event.source, event.level.value,
            event.requires_action, event.id,
        )

        if dispatch:
            self._drain()
        return True

    # ── Helpers de publication ─────────────────────────────────────────────

    def publish_simple(
        self,
        type: str,
        source: str,
        message: str = "",
        level: EventLevel = EventLevel.INFO,
        payload: Optional[Dict[str, Any]] = None,
        requires_action: bool = False,
    ) -> bool:
        return self.publish(Event(
            type=type, source=source, message=message,
            level=level, payload=payload or {},
            requires_action=requires_action,
        ))

    # ── Drain — appel handlers par ordre de priorité ────────────────────────

    def _drain(self) -> None:
        """
        Vide la file en respectant la priorité.

        Ordre :
          1. par level décroissant (CRITICAL > HIGH > MEDIUM > LOW > INFO)
          2. à level égal, par priority numérique décroissante (0..100)
          3. à priority égale, FIFO (ordre d'arrivée)
        """
        with self._lock:
            ordered: List[CoreEvent] = []
            for lvl in sorted(EventLevel, key=lambda l: -_LEVEL_ORDER[l]):
                q = self._queues[lvl]
                # Vider la file dans une liste pour pouvoir trier par priority
                batch = []
                while q:
                    batch.append(q.popleft())
                # Tri stable : priority décroissante, FIFO en cas d'égalité
                batch.sort(key=lambda e: -(e.priority or 0))
                ordered.extend(batch)
            handlers = list(self._handlers)

        for ev in ordered:
            for h in handlers:
                try:
                    h(ev)
                except Exception as exc:
                    with self._lock:
                        self._stats["handler_errors"] += 1
                    logger.error(
                        "[EVENT_BUS] handler %s a échoué sur event %s : %s",
                        getattr(h, "__name__", repr(h)), ev.id, exc,
                    )
            with self._lock:
                self._stats["processed"] += 1

    # ── Introspection / journal ───────────────────────────────────────────

    def get_journal(self, limit: int = 50, level_min: Optional[EventLevel] = None) -> List[Dict[str, Any]]:
        with self._lock:
            items = list(self._journal)
        if level_min:
            min_order = _LEVEL_ORDER[level_min]
            items = [e for e in items if _LEVEL_ORDER[e.level] >= min_order]
        return [e.to_dict() for e in items[-limit:]]

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._stats)

    def clear_journal(self) -> int:
        with self._lock:
            n = len(self._journal)
            self._journal.clear()
        logger.info("[EVENT_BUS] journal vidé (%d entrées)", n)
        return n


# ── Singleton ──────────────────────────────────────────────────────────────

_bus: Optional[EventBus] = None
_bus_lock = threading.Lock()


def get_event_bus() -> EventBus:
    global _bus
    if _bus is None:
        with _bus_lock:
            if _bus is None:
                _bus = EventBus()
    return _bus
