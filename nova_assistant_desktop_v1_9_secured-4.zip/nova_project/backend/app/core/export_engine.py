import json
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.config import settings
from app.db.models import Conversation, Memory, Message, Note


class ExportEngine:
    def _write_json(self, filename_prefix: str, payload: dict) -> str:
        settings.export_path.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        path = settings.export_path / f"{filename_prefix}_{timestamp}.json"

        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        return str(path.relative_to(settings.base_dir)).replace("\\", "/")

    def export_memories(self, db: Session) -> str:
        items = db.query(Memory).order_by(Memory.id.asc()).all()
        payload = {
            "type": "memories",
            "count": len(items),
            "items": [
                {
                    "id": item.id,
                    "content": item.content,
                    "category": item.category,
                    "importance": item.importance,
                    "source": item.source,
                    "created_at": item.created_at.isoformat() if item.created_at else None,
                }
                for item in items
            ],
        }
        return self._write_json("memories_export", payload)

    def export_notes(self, db: Session) -> str:
        items = db.query(Note).order_by(Note.id.asc()).all()
        payload = {
            "type": "notes",
            "count": len(items),
            "items": [
                {
                    "id": item.id,
                    "title": item.title,
                    "content": item.content,
                    "tags": item.tags,
                    "created_at": item.created_at.isoformat() if item.created_at else None,
                    "updated_at": item.updated_at.isoformat() if item.updated_at else None,
                }
                for item in items
            ],
        }
        return self._write_json("notes_export", payload)

    def export_conversations(self, db: Session) -> str:
        conversations = db.query(Conversation).order_by(Conversation.id.asc()).all()

        payload_items = []
        for conv in conversations:
            messages = (
                db.query(Message)
                .filter(Message.conversation_id == conv.id)
                .order_by(Message.id.asc())
                .all()
            )

            payload_items.append(
                {
                    "id": conv.id,
                    "title": conv.title,
                    "created_at": conv.created_at.isoformat() if conv.created_at else None,
                    "updated_at": conv.updated_at.isoformat() if conv.updated_at else None,
                    "messages": [
                        {
                            "id": msg.id,
                            "role": msg.role,
                            "content": msg.content,
                            "created_at": msg.created_at.isoformat() if msg.created_at else None,
                        }
                        for msg in messages
                    ],
                }
            )

        payload = {
            "type": "conversations",
            "count": len(payload_items),
            "items": payload_items,
        }
        return self._write_json("conversations_export", payload)

    def export_all(self, db: Session) -> dict:
        return {
            "memories": self.export_memories(db),
            "notes": self.export_notes(db),
            "conversations": self.export_conversations(db),
        }