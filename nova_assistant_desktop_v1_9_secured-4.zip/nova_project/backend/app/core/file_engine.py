from pathlib import Path
from typing import List, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.core.ranking import weighted_document_score
from app.core.safety import SafetyError, resolve_and_validate_path
from app.db.models import Document


ALLOWED_EXTENSIONS = {".txt", ".md", ".json"}


class FileEngine:
    def list_files(self, relative_dir: str) -> List[dict]:
        target_dir = resolve_and_validate_path(relative_dir)

        if not target_dir.exists():
            raise FileNotFoundError("Dossier introuvable.")
        if not target_dir.is_dir():
            raise NotADirectoryError("Le chemin fourni n'est pas un dossier.")

        results = []
        for item in sorted(target_dir.iterdir(), key=lambda p: (not p.is_file(), p.name.lower())):
            results.append(
                {
                    "name": item.name,
                    "relative_path": str(item.relative_to(settings.base_dir)).replace("\\", "/"),
                    "is_file": item.is_file(),
                    "is_dir": item.is_dir(),
                    "size": item.stat().st_size if item.is_file() else None,
                }
            )
        return results

    def read_file(self, relative_path: str) -> dict:
        file_path = resolve_and_validate_path(relative_path)

        if not file_path.exists():
            raise FileNotFoundError("Fichier introuvable.")
        if not file_path.is_file():
            raise IsADirectoryError("Le chemin fourni est un dossier.")

        extension = file_path.suffix.lower()
        if extension not in ALLOWED_EXTENSIONS:
            raise SafetyError(f"Extension non autorisée: {extension}")

        size = file_path.stat().st_size
        if size > settings.max_file_size_bytes:
            raise SafetyError("Fichier trop volumineux pour la lecture directe.")

        content = file_path.read_text(encoding="utf-8", errors="replace")
        return {
            "filename": file_path.name,
            "relative_path": str(file_path.relative_to(settings.base_dir)).replace("\\", "/"),
            "extension": extension,
            "size": size,
            "content": content,
        }

    def index_file(self, db: Session, relative_path: str) -> Document:
        file_info = self.read_file(relative_path)
        preview = file_info["content"][: settings.max_document_preview_chars]

        existing = db.query(Document).filter(Document.path == file_info["relative_path"]).first()

        if existing:
            existing.filename = file_info["filename"]
            existing.content_preview = preview
            db.commit()
            db.refresh(existing)
            return existing

        doc = Document(
            filename=file_info["filename"],
            path=file_info["relative_path"],
            content_preview=preview,
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        return doc

    def list_indexed_documents(self, db: Session, limit: int = 100) -> List[Document]:
        return (
            db.query(Document)
            .order_by(Document.id.desc())
            .limit(limit)
            .all()
        )

    def search_documents(self, db: Session, query: str, limit: int = 20) -> List[Document]:
        cleaned = query.strip()
        if not cleaned:
            return []

        docs = db.query(Document).all()
        scored = []

        for doc in docs:
            score = weighted_document_score(
                cleaned,
                doc.filename,
                doc.path,
                doc.content_preview,
            )
            if score > 0:
                scored.append((score, doc))

        scored.sort(key=lambda x: (x[0], x[1].id), reverse=True)
        return [item for _, item in scored[:limit]]

    def get_document_by_id(self, db: Session, document_id: int) -> Optional[Document]:
        return db.query(Document).filter(Document.id == document_id).first()