from typing import Any, Dict


def detect_intent(message: str) -> Dict[str, Any]:
    text = message.strip()
    lower = text.lower()

    if lower.startswith("retiens que "):
        return {
            "intent": "memory_add",
            "content": text[12:].strip(),
            "category": "general",
            "importance": 3,
        }

    if lower.startswith("souviens-toi que "):
        return {
            "intent": "memory_add",
            "content": text[16:].strip(),
            "category": "general",
            "importance": 3,
        }

    if lower.startswith("cherche dans ta mémoire "):
        return {
            "intent": "memory_search",
            "query": text[24:].strip(),
        }

    if lower.startswith("liste mes souvenirs"):
        return {"intent": "memory_list"}

    if lower.startswith("supprime la mémoire "):
        memory_id = _parse_trailing_int(lower, prefix="supprime la mémoire ")
        if memory_id is not None:
            return {"intent": "memory_delete", "memory_id": memory_id}

    if lower.startswith("supprime la memoire "):
        memory_id = _parse_trailing_int(lower, prefix="supprime la memoire ")
        if memory_id is not None:
            return {"intent": "memory_delete", "memory_id": memory_id}

    if lower.startswith("crée une note:"):
        payload = text[len("crée une note:"):].strip()
        return _parse_note_payload(payload)

    if lower.startswith("cree une note:"):
        payload = text[len("cree une note:"):].strip()
        return _parse_note_payload(payload)

    if lower.startswith("liste mes notes"):
        return {"intent": "note_list"}

    if lower.startswith("cherche dans mes notes "):
        return {
            "intent": "note_search",
            "query": text[22:].strip(),
        }

    if lower.startswith("lis la note "):
        note_id = _parse_trailing_int(lower, prefix="lis la note ")
        if note_id is not None:
            return {"intent": "note_read", "note_id": note_id}

    if lower.startswith("supprime la note "):
        note_id = _parse_trailing_int(lower, prefix="supprime la note ")
        if note_id is not None:
            return {"intent": "note_delete", "note_id": note_id}

    if lower.startswith("modifie la note "):
        payload = text[len("modifie la note "):].strip()
        return _parse_note_update_payload(payload)

    if lower.startswith("liste les fichiers "):
        return {
            "intent": "file_list",
            "relative_dir": text[19:].strip(),
        }

    if lower.startswith("lis le fichier "):
        return {
            "intent": "file_read",
            "relative_path": text[14:].strip(),
        }

    if lower.startswith("indexe le fichier "):
        return {
            "intent": "file_index",
            "relative_path": text[17:].strip(),
        }

    if lower.startswith("liste les documents indexés"):
        return {"intent": "document_list"}

    if lower.startswith("liste les documents indexes"):
        return {"intent": "document_list"}

    if lower.startswith("cherche dans les documents "):
        return {
            "intent": "document_search",
            "query": text[26:].strip(),
        }

    if lower.startswith("liste les conversations"):
        return {"intent": "conversation_list"}

    if lower.startswith("lis la conversation "):
        conv_id = _parse_trailing_int(lower, prefix="lis la conversation ")
        if conv_id is not None:
            return {"intent": "conversation_read", "conversation_id": conv_id}

    if lower == "exporte les mémoires" or lower == "exporte les memoires":
        return {"intent": "export_memories"}

    if lower == "exporte les notes":
        return {"intent": "export_notes"}

    if lower == "exporte les conversations":
        return {"intent": "export_conversations"}

    return {"intent": "chat"}


def _parse_note_payload(payload: str) -> Dict[str, Any]:
    parts = [p.strip() for p in payload.split("|")]

    if len(parts) < 2:
        return {
            "intent": "invalid_note_format",
            "error": "Format attendu : crée une note: Titre | Contenu | tags optionnels",
        }

    title = parts[0]
    content = parts[1]
    tags = parts[2] if len(parts) >= 3 else ""

    return {
        "intent": "note_create",
        "title": title,
        "content": content,
        "tags": tags,
    }


def _parse_note_update_payload(payload: str) -> Dict[str, Any]:
    """
    Format :
    {id} | nouveau titre | nouveau contenu | tags optionnels
    """
    parts = [p.strip() for p in payload.split("|")]

    if len(parts) < 3:
        return {
            "intent": "invalid_note_update_format",
            "error": "Format attendu : modifie la note {id} | nouveau titre | nouveau contenu | tags optionnels",
        }

    try:
        note_id = int(parts[0])
    except ValueError:
        return {
            "intent": "invalid_note_update_format",
            "error": "ID de note invalide dans la commande de modification.",
        }

    title = parts[1]
    content = parts[2]
    tags = parts[3] if len(parts) >= 4 else None

    return {
        "intent": "note_update",
        "note_id": note_id,
        "title": title,
        "content": content,
        "tags": tags,
    }


def _parse_trailing_int(text: str, prefix: str) -> int | None:
    raw = text[len(prefix):].strip()
    try:
        return int(raw)
    except ValueError:
        return None