"""
llm.py — Client Ollama avec fallback Mistral automatique

Deux modes :
  - chat()        : appel bloquant (chat texte, fallback)
  - chat_stream() : générateur streaming (mode vocal principal)

Fallback Mistral :
  Activé si USE_MISTRAL_FALLBACK=true ET MISTRAL_API_KEY renseigné dans .env.
  Déclenché sur : timeout, connection error, réponse vide, modèle non chargé.
  Pour chat_stream() : fallback UNIQUEMENT si aucun token n'a encore été reçu
  (évite la corruption d'une réponse déjà en cours).

Logs structurés :
  [LLM] OLLAMA_OK          — Ollama a répondu correctement
  [LLM] OLLAMA_TIMEOUT     — timeout Ollama
  [LLM] OLLAMA_ERROR       — autre erreur Ollama
  [LLM] MISTRAL_FALLBACK   — basculement vers Mistral
  [LLM] MISTRAL_OK         — Mistral a répondu correctement
  [LLM] LLM_ERROR          — aucun backend n'a pu répondre

Paramètres vocaux équilibrés :
  num_predict=60, temperature=0.2, num_ctx=1024
  → réponses utiles ET rapides sur llama3.2:3b
"""
import json
import time
from typing import Any, Dict, Generator, List, Optional

import requests

from app.config import settings
from app.utils.logger import get_logger
from app.utils.perf_logger import perf as _perf


logger = get_logger("llm")

# Options vocales : équilibre vitesse/qualité pour llama3.2:3b
_VOICE_OPTIONS: Dict[str, Any] = {
    "temperature":    0.2,
    "num_predict":    60,       # réponse vocale courte
    "num_ctx":        1024,     # contexte minimal pour mode vocal
    "top_p":          0.85,
    "repeat_penalty": 1.1,
}

# Options chat texte : contexte étendu mais génération bornée pour éviter
# les réponses infinies qui bloquent le streaming sur CPU limité.
# Sur 8 Go RAM Windows : num_ctx 2048 + llama3.2:3b (~2 Go) = marge correcte.
_CHAT_OPTIONS: Dict[str, Any] = {
    "temperature":    0.3,
    "num_predict":    300,      # ~3-4 paragraphes max ; évite génération infinie
    "num_ctx":        2048,     # contexte suffisant sans saturer la RAM
    "top_p":          0.9,
    "repeat_penalty": 1.1,
    "num_thread":     4,        # exploiter 4 cœurs CPU sur Windows (ajustable via .env)
}

_KEEP_ALIVE = "30m"            # modèle chargé 30 min en mémoire entre requêtes


class OllamaClient:
    def __init__(self) -> None:
        self.base_url        = settings.ollama_base_url.rstrip("/")
        self.model           = settings.ollama_model
        self.timeout         = settings.ollama_timeout
        self._model_verified = False
        self._mistral_client = None   # instancié à la première demande de fallback

    # ── Fallback Mistral ───────────────────────────────────────────────────────

    def _should_fallback(self) -> bool:
        """True si le fallback Mistral est activé ET la clé configurée."""
        try:
            return (
                bool(settings.use_mistral_fallback)
                and bool(settings.mistral_api_key)
                and settings.mistral_api_key != ""
            )
        except Exception:
            return False

    def _get_mistral(self):
        """Retourne le MistralClient (lazy, singleton par instance OllamaClient)."""
        if self._mistral_client is None:
            from app.services.mistral_client import MistralClient
            self._mistral_client = MistralClient(
                api_key=settings.mistral_api_key,
                model=settings.mistral_model,
                timeout=settings.mistral_timeout,
            )
        return self._mistral_client

    def _mistral_chat(self, messages: List[Dict[str, str]]) -> str:
        """Appel Mistral non-streaming avec log LLM_ERROR si ça échoue aussi."""
        try:
            result = self._get_mistral().chat(messages)
            return result
        except Exception as exc:
            logger.error("[LLM] LLM_ERROR mistral_also_failed=%s", str(exc)[:120])
            return f"Service IA temporairement indisponible. ({exc})"

    def _mistral_stream(self, messages: List[Dict[str, str]]) -> Generator[str, None, None]:
        """Fallback streaming Mistral avec log LLM_ERROR si ça échoue aussi."""
        try:
            yield from self._get_mistral().chat_stream(messages)
        except Exception as exc:
            logger.error("[LLM] LLM_ERROR mistral_stream_also_failed=%s", str(exc)[:120])
            yield "Service IA temporairement indisponible."

    # ── Santé ─────────────────────────────────────────────────────────────────

    def health_check(self) -> Dict[str, Any]:
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=10)
            r.raise_for_status()
            models = [m.get("name", "") for m in r.json().get("models", [])]
            return {
                "status": "ok", "reachable": True,
                "model_configured": self.model,
                "available_models": models,
                "model_available":  self.model in models,
            }
        except Exception as exc:
            return {
                "status": "error", "reachable": False,
                "model_configured": self.model,
                "available_models": [], "model_available": False,
                "error": str(exc),
            }

    def warmup(self) -> Dict[str, Any]:
        """Charge le modèle Ollama en mémoire au démarrage."""
        logger.info("[LLM_WARMUP_START] model=%s", self.model)
        t0 = time.perf_counter()
        try:
            resp = requests.post(
                f"{self.base_url}/api/chat",
                json={
                    "model":      self.model,
                    "messages":   [{"role": "user", "content": "ok"}],
                    "stream":     False,
                    "keep_alive": _KEEP_ALIVE,
                    "options":    {"num_predict": 1, "num_ctx": 2048},
                },
                timeout=30,
            )
            resp.raise_for_status()
            self._model_verified = True
            ms = int((time.perf_counter() - t0) * 1000)
            logger.info("[LLM_WARMUP_END] warmup_ms=%d  model=%s", ms, self.model)
            return {"ok": True, "warmup_ms": ms, "model": self.model}
        except Exception as exc:
            ms = int((time.perf_counter() - t0) * 1000)
            logger.warning("[LLM_WARMUP_END] failed  warmup_ms=%d  error=%s", ms, str(exc)[:80])
            return {"ok": False, "warmup_ms": ms, "error": str(exc)[:80]}

    # ── Vérification connexion (une seule fois) ────────────────────────────────

    def _ensure_verified(self) -> Optional[str]:
        """Retourne un message d'erreur si Ollama injoignable, None si OK."""
        if self._model_verified:
            return None
        try:
            requests.get(f"{self.base_url}/api/tags", timeout=5)
        except requests.exceptions.ConnectionError:
            return "Ollama est indisponible. Vérifiez qu'il est bien lancé."
        except Exception as exc:
            return f"Impossible de joindre Ollama : {exc}"

        health = self.health_check()
        if not health.get("model_available"):
            available = ", ".join(health.get("available_models", [])) or "aucun"
            return (
                f"Modèle {self.model} non installé. "
                f"Disponibles : {available}. "
                f"Lancez : ollama pull {self.model}"
            )
        self._model_verified = True
        return None

    # ── Streaming ─────────────────────────────────────────────────────────────

    def chat_stream(
        self,
        messages: List[Dict[str, str]],
        voice_mode: bool = True,
    ) -> Generator[str, None, None]:
        """
        Appel Ollama avec stream=True.
        Yield chaque token dès qu'il arrive.

        Fallback Mistral si :
          - Ollama injoignable dès le départ (_ensure_verified fail)
          - ConnectionError ou Timeout AVANT le premier token

        Pas de fallback mi-flux : impossible de recommencer une réponse en cours.
        """
        # ── Vérification Ollama disponible ────────────────────────────────────
        err = self._ensure_verified()
        if err:
            logger.warning("[LLM] OLLAMA_ERROR unverified=%s", err[:80])
            if self._should_fallback():
                logger.info("[LLM] MISTRAL_FALLBACK stream (ollama_unverified)")
                yield from self._mistral_stream(messages)
                return
            raise RuntimeError(err)

        options = _VOICE_OPTIONS if voice_mode else _CHAT_OPTIONS
        payload: Dict[str, Any] = {
            "model":      self.model,
            "messages":   messages,
            "stream":     True,
            "keep_alive": _KEEP_ALIVE,
        }
        if options:
            payload["options"] = options

        logger.info("[LLM_STREAM_START] model=%s  msgs=%d", self.model, len(messages))
        t0 = time.perf_counter()
        token_count = 0
        first_token_received = False

        # ── Perf session ──────────────────────────────────────────────────
        _session = _perf.start_session(model=self.model)

        try:
            _session.mark_ollama_start()
            with requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                stream=True,
                timeout=self.timeout,
            ) as response:
                response.raise_for_status()
                for raw_line in response.iter_lines():
                    if not raw_line:
                        continue
                    try:
                        obj = json.loads(raw_line)
                    except json.JSONDecodeError:
                        continue
                    if obj.get("done"):
                        break
                    token = obj.get("message", {}).get("content", "")
                    if token:
                        if not first_token_received:
                            _session.mark_first_token()
                        first_token_received = True
                        token_count += 1
                        yield token

            ms = int((time.perf_counter() - t0) * 1000)
            logger.info("[LLM_STREAM_END] llm_ms=%d  tokens=%d", ms, token_count)
            logger.info("[LLM] OLLAMA_OK stream tokens=%d", token_count)
            _session.mark_end(token_count, backend="ollama")
            _perf.record(_session)

        except requests.exceptions.Timeout as exc:
            ms = int((time.perf_counter() - t0) * 1000)
            if not first_token_received and self._should_fallback():
                logger.warning(
                    "[LLM] OLLAMA_TIMEOUT stream_ms=%d → MISTRAL_FALLBACK", ms,
                )
                yield from self._mistral_stream(messages)
            else:
                logger.error(
                    "[LLM] LLM_ERROR stream timeout first_token=%s ms=%d",
                    first_token_received, ms,
                )
                raise

        except requests.exceptions.ConnectionError as exc:
            ms = int((time.perf_counter() - t0) * 1000)
            if not first_token_received and self._should_fallback():
                logger.warning(
                    "[LLM] OLLAMA_ERROR connection_ms=%d → MISTRAL_FALLBACK", ms,
                )
                yield from self._mistral_stream(messages)
            else:
                logger.error(
                    "[LLM] LLM_ERROR stream connection first_token=%s ms=%d",
                    first_token_received, ms,
                )
                raise

        except Exception as exc:
            ms = int((time.perf_counter() - t0) * 1000)
            if not first_token_received and self._should_fallback():
                logger.warning(
                    "[LLM] OLLAMA_ERROR type=%s ms=%d → MISTRAL_FALLBACK",
                    type(exc).__name__, ms,
                )
                yield from self._mistral_stream(messages)
            else:
                logger.error(
                    "[LLM] LLM_ERROR stream type=%s first_token=%s",
                    type(exc).__name__, first_token_received,
                )
                raise

    # ── Non-streaming (chat texte + fallback) ─────────────────────────────────

    def chat(
        self,
        messages: List[Dict[str, str]],
        voice_mode: bool = False,
    ) -> str:
        """Appel bloquant. Utilisé par le chat texte.

        Fallback Mistral sur : connexion impossible, timeout, réponse vide, crash.
        """
        err = self._ensure_verified()
        if err:
            logger.warning("[LLM] OLLAMA_ERROR unverified=%s", err[:80])
            if self._should_fallback():
                logger.info("[LLM] MISTRAL_FALLBACK (ollama_unverified)")
                return self._mistral_chat(messages)
            return err

        options = _VOICE_OPTIONS if voice_mode else _CHAT_OPTIONS

        _session = _perf.start_session(model=self.model)
        _session.mark_ollama_start()
        try:
            logger.info("Ollama /api/chat | model=%s | voice=%s", self.model, voice_mode)
            result = self._try_chat(messages, options=options)
            logger.info("[LLM] OLLAMA_OK chars=%d", len(result))
            # Non-streaming : on estime 1 token ≈ 4 chars pour le comptage
            _session.mark_first_token()
            _session.mark_end(max(1, len(result) // 4), backend="ollama")
            _perf.record(_session)
            return result

        except requests.exceptions.HTTPError as exc:
            # 404 → essai /api/generate (ancien Ollama)
            if exc.response is not None and exc.response.status_code == 404:
                logger.warning("/api/chat → 404, fallback /api/generate")
                try:
                    result = self._try_generate(messages, options=options)
                    logger.info("[LLM] OLLAMA_OK via /api/generate chars=%d", len(result))
                    return result
                except Exception as gen_exc:
                    logger.warning("[LLM] OLLAMA_ERROR /api/generate: %s", gen_exc)
                    if self._should_fallback():
                        logger.info("[LLM] MISTRAL_FALLBACK (generate_failed)")
                        return self._mistral_chat(messages)
                    return f"Erreur Ollama (/api/generate) : {gen_exc}"
            # Autre erreur HTTP
            logger.warning("[LLM] OLLAMA_ERROR http_status=%s", exc.response.status_code if exc.response else "?")
            if self._should_fallback():
                logger.info("[LLM] MISTRAL_FALLBACK (http_error)")
                return self._mistral_chat(messages)
            return f"Erreur Ollama : {exc}"

        except requests.exceptions.Timeout:
            logger.warning("[LLM] OLLAMA_TIMEOUT timeout=%ds", self.timeout)
            if self._should_fallback():
                logger.info("[LLM] MISTRAL_FALLBACK (timeout)")
                return self._mistral_chat(messages)
            return f"Ollama timeout ({self.timeout}s)."

        except Exception as exc:
            logger.warning("[LLM] OLLAMA_ERROR type=%s msg=%s", type(exc).__name__, str(exc)[:80])
            if self._should_fallback():
                logger.info("[LLM] MISTRAL_FALLBACK (exception)")
                return self._mistral_chat(messages)
            return f"Erreur inattendue Ollama : {exc}"

    def _try_chat(self, messages, options=None) -> str:
        payload: Dict[str, Any] = {
            "model": self.model, "messages": messages,
            "stream": False, "keep_alive": _KEEP_ALIVE,
        }
        if options:
            payload["options"] = options
        r = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=self.timeout)
        r.raise_for_status()
        content = r.json().get("message", {}).get("content", "").strip()
        if not content:
            raise RuntimeError("Réponse vide /api/chat.")
        return content

    def _try_generate(self, messages, options=None) -> str:
        parts = []
        for msg in messages:
            role, content = msg.get("role", ""), (msg.get("content") or "").strip()
            if role == "system":
                parts.append(f"[Système]\n{content}")
            elif role == "user":
                parts.append(f"Utilisateur : {content}")
            elif role == "assistant":
                parts.append(f"Assistant : {content}")
        prompt = "\n\n".join(parts) + "\n\nAssistant :"
        payload: Dict[str, Any] = {
            "model": self.model, "prompt": prompt,
            "stream": False, "keep_alive": _KEEP_ALIVE,
        }
        if options:
            payload["options"] = options
        r = requests.post(f"{self.base_url}/api/generate", json=payload, timeout=self.timeout)
        r.raise_for_status()
        content = r.json().get("response", "").strip()
        if not content:
            raise RuntimeError("Réponse vide /api/generate.")
        return content
