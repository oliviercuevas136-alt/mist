from typing import List, Optional

from sqlalchemy.orm import Session

from app.core.ranking import weighted_memory_score
from app.db.models import Memory


class MemoryEngine:
    def add_memory(
        self,
        db: Session,
        content: str,
        category: str = "general",
        importance: int = 1,
        source: str = "manual",
    ) -> Memory:
        cleaned = content.strip()
        if not cleaned:
            raise ValueError("Le contenu mémoire est vide.")

        memory = Memory(
            content=cleaned,
            category=category.strip() or "general",
            importance=max(1, min(5, int(importance))),
            source=source.strip() or "manual",
        )
        db.add(memory)
        db.commit()
        db.refresh(memory)
        return memory

    def list_memories(self, db: Session, limit: int = 50) -> List[Memory]:
        return (
            db.query(Memory)
            .order_by(Memory.importance.desc(), Memory.id.desc())
            .limit(limit)
            .all()
        )

    def search_memories(self, db: Session, query: str, limit: int = 10) -> List[Memory]:
        cleaned = query.strip()
        if not cleaned:
            return []

        all_memories = db.query(Memory).all()
        scored = []

        for item in all_memories:
            haystack = f"{item.content} {item.category} {item.source}"
            score = weighted_memory_score(cleaned, haystack, item.importance)
            if score > 0:
                scored.append((score, item))

        scored.sort(key=lambda x: (x[0], x[1].id), reverse=True)
        return [item for _, item in scored[:limit]]

    def get_relevant_memory_texts(self, db: Session, query: str, limit: int = 5) -> List[str]:
        memories = self.search_memories(db, query=query, limit=limit)
        return [f"[importance={m.importance}] {m.content}" for m in memories]

    def get_memory_by_id(self, db: Session, memory_id: int) -> Optional[Memory]:
        return db.query(Memory).filter(Memory.id == memory_id).first()

    def delete_memory(self, db: Session, memory_id: int) -> bool:
        memory = self.get_memory_by_id(db, memory_id)
        if not memory:
            return False

        db.delete(memory)
        db.commit()
        return True