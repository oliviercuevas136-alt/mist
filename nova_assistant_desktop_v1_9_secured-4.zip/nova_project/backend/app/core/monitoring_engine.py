"""
monitoring_engine.py — Moteur de surveillance V4.
Architecture : state machine claire, persistance propre, mode dégradé.

State machine :
  IDLE -> DETECTION -> CHECK -> CONFIRM -> ALERT -> ESCALATE

Séquence chute :
  signal_fall()
    IDLE -> DETECTION : TTS immédiat "Tu es tombé ? Réponds-moi."
    DETECTION -> CHECK : fenêtre 10-15s
    CHECK -> CONFIRM   : réponse reçue (WARNING seulement)
    CHECK -> ALERT     : pas de réponse -> CRITICAL + escalade comms

Garanties absolues :
  - Absence != Chute. Signaux, niveaux, chemins distincts.
  - Callbacks hors verrou -> pas de deadlock.
  - Cooldown par type, instance-isolé.
  - _persist_alert() jamais bloquant (thread séparé).
  - Mode dégradé : fonctionne sans caméra, sans micro, sans DB.
"""

import json
import queue
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Callable, Dict, List, Optional

from app.utils.logger import get_logger

logger = get_logger("monitoring_engine")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    """Datetime UTC aware — remplace utcnow() deprecated."""
    return datetime.now(timezone.utc)


def _iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


# ---------------------------------------------------------------------------
# Enums publics
# ---------------------------------------------------------------------------

class AlertLevel(str, Enum):
    INFO     = "info"
    WARNING  = "warning"
    URGENT   = "urgent"
    CRITICAL = "critical"


class AlertType(str, Enum):
    FALL              = "fall"
    FALL_CONFIRMED    = "fall_confirmed"    # chute + réponse reçue
    FALL_ESCALATED    = "fall_escalated"    # chute + pas de réponse
    PROLONGED_SILENCE = "prolonged_silence"
    PROLONGED_ABSENCE = "prolonged_absence"
    INACTIVITY        = "inactivity"
    MANUAL            = "manual"
    TEST              = "test"


class MachineState(str, Enum):
    """
    État global de la state machine.
    Transitions autorisées :
      IDLE -> DETECTION (signal_fall ou signal_absence critique)
      DETECTION -> CHECK (TTS envoyé, fenêtre ouverte)
      CHECK -> CONFIRM   (réponse reçue)
      CHECK -> ALERT     (timeout)
      ALERT -> ESCALATE  (comms envoyés)
      CONFIRM -> IDLE    (résolu)
      ESCALATE -> IDLE   (après traitement)
    """
    IDLE      = "idle"
    DETECTION = "detection"   # événement détecté, TTS envoyé
    CHECK     = "check"       # fenêtre de confirmation ouverte
    CONFIRM   = "confirm"     # réponse reçue, situation résolue
    ALERT     = "alert"       # alerte émise, pas de réponse
    ESCALATE  = "escalate"    # escalade comms déclenchée


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class Alert:
    type:         AlertType
    level:        AlertLevel
    message:      str
    id:           int            = field(default=0)
    timestamp:    datetime       = field(default_factory=_now)
    acknowledged: bool           = field(default=False)
    extra:        Dict           = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id":           self.id,
            "type":         self.type.value,
            "level":        self.level.value,
            "message":      self.message,
            "timestamp":    _iso(self.timestamp),
            "acknowledged": self.acknowledged,
            "extra":        self.extra,
        }


@dataclass
class IncidentContext:
    """Contexte de l'incident actif. Un seul incident à la fois."""
    machine_state:     MachineState       = MachineState.IDLE
    incident_type:     str                = ""
    detected_at:       Optional[datetime] = None
    response_at:       Optional[datetime] = None
    escalated_at:      Optional[datetime] = None
    response_received: bool               = False
    tts_sent:          str                = ""
    extra:             Dict               = field(default_factory=dict)

    def is_active(self) -> bool:
        return self.machine_state not in (
            MachineState.IDLE, MachineState.CONFIRM, MachineState.ESCALATE
        )

    def to_dict(self) -> dict:
        return {
            "state":            self.machine_state.value,
            "incident_type":    self.incident_type,
            "detected_at":      _iso(self.detected_at),
            "response_at":      _iso(self.response_at),
            "escalated_at":     _iso(self.escalated_at),
            "response_received": self.response_received,
            "tts_sent":         self.tts_sent,
        }


@dataclass
class SensorState:
    """État des capteurs — permet le mode dégradé."""
    camera_available: bool           = False
    mic_available:    bool           = False
    last_voice_at:    Optional[datetime] = None
    last_seen_at:     Optional[datetime] = None
    last_any_at:      Optional[datetime] = None
    silence_minutes:  float          = 0.0
    absence_minutes:  float          = 0.0
    fall_count_today: int            = 0
    alert_count:      int            = 0
    started_at:       Optional[datetime] = None
    active:           bool           = False
    safe_mode:        bool           = False
    safe_mode_since:  Optional[datetime] = None


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class MonitoringEngine:
    """
    Moteur de surveillance avec state machine IDLE->DETECTION->CHECK->CONFIRM/ALERT->ESCALATE.

    Mode dégradé :
      - Caméra OFF : monitoring vocal + temporel continue
      - Micro OFF  : monitoring visuel + temporel continue
      - DB OFF     : alertes en RAM, log fichier fallback
      - Jamais de crash sur défaillance d'un capteur
    """

    # ── Seuils temporels — MODE NORMAL ───────────────────────────────
    SILENCE_ALERT_MINUTES  = 120    # 2h de silence vocal
    ABSENCE_ALERT_MINUTES  = 45     # 45min sans caméra
    INACTIVITY_ALERT_HOURS = 8      # 8h sans aucune interaction
    CHECK_INTERVAL_SECONDS = 60     # fréquence de la boucle de surveillance

    # ── Fenêtre de confirmation vocale — MODE NORMAL ──────────────────
    CONFIRM_WINDOW_S = 12           # secondes d'attente avant escalade [10-15]

    # ── Paramètres MODE SAFE (vigilance renforcée) ────────────────────
    # Activé via enable_safe_mode() — p.ex. après une chute, la nuit,
    # ou quand la personne est seule pour une longue durée.
    SAFE_CONFIRM_WINDOW_S     = 15   # +3s de plus pour répondre
    SAFE_SILENCE_ALERT_MIN    = 60   # alerte silence après 1h (au lieu de 2h)
    SAFE_ABSENCE_ALERT_MIN    = 20   # alerte absence après 20min (au lieu de 45)
    SAFE_INACTIVITY_ALERT_H   = 4    # inactivité après 4h (au lieu de 8h)

    # ── Cooldowns par type (dict par instance, pas de classe partagée) ─
    _DEFAULT_COOLDOWNS: Dict[str, int] = {
        "fall":              45,
        "fall_escalated":    120,
        "fall_confirmed":    300,
        "prolonged_absence": 3600,
        "prolonged_silence": 3600,
        "inactivity":        7200,
        "manual":            0,
        "test":              0,
    }

    def __init__(self) -> None:
        self._sensors  = SensorState()
        self._incident = IncidentContext()
        self._lock     = threading.Lock()

        self._alerts:        List[Alert]                     = []
        self._callbacks:     List[Callable[[Alert], None]]   = []
        self._tts_callbacks: List[Callable[[str], None]]     = []

        self._thread:      Optional[threading.Thread] = None
        self._stop_event   = threading.Event()
        self._next_id      = 1

        # Délais de reset IDLE — modifiables par instance (raccourcir en tests)
        self._reset_idle_delay_confirm  = 5.0   # s après CONFIRM → IDLE
        self._reset_idle_delay_escalate = 60.0  # s après ESCALATE → IDLE

        # Cooldowns isolés par instance
        self.cooldowns: Dict[str, int] = dict(self._DEFAULT_COOLDOWNS)
        self._last_alert_ts: Dict[str, datetime] = {}

        # File de persistance asynchrone (ne bloque jamais le thread principal)
        self._persist_queue: queue.Queue = queue.Queue(maxsize=500)
        self._persist_thread = threading.Thread(
            target=self._persist_worker,
            daemon=True,
            name="persist-worker",
        )
        self._persist_thread.start()

    # ──────────────────────────────────────────────────────────────────
    # Lifecycle
    # ──────────────────────────────────────────────────────────────────

    def start(self) -> None:
        with self._lock:
            if self._sensors.active:
                return
            self._sensors.active     = True
            self._sensors.started_at = _now()

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._surveillance_loop,
            daemon=True,
            name="monitoring-engine",
        )
        self._thread.start()
        logger.info("MonitoringEngine démarré")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        with self._lock:
            self._sensors.active = False
        logger.info("MonitoringEngine arrêté")

    # ──────────────────────────────────────────────────────────────────
    # Queries
    # ──────────────────────────────────────────────────────────────────

    # ──────────────────────────────────────────────────────────────────
    # Mode Safe — vigilance renforcée activable à tout moment
    # ──────────────────────────────────────────────────────────────────

    @property
    def safe_mode(self) -> bool:
        """True si le mode safe est activé."""
        with self._lock:
            return self._sensors.safe_mode

    def enable_safe_mode(self, reason: str = "") -> None:
        """
        Active le mode safe (vigilance renforcée).
        Effets :
          - Fenêtre de confirmation : 12s → 15s (plus de temps pour répondre)
          - Seuil silence : 120min → 60min
          - Seuil absence : 45min → 20min
          - Seuil inactivité : 8h → 4h
        """
        with self._lock:
            if self._sensors.safe_mode:
                return  # déjà actif
            self._sensors.safe_mode       = True
            self._sensors.safe_mode_since = _now()
        logger.info("MODE SAFE activé | raison=%s", reason or "non précisée")
        self._speak("Le mode vigilance renforcée est activé. Je surveille de plus près.")

    def disable_safe_mode(self) -> None:
        """Désactive le mode safe, retour aux paramètres normaux."""
        with self._lock:
            if not self._sensors.safe_mode:
                return
            self._sensors.safe_mode       = False
            self._sensors.safe_mode_since = None
        logger.info("MODE SAFE désactivé — paramètres normaux")
        self._speak("Le mode vigilance normale est rétabli.")

    def _get_confirm_window(self) -> float:
        """Retourne la fenêtre de confirmation selon le mode actif."""
        with self._lock:
            safe = self._sensors.safe_mode
        return self.SAFE_CONFIRM_WINDOW_S if safe else self.CONFIRM_WINDOW_S

    def _get_silence_threshold(self) -> float:
        with self._lock:
            safe = self._sensors.safe_mode
        return self.SAFE_SILENCE_ALERT_MIN if safe else self.SILENCE_ALERT_MINUTES

    def _get_absence_threshold(self) -> float:
        with self._lock:
            safe = self._sensors.safe_mode
        return self.SAFE_ABSENCE_ALERT_MIN if safe else self.ABSENCE_ALERT_MINUTES

    def _get_inactivity_threshold(self) -> float:
        with self._lock:
            safe = self._sensors.safe_mode
        return self.SAFE_INACTIVITY_ALERT_H if safe else self.INACTIVITY_ALERT_HOURS

    def get_state(self) -> dict:
        with self._lock:
            s   = self._sensors
            inc = self._incident
            alerts = [a.to_dict() for a in self._alerts[-20:]]
        return {
            "active":               s.active,
            "camera_available":     s.camera_available,
            "mic_available":        s.mic_available,
            "last_voice_at":        _iso(s.last_voice_at),
            "last_seen_at":         _iso(s.last_seen_at),
            "last_any_at":          _iso(s.last_any_at),
            "silence_minutes":      round(s.silence_minutes,  1),
            "absence_minutes":      round(s.absence_minutes,  1),
            "fall_count_today":     s.fall_count_today,
            "alert_count":          s.alert_count,
            "started_at":           _iso(s.started_at),
            "incident":             inc.to_dict(),
            "recent_alerts":        alerts,
            "safe_mode":            s.safe_mode,
            "safe_mode_since":      _iso(s.safe_mode_since),
            "confirm_window_s":     self._get_confirm_window(),
            "silence_threshold_m":  self._get_silence_threshold(),
            "absence_threshold_m":  self._get_absence_threshold(),
            "inactivity_threshold_h": self._get_inactivity_threshold(),
        }

    def get_alerts(self, limit: int = 50) -> List[dict]:
        with self._lock:
            return [a.to_dict() for a in self._alerts[-limit:]]

    def get_incident(self) -> dict:
        with self._lock:
            return self._incident.to_dict()

    def acknowledge_alert(self, alert_id: int) -> bool:
        with self._lock:
            for a in self._alerts:
                if a.id == alert_id:
                    a.acknowledged = True
                    logger.info("Alerte acquittée id=%d", alert_id)
                    return True
        return False

    # ──────────────────────────────────────────────────────────────────
    # Registration
    # ──────────────────────────────────────────────────────────────────

    def register_callback(self, cb: Callable[[Alert], None]) -> None:
        self._callbacks.append(cb)

    def register_tts_callback(self, cb: Callable[[str], None]) -> None:
        self._tts_callbacks.append(cb)

    # ──────────────────────────────────────────────────────────────────
    # Signaux capteurs — mode dégradé géré ici
    # ──────────────────────────────────────────────────────────────────

    def signal_camera_available(self, available: bool) -> None:
        """Mode dégradé : la caméra peut être indisponible sans crash."""
        with self._lock:
            self._sensors.camera_available = available
        logger.info("Caméra disponible=%s", available)

    def signal_mic_available(self, available: bool) -> None:
        """Mode dégradé : le micro peut être indisponible sans crash."""
        with self._lock:
            self._sensors.mic_available = available
        logger.info("Micro disponible=%s", available)

    def signal_voice_activity(self) -> None:
        """
        Voix détectée ou interaction chat.
        Réinitialise le silence + répond à l'incident si en phase CHECK.
        """
        with self._lock:
            now = _now()
            self._sensors.last_voice_at = now
            self._sensors.last_any_at   = now
            self._sensors.silence_minutes = 0.0
            self._sensors.mic_available   = True
            # Réponse automatique si on attend
            if self._incident.machine_state == MachineState.CHECK:
                self._incident.response_received = True
                self._incident.response_at       = now
                logger.info("Voix reçue → réponse incident automatique")

    def signal_person_seen(self) -> None:
        """Mouvement caméra détecté."""
        with self._lock:
            now = _now()
            self._sensors.last_seen_at    = now
            self._sensors.last_any_at     = now
            self._sensors.absence_minutes = 0.0
            self._sensors.camera_available = True

    def signal_response(self) -> None:
        """Bouton 'Je vais bien' ou signal explicite de l'utilisateur."""
        with self._lock:
            if self._incident.machine_state == MachineState.CHECK:
                self._incident.response_received = True
                self._incident.response_at       = _now()
                logger.info("Réponse explicite reçue")

    # ──────────────────────────────────────────────────────────────────
    # Signaux événements
    # ──────────────────────────────────────────────────────────────────

    def signal_fall(self, extra: dict = None) -> None:
        """
        Chute détectée par la vision.
        Lance IMMÉDIATEMENT la séquence de confirmation vocale.
        NE produit pas d'alerte CRITICAL immédiate — attend la réponse.
        """
        now = _now()
        if self._is_in_cooldown("fall", now):
            logger.debug("signal_fall ignoré — cooldown actif")
            return

        extra = extra or {}

        # Lire la fenêtre AVANT d'acquérir le lock (Lock non réentrant — évite deadlock)
        confirm_window = self._get_confirm_window()

        with self._lock:
            # Ignorer si un incident est déjà actif
            if self._incident.is_active():
                logger.debug("signal_fall ignoré — incident déjà actif: %s",
                             self._incident.machine_state)
                return

            self._sensors.fall_count_today += 1
            self._last_alert_ts["fall"] = now  # cooldown immédiat

            self._incident = IncidentContext(
                machine_state  = MachineState.DETECTION,
                incident_type  = "fall",
                detected_at    = now,
                extra          = {**extra, "confirm_window_s": confirm_window},
                tts_sent       = "Tu es tombé ? Réponds-moi s'il te plaît.",
            )
            tts_msg  = self._incident.tts_sent
            tts_cbs  = list(self._tts_callbacks)

        conf = extra.get("confidence", 0)
        logger.warning("CHUTE DÉTECTÉE | conf=%.2f | frames=%s | séquence confirmaton",
                       conf, extra.get("frames_confirmed", "?"))

        # TTS immédiat — hors lock
        self._invoke_tts(tts_cbs, tts_msg)

        # Fenêtre de confirmation dans un thread dédié
        # confirm_window déjà lu avant le lock ci-dessus — on le passe directement
        threading.Thread(
            target=self._run_confirmation_window,
            args=(now, extra, confirm_window),
            daemon=True,
            name="fall-confirm",
        ).start()

    def signal_absence(self, extra: dict = None) -> None:
        """
        Absence prolongée — DISTINCTE de signal_fall.
        Niveau WARNING uniquement, jamais CRITICAL.
        """
        now = _now()
        if self._is_in_cooldown("prolonged_absence", now):
            return

        minutes = (extra or {}).get("minutes", 0)
        alert   = Alert(
            type    = AlertType.PROLONGED_ABSENCE,
            level   = AlertLevel.WARNING,
            message = f"Absence prolongée depuis {round(minutes)} min",
            extra   = extra or {},
        )
        self._raise_alert(alert)

    def signal_inactivity(self, extra: dict = None) -> None:
        """Inactivité totale — WARNING."""
        now = _now()
        if self._is_in_cooldown("inactivity", now):
            return

        hours = (extra or {}).get("hours", 0)
        alert = Alert(
            type    = AlertType.INACTIVITY,
            level   = AlertLevel.WARNING,
            message = f"Aucune activité depuis {round(hours, 1)} heures",
            extra   = extra or {},
        )
        self._raise_alert(alert)

    def signal_manual_emergency(self) -> None:
        """Bouton urgence physique — pas de cooldown, réponse immédiate."""
        alert = Alert(
            type    = AlertType.MANUAL,
            level   = AlertLevel.CRITICAL,
            message = "URGENCE MANUELLE — Bouton d'urgence activé",
        )
        self._raise_alert(alert)
        self._speak("J'ai reçu votre appel. Restez calme, les secours sont prévenus.")

    def signal_test(self) -> None:
        alert = Alert(
            type    = AlertType.TEST,
            level   = AlertLevel.INFO,
            message = "Test de surveillance — Système opérationnel",
        )
        self._raise_alert(alert)

    # ──────────────────────────────────────────────────────────────────
    # State machine — fenêtre de confirmation
    # ──────────────────────────────────────────────────────────────────

    def _run_confirmation_window(
        self, detected_at: datetime, extra: dict, window_s: float = None
    ) -> None:
        """
        Transition DETECTION -> CHECK -> CONFIRM ou ALERT -> ESCALATE.
        Exécuté dans un thread daemon dédié.
        window_s : durée de la fenêtre (héritée du moment de la détection).
        """
        if window_s is None:
            window_s = self._get_confirm_window()

        # Transition DETECTION -> CHECK
        with self._lock:
            if self._incident.machine_state != MachineState.DETECTION:
                return  # incident annulé entre-temps
            self._incident.machine_state = MachineState.CHECK

        logger.info("CHECK ouvert | fenêtre=%.1fs | safe_mode=%s",
                    window_s, self.safe_mode)

        # Attente de la réponse
        time.sleep(window_s)

        with self._lock:
            # Vérifier que c'est toujours notre incident
            if self._incident.machine_state != MachineState.CHECK:
                return
            response_ok = self._incident.response_received

        if response_ok:
            self._handle_fall_confirmed(extra)
        else:
            self._handle_fall_escalated(extra)

    def _handle_fall_confirmed(self, extra: dict) -> None:
        """CHECK -> CONFIRM : la personne a répondu."""
        with self._lock:
            self._incident.machine_state = MachineState.CONFIRM

        alert = Alert(
            type    = AlertType.FALL_CONFIRMED,
            level   = AlertLevel.WARNING,
            message = "Chute — personne consciente et répondante",
            extra   = {**extra, "window_s": self._get_confirm_window(),
                       "safe_mode": self.safe_mode},
        )
        self._raise_alert(alert)
        self._speak("Bien, je suis là si vous avez besoin. Tout va bien ?")
        logger.info("Incident CONFIRM — réponse reçue")

        # Retour à IDLE après traitement (daemon pour ne pas bloquer l'arrêt)
        t = threading.Timer(self._reset_idle_delay_confirm, self._reset_incident_to_idle)
        t.daemon = True
        t.start()

    def _handle_fall_escalated(self, extra: dict) -> None:
        """CHECK -> ALERT -> ESCALATE : pas de réponse."""
        now = _now()
        with self._lock:
            self._incident.machine_state = MachineState.ALERT
            self._incident.escalated_at  = now

        # ALERT
        alert = Alert(
            type    = AlertType.FALL_ESCALATED,
            level   = AlertLevel.CRITICAL,
            message = "CHUTE — AUCUNE RÉPONSE — Intervention d'urgence requise",
            extra   = {**extra, "waited_s": self._get_confirm_window(),
                       "safe_mode": self.safe_mode},
        )
        self._raise_alert(alert)
        self._speak("Je n'ai pas de réponse. J'appelle les secours maintenant.")
        logger.warning("Incident ALERT — aucune réponse dans la fenêtre")

        # ESCALATE immédiat (comms gérés par callback -> orchestrateur)
        with self._lock:
            self._incident.machine_state = MachineState.ESCALATE

        logger.warning("Incident ESCALATE — comms d'urgence déclenchés")

        # Retour à IDLE après délai configurable (daemon pour ne pas bloquer l'arrêt)
        t = threading.Timer(self._reset_idle_delay_escalate, self._reset_incident_to_idle)
        t.daemon = True
        t.start()

    def _reset_incident_to_idle(self) -> None:
        with self._lock:
            if self._incident.machine_state in (
                MachineState.CONFIRM, MachineState.ESCALATE
            ):
                self._incident = IncidentContext()
        logger.info("Incident réinitialisé -> IDLE")

    # ──────────────────────────────────────────────────────────────────
    # TTS helpers
    # ──────────────────────────────────────────────────────────────────

    def _speak(self, message: str) -> None:
        with self._lock:
            cbs = list(self._tts_callbacks)
        self._invoke_tts(cbs, message)

    @staticmethod
    def _invoke_tts(callbacks: list, message: str) -> None:
        """Appelle les callbacks TTS — chaque erreur est catchée."""
        for cb in callbacks:
            try:
                cb(message)
            except Exception as exc:
                logger.error("TTS callback error | %s", exc)

    # ──────────────────────────────────────────────────────────────────
    # Cooldown
    # ──────────────────────────────────────────────────────────────────

    def _is_in_cooldown(self, key: str, now: datetime) -> bool:
        cooldown_s = self.cooldowns.get(key, 0)
        if cooldown_s == 0:
            return False
        with self._lock:
            last = self._last_alert_ts.get(key)
        if last is None:
            return False
        elapsed = (now - last).total_seconds()
        if elapsed < cooldown_s:
            logger.debug("Cooldown %s | %.1fs / %ds", key, elapsed, cooldown_s)
            return True
        return False

    # ──────────────────────────────────────────────────────────────────
    # Raise alert
    # ──────────────────────────────────────────────────────────────────

    def _raise_alert(self, alert: Alert) -> None:
        """
        Enregistre l'alerte, met à jour le cooldown, notifie.
        Callbacks appelés HORS verrou pour éviter les deadlocks.
        Persistance asynchrone — ne bloque jamais.
        """
        now = _now()
        with self._lock:
            alert.id = self._next_id
            self._next_id += 1
            self._alerts.append(alert)
            self._sensors.alert_count += 1
            self._last_alert_ts[alert.type.value] = now
            callbacks = list(self._callbacks)

        logger.warning("ALERTE id=%d type=%s level=%s | %s",
                       alert.id, alert.type.value, alert.level.value, alert.message)

        # Persistance asynchrone (jamais bloquante)
        try:
            self._persist_queue.put_nowait(alert)
        except queue.Full:
            logger.debug("File persistance pleine — alerte ignorée en DB")

        # Notifications
        for cb in callbacks:
            try:
                cb(alert)
            except Exception as exc:
                logger.error("Alert callback error | %s", exc)

    # ──────────────────────────────────────────────────────────────────
    # Persistance asynchrone
    # ──────────────────────────────────────────────────────────────────

    def _persist_worker(self) -> None:
        """Thread daemon de persistance — consomme la file sans bloquer."""
        while True:
            try:
                alert = self._persist_queue.get(timeout=5)
                self._persist_alert_sync(alert)
                self._persist_queue.task_done()
            except queue.Empty:
                continue
            except Exception as exc:
                logger.debug("Persist worker error | %s", exc)

    def _persist_alert_sync(self, alert: Alert) -> None:
        """Écriture SQLite + fallback fichier texte si DB indisponible."""
        # Tentative SQLite
        try:
            from app.db.database import SessionLocal
            from app.db.models import MonitoringAlert
            with SessionLocal() as db:
                row = MonitoringAlert(
                    alert_type   = alert.type.value,
                    alert_level  = alert.level.value,
                    message      = alert.message,
                    timestamp    = alert.timestamp,
                    acknowledged = alert.acknowledged,
                    extra_json   = json.dumps(alert.extra, ensure_ascii=False, default=str),
                )
                db.add(row)
                db.commit()
            return
        except Exception as exc:
            logger.debug("SQLite indisponible, fallback fichier | %s", exc)

        # Fallback fichier texte — ne peut pas échouer (sauf disque plein)
        try:
            from app.config import settings
            log_path = settings.data_path / "alerts_fallback.log"
            line = (
                f"[{_iso(alert.timestamp)}] "
                f"[{alert.level.value.upper()}] "
                f"[{alert.type.value}] "
                f"{alert.message}\n"
            )
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception as exc:
            logger.error("Fallback fichier impossible | %s", exc)

    # ──────────────────────────────────────────────────────────────────
    # Boucle de surveillance temporelle
    # ──────────────────────────────────────────────────────────────────

    def _surveillance_loop(self) -> None:
        logger.info("Boucle de surveillance démarrée")
        while not self._stop_event.wait(timeout=self.CHECK_INTERVAL_SECONDS):
            try:
                self._check_temporal_rules()
            except Exception as exc:
                logger.error("Erreur boucle surveillance | %s", exc)
        logger.info("Boucle de surveillance arrêtée")

    def _check_temporal_rules(self) -> None:
        """
        Règles temporelles — fonctionnent en mode dégradé.
        Silence : uniquement si micro disponible ou interaction connue.
        Absence  : uniquement si caméra disponible.
        Inactivité : toujours (fallback universel).
        """
        now = _now()

        with self._lock:
            last_voice  = self._sensors.last_voice_at
            last_seen   = self._sensors.last_seen_at
            last_any    = self._sensors.last_any_at
            cam_ok      = self._sensors.camera_available
            mic_ok      = self._sensors.mic_available

        # Lire les seuils dynamiques (normal vs safe mode)
        silence_thr    = self._get_silence_threshold()
        absence_thr    = self._get_absence_threshold()
        inactivity_thr = self._get_inactivity_threshold()

        # Silence vocal — seulement si le micro est/était disponible
        if last_voice and mic_ok:
            silence_min = (now - last_voice).total_seconds() / 60
            with self._lock:
                self._sensors.silence_minutes = silence_min
            if silence_min >= silence_thr:
                self._maybe_alert_silence(silence_min, last_voice)

        # Absence caméra — seulement si la caméra est/était disponible
        if last_seen and cam_ok:
            absence_min = (now - last_seen).total_seconds() / 60
            with self._lock:
                self._sensors.absence_minutes = absence_min
            if absence_min >= absence_thr:
                self.signal_absence(extra={
                    "since":   _iso(last_seen),
                    "minutes": round(absence_min, 1),
                    "source":  "temporal_loop",
                    "safe_mode": self.safe_mode,
                })

        # Inactivité totale — fonctionne même sans caméra ni micro
        if last_any:
            inactivity_h = (now - last_any).total_seconds() / 3600
            if inactivity_h >= inactivity_thr:
                self.signal_inactivity(extra={
                    "since":     _iso(last_any),
                    "hours":     round(inactivity_h, 1),
                    "safe_mode": self.safe_mode,
                })

    def _maybe_alert_silence(self, minutes: float, since: datetime) -> None:
        if self._is_in_cooldown("prolonged_silence", _now()):
            return
        alert = Alert(
            type    = AlertType.PROLONGED_SILENCE,
            level   = AlertLevel.WARNING,
            message = f"Silence prolongé depuis {round(minutes)} min",
            extra   = {"since": _iso(since), "minutes": round(minutes, 1)},
        )
        self._raise_alert(alert)
        self._speak("Bonjour ! Je ne vous ai pas entendu depuis un moment. Tout va bien ?")


# Singleton
monitoring_engine = MonitoringEngine()
