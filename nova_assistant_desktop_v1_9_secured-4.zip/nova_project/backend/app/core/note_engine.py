from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.db.models import Note


class NoteEngine:
    def create_note(
        self,
        db: Session,
        title: str,
        content: str,
        tags: str = "",
    ) -> Note:
        cleaned_title = title.strip()
        cleaned_content = content.strip()

        if not cleaned_title:
            raise ValueError("Le titre de la note est vide.")
        if not cleaned_content:
            raise ValueError("Le contenu de la note est vide.")

        note = Note(
            title=cleaned_title,
            content=cleaned_content,
            tags=tags.strip(),
        )
        db.add(note)
        db.commit()
        db.refresh(note)
        return note

    def list_notes(self, db: Session, limit: int = 100) -> List[Note]:
        return (
            db.query(Note)
            .order_by(Note.updated_at.desc(), Note.id.desc())
            .limit(limit)
            .all()
        )

    def get_note_by_id(self, db: Session, note_id: int) -> Optional[Note]:
        return db.query(Note).filter(Note.id == note_id).first()

    def search_notes(self, db: Session, query: str, limit: int = 20) -> List[Note]:
        cleaned = query.strip()
        if not cleaned:
            return []

        pattern = f"%{cleaned}%"
        return (
            db.query(Note)
            .filter(
                or_(
                    Note.title.ilike(pattern),
                    Note.content.ilike(pattern),
                    Note.tags.ilike(pattern),
                )
            )
            .order_by(Note.updated_at.desc(), Note.id.desc())
            .limit(limit)
            .all()
        )

    def update_note(
        self,
        db: Session,
        note_id: int,
        title: str | None = None,
        content: str | None = None,
        tags: str | None = None,
    ) -> Optional[Note]:
        note = self.get_note_by_id(db, note_id)
        if not note:
            return None

        if title is not None:
            cleaned_title = title.strip()
            if not cleaned_title:
                raise ValueError("Le titre de la note est vide.")
            note.title = cleaned_title

        if content is not None:
            cleaned_content = content.strip()
            if not cleaned_content:
                raise ValueError("Le contenu de la note est vide.")
            note.content = cleaned_content

        if tags is not None:
            note.tags = tags.strip()

        note.updated_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(note)
        return note

    def delete_note(self, db: Session, note_id: int) -> bool:
        note = self.get_note_by_id(db, note_id)
        if not note:
            return False

        db.delete(note)
        db.commit()
        return True