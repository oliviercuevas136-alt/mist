"""
orchestrator.py — Coordinateur principal V4.

Rôle : router les événements entre les moteurs, jamais de logique métier.

Architecture :
  VisionEngine  --(callbacks)--> Orchestrator --> MonitoringEngine
  MonitoringEngine --(callbacks)--> Orchestrator --> CommsEngine
  MonitoringEngine --(tts_callbacks)--> Orchestrator --> TTS + FrontendQueue

Mode dégradé :
  - Caméra OFF  : monitoring vocal continue
  - Micro OFF   : monitoring visuel continue
  - Comms OFF   : log fichier fallback
  - DB OFF      : RAM + log fallback
  - Jamais de crash
"""

import json
import threading
from datetime import datetime, timezone
from typing import Optional

from app.core.comms_engine import comms_engine
from app.core.monitoring_engine import (
    Alert, AlertLevel, AlertType, MachineState,
    monitoring_engine,
)
from app.core.vision_engine import VisionEvent, vision_engine
from app.core.event_bus import CoreEvent, Event, EventLevel, CoreDecision, get_event_bus
from app.core.core_decision import get_decision_engine
from app.utils.logger import get_logger

logger = get_logger("orchestrator")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Mapping AlertLevel monitoring → EventLevel bus ─────────────────────────
_LEVEL_MAP = {
    AlertLevel.INFO:     EventLevel.INFO,
    AlertLevel.WARNING:  EventLevel.MEDIUM,
    AlertLevel.URGENT:   EventLevel.HIGH,
    AlertLevel.CRITICAL: EventLevel.CRITICAL,
}


class Orchestrator:
    """
    Coordinateur principal — pur routeur.
    Toute la logique métier est dans MonitoringEngine.

    Depuis v1.9.1 : intégré au EventBus central.
      - Continue de recevoir les callbacks directs des modules (compat)
      - Republie chaque événement sur le bus pour traçabilité unifiée
      - Consulte CoreDecisionEngine pour les décisions standards
      - Garde sa logique métier existante (compat ascendante 100%)
    """

    def __init__(self) -> None:
        self._active       = False
        self._lock         = threading.Lock()
        self._event_log:   list = []
        self._probe_queue: list = []    # file FIFO pour le frontend poll

        # Bus central
        self._bus = get_event_bus()
        self._decision_engine = get_decision_engine()

        # Câblage existant (préservé)
        vision_engine.register_callback(self._on_vision_event)
        monitoring_engine.register_callback(self._on_alert)
        monitoring_engine.register_tts_callback(self._on_tts)

        # Abonnement au bus : décide via core_decision pour les events
        # publiés par d'autres modules (file_search, voice, etc.)
        self._bus.subscribe(self._on_bus_event)

    # ──────────────────────────────────────────────────────────────────
    # POINT D'ENTRÉE UNIQUE — submit_event / decide_event (v1.9.2)
    # ──────────────────────────────────────────────────────────────────
    #
    # À partir de v1.9.2, TOUS les modules doivent envoyer leurs événements
    # au CORE via cette méthode unique :
    #
    #     from app.core.orchestrator import orchestrator
    #     from app.core.event_bus import CoreEvent, EventLevel
    #
    #     orchestrator.submit_event(CoreEvent(
    #         type="voice.activity",
    #         source="voice_engine",
    #         level=EventLevel.LOW,
    #         message="Activité micro détectée",
    #         payload={"duration_ms": 1200},
    #     ))
    #
    # Les anciennes voies (vision_engine.register_callback, monitoring_engine
    # callbacks) sont préservées pour compat ascendante mais déprécient
    # progressivement.

    def submit_event(self, event) -> dict:
        """
        Point d'entrée UNIQUE pour signaler un événement au CORE.

        Pipeline :
            1. Validation du type (CoreEvent attendu)
            2. Publication sur le bus (cooldown + journal automatiques)
            3. Décision automatique via decide_event() (dispatch interne au bus)
            4. Trace dans le journal Orchestrator

        Retourne un dict { accepted, dropped_reason?, decision?, event_id }.

        Robustesse : ne lève JAMAIS. Toute erreur est tracée et retournée
        dans le dict de réponse.
        """
        try:
            # Validation tolérante : accepter CoreEvent OU dict équivalent
            if isinstance(event, dict):
                try:
                    event = CoreEvent(**event)
                except Exception as exc:
                    return {
                        "accepted":       False,
                        "dropped_reason": f"invalid_dict: {exc}",
                        "event_id":       None,
                    }
            if not isinstance(event, CoreEvent):
                return {
                    "accepted":       False,
                    "dropped_reason": f"not a CoreEvent: {type(event).__name__}",
                    "event_id":       None,
                }

            # Publication bus — déclenche _on_bus_event() qui appelle decide_event()
            accepted = self._bus.publish(event)
            if not accepted:
                return {
                    "accepted":       False,
                    "dropped_reason": "cooldown",
                    "event_id":       event.id,
                }
            return {
                "accepted": True,
                "event_id": event.id,
            }
        except Exception as exc:
            logger.error("[CORE] submit_event a échoué : %s", exc)
            return {
                "accepted":       False,
                "dropped_reason": f"internal_error: {exc}",
                "event_id":       getattr(event, "id", None),
            }

    def decide_event(self, event) -> dict:
        """
        Décision pure (pas d'exécution) sur un CoreEvent.
        Retourne un dict avec la décision claire.

        Décisions possibles :
            ignore                        — rien à faire
            log                           — entrée journal seule
            memorize                      — persister pour mémoire long-terme
            notify                        — pousser TTS/UI
            ask_confirmation              — demander confirmation utilisateur
            execute_authorized_action     — exécuter action whitelistée

        Robustesse : si decision_engine échoue, fallback rule-based local
        garanti — ne plante jamais.
        """
        try:
            if isinstance(event, dict):
                event = CoreEvent(**event)
            if not isinstance(event, CoreEvent):
                return {"decision": "ignore", "reason": "invalid_event", "error": True}
            d = self._decision_engine.decide(event)
            return d.to_dict()
        except Exception as exc:
            logger.warning("[CORE] decide_event fallback : %s", exc)
            # Fallback : sécuritaire et déterministe
            return {
                "decision":   "log",
                "reason":     f"fallback_after_error: {exc}",
                "error":      True,
                "event_id":   getattr(event, "id", None),
                "event_type": getattr(event, "type", "unknown"),
            }

    # ──────────────────────────────────────────────────────────────────
    # Lifecycle
    # ──────────────────────────────────────────────────────────────────

    def start(self, enable_vision: bool = False, camera_index: int = 0) -> dict:
        with self._lock:
            if self._active:
                return {"status": "already_running"}

        monitoring_engine.start()

        vision_started = False
        if enable_vision:
            vision_started = vision_engine.start(camera_index=camera_index)
            monitoring_engine.signal_camera_available(vision_started)
        else:
            # Mode dégradé explicite : caméra désactivée
            monitoring_engine.signal_camera_available(False)

        with self._lock:
            self._active = True

        self._log("system", "Orchestrateur démarré",
                  {"vision": vision_started, "monitoring": True})
        logger.info("Orchestrateur démarré | vision=%s", vision_started)
        return {"status": "started", "vision": vision_started, "monitoring": True}

    def stop(self) -> dict:
        vision_engine.stop()
        monitoring_engine.stop()
        monitoring_engine.signal_camera_available(False)
        with self._lock:
            self._active = False
        self._log("system", "Orchestrateur arrêté", {})
        return {"status": "stopped"}

    # ──────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────

    def get_status(self) -> dict:
        with self._lock:
            active = self._active
            events = list(self._event_log[-30:])
        return {
            "active":        active,
            "monitoring":    monitoring_engine.get_state(),
            "vision":        vision_engine.get_state(),
            "incident":      monitoring_engine.get_incident(),
            "recent_events": events,
            "comms_history": comms_engine.get_history(10),
        }

    def signal_voice_activity(self, text: str = "") -> None:
        """API voix → réinitialise silence + signale micro disponible."""
        monitoring_engine.signal_mic_available(True)
        monitoring_engine.signal_voice_activity()
        self._log("voice", "Activité vocale", {"preview": text[:60]})

    def signal_user_interaction(self) -> None:
        """Chat → compte comme activité vocale."""
        monitoring_engine.signal_voice_activity()

    def signal_user_response(self) -> dict:
        """Bouton 'Je vais bien' → résout l'incident en cours."""
        monitoring_engine.signal_response()
        self._log("response", "Réponse utilisateur", {"ts": _now_iso()})
        return {"status": "response_registered"}

    def trigger_emergency(self) -> dict:
        """Bouton d'urgence."""
        monitoring_engine.signal_manual_emergency()
        self._log("emergency", "Bouton urgence activé", {"ts": _now_iso()})
        return {"status": "emergency_triggered"}

    def configure_comms(self, config: dict) -> None:
        comms_engine.configure(config)

    def get_pending_vocal_probe(self) -> Optional[dict]:
        """Frontend poll — retourne le prochain TTS à jouer et le consomme."""
        with self._lock:
            if self._probe_queue:
                return self._probe_queue.pop(0)
        return None

    # ──────────────────────────────────────────────────────────────────
    # Vision event handler
    # ──────────────────────────────────────────────────────────────────

    def _on_vision_event(self, event: VisionEvent, data: dict) -> None:
        """
        Routage strict :
          FALL_SUSPECTED    → signal_fall()    [jamais signal_absence]
          ABSENCE_PROLONGED → signal_absence() [jamais signal_fall]
          PRESENCE_DETECTED → signal_person_seen()
          PRESENCE_LOST     → log seul
          CAMERA_ERROR      → signal_camera_available(False)
        """
        self._log("vision", event.value, data)

        if event == VisionEvent.PRESENCE_DETECTED:
            monitoring_engine.signal_person_seen()

        elif event == VisionEvent.PRESENCE_LOST:
            pass  # log suffit — monitoring_engine gère le timeout

        elif event == VisionEvent.FALL_SUSPECTED:
            # RÈGLE ABSOLUE : chute -> signal_fall, jamais signal_absence
            monitoring_engine.signal_fall(extra=data)

        elif event == VisionEvent.ABSENCE_PROLONGED:
            # RÈGLE ABSOLUE : absence -> signal_absence, jamais signal_fall
            monitoring_engine.signal_absence(extra=data)

        elif event == VisionEvent.CAMERA_ERROR:
            # Mode dégradé : caméra en erreur → on continue sans elle
            monitoring_engine.signal_camera_available(False)
            self._log("error", "Caméra en erreur — mode dégradé activé", data)
            logger.warning("Caméra hors service — surveillance vocale+temporelle maintenue")

    # ──────────────────────────────────────────────────────────────────
    # Alert handler
    # ──────────────────────────────────────────────────────────────────

    def _on_alert(self, alert: Alert) -> None:
        """
        Reçoit toutes les alertes du monitoring_engine.
        Décide via decide() si on notifie les comms.

        Depuis v1.9.1 : publie aussi sur le bus pour traçabilité unifiée.
        Le bus déclenchera _on_bus_event() qui passe par core_decision.
        Les deux mécanismes coexistent : compat 100%, traçabilité ajoutée.
        """
        self._log("alert", alert.message, alert.to_dict())

        # ── Publication bus (traçabilité, journal central) ──
        try:
            self._bus.publish(Event(
                type=f"alert.{alert.type.value}",
                source="monitoring_engine",
                level=_LEVEL_MAP.get(alert.level, EventLevel.MEDIUM),
                message=alert.message,
                payload=alert.to_dict(),
            ))
        except Exception as exc:
            logger.warning("[CORE] bus publish failed (alert) : %s", exc)

        # ── Décision via assistant (logique métier conservée) ──
        decision = self._call_decide(alert)

        logger.info("Décision alert=%s action=%s tts=%s notify=%s src=%s",
                    alert.type.value, decision.get("action"),
                    decision.get("tts"), decision.get("notify"),
                    decision.get("source", "?"))

        # TTS probe pour le frontend (seulement si pas déjà géré par monitoring_engine)
        # Les types FALL, FALL_ESCALATED, FALL_CONFIRMED, MANUAL ont déjà leur TTS
        ALREADY_HAS_TTS = {
            AlertType.FALL, AlertType.FALL_ESCALATED,
            AlertType.FALL_CONFIRMED, AlertType.MANUAL,
        }
        if decision.get("tts") and alert.type not in ALREADY_HAS_TTS:
            msg = decision.get("message", "")
            if msg:
                self._enqueue_probe(alert.type.value, alert.level.value, msg, immediate=False)

        # Comms — sur CRITICAL/URGENT ou décision explicite
        needs_comms = (
            decision.get("notify")
            or alert.level in (AlertLevel.CRITICAL, AlertLevel.URGENT)
        )
        if needs_comms:
            self._send_comms_safe(alert)

    # ── Handler bus pour évts venant d'autres modules ─────────────────────

    def _on_bus_event(self, event: Event) -> None:
        """
        Reçoit les événements publiés sur le bus par les modules transverses
        (file_search, voice activity, camera analyze, etc.).

        N'agit PAS sur les events `alert.*` republiés depuis _on_alert
        (déjà traités par la logique monitoring historique).

        Consulte core_decision pour décider, et trace tout dans le journal.
        """
        # Éviter le double traitement des alertes monitoring déjà gérées
        if event.type.startswith("alert."):
            return

        decision = self._decision_engine.decide(event)

        # Trace dans le journal local de l'orchestrator
        self._log("bus", event.message or event.type, {
            "event":    event.to_dict(),
            "decision": decision.to_dict(),
        })

        # Exécution selon la décision (cadre strict, pas d'action arbitraire)
        if decision.decision == CoreDecision.NOTIFY:
            # Notification UI via probe TTS / chat
            if event.message:
                self._enqueue_probe(
                    event.type, event.level.value, event.message,
                    immediate=(event.level == EventLevel.CRITICAL),
                )
        elif decision.decision == CoreDecision.REQUEST_CONFIRM:
            # Marquer en probe avec un flag confirmation requise
            self._enqueue_probe(
                event.type, event.level.value,
                event.message or f"Confirmation requise : {event.type}",
                immediate=False,
            )
        elif decision.decision == CoreDecision.TRIGGER_ACTION:
            # Actions auto-déclenchables : liste blanche dans core_decision
            self._execute_authorized_action(decision.action_name, decision.action_payload)
        # IGNORE / REMEMBER : déjà tracé dans _log, rien d'autre à faire ici

    def _execute_authorized_action(self, action_name: Optional[str], payload: dict) -> None:
        """
        Exécute UNIQUEMENT les actions de la whitelist (core_decision).
        Toute action inconnue est refusée et tracée.
        """
        if not action_name:
            return
        if action_name == "trigger_emergency_protocol":
            try:
                self.trigger_emergency()
                logger.info("[CORE] action exécutée : %s", action_name)
            except Exception as exc:
                logger.error("[CORE] action %s a échoué : %s", action_name, exc)
        elif action_name == "graceful_shutdown":
            try:
                self.stop()
                logger.info("[CORE] action exécutée : %s", action_name)
            except Exception as exc:
                logger.error("[CORE] action %s a échoué : %s", action_name, exc)
        else:
            logger.warning("[CORE] action refusée (non whitelistée) : %s", action_name)

    def _on_tts(self, message: str) -> None:
        """
        Callback TTS direct depuis monitoring_engine.
        Enfile le message en priorité (immédiate=True) ET tente TTS local.
        """
        if not message:
            return
        self._enqueue_probe("system", "critical", message, immediate=True)
        self._try_local_tts(message)

    # ──────────────────────────────────────────────────────────────────
    # decide() — assistant central
    # ──────────────────────────────────────────────────────────────────

    def _call_decide(self, alert: Alert) -> dict:
        """
        Tous les événements passent par assistant.decide().
        Fallback rule-based si indisponible — ne plante jamais.
        """
        try:
            from app.core.assistant_extension import extended_assistant
            from app.db.database import SessionLocal
            with SessionLocal() as db:
                return extended_assistant.decide(
                    db=db,
                    event=alert.type.value,
                    context={
                        **alert.extra,
                        "_level":          alert.level.value,
                        "_incident_state": monitoring_engine.get_incident().get("state"),
                    },
                )
        except Exception as exc:
            logger.warning("decide() fallback | %s", exc)
            return self._fallback_decide(alert)

    def _fallback_decide(self, alert: Alert) -> dict:
        """Décision minimale — ne plante jamais."""
        is_critical = alert.level in (AlertLevel.CRITICAL, AlertLevel.URGENT)
        return {
            "action":  "alert" if is_critical else "log",
            "message": "",
            "tts":     False,   # évite double TTS
            "notify":  is_critical,
            "source":  "fallback",
        }

    # ──────────────────────────────────────────────────────────────────
    # Internal helpers
    # ──────────────────────────────────────────────────────────────────

    def _enqueue_probe(
        self,
        alert_type: str,
        alert_level: str,
        message: str,
        immediate: bool,
    ) -> None:
        """Ajoute un message TTS à la file frontend. Ignore les messages vides."""
        if not message or not message.strip():
            return
        entry = {
            "probe":       True,
            "message":     message,
            "alert_type":  alert_type,
            "alert_level": alert_level,
            "timestamp":   _now_iso(),
            "immediate":   immediate,
        }
        with self._lock:
            if immediate:
                self._probe_queue.insert(0, entry)
                # Max 5 messages immédiats
                if len(self._probe_queue) > 5:
                    self._probe_queue = self._probe_queue[:5]
            else:
                if len(self._probe_queue) < 3:
                    self._probe_queue.append(entry)

        logger.info("Probe vocal enfilé | immediate=%s | %s", immediate, message[:60])

    def _send_comms_safe(self, alert: Alert) -> None:
        """Envoi comms — jamais de crash, log si échec."""
        try:
            result = comms_engine.notify(alert)
            logger.info("Comms envoyé | channels=%s", result.get("channels"))
        except Exception as exc:
            logger.error("Comms error (non bloquant) | %s", exc)

    def _try_local_tts(self, message: str) -> None:
        """pyttsx3 en thread daemon — silencieux si indisponible."""
        def _speak():
            try:
                from app.core.tts_engine import TTSEngine
                TTSEngine().speak(message)
            except Exception as exc:
                logger.debug("TTS local indisponible | %s", exc)
        threading.Thread(target=_speak, daemon=True, name="tts-local").start()

    def _log(self, source: str, description: str, data: dict) -> None:
        entry = {
            "timestamp":   _now_iso(),
            "source":      source,
            "description": description,
            "data":        data,
        }
        with self._lock:
            self._event_log.append(entry)
            if len(self._event_log) > 500:
                self._event_log = self._event_log[-500:]
        # Persistance best-effort
        self._persist_event_safe(source, description, data)

    def _persist_event_safe(self, source: str, description: str, data: dict) -> None:
        try:
            from app.db.database import SessionLocal
            from app.db.models import MonitoringEvent
            with SessionLocal() as db:
                row = MonitoringEvent(
                    source      = source,
                    description = description[:255],
                    extra_json  = json.dumps(data, ensure_ascii=False, default=str)[:2000],
                )
                db.add(row)
                db.commit()
        except Exception:
            pass  # silencieux — RAM suffit


# Singleton
orchestrator = Orchestrator()
