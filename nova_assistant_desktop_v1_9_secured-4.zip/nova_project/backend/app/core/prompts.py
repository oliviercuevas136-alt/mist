from typing import List

from app.config import settings


def build_system_prompt(
    memory_items: List[str] | None = None,
    document_items: List[str] | None = None,
    conversation_summary: str | None = None,
) -> str:
    language = settings.system_language
    memory_block = ""
    document_block = ""
    summary_block = ""

    if memory_items:
        joined = "\n".join(f"- {item}" for item in memory_items)
        memory_block = f"\nMémoire pertinente :\n{joined}\n"

    if document_items:
        joined = "\n".join(f"- {item}" for item in document_items)
        document_block = f"\nExtraits documentaires utiles :\n{joined}\n"

    if conversation_summary:
        summary_block = f"\nRésumé de la conversation en cours :\n{conversation_summary}\n"

    return f"""
Tu es un assistant personnel local, sobre et efficace, tournant sur la machine de l'utilisateur.
Tu réponds en {language}, sauf demande contraire explicite.

Principes de réponse :
- Sois direct et concret ; évite le remplissage
- N'invente pas de faits : dis clairement si une information manque
- Utilise la mémoire seulement si elle est réellement utile à la question posée
- Utilise les documents seulement si leur contenu répond directement
- Structure ta réponse si c'est plus lisible, sinon réponds en prose courte
- Ne prétends jamais avoir exécuté une action que tu n'as pas faite
- Quand c'est utile, propose la prochaine étape concrète à l'utilisateur
- Ne répète pas ce que l'utilisateur vient de dire
{summary_block}{memory_block}{document_block}""".strip()