import re
import unicodedata
from collections import Counter
from typing import Iterable


WORD_RE = re.compile(r"\w+", re.UNICODE)


def normalize_text(text: str) -> str:
    text = (text or "").lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return text


def tokenize(text: str) -> list[str]:
    normalized = normalize_text(text)
    return [w for w in WORD_RE.findall(normalized) if w.strip()]


def overlap_score(query: str, text: str) -> int:
    q_tokens = tokenize(query)
    t_tokens = tokenize(text)

    if not q_tokens or not t_tokens:
        return 0

    q_counter = Counter(q_tokens)
    t_counter = Counter(t_tokens)

    score = 0
    for token, count in q_counter.items():
        score += min(count, t_counter.get(token, 0))

    return score


def weighted_memory_score(query: str, content: str, importance: int) -> int:
    base = overlap_score(query, content)
    # Pas de remontée si aucun mot ne correspond
    if base == 0:
        return 0
    return base * 10 + max(1, int(importance))


def weighted_document_score(query: str, filename: str, path: str, preview: str) -> int:
    score = 0
    score += overlap_score(query, filename) * 15
    score += overlap_score(query, path) * 10
    score += overlap_score(query, preview) * 5
    return score


def sort_by_score(items: Iterable[tuple[int, object]]) -> list[object]:
    return [item for _, item in sorted(items, key=lambda x: x[0], reverse=True)]