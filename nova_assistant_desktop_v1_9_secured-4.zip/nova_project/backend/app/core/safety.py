from pathlib import Path

from app.config import settings


class SafetyError(Exception):
    pass


def resolve_and_validate_path(relative_path: str) -> Path:
    if not relative_path or not relative_path.strip():
        raise SafetyError("Chemin vide.")

    candidate = (settings.base_dir / relative_path.strip()).resolve()

    for allowed in settings.allowed_base_paths:
        allowed_resolved = allowed.resolve()
        try:
            candidate.relative_to(allowed_resolved)
            return candidate
        except ValueError:
            continue

    raise SafetyError("Chemin non autorisé.")