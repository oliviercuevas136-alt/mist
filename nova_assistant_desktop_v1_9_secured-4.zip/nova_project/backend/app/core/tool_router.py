"""
tool_router.py — Router d'intentions pour les outils agentiques.

Architecture intentionnellement simple :
  - Pas de LangGraph (trop lourd pour un usage solo)
  - Pattern matching sur mots-clés (déterministe, rapide, sans LLM)
  - Chaque outil retourne {"ok": bool, "text": str, ...données...}
  - Le texte est directement utilisable pour TTS

Ajouter un outil :
  1. Créer app/core/tools/mon_outil.py avec une fonction principale
  2. Ajouter un _PATTERN dans ce fichier
  3. Ajouter le cas dans route()

Ordre de priorité des patterns : du plus spécifique au plus général.
"""
import re
from typing import Any, Dict, Optional
from app.utils.logger import get_logger

logger = get_logger("tool_router")


# ── Patterns de détection ──────────────────────────────────────────────────────
# Chaque pattern retourne un dict d'intention ou None

def _match_weather(text: str) -> Optional[Dict]:
    """Détecte les demandes météo et extrait la ville."""
    lower = text.lower()
    keywords = ["météo", "meteo", "temps qu'il fait", "temperature", "température",
                "va-t-il pleuvoir", "va-t-il neiger", "faire dehors", "sortir aujourd",
                "vent", "nuageux", "ensoleillé", "pluie", "neige", "chaud", "froid"]

    if not any(k in lower for k in keywords):
        return None

    # Extraire la ville
    city_patterns = [
        r"(?:météo|meteo|temps).*?(?:à|a|de|pour|sur)\s+([A-ZÀ-Ÿa-zà-ÿ\s\-]+?)(?:\s*\?|$|\.|,)",
        r"(?:à|a)\s+([A-ZÀ-Ÿa-zà-ÿ\s\-]+?)(?:\s+(?:il fait|aujourd|demain|\?))",
        r"(?:sur|pour)\s+([A-ZÀ-Ÿa-zà-ÿ\s\-]+?)(?:\s*\?|$)",
    ]
    city = "Paris"  # défaut
    for pattern in city_patterns:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            candidate = m.group(1).strip().title()
            if len(candidate) > 2:
                city = candidate
                break

    return {"tool": "weather", "city": city}


def _match_system(text: str) -> Optional[Dict]:
    """Détecte les demandes de monitoring système."""
    lower = text.lower()
    keywords = [
        "cpu", "ram", "mémoire", "memoire", "disque", "processeur",
        "système", "systeme", "ordinateur", "pc",
        "lent", "ralentit", "ralenti", "charge", "surchauffe",
        "processus", "état du système", "comment va le pc",
        "espace disque", "batterie",
    ]
    if any(k in lower for k in keywords):
        # Distinguer demande processus vs état général
        if any(k in lower for k in ["processus", "programme", "application qui tourne"]):
            return {"tool": "system_processes"}
        return {"tool": "system_status"}
    return None


def _match_datetime(text: str) -> Optional[Dict]:
    """Détecte les demandes d'heure et de date."""
    lower = text.lower()
    keywords = [
        "quelle heure", "il est quelle heure", "heure est-il",
        "quelle date", "on est le", "quel jour", "aujourd'hui c'est",
        "quel mois", "quelle année",
    ]
    if any(k in lower for k in keywords):
        return {"tool": "datetime"}
    return None


def _match_web_search(text: str) -> Optional[Dict]:
    """Détecte les demandes de recherche web."""
    lower = text.lower()
    triggers = [
        "cherche", "recherche", "trouve", "googl", "qu'est-ce que",
        "c'est quoi", "qui est", "qu'est-ce qu'", "dis-moi ce que c'est",
        "explique-moi", "définition de", "c'est quoi",
    ]
    if any(k in lower for k in triggers):
        # Extraire la requête (supprimer le trigger)
        query = text
        for trigger in ["cherche ", "recherche ", "trouve ", "qu'est-ce que ",
                        "c'est quoi ", "qui est ", "explique-moi "]:
            if lower.startswith(trigger):
                query = text[len(trigger):]
                break
        return {"tool": "web_search", "query": query.strip(" ?.")}
    return None


# ── Router principal ──────────────────────────────────────────────────────────

_MATCHERS = [
    _match_datetime,   # avant weather (évite confusion "temps")
    _match_weather,
    _match_system,
    _match_web_search,
]


def route(text: str) -> Optional[Dict[str, Any]]:
    """
    Tente de router le texte vers un outil.
    Retourne None si aucun outil ne correspond (→ chat LLM normal).
    """
    for matcher in _MATCHERS:
        result = matcher(text)
        if result is not None:
            logger.info("Tool routed | tool=%s | input=%s...", result["tool"], text[:40])
            return result
    return None


def execute(intent: Dict[str, Any]) -> Dict[str, Any]:
    """
    Exécute l'outil correspondant à l'intention.
    Retourne toujours {"ok": bool, "text": str, ...}.
    """
    tool = intent.get("tool")

    try:
        if tool == "weather":
            from app.core.tools.weather_tool import get_weather
            return get_weather(city=intent.get("city", "Paris"))

        elif tool == "system_status":
            from app.core.tools.system_tool import get_system_status
            return get_system_status()

        elif tool == "system_processes":
            from app.core.tools.system_tool import get_top_processes
            return get_top_processes(n=5)

        elif tool == "datetime":
            from app.core.tools.web_tool import get_current_time
            return get_current_time()

        elif tool == "web_search":
            from app.core.tools.web_tool import web_search
            return web_search(query=intent.get("query", ""))

        else:
            logger.warning("Outil inconnu | tool=%s", tool)
            return {"ok": False, "text": f"Outil '{tool}' non disponible.", "tool": tool}

    except Exception as exc:
        logger.error("Outil échoué | tool=%s | error=%s", tool, exc)
        return {
            "ok":    False,
            "text":  "Une erreur est survenue lors de l'exécution de l'outil.",
            "tool":  tool,
            "error": str(exc),
        }
