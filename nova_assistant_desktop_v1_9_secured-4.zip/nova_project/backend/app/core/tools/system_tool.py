"""
system_tool.py — Monitoring système local via psutil.

Fournit CPU, RAM, disque, processus actifs, température (si dispo).
Pas de dépendances externes — psutil est léger et cross-platform.
"""
import datetime
from typing import Any, Dict
from app.utils.logger import get_logger

logger = get_logger("tool.system")


def _try_import_psutil():
    try:
        import psutil
        return psutil
    except ImportError:
        return None


def get_system_status() -> Dict[str, Any]:
    """
    Retourne l'état système avec une phrase TTS-ready.
    Fonctionne même si psutil n'est pas installé (mode dégradé).
    """
    psutil = _try_import_psutil()

    if psutil is None:
        return {
            "ok":   False,
            "text": "Le module système n'est pas installé. Lancez : pip install psutil",
            "error": "psutil_missing",
        }

    try:
        cpu      = psutil.cpu_percent(interval=0.5)
        ram      = psutil.virtual_memory()
        disk     = psutil.disk_usage("/")
        boot_time = datetime.datetime.fromtimestamp(psutil.boot_time())
        uptime_h  = (datetime.datetime.now() - boot_time).seconds // 3600

        ram_used_gb  = round(ram.used  / 1e9, 1)
        ram_total_gb = round(ram.total / 1e9, 1)
        disk_free_gb = round(disk.free / 1e9, 1)

        # Température (Windows : souvent indisponible)
        temp_str = ""
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                first = next(iter(temps.values()))
                if first:
                    t = round(first[0].current)
                    temp_str = f" Température CPU {t}°C."
        except Exception:
            pass

        # Évaluation santé
        warnings = []
        if cpu > 85:
            warnings.append("CPU surchargé")
        if ram.percent > 85:
            warnings.append("mémoire critique")
        if disk.percent > 90:
            warnings.append("disque presque plein")

        health = "Tout va bien." if not warnings else "Attention : " + ", ".join(warnings) + "."

        text = (
            f"CPU à {cpu}%, RAM {ram_used_gb}/{ram_total_gb} Go "
            f"({round(ram.percent)}%), disque libre {disk_free_gb} Go.{temp_str} {health}"
        )

        logger.info("Système OK | cpu=%.1f%% | ram=%.1f%% | disk_free=%.1fGo",
                    cpu, ram.percent, disk_free_gb)

        return {
            "ok":          True,
            "text":        text,
            "cpu_percent": cpu,
            "ram_percent": round(ram.percent),
            "ram_used_gb": ram_used_gb,
            "ram_total_gb": ram_total_gb,
            "disk_free_gb": disk_free_gb,
            "disk_percent": disk.percent,
            "uptime_hours": uptime_h,
            "warnings":    warnings,
        }

    except Exception as exc:
        logger.error("Système status échoué | %s", exc)
        return {
            "ok":    False,
            "text":  "Je n'ai pas pu lire l'état du système.",
            "error": str(exc),
        }


def get_top_processes(n: int = 5) -> Dict[str, Any]:
    """Retourne les N processus les plus gourmands en CPU."""
    psutil = _try_import_psutil()
    if psutil is None:
        return {"ok": False, "text": "psutil non installé.", "processes": []}

    try:
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                info = p.info
                procs.append({
                    "pid":  info["pid"],
                    "name": info["name"],
                    "cpu":  round(info["cpu_percent"] or 0, 1),
                    "mem":  round(info["memory_percent"] or 0, 1),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        procs.sort(key=lambda x: x["cpu"], reverse=True)
        top = procs[:n]

        if top:
            parts = [f"{p['name']} ({p['cpu']}% CPU)" for p in top[:3]]
            text = "Processus les plus actifs : " + ", ".join(parts) + "."
        else:
            text = "Aucun processus actif détecté."

        return {"ok": True, "text": text, "processes": top}

    except Exception as exc:
        logger.error("Top processus échoué | %s", exc)
        return {"ok": False, "text": "Impossible de lire les processus.", "error": str(exc)}
