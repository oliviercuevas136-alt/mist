"""
weather_tool.py — Météo locale via Open-Meteo (gratuit, sans clé API).

Usage :
    result = get_weather("Paris")
    # → {"text": "À Paris il fait 18°C, ciel dégagé.", "temp": 18, ...}

Pas de clé API requise. Geocoding via Open-Meteo aussi.
"""
import urllib.request
import urllib.parse
import json
from typing import Optional
from app.utils.logger import get_logger

logger = get_logger("tool.weather")

# Codes WMO → description française courte
_WMO_CODES = {
    0:  "ciel dégagé",
    1:  "peu nuageux", 2: "partiellement nuageux", 3: "couvert",
    45: "brouillard", 48: "brouillard givrant",
    51: "bruine légère", 53: "bruine modérée", 55: "bruine dense",
    61: "pluie légère", 63: "pluie modérée", 65: "pluie forte",
    71: "neige légère", 73: "neige modérée", 75: "neige forte",
    77: "grésil",
    80: "averses légères", 81: "averses modérées", 82: "averses violentes",
    85: "averses de neige", 86: "averses de neige fortes",
    95: "orage", 96: "orage avec grêle", 99: "orage violent",
}


def _fetch_json(url: str, timeout: int = 8) -> dict:
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _geocode(city: str) -> Optional[tuple[float, float, str]]:
    """Retourne (lat, lon, nom_affiché) ou None."""
    url = (
        "https://geocoding-api.open-meteo.com/v1/search?"
        + urllib.parse.urlencode({"name": city, "count": 1, "language": "fr", "format": "json"})
    )
    try:
        data = _fetch_json(url)
        results = data.get("results", [])
        if not results:
            return None
        r = results[0]
        return r["latitude"], r["longitude"], r.get("name", city)
    except Exception as exc:
        logger.warning("Geocoding échoué | city=%s | %s", city, exc)
        return None


def get_weather(city: str = "Paris") -> dict:
    """
    Récupère la météo actuelle pour une ville.
    Retourne un dict avec 'text' (phrase prête pour TTS) et les données brutes.
    """
    geo = _geocode(city)
    if geo is None:
        return {
            "ok": False,
            "text": f"Je n'ai pas trouvé la ville {city}.",
            "error": "geocoding_failed",
        }

    lat, lon, display_name = geo
    url = (
        "https://api.open-meteo.com/v1/forecast?"
        + urllib.parse.urlencode({
            "latitude":  lat,
            "longitude": lon,
            "current":   "temperature_2m,apparent_temperature,weathercode,windspeed_10m,relativehumidity_2m",
            "timezone":  "auto",
            "wind_speed_unit": "kmh",
        })
    )

    try:
        data = _fetch_json(url)
        cur  = data["current"]
        temp      = round(cur["temperature_2m"])
        feels     = round(cur["apparent_temperature"])
        code      = cur["weathercode"]
        wind      = round(cur["windspeed_10m"])
        humidity  = cur["relativehumidity_2m"]
        desc      = _WMO_CODES.get(code, "conditions inconnues")

        # Phrase naturelle pour TTS
        feels_str = f", ressenti {feels}°C" if abs(feels - temp) >= 2 else ""
        text = (
            f"À {display_name} il fait {temp}°C{feels_str}, {desc}. "
            f"Vent {wind} km/h, humidité {humidity}%."
        )

        logger.info("Météo OK | city=%s | temp=%d | desc=%s", display_name, temp, desc)
        return {
            "ok":          True,
            "text":        text,
            "city":        display_name,
            "temp":        temp,
            "feels_like":  feels,
            "description": desc,
            "wind_kmh":    wind,
            "humidity":    humidity,
            "wmo_code":    code,
        }

    except Exception as exc:
        logger.error("Météo échouée | city=%s | %s", city, exc)
        return {
            "ok":    False,
            "text":  f"Je n'ai pas pu obtenir la météo de {city}.",
            "error": str(exc),
        }
