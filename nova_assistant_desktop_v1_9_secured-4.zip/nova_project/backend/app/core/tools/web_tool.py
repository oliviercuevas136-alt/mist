"""
web_tool.py — Recherche web simple via DuckDuckGo Instant Answer API.

Pas de clé API. Résultats textuels seulement.
Pour des recherches plus complètes, utiliser SerpAPI ou Brave Search (clé requise).
"""
import urllib.request
import urllib.parse
import json
from typing import Dict, Any
from app.utils.logger import get_logger

logger = get_logger("tool.web")


def web_search(query: str, max_results: int = 3) -> Dict[str, Any]:
    """
    Recherche DuckDuckGo Instant Answer (sans clé, résultats limités).
    Pour un résumé factuel rapide sur un sujet.
    """
    url = (
        "https://api.duckduckgo.com/?"
        + urllib.parse.urlencode({
            "q":      query,
            "format": "json",
            "no_redirect": 1,
            "no_html": 1,
            "skip_disambig": 1,
        })
    )

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "LocalAssistant/1.0"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode())

        abstract = data.get("AbstractText", "").strip()
        answer   = data.get("Answer", "").strip()
        entity   = data.get("Heading", "").strip()

        if answer:
            text = answer
        elif abstract:
            # Limiter à 300 chars pour TTS
            text = abstract[:300].rstrip() + ("…" if len(abstract) > 300 else "")
        else:
            text = f"Je n'ai pas trouvé de réponse directe pour : {query}."

        logger.info("Recherche OK | query=%s | found=%s", query[:40], bool(abstract or answer))
        return {
            "ok":       True,
            "text":     text,
            "entity":   entity,
            "query":    query,
            "source":   data.get("AbstractSource", "DuckDuckGo"),
            "url":      data.get("AbstractURL", ""),
        }

    except Exception as exc:
        logger.error("Recherche échouée | query=%s | %s", query[:40], exc)
        return {
            "ok":    False,
            "text":  f"Je n'ai pas pu effectuer la recherche.",
            "error": str(exc),
            "query": query,
        }


def get_current_time() -> Dict[str, Any]:
    """Retourne l'heure et la date actuelles — aucune API nécessaire."""
    import datetime
    now  = datetime.datetime.now()
    date = now.strftime("%A %d %B %Y")
    time = now.strftime("%H h %M")
    # Traduction basique des jours/mois (Windows locale peut varier)
    fr_days = {
        "Monday": "lundi", "Tuesday": "mardi", "Wednesday": "mercredi",
        "Thursday": "jeudi", "Friday": "vendredi", "Saturday": "samedi", "Sunday": "dimanche",
    }
    fr_months = {
        "January": "janvier", "February": "février", "March": "mars",
        "April": "avril", "May": "mai", "June": "juin",
        "July": "juillet", "August": "août", "September": "septembre",
        "October": "octobre", "November": "novembre", "December": "décembre",
    }
    for en, fr in {**fr_days, **fr_months}.items():
        date = date.replace(en, fr)

    text = f"Il est {time}, le {date}."
    return {"ok": True, "text": text, "datetime": now.isoformat()}
