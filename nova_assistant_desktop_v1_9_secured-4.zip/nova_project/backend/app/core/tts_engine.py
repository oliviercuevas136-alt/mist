import queue as _qmod
import re
import time
from threading import Event, Lock

import pyttsx3

from app.config import settings
from app.utils.logger import get_logger


logger = get_logger("tts_engine")

# Regex découpe phrases sur . ! ? suivi d'espace+lettre ou fin de texte
_SENTENCE_RE = re.compile(r'(?<=[.!?])\s+(?=[A-ZÀ-Ÿa-zà-ÿ])|(?<=[.!?])$')

# Mode vocal : on vise < 2s → 2 mots/s à 180wpm → 4-5 mots max → ~25 chars sûrs
# On prend 80 chars mais on coupe à la première fin de phrase
_VOICE_MAX_CHARS = 80
_TTS_SLOW_MS     = 2000


def _clean_for_voice(text: str) -> str:
    """Nettoie le texte pour TTS : supprime markdown, listes, retours à la ligne."""
    text = re.sub(r'\*+', '', text)          # bold/italic markdown
    text = re.sub(r'#+\s*', '', text)        # headers
    text = re.sub(r'[-•]\s+', '', text)      # listes
    text = re.sub(r'\n+', ' ', text)         # retours à la ligne
    text = re.sub(r'\s{2,}', ' ', text)      # espaces multiples
    return text.strip()


def _first_sentence(text: str, max_chars: int) -> str:
    """
    Extrait la première phrase complète dans max_chars caractères.
    Coupe proprement sur . ! ? — jamais en milieu de mot.
    """
    text = text[:max_chars * 2]  # buffer de travail
    # Chercher la première fin de phrase dans max_chars
    for i, ch in enumerate(text[:max_chars]):
        if ch in '.!?' and i > 2:
            return text[:i + 1].strip()
    # Pas de phrase complète dans max_chars — couper au dernier espace
    truncated = text[:max_chars]
    last_space = truncated.rfind(' ')
    if last_space > max_chars // 2:
        return truncated[:last_space].strip()
    return truncated.strip()


class TTSEngine:
    """
    Moteur TTS singleton.
    v4.6 : engine.stop() dans stop(), logs VOICE_SEGMENT_READY/SPOKEN/INTERRUPTED/QUEUE_SIZE.
    - moteur pyttsx3 initialisé UNE SEULE FOIS dans __init__
    - verrou _lock : un seul TTS à la fois
    - _stop_event : permet d'interrompre le TTS en cours
    - _current_seg : segment en cours (debug)
    """
    _lock        = Lock()
    _stop_event  = Event()
    _current_seg = ""  # segment en cours de lecture (debug / monitoring)

    def __init__(self) -> None:
        try:
            self.engine = pyttsx3.init()
            self.engine.setProperty("rate", 175)  # 175 wpm — clair pour personne âgée
            self._available = True
            logger.info("TTS initialisé | rate=175")
        except Exception as exc:
            logger.error("Initialisation TTS échouée | erreur=%s", str(exc))
            self.engine = None
            self._available = False

    # ── Interface publique ────────────────────────────────────────────────────

    def stop(self) -> None:
        """Arrêt immédiat : stop_event + interruption pyttsx3 runAndWait()."""
        self._stop_event.set()
        # engine.stop() interrompt runAndWait() en cours (Windows SAPI5 / espeak)
        if self._available and self.engine is not None:
            try:
                self.engine.stop()
            except Exception:
                pass
        logger.info("[VOICE_INTERRUPTED] TTS stop demandé")

    def speak(self, text: str) -> int:
        """Synthèse complète (endpoint /speak classique). Retourne tts_ms."""
        if not settings.enable_tts:
            return 0
        if not self._available or self.engine is None:
            return 0
        cleaned = _clean_for_voice(text or "")
        if not cleaned:
            return 0
        return self._speak_internal(cleaned)

    def speak_voice_mode(self, text: str) -> int:
        """
        Mode vocal rapide :
        - nettoie le markdown
        - extrait la première phrase complète dans 80 chars
        - skip si stop_event levé
        - log TTS_TOO_SLOW si > 2s
        """
        if not settings.enable_tts:
            return 0
        if not self._available or self.engine is None:
            return 0

        cleaned = _clean_for_voice(text or "")
        if not cleaned:
            return 0

        # Extraire première phrase courte
        voice_text = _first_sentence(cleaned, _VOICE_MAX_CHARS)
        if not voice_text:
            return 0

        logger.debug("TTS voice_mode | original=%d chars → voice=%d chars | %s...",
                     len(cleaned), len(voice_text), voice_text[:30])
        return self._speak_internal(voice_text)

    # ── Interne ───────────────────────────────────────────────────────────────

    def _speak_internal(self, text: str) -> int:
        """Synthèse réelle avec verrou, stop_event, mesure de temps."""
        self._stop_event.clear()
        t0 = time.perf_counter()

        logger.info("[VOICE_TTS_START] len=%d  preview=%s...", len(text), text[:40])

        if not self._lock.acquire(timeout=0.1):
            logger.warning("TTS déjà en cours — requête ignorée")
            return 0

        try:
            if self._stop_event.is_set():
                logger.debug("TTS annulé avant démarrage")
                return 0

            self.engine.say(text)
            self.engine.runAndWait()

        except Exception as exc:
            logger.error("Erreur TTS | %s", str(exc))
        finally:
            self._lock.release()

        elapsed = int((time.perf_counter() - t0) * 1000)

        if elapsed > _TTS_SLOW_MS:
            logger.warning("[TTS_TOO_SLOW] tts_ms=%d  len=%d", elapsed, len(text))

        logger.info("[VOICE_TTS_END] tts_ms=%d", elapsed)
        return elapsed

    # ── TTS progressif (pipeline streaming) ──────────────────────────────────

    def speak_sentence_queue(
        self,
        q: "_qmod.Queue[str | None]",
        timeout_total: float = 30.0,
    ) -> int:
        """
        TTS progressif : lit les phrases de la queue au fur et à mesure.

        Conçu pour tourner dans un thread dédié pendant le streaming LLM :
        - Attend le verrou si un TTS est déjà en cours (ex: ACK vocal).
        - S'arrête sur None (sentinel) ou stop_event.
        - Timeout de sécurité : timeout_total secondes.
        - Retourne le temps total TTS en ms.

        Usage typique :
            tts_q = queue.Queue()
            t = threading.Thread(target=tts_engine.speak_sentence_queue, args=(tts_q,))
            t.start()
            tts_q.put("Bonjour !")       # jouée dès que le verrou est libre
            tts_q.put("Comment allez-vous ?")
            tts_q.put(None)              # sentinel → fin du thread
            t.join()
        """
        if not self._available or self.engine is None:
            return 0

        t0 = time.perf_counter()
        deadline = t0 + timeout_total
        total_ms = 0

        while True:
            # Arrêt demandé (ex: /stop endpoint ou nouvelle requête utilisateur)
            if self._stop_event.is_set():
                logger.info("[VOICE_INTERRUPTED] [TTS_QUEUE] stop_event — arrêt propre")
                break

            # Timeout global de sécurité
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                logger.warning("[TTS_QUEUE] timeout=%.0fs atteint", timeout_total)
                break

            # Récupérer prochaine phrase (non-bloquant avec timeout court)
            try:
                segment = q.get(timeout=min(0.05, remaining))
            except _qmod.Empty:
                continue

            if segment is None:
                break  # sentinel : fin normale

            segment = segment.strip()
            if not segment:
                continue

            if not settings.enable_tts:
                continue

            # Attendre le verrou (ACK ou phrase précédente peut être en lecture)
            # Contrairement à _speak_internal (0.1s), ici on attend proprement
            t_acquire = time.perf_counter()
            acquired = False
            while not acquired:
                if self._stop_event.is_set():
                    break
                if time.perf_counter() > deadline:
                    break
                acquired = self._lock.acquire(timeout=0.2)

            if not acquired:
                logger.debug("[TTS_QUEUE] lock non acquis pour segment=%s...", segment[:20])
                continue

            try:
                if self._stop_event.is_set():
                    logger.info(
                        "[VOICE_INTERRUPTED] stop_event détecté — segment abandonné"
                        " | preview=%s...", segment[:20]
                    )
                    continue

                wait_ms = int((time.perf_counter() - t_acquire) * 1000)
                seg_t0 = time.perf_counter()
                self._current_seg = segment  # debug / monitoring
                logger.info(
                    "[TTS_QUEUE_SPEAK] len=%d  wait_ms=%d  preview=%s...",
                    len(segment), wait_ms, segment[:35],
                )
                self.engine.say(segment)
                self.engine.runAndWait()
                seg_ms = int((time.perf_counter() - seg_t0) * 1000)
                total_ms += seg_ms
                self._current_seg = ""
                logger.info(
                    "[VOICE_SEGMENT_SPOKEN] seg_ms=%d  len=%d  preview=%s...",
                    seg_ms, len(segment), segment[:30],
                )
                logger.info("[TTS_QUEUE_END] seg_ms=%d", seg_ms)

            except Exception as exc:
                logger.error("[TTS_QUEUE] erreur pyttsx3: %s", str(exc))
            finally:
                self._lock.release()

        logger.info("[TTS_QUEUE_TOTAL] total_ms=%d", total_ms)
        return total_ms
