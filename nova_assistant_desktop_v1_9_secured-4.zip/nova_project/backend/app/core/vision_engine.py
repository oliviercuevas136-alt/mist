"""
vision_engine.py — Stub mode dégradé (caméra optionnelle).

La caméra est désactivée par défaut. Ce module expose l'interface
complète attendue par orchestrator.py et monitoring.py, mais ne
tente jamais d'ouvrir une caméra sans demande explicite.

Pour activer la vision : POST /api/monitoring/start avec enable_vision=true.
"""

from enum import Enum
from typing import Callable, Dict, Optional
from app.utils.logger import get_logger

logger = get_logger("vision_engine")


class VisionEvent(str, Enum):
    PRESENCE_DETECTED  = "presence_detected"
    PRESENCE_LOST      = "presence_lost"
    FALL_SUSPECTED     = "fall_suspected"
    ABSENCE_PROLONGED  = "absence_prolonged"
    CAMERA_ERROR       = "camera_error"


class VisionEngine:
    """
    Moteur vision optionnel.
    Sans caméra : mode dégradé silencieux, jamais de crash.
    Avec caméra  : démarre sur demande via start().
    """

    def __init__(self) -> None:
        self._running     = False
        self._available   = False   # caméra non testée
        self._callback: Optional[Callable] = None
        self._camera_index = 0

    # ── Interface publique ────────────────────────────────────────────────────

    def register_callback(self, cb: Callable[[VisionEvent, dict], None]) -> None:
        """Enregistre le callback appelé à chaque événement vision."""
        self._callback = cb

    def start(self, camera_index: int = 0) -> bool:
        """
        Démarre la capture vidéo si opencv est disponible.
        Retourne True si succès, False en mode dégradé.
        """
        self._camera_index = camera_index
        try:
            import cv2  # type: ignore
            cap = cv2.VideoCapture(camera_index)
            if not cap.isOpened():
                logger.warning("Caméra %d inaccessible — mode dégradé", camera_index)
                cap.release()
                self._available = False
                return False
            cap.release()
            self._running   = True
            self._available = True
            logger.info("Vision démarrée | caméra=%d", camera_index)
            return True
        except ImportError:
            logger.info("opencv absent — vision désactivée (mode dégradé)")
            self._available = False
            return False
        except Exception as exc:
            logger.warning("Vision start échoué | %s", exc)
            self._available = False
            return False

    def stop(self) -> None:
        """Arrête proprement la capture."""
        self._running   = False
        self._available = False
        logger.info("Vision arrêtée")

    def get_state(self) -> Dict:
        """Retourne l'état courant. Ne lève jamais d'exception."""
        return {
            "running":       self._running,
            "available":     self._available,
            "camera_index":  self._camera_index,
            "mode":          "active" if self._running else "degraded",
        }

    def _emit(self, event: VisionEvent, data: dict) -> None:
        """Appelle le callback enregistré (hors verrou, non bloquant)."""
        if self._callback:
            try:
                self._callback(event, data)
            except Exception as exc:
                logger.error("Callback vision error | %s", exc)


# Singleton
vision_engine = VisionEngine()
