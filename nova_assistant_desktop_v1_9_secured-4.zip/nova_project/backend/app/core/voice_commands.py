"""
voice_commands.py — Commandes locales prioritaires (Phase 2).

Ces commandes court-circuitent le LLM — réponse en < 10ms.
Priorité : commandes locales > outils > LLM

Commandes reconnues :
  heure / date          → horloge locale
  stop / arrête         → signal d'arrêt conversation
  test                  → diagnostic système
  état système          → cpu/ram/disque
  nouvelle conversation → vide la mémoire vocale
  aide / commandes      → liste des commandes disponibles
"""
import re
from typing import Optional, Dict, Any
from app.utils.logger import get_logger

logger = get_logger("voice_commands")

# Commandes locales : (patterns, handler_key)
_LOCAL_COMMANDS = [
    # Heure / date
    (["quelle heure", "il est quelle heure", "heure est-il",
      "quelle date", "on est quel jour", "quel jour on est",
      "c'est quoi la date"], "datetime"),

    # Stop
    (["stop", "arrête", "arrete", "stoppe", "fin", "termine",
      "arrête la conversation", "fin de conversation"], "stop"),

    # Test
    (["test", "teste", "tu fonctionnes", "tu m'entends",
      "tu mentends", "es-tu là", "es tu là"], "test"),

    # Aide
    (["aide", "help", "commandes", "que sais-tu faire",
      "que peux-tu faire", "tes capacités"], "help"),

    # Nouvelle conversation
    (["nouvelle conversation", "efface la mémoire", "recommence",
      "oublie tout", "repart à zéro"], "reset_memory"),
]


def match_local(text: str) -> Optional[str]:
    """
    Retourne la clé de commande locale si trouvée, sinon None.
    Vérification rapide par mots-clés, sans regex lourde.
    """
    lower = text.lower().strip(" ?!.")
    for patterns, key in _LOCAL_COMMANDS:
        if any(p in lower for p in patterns):
            logger.debug("Commande locale | key=%s | input=%s", key, lower[:40])
            return key
    return None


def execute_local(key: str, text: str = "") -> Dict[str, Any]:
    """
    Exécute une commande locale et retourne {"reply": str, "action": str}.
    Certaines commandes ont un side-effect (reset_memory, stop).
    """
    if key == "datetime":
        from app.core.tools.web_tool import get_current_time
        result = get_current_time()
        return {"reply": result["text"], "action": "datetime"}

    elif key == "stop":
        return {
            "reply": "Conversation arrêtée. À bientôt !",
            "action": "stop",
        }

    elif key == "test":
        from app.core.voice_memory import voice_memory
        mem_info = voice_memory.summary()
        return {
            "reply": f"Je fonctionne correctement. {mem_info}.",
            "action": "test",
        }

    elif key == "help":
        cmds = (
            "Je peux : répondre à vos questions, donner l'heure, "
            "vérifier la météo, surveiller le système, "
            "effectuer des recherches web, et mémoriser des informations."
        )
        return {"reply": cmds, "action": "help"}

    elif key == "reset_memory":
        from app.core.voice_memory import voice_memory
        voice_memory.clear()
        return {
            "reply": "Mémoire de conversation effacée. Nous repartons de zéro.",
            "action": "reset_memory",
        }

    else:
        return {"reply": "Commande non reconnue.", "action": "unknown"}
