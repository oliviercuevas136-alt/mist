import io
import subprocess
import tempfile
import time
import wave
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from faster_whisper import WhisperModel

from app.config import settings
from app.utils.logger import get_logger


logger = get_logger("voice_engine")


# ── Conversion audio (fonction utilitaire pure) ───────────────────────────────

def _convert_to_wav(input_path: Path, output_path: Path) -> bool:
    """
    Convertit n'importe quel format audio en WAV mono 16kHz via ffmpeg.
    Retourne True si succès, False si ffmpeg absent ou erreur (non bloquant).
    """
    try:
        result = subprocess.run(
            [
                "ffmpeg", "-y",
                "-i", str(input_path),
                "-ar", "16000",              # 16kHz — fréquence optimale Whisper
                "-ac", "1",                  # mono
                "-af", "silenceremove=start_periods=1:start_threshold=-50dB",  # supprime silence début/fin
                "-f", "wav",
                str(output_path),
            ],
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            logger.debug("ffmpeg stderr: %s", result.stderr[-200:].decode(errors="ignore"))
        return result.returncode == 0
    except FileNotFoundError:
        logger.warning("ffmpeg absent — transcription sans conversion audio")
        return False
    except subprocess.TimeoutExpired:
        logger.warning("ffmpeg timeout lors de la conversion")
        return False
    except Exception as exc:
        logger.warning("ffmpeg erreur | %s", exc)
        return False


# ── VoiceEngine ───────────────────────────────────────────────────────────────

class VoiceEngine:
    """
    Moteur STT + gestion fichiers audio.

    Le modèle Whisper est chargé UNE SEULE FOIS dans __init__() et
    réutilisé pour toutes les transcriptions. Jamais rechargé.
    """

    def __init__(self) -> None:
        t0 = time.perf_counter()
        logger.info(
            "Chargement modèle Whisper | model=%s | device=%s | compute=%s",
            settings.whisper_model_size,
            settings.stt_device,
            settings.stt_compute_type,
        )
        self.model = WhisperModel(
            settings.whisper_model_size,
            device=settings.stt_device,
            compute_type=settings.stt_compute_type,
        )
        self._model_load_ms = int((time.perf_counter() - t0) * 1000)
        logger.info(
            "[STT_MODEL_READY] load_ms=%d  model=%s",
            self._model_load_ms,
            settings.whisper_model_size,
        )

    # ── Warmup ───────────────────────────────────────────────────────────────

    def warmup(self) -> Dict[str, Any]:
        """
        Fait passer une mini-transcription à travers le modèle déjà chargé.
        Le modèle est déjà en mémoire depuis __init__ — ceci ne le recharge pas.
        Sert à chauffer les couches internes (cache BLAS, allocation mémoire).
        """
        logger.info("STT warmup (modèle déjà chargé, chauffage interne)...")
        t0 = time.perf_counter()

        try:
            buf = io.BytesIO()
            with wave.open(buf, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(16000)
                w.writeframes(b"\x00" * 3200)  # 0.1s silence
            buf.seek(0)

            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(buf.read())
                tmp_path = f.name

            segments, _ = self.model.transcribe(
                tmp_path,
                language=settings.stt_language,
                beam_size=1,
                vad_filter=True,
            )
            list(segments)  # consomme le générateur
            Path(tmp_path).unlink(missing_ok=True)

        except Exception as exc:
            logger.warning("STT warmup test échoué (non bloquant) | %s", exc)

        warmup_ms = int((time.perf_counter() - t0) * 1000)
        logger.info("[STT_MODEL_READY] warmup_ms=%d  model=%s", warmup_ms, settings.whisper_model_size)
        return {
            "model":     settings.whisper_model_size,
            "load_ms":   self._model_load_ms,
            "warmup_ms": warmup_ms,
        }

    # ── Gestion fichiers ─────────────────────────────────────────────────────

    def save_uploaded_audio(self, filename: str, data: bytes) -> Path:
        settings.voice_input_path.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        # Sanitisation : Path.name extrait uniquement le nom de fichier terminal
        # → bloque tout path traversal (../../etc/passwd → passwd)
        base_filename = Path(filename or "input.webm").name or "input.webm"
        safe_name = f"{timestamp}_{base_filename}"
        path = settings.voice_input_path / safe_name
        path.write_bytes(data)
        logger.debug("Audio sauvegardé | path=%s | taille=%d octets", path, len(data))
        self._cleanup_old_audio()
        return path

    def _cleanup_old_audio(self) -> None:
        keep = max(1, settings.voice_keep_audio_files)
        try:
            files = sorted(
                settings.voice_input_path.glob("*.*"),
                key=lambda p: p.stat().st_mtime,
            )
            for old in files[:-keep]:
                old.unlink(missing_ok=True)
        except Exception as exc:
            logger.debug("Nettoyage audio | %s", exc)

    # ── Transcription interne ────────────────────────────────────────────────

    def _run_transcribe(self, audio_path: Path) -> tuple[str, float, int]:
        """
        Lance la transcription sur self.model (déjà chargé).
        Retourne (text, audio_duration, transcribe_ms).

        v1.9.5 : utilise les paramètres VAD du calibrateur si disponible.
        """
        beam = 1 if settings.stt_fast_mode else 3
        # v1.9.5 : override depuis settings si fourni
        beam = int(getattr(settings, "stt_beam_size", beam) or beam)

        # Paramètres VAD : tenter de prendre ceux du calibrateur,
        # sinon fallback aux valeurs précédentes.
        vad_params: Dict[str, Any] = {"min_silence_duration_ms": 150}
        try:
            from app.services.voice_enhancers import get_vad_calibrator
            vad_params = get_vad_calibrator().get_params().to_whisper_dict()
        except Exception:
            pass

        t0 = time.perf_counter()
        segments, info = self.model.transcribe(
            str(audio_path),
            language=settings.stt_language,
            vad_filter=True,
            vad_parameters=vad_params,
            beam_size=beam,
            best_of=1,
            temperature=0.0,
            condition_on_previous_text=False,
            without_timestamps=True,
        )
        text_parts = [seg.text.strip() for seg in segments if seg.text.strip()]
        text = " ".join(text_parts).strip()
        transcribe_ms = int((time.perf_counter() - t0) * 1000)
        duration = getattr(info, "duration", 0.0)

        # Garde anti-hallucination : si audio court mais transcript long → suspect
        max_chars = int(getattr(settings, "stt_max_audio_chars", 1000) or 1000)
        if duration < 5.0 and len(text) > max_chars:
            logger.warning(
                "[STT] hallucination suspectée : duration=%.1fs, chars=%d → vide forcé",
                duration, len(text),
            )
            text = ""

        return text, duration, transcribe_ms

    # ── API publique ─────────────────────────────────────────────────────────

    def transcribe_bytes(self, audio_data: bytes, filename: str = "input.webm") -> Dict[str, Any]:
        """
        Pipeline complet depuis des bytes audio :
          1. Sauvegarde
          2. Conversion WAV 16kHz mono (ffmpeg)
          3. Transcription via self.model (déjà en mémoire)

        Retourne : text, is_empty, file_size, stt_time_ms, convert_ms, transcribe_ms
        """
        file_size = len(audio_data)

        if file_size < 500:
            logger.warning("[VOICE_STT_END] rejected=too_small  bytes=%d", file_size)
            return {
                "text": "", "is_empty": True, "file_size": file_size,
                "stt_time_ms": 0, "convert_ms": 0, "transcribe_ms": 0,
            }

        # 1. Sauvegarde
        t_save = time.perf_counter()
        raw_path = self.save_uploaded_audio(filename, audio_data)
        save_ms = int((time.perf_counter() - t_save) * 1000)

        # 2. Conversion WAV
        t_conv = time.perf_counter()
        wav_path = raw_path.with_suffix(".wav")
        converted = _convert_to_wav(raw_path, wav_path)
        convert_ms = int((time.perf_counter() - t_conv) * 1000)
        transcribe_path = wav_path if converted else raw_path

        # 3. Transcription (self.model — jamais rechargé)
        try:
            text, audio_dur, transcribe_ms = self._run_transcribe(transcribe_path)
        except Exception as exc:
            logger.error("[VOICE_STT_END] result=error  error=%s", str(exc)[:80])
            raise
        finally:
            if converted and wav_path.exists():
                wav_path.unlink(missing_ok=True)

        stt_time_ms = save_ms + convert_ms + transcribe_ms
        is_empty = not bool(text)

        if stt_time_ms > settings.stt_slow_threshold_ms:
            logger.warning(
                "[STT_TOO_SLOW] stt_ms=%d  threshold=%d  model=%s",
                stt_time_ms, settings.stt_slow_threshold_ms, settings.whisper_model_size,
            )

        if is_empty:
            logger.warning(
                "[VOICE_STT_END] is_empty=True  stt_ms=%d  audio_dur=%.2fs",
                stt_time_ms, audio_dur,
            )
        else:
            logger.info(
                "[VOICE_STT_END] stt_ms=%d  (save=%d conv=%d transcribe=%d)  text=%s...",
                stt_time_ms, save_ms, convert_ms, transcribe_ms, text[:50],
            )

        return {
            "text":          text,
            "is_empty":      is_empty,
            "file_size":     file_size,
            "stt_time_ms":   stt_time_ms,
            "convert_ms":    convert_ms,
            "transcribe_ms": transcribe_ms,
        }

    def transcribe_file(self, audio_path: Path) -> Dict[str, Any]:
        """
        Transcrit depuis un fichier existant (endpoint /transcribe classique).
        Utilise self.model — jamais rechargé.
        """
        file_size = audio_path.stat().st_size if audio_path.exists() else 0

        if file_size < 500:
            logger.warning("Fichier audio trop petit | taille=%d", file_size)
            return {
                "text": "", "is_empty": True, "file_size": file_size,
                "stt_time_ms": 0, "convert_ms": 0, "transcribe_ms": 0,
            }

        # Conversion optionnelle
        t_conv = time.perf_counter()
        wav_path = audio_path.with_suffix(".wav")
        converted = _convert_to_wav(audio_path, wav_path)
        convert_ms = int((time.perf_counter() - t_conv) * 1000)
        transcribe_path = wav_path if converted else audio_path

        try:
            text, audio_dur, transcribe_ms = self._run_transcribe(transcribe_path)
        except Exception as exc:
            logger.error("Erreur transcription | %s | %s", audio_path, exc)
            raise
        finally:
            if converted and wav_path.exists():
                wav_path.unlink(missing_ok=True)

        stt_time_ms = convert_ms + transcribe_ms
        is_empty = not bool(text)

        if stt_time_ms > settings.stt_slow_threshold_ms:
            logger.warning("[STT_TOO_SLOW] stt_ms=%d  model=%s", stt_time_ms, settings.whisper_model_size)

        logger.info(
            "transcribe_file OK | stt_ms=%d  (conv=%d transcribe=%d)  text=%s...",
            stt_time_ms, convert_ms, transcribe_ms, text[:60],
        )

        return {
            "text":          text,
            "is_empty":      is_empty,
            "file_size":     file_size,
            "stt_time_ms":   stt_time_ms,
            "convert_ms":    convert_ms,
            "transcribe_ms": transcribe_ms,
        }
