"""
voice_memory.py — Mémoire conversationnelle courte pour le mode vocal.

Stockage en RAM uniquement (pas de SQLite, pas de fichier).
Les échanges disparaissent au redémarrage — c'est voulu.
Pour une mémoire longue persistante, utiliser memory_engine.py.

Usage :
    vm = VoiceMemory(max_exchanges=5)
    vm.add("utilisateur", "Bonjour")
    vm.add("assistant", "Bonjour ! Comment puis-je vous aider ?")
    messages = vm.as_messages(system_prompt="...")
    # → liste de dicts prête pour Ollama
"""
import threading
from collections import deque
from datetime import datetime, timezone
from typing import Deque, Dict, List, Optional, Tuple
from app.utils.logger import get_logger

logger = get_logger("voice_memory")


class VoiceMemory:
    """
    Mémoire conversationnelle vocale en RAM.
    Thread-safe — plusieurs requêtes simultanées possibles.
    """

    def __init__(self, max_exchanges: int = 5) -> None:
        # max_exchanges = nb d'échanges user+assistant conservés
        # 5 échanges = 10 messages max
        self._max = max_exchanges * 2
        self._history: Deque[Tuple[str, str, str]] = deque(maxlen=self._max)
        # (role, content, timestamp_iso)
        self._lock = threading.Lock()

    def add(self, role: str, content: str) -> None:
        """Ajoute un message. role = 'user' | 'assistant'."""
        if role not in ("user", "assistant"):
            logger.warning("VoiceMemory: rôle invalide '%s' ignoré", role)
            return
        content = (content or "").strip()
        if not content:
            return
        with self._lock:
            self._history.append((role, content, datetime.now(timezone.utc).isoformat()))
        logger.debug("VoiceMemory add | role=%s | len=%d | total=%d",
                     role, len(content), len(self._history))

    def clear(self) -> None:
        """Vide la mémoire (ex: commande 'nouvelle conversation')."""
        with self._lock:
            self._history.clear()
        logger.info("VoiceMemory vidée")

    def as_messages(
        self,
        system_prompt: Optional[str] = None,
        current_user_message: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """
        Construit la liste de messages pour Ollama.
        Format : [{"role": "system", "content": "..."}, {"role": "user", ...}, ...]

        current_user_message est ajouté en dernier si fourni
        (il ne doit PAS être encore dans _history à ce stade).
        """
        messages = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        with self._lock:
            history_snapshot = list(self._history)

        for role, content, _ in history_snapshot:
            messages.append({"role": role, "content": content})

        if current_user_message:
            messages.append({"role": "user", "content": current_user_message.strip()})

        return messages

    def summary(self) -> str:
        """Résumé court pour les logs."""
        with self._lock:
            n = len(self._history)
        return f"{n} messages en mémoire courte (max {self._max})"

    def __len__(self) -> int:
        with self._lock:
            return len(self._history)


# Singleton global pour le mode vocal
# Une seule instance partagée entre tous les appels /stream
voice_memory = VoiceMemory(max_exchanges=5)
