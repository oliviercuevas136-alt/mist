from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base


def _utcnow() -> datetime:
    """Retourne datetime UTC aware (remplace datetime.utcnow() déprécié)."""
    return datetime.now(timezone.utc)


class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String(255), default="Nouvelle conversation")
    summary: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    conversation_id: Mapped[int] = mapped_column(Integer, index=True)
    role: Mapped[str] = mapped_column(String(50), index=True)
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class Memory(Base):
    __tablename__ = "memories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    content: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(100), default="general")
    importance: Mapped[int] = mapped_column(Integer, default=1)
    source: Mapped[str] = mapped_column(String(100), default="manual")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class Note(Base):
    __tablename__ = "notes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String(255), index=True)
    content: Mapped[str] = mapped_column(Text)
    tags: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class Document(Base):
    __tablename__ = "documents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    filename: Mapped[str] = mapped_column(String(255), index=True)
    path: Mapped[str] = mapped_column(String(500))
    content_preview: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


# ------------------------------------------------------------------
# Surveillance tables — ajoutées en V2
# ------------------------------------------------------------------

class MonitoringAlert(Base):
    """Persistance SQLite des alertes de surveillance."""
    __tablename__ = "monitoring_alerts"

    id:           Mapped[int]      = mapped_column(Integer, primary_key=True, index=True)
    alert_type:   Mapped[str]      = mapped_column(String(50), index=True)
    alert_level:  Mapped[str]      = mapped_column(String(20), index=True)
    message:      Mapped[str]      = mapped_column(Text)
    timestamp:    Mapped[datetime] = mapped_column(DateTime, default=_utcnow, index=True)
    acknowledged: Mapped[bool]     = mapped_column(Boolean, default=False)
    extra_json:   Mapped[str]      = mapped_column(Text, default="{}")


class MonitoringEvent(Base):
    """Journal des événements système (vision, voix, orchestrateur)."""
    __tablename__ = "monitoring_events"

    id:          Mapped[int]      = mapped_column(Integer, primary_key=True, index=True)
    source:      Mapped[str]      = mapped_column(String(50), index=True)   # vision|voice|system|alert
    description: Mapped[str]      = mapped_column(String(255))
    extra_json:  Mapped[str]      = mapped_column(Text, default="{}")
    timestamp:   Mapped[datetime] = mapped_column(DateTime, default=_utcnow, index=True)


# ── v1.9.8 : Index sémantique local ────────────────────────────────────────

class IndexedDocument(Base):
    """
    Un document indexé (fichier local, conversation, note).
    Le contenu peut être segmenté en chunks (table IndexedChunk).
    """
    __tablename__ = "indexed_documents"

    id:         Mapped[int]      = mapped_column(Integer, primary_key=True, index=True)
    # Origine : "file" | "conversation" | "note"
    source_type: Mapped[str]     = mapped_column(String(20), index=True)
    # Chemin absolu OU "conversation:<id>" OU "note:<id>"
    source_path: Mapped[str]     = mapped_column(String(500), unique=True, index=True)
    title:      Mapped[str]      = mapped_column(String(255), default="")
    extension:  Mapped[str]      = mapped_column(String(20), default="", index=True)
    category:   Mapped[str]      = mapped_column(String(50), default="autres", index=True)
    size_bytes: Mapped[int]      = mapped_column(Integer, default=0)
    # Hash sha256 du contenu — permet de détecter les changements
    content_hash: Mapped[str]    = mapped_column(String(64), default="", index=True)
    chunk_count:  Mapped[int]    = mapped_column(Integer, default=0)
    # Résumé court (rempli à la demande)
    summary:    Mapped[str]      = mapped_column(Text, default="")
    summary_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    indexed_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, index=True)
    accessed_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, index=True)
    access_count: Mapped[int]    = mapped_column(Integer, default=0)


class IndexedChunk(Base):
    """
    Un morceau de document (~500 caractères). Contient le texte + embedding
    sérialisé. Une seule table simplifie la requête sémantique.
    """
    __tablename__ = "indexed_chunks"

    id:         Mapped[int]      = mapped_column(Integer, primary_key=True, index=True)
    document_id: Mapped[int]     = mapped_column(Integer, index=True)
    chunk_index: Mapped[int]     = mapped_column(Integer, default=0)
    content:    Mapped[str]      = mapped_column(Text)
    # Embedding sérialisé via numpy.ndarray.tobytes() ; vide si pas d'embedding
    embedding:  Mapped[bytes]    = mapped_column(default=b"")
    embedding_dim: Mapped[int]   = mapped_column(Integer, default=0)
