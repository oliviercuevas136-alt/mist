from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.chat import router as chat_router
from app.api.conversations import router as conversations_router
from app.api.exports import router as exports_router
from app.api.files import router as files_router
from app.api.health import router as health_router
from app.api.health import health_check as _health_check  # alias /health
from app.api.memory import router as memory_router
from app.api.monitoring import router as monitoring_router
from app.api.notes import router as notes_router
from app.api.tools import router as tools_router
from app.api.camera import router as camera_router
from app.api.file_search import router as file_search_router
from app.api.event_bus import router as core_router
from app.api.security import router as security_router
from app.api.voice_extras import router as voice_extras_router
from app.api.semantic_index import router as semantic_index_router
from app.config import settings   # ⚠ Doit être importé AVANT toute utilisation conditionnelle ci-dessous
# voice_router chargé conditionnellement : évite de charger Whisper + pyttsx3
# en RAM si STT/TTS sont désactivés (économie ~300-500 Mo sur Windows 8 Go).
# L'import conditionnel préserve toutes les routes /api/voice/* si activé.
if settings.enable_stt or settings.enable_tts:
    from app.api.voice import router as voice_router  # type: ignore[assignment]
    _VOICE_ENABLED = True
else:
    from fastapi import APIRouter as _APIRouter
    voice_router = _APIRouter()  # router vide — routes /api/voice/* retournent 404
    _VOICE_ENABLED = False
from app.api.ws import router as ws_router          # ← Nova WebSocket bridge
from app.db.database import Base, engine
from app.utils.logger import get_logger
from app.utils.startup_checks import run_startup_checks
import app.db.models  # noqa: F401


logger = get_logger("app")


def ensure_directories() -> None:
    required_dirs = [
        settings.data_path,
        settings.log_path,
        settings.notes_path,
        settings.uploads_path,
        settings.memory_exports_path,
        settings.export_path,
        settings.voice_input_path,
        settings.voice_output_path,
        settings.static_path,
    ]
    for directory in required_dirs:
        Path(directory).mkdir(parents=True, exist_ok=True)


ensure_directories()
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Nova Assistant Desktop — Backend",
    description="Local AI backend: chat, voice, camera, monitoring. Compatible Electron frontend.",
    version="1.0.0",
    debug=settings.debug,
)

# ── CORS : autoriser le renderer Electron (file://) et localhost ──────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "null",          # Electron renderer (file:// → origin=null)
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers V4.8 (inchangés) ──────────────────────────────────────────────
app.include_router(health_router)
app.include_router(chat_router)
app.include_router(memory_router)
app.include_router(notes_router)
app.include_router(files_router)
app.include_router(conversations_router)
app.include_router(exports_router)
app.include_router(voice_router)
app.include_router(tools_router)
app.include_router(monitoring_router)
app.include_router(camera_router)
app.include_router(file_search_router)
app.include_router(core_router)
app.include_router(security_router)
app.include_router(voice_extras_router)
app.include_router(semantic_index_router)

# ── Nova WebSocket bridge ─────────────────────────────────────────────────
app.include_router(ws_router)

app.mount("/static", StaticFiles(directory=settings.static_path), name="static")

logger.info("Nova Assistant Desktop — Backend démarré")
logger.info("Startup checks | %s", run_startup_checks())

# ── Warmup STT ────────────────────────────────────────────────────────────
if settings.enable_stt and settings.stt_warmup and _VOICE_ENABLED:
    try:
        from app.api.voice import voice_engine as _ve
        warmup_result = _ve.warmup()
        logger.info("STT warmup OK | %s", warmup_result)
    except Exception as _warmup_exc:
        logger.warning("STT warmup échoué (non bloquant) | %s", _warmup_exc)
else:
    if not _VOICE_ENABLED:
        logger.info("[PERF] STT/TTS désactivés — Whisper non chargé (économie RAM ~300 Mo)")

# ── Warmup LLM ────────────────────────────────────────────────────────────
# Utilise le client LLM du bridge WebSocket (indépendant de voice.py).
# Cela garantit le warmup même si ENABLE_STT=false.
if settings.ollama_warmup:
    try:
        from app.api.ws import _llm as _ollama_ws
        warmup_llm = _ollama_ws.warmup()
        logger.info("LLM warmup OK | %s", warmup_llm)
    except Exception as _warmup_llm_exc:
        logger.warning("LLM warmup échoué (non bloquant) | %s", _warmup_llm_exc)


# ── Démarrage SystemMonitor (surveillance longue durée) ───────────────────
if getattr(settings, "system_monitor_enabled", True):
    try:
        from app.services.system_monitor import get_system_monitor
        _sm = get_system_monitor()
        # Override interval depuis config si fourni
        _sm._interval = float(getattr(settings, "system_monitor_interval_sec", 5.0))
        _sm._top_n = int(getattr(settings, "system_monitor_top_n", 5))
        ok = _sm.start()
        logger.info("SystemMonitor | running=%s interval=%.1fs", ok, _sm._interval)
    except Exception as exc:
        logger.warning("SystemMonitor non démarré (non bloquant) | %s", exc)


# ── Démarrage VoiceWatchdog v1.9.9 (récupération sessions bloquées) ──────
if getattr(settings, "voice_watchdog_enabled", True):
    try:
        from app.services.voice_watchdog import get_voice_watchdog
        _wd = get_voice_watchdog()
        ok = _wd.start()
        logger.info("VoiceWatchdog | running=%s", ok)
    except Exception as exc:
        logger.warning("VoiceWatchdog non démarré (non bloquant) | %s", exc)


@app.get("/health", tags=["health"])
def health_alias():
    """Alias de /api/health — compatibilité Electron, scripts Windows, healthcheck Docker."""
    return _health_check()


@app.get("/")
def serve_index():
    index_file = settings.static_path / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return JSONResponse(
        status_code=200,
        content={
            "message": "Nova Assistant Desktop Backend",
            "version": "1.0.0",
            "ws": "ws://127.0.0.1:8000/ws",
            "health": "GET /health",
            "docs": "GET /docs",
        },
    )


@app.get("/api")
def api_root():
    return {
        "message": "Nova Assistant Desktop — API locale opérationnelle",
        "app_name": settings.app_name,
        "model": settings.ollama_model,
        "ws_endpoint": "/ws",
        "endpoints": {
            "health": "/health",
            "chat": "/api/chat/send",
            "voice": "/api/voice/",
            "camera": "/api/camera/status",
            "monitoring": "/api/monitoring/status",
        },
    }
