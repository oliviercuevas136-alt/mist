"""
action_manager.py — Gestionnaire d'actions PC contrôlées.

Workflow strict en 3 phases :
    1. propose_action(action, params)   → renvoie un confirmation_token
    2. confirm_action(token)             → renvoie execution_token
    3. execute_action(execution_token)   → exécute si valide + permission OK

Garde-fous :
    - chaque action est associée à une PERMISSION granulaire (config)
    - chaque action passe par la SANDBOX
    - token à usage unique avec TTL (60s défaut)
    - audit log de toutes les tentatives

Actions supportées :
    - open_file              : ouvrir un fichier dans son app par défaut
    - launch_application     : lancer une appli whitelistée
    - kill_process           : tuer un processus (refusé sur protégés)
    - move_files             : organiser fichiers (déplacer)
    - cleanup_folder         : supprimer fichiers d'un dossier autorisé
    - backup_files           : copier des fichiers vers un dossier sûr

Important : ce module N'EXÉCUTE RIEN sans token valide ET permission ET sandbox OK.
"""

from __future__ import annotations

import os
import platform
import secrets
import shutil
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple

from app.config import settings
from app.services.sandbox import (
    SandboxDecision, check_path, check_process_kill, check_executable,
)
from app.utils.logger import get_logger

logger = get_logger("action_manager")


# ── Permissions disponibles ────────────────────────────────────────────────
#
# Chaque action est associée à un nom de permission. Pour qu'une action
# s'exécute, la permission doit être présente dans
# settings.allowed_pc_actions (CSV, défaut vide = tout refusé).

class Permission:
    OPEN_FILE             = "open_file"
    LAUNCH_APPLICATION    = "launch_application"
    KILL_PROCESS          = "kill_process"
    MOVE_FILES            = "move_files"
    CLEANUP_FOLDER        = "cleanup_folder"
    BACKUP_FILES          = "backup_files"
    # v1.9.7 — Modification contrôlée
    EDIT_FILE_TEXT        = "edit_file_text"
    APPEND_FILE_TEXT      = "append_file_text"


_ALL_PERMISSIONS = {
    Permission.OPEN_FILE, Permission.LAUNCH_APPLICATION,
    Permission.KILL_PROCESS, Permission.MOVE_FILES,
    Permission.CLEANUP_FOLDER, Permission.BACKUP_FILES,
    Permission.EDIT_FILE_TEXT, Permission.APPEND_FILE_TEXT,
}


# ── État interne ───────────────────────────────────────────────────────────

@dataclass
class PendingAction:
    """Action proposée, en attente de confirmation ou d'exécution."""
    confirmation_token: str
    execution_token:    Optional[str]
    action:             str
    params:             Dict[str, Any]
    created_at:         float
    confirmed_at:       Optional[float]
    expires_at:         float

    def is_expired(self) -> bool:
        return time.time() > self.expires_at


@dataclass
class AuditEntry:
    timestamp:  float
    action:     str
    phase:      str          # propose | confirm | execute | denied
    status:     str          # ok | denied_permission | denied_sandbox | denied_token | error
    reason:     str
    params:     Dict[str, Any] = field(default_factory=dict)


# ── Manager ────────────────────────────────────────────────────────────────

class ActionManager:

    DEFAULT_TOKEN_TTL_SEC = 60.0

    def __init__(self) -> None:
        self._pending: Dict[str, PendingAction] = {}
        self._lock = threading.RLock()
        self._audit: Deque[AuditEntry] = deque(maxlen=500)

    # ── Permissions ────────────────────────────────────────────────────────

    @staticmethod
    def _granted_permissions() -> set:
        """
        Lit settings.allowed_pc_actions (CSV) et retourne le set des
        permissions effectivement accordées par l'utilisateur dans .env.
        Vide par défaut → AUCUNE action n'est autorisée.
        """
        raw = getattr(settings, "allowed_pc_actions", "") or ""
        items = {x.strip() for x in raw.split(",") if x.strip()}
        return items & _ALL_PERMISSIONS

    def _check_permission(self, permission: str) -> Tuple[bool, str]:
        granted = self._granted_permissions()
        if permission in granted:
            return True, ""
        return False, (
            f"permission refusée : '{permission}' n'est pas dans "
            f"ALLOWED_PC_ACTIONS. Granted: {sorted(granted)}"
        )

    def list_permissions(self) -> Dict[str, Any]:
        granted = self._granted_permissions()
        return {
            "all": sorted(_ALL_PERMISSIONS),
            "granted": sorted(granted),
            "denied": sorted(_ALL_PERMISSIONS - granted),
        }

    # ── Phase 1 : propose ──────────────────────────────────────────────────

    def propose_action(self, action: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Étape 1 : valider statiquement l'action (permission + sandbox)
        et émettre un confirmation_token à usage unique.

        Ne fait AUCUN side-effect système.
        Retourne dict { ok, confirmation_token?, denied_reason?, action, params }.
        """
        # Lookup descriptif
        descriptor = _ACTION_DESCRIPTORS.get(action)
        if not descriptor:
            self._audit_add(action, "propose", "denied_unknown", "action inconnue", params)
            return {"ok": False, "denied_reason": f"action inconnue : {action}"}

        # Permission
        ok, why = self._check_permission(descriptor["permission"])
        if not ok:
            self._audit_add(action, "propose", "denied_permission", why, params)
            return {"ok": False, "denied_reason": why}

        # Sandbox pré-check (validation rapide des paramètres critiques)
        ok, why = self._sandbox_precheck(action, params)
        if not ok:
            self._audit_add(action, "propose", "denied_sandbox", why, params)
            return {"ok": False, "denied_reason": why}

        # Token
        token = secrets.token_urlsafe(16)
        with self._lock:
            self._pending[token] = PendingAction(
                confirmation_token=token, execution_token=None,
                action=action, params=dict(params),
                created_at=time.time(), confirmed_at=None,
                expires_at=time.time() + self.DEFAULT_TOKEN_TTL_SEC,
            )
        self._audit_add(action, "propose", "ok", "proposition acceptée", params)
        logger.info("[ACTION] PROPOSED action=%s token=%s...", action, token[:8])

        # v1.9.7 — Aperçu enrichi pour les modifications de fichiers
        # Consigne : afficher fichier ciblé / changement prévu / sauvegarde / confirmation
        preview: Optional[Dict[str, Any]] = None
        if action == "edit_file_text":
            try:
                from app.services.file_editor import preview_replace_text
                preview = preview_replace_text(
                    params.get("path", ""),
                    params.get("old", ""),
                    params.get("new", ""),
                    count=params.get("count", 1),
                )
            except Exception as exc:
                preview = {"ok": False, "reason": f"preview failed: {exc}"}
        elif action == "append_file_text":
            try:
                from app.services.file_editor import preview_append_text
                preview = preview_append_text(
                    params.get("path", ""),
                    params.get("content", ""),
                )
            except Exception as exc:
                preview = {"ok": False, "reason": f"preview failed: {exc}"}

        result = {
            "ok": True,
            "confirmation_token": token,
            "action": action,
            "params": params,
            "expires_in_sec": int(self.DEFAULT_TOKEN_TTL_SEC),
            "description": descriptor.get("description", ""),
        }
        if preview is not None:
            result["preview"] = preview
            # Si preview échoue, on annule la pending action et refuse
            if not preview.get("ok"):
                with self._lock:
                    self._pending.pop(token, None)
                self._audit_add(action, "propose", "denied_preview",
                                preview.get("reason", ""), params)
                return {"ok": False,
                        "denied_reason": f"preview: {preview.get('reason', '')}"}
        return result

    # ── Phase 2 : confirm ──────────────────────────────────────────────────

    def confirm_action(self, confirmation_token: str) -> Dict[str, Any]:
        """
        Étape 2 : l'utilisateur confirme. Génère un execution_token
        à usage unique.
        v1.9.7 : confirmation_token est désormais à usage unique aussi.
        Une fois confirmé, il ne peut plus l'être à nouveau.
        """
        with self._lock:
            p = self._pending.get(confirmation_token)
            if not p:
                self._audit_add("?", "confirm", "denied_token", "token inconnu", {})
                return {"ok": False, "denied_reason": "token de confirmation inconnu"}
            if p.is_expired():
                self._pending.pop(confirmation_token, None)
                self._audit_add(p.action, "confirm", "denied_token", "token expiré", p.params)
                return {"ok": False, "denied_reason": "token expiré"}
            # v1.9.7 : refus si déjà confirmé (anti-replay)
            if p.confirmed_at is not None:
                self._audit_add(p.action, "confirm", "denied_token",
                                "confirmation_token déjà utilisé", p.params)
                return {"ok": False,
                        "denied_reason": "confirmation_token déjà utilisé"}
            exec_token = secrets.token_urlsafe(16)
            p.execution_token = exec_token
            p.confirmed_at = time.time()
            p.expires_at = time.time() + self.DEFAULT_TOKEN_TTL_SEC
        self._audit_add(p.action, "confirm", "ok", "confirmation acceptée", p.params)
        logger.info("[ACTION] CONFIRMED action=%s exec_token=%s...", p.action, exec_token[:8])
        return {"ok": True, "execution_token": exec_token, "action": p.action}

    # ── Phase 3 : execute ──────────────────────────────────────────────────

    def execute_action(self, execution_token: str) -> Dict[str, Any]:
        """
        Étape 3 : exécution effective. Le token est invalidé après usage.
        """
        with self._lock:
            # Trouver l'action correspondante
            p = None
            for tok, pa in list(self._pending.items()):
                if pa.execution_token == execution_token:
                    p = pa
                    self._pending.pop(tok, None)
                    break
            if not p:
                self._audit_add("?", "execute", "denied_token", "execution_token inconnu", {})
                return {"ok": False, "denied_reason": "token d'exécution inconnu"}
            if p.is_expired():
                self._audit_add(p.action, "execute", "denied_token", "token expiré", p.params)
                return {"ok": False, "denied_reason": "token expiré"}

        # Re-check permission au moment de l'exécution (config peut changer)
        descriptor = _ACTION_DESCRIPTORS.get(p.action)
        if not descriptor:
            return {"ok": False, "denied_reason": "action inconnue (race)"}
        ok, why = self._check_permission(descriptor["permission"])
        if not ok:
            self._audit_add(p.action, "execute", "denied_permission", why, p.params)
            return {"ok": False, "denied_reason": why}

        # Sandbox re-check
        ok, why = self._sandbox_precheck(p.action, p.params)
        if not ok:
            self._audit_add(p.action, "execute", "denied_sandbox", why, p.params)
            return {"ok": False, "denied_reason": why}

        # Exécution réelle
        handler = descriptor["handler"]
        try:
            result = handler(p.params)
            self._audit_add(p.action, "execute", "ok", "exécutée", p.params)
            # Publier sur le CORE
            self._publish_action_event(p.action, "executed", p.params, result)
            return {"ok": True, "action": p.action, "result": result}
        except Exception as exc:
            self._audit_add(p.action, "execute", "error", str(exc), p.params)
            logger.error("[ACTION] %s failed: %s", p.action, exc)
            return {"ok": False, "denied_reason": f"erreur exécution: {exc}"}

    # ── Sandbox pré-checks pour chaque action ─────────────────────────────

    def _sandbox_precheck(self, action: str, params: Dict[str, Any]) -> Tuple[bool, str]:
        if action == "open_file":
            d, r = check_path(params.get("path", ""), "read")
            if d == SandboxDecision.DENY:
                return False, r
        elif action == "launch_application":
            d, r = check_executable(params.get("name", ""))
            if d == SandboxDecision.DENY:
                return False, r
            # Pas de path : on s'appuie sur PATH système et la blocklist execs
        elif action == "kill_process":
            d, r = check_process_kill(params.get("target", ""))
            if d == SandboxDecision.DENY:
                return False, r
        elif action in ("move_files", "cleanup_folder", "backup_files"):
            for key in ("src", "dst", "folder", "source", "destination"):
                if key in params:
                    d, r = check_path(params[key], "write" if key in ("dst", "destination", "folder") else "read")
                    if d == SandboxDecision.DENY:
                        return False, r
        # v1.9.7 — Modifications contrôlées de fichiers
        elif action in ("edit_file_text", "append_file_text"):
            # Sandbox: check_path "write" + validation file_editor (allowlist)
            from app.services.file_editor import validate_path_for_write
            target = params.get("path", "")
            d, r = check_path(target, "write")
            if d == SandboxDecision.DENY:
                return False, f"sandbox: {r}"
            chk = validate_path_for_write(target)
            if not chk.ok:
                return False, f"file_editor refuse: {chk.reason}"
        return True, ""

    # ── Audit ──────────────────────────────────────────────────────────────

    def _audit_add(self, action: str, phase: str, status: str, reason: str, params: Dict[str, Any]) -> None:
        with self._lock:
            self._audit.append(AuditEntry(
                timestamp=time.time(), action=action, phase=phase,
                status=status, reason=reason, params=dict(params),
            ))

    def get_audit_log(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            items = list(self._audit)
        return [asdict(e) for e in items[-limit:]]

    def get_pending(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {"action": p.action, "params": p.params,
                 "created_at": p.created_at, "confirmed_at": p.confirmed_at,
                 "confirmation_token": p.confirmation_token[:8] + "...",
                 "expired": p.is_expired()}
                for p in self._pending.values()
            ]

    # ── CORE submit ─────────────────────────────────────────────────────────

    def _publish_action_event(self, action: str, status: str,
                              params: Dict[str, Any], result: Any) -> None:
        try:
            from app.core.event_bus import CoreEvent, EventLevel
            from app.core.orchestrator import orchestrator
            orchestrator.submit_event(CoreEvent(
                type=f"action.{status}",
                source="action_manager",
                level=EventLevel.MEDIUM,
                message=f"Action {action} : {status}",
                payload={"action": action, "params": params, "result": result},
            ))
        except Exception as exc:
            logger.debug("[ACTION] CORE submit skipped: %s", exc)


# ── Handlers réels ─────────────────────────────────────────────────────────

def _handler_open_file(params: Dict[str, Any]) -> Dict[str, Any]:
    """Ouvre un fichier avec l'app par défaut de l'OS."""
    path = params.get("path")
    if not path or not Path(path).exists():
        raise FileNotFoundError(f"fichier introuvable : {path}")
    system = platform.system()
    if system == "Windows":
        os.startfile(path)  # type: ignore[attr-defined]
    elif system == "Darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])
    return {"opened": str(path)}


def _handler_launch_application(params: Dict[str, Any]) -> Dict[str, Any]:
    """Lance une application par nom (utilise le PATH système)."""
    name = params.get("name")
    if not name:
        raise ValueError("paramètre 'name' requis")
    # Lancer en arrière-plan, ne pas attendre
    proc = subprocess.Popen(
        [name] + list(params.get("args", [])),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return {"launched": name, "pid": proc.pid}


def _handler_kill_process(params: Dict[str, Any]) -> Dict[str, Any]:
    """Tue un processus par PID ou nom."""
    try:
        import psutil
    except ImportError:
        raise RuntimeError("psutil indisponible — kill_process désactivé")
    target = params.get("target")
    if target is None:
        raise ValueError("paramètre 'target' (pid ou name) requis")
    # PID ou nom
    try:
        pid = int(target)
        p = psutil.Process(pid)
        p.terminate()
        p.wait(timeout=3)
        return {"killed_pid": pid}
    except ValueError:
        # Par nom — kill premier match
        for p in psutil.process_iter(["pid", "name"]):
            if (p.info.get("name") or "").lower() == str(target).lower():
                p.terminate()
                p.wait(timeout=3)
                return {"killed_pid": p.pid, "name": target}
        raise LookupError(f"processus {target} introuvable")


def _handler_move_files(params: Dict[str, Any]) -> Dict[str, Any]:
    src = params.get("src")
    dst = params.get("dst")
    if not src or not dst:
        raise ValueError("'src' et 'dst' requis")
    if not Path(src).exists():
        raise FileNotFoundError(src)
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    shutil.move(src, dst)
    return {"moved": [src, dst]}


def _handler_cleanup_folder(params: Dict[str, Any]) -> Dict[str, Any]:
    """Supprime UNIQUEMENT les fichiers dans un dossier (pas le dossier lui-même).
    Refuse si > max_files (anti-massacre)."""
    folder = params.get("folder")
    max_files = int(params.get("max_files", 100))
    older_than_sec = float(params.get("older_than_sec", 0))
    if not folder or not Path(folder).is_dir():
        raise NotADirectoryError(folder)
    targets = []
    for f in Path(folder).iterdir():
        if f.is_file():
            if older_than_sec > 0:
                age = time.time() - f.stat().st_mtime
                if age < older_than_sec:
                    continue
            targets.append(f)
    if len(targets) > max_files:
        raise RuntimeError(
            f"refusé : {len(targets)} fichiers > max_files={max_files} (anti-massacre)"
        )
    deleted = []
    for f in targets:
        try:
            f.unlink()
            deleted.append(str(f))
        except OSError:
            continue
    return {"deleted_count": len(deleted), "sample": deleted[:10]}


def _handler_backup_files(params: Dict[str, Any]) -> Dict[str, Any]:
    """Copie une liste de fichiers vers un dossier de backup."""
    sources = params.get("source") or params.get("sources")
    destination = params.get("destination") or params.get("dst")
    if not sources or not destination:
        raise ValueError("'source(s)' et 'destination' requis")
    if isinstance(sources, str):
        sources = [sources]
    Path(destination).mkdir(parents=True, exist_ok=True)
    copied = []
    for src in sources:
        p = Path(src)
        if not p.exists():
            continue
        target = Path(destination) / p.name
        if p.is_dir():
            shutil.copytree(p, target, dirs_exist_ok=True)
        else:
            shutil.copy2(p, target)
        copied.append({"src": str(p), "dst": str(target)})
    return {"copied": copied, "count": len(copied)}


# v1.9.7 — Handlers modification contrôlée ───────────────────────────────────

def _handler_edit_file_text(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Remplace une chaîne 'old' par 'new' dans le fichier ciblé.
    Le backup automatique est créé par file_editor avant l'écriture.
    """
    from app.services.file_editor import replace_text
    path = params.get("path", "")
    old  = params.get("old", "")
    new  = params.get("new", "")
    count = params.get("count", 1)
    if not path or old is None or new is None:
        raise ValueError("'path', 'old', 'new' requis")
    res = replace_text(path, old, new, count=count)
    if not res.ok:
        raise RuntimeError(f"replace_text refusé: {res.reason}")
    return {
        "target":       res.target,
        "backup_path":  res.backup_path,
        "diff_summary": res.diff_summary,
        "bytes_before": res.bytes_before,
        "bytes_after":  res.bytes_after,
    }


def _handler_append_file_text(params: Dict[str, Any]) -> Dict[str, Any]:
    """Ajoute du texte à la fin d'un fichier existant. Backup créé d'abord."""
    from app.services.file_editor import append_text
    path = params.get("path", "")
    content = params.get("content", "")
    if not path or content is None:
        raise ValueError("'path' et 'content' requis")
    res = append_text(path, content)
    if not res.ok:
        raise RuntimeError(f"append_text refusé: {res.reason}")
    return {
        "target":       res.target,
        "backup_path":  res.backup_path,
        "diff_summary": res.diff_summary,
        "bytes_before": res.bytes_before,
        "bytes_after":  res.bytes_after,
    }


# ── Descripteurs ───────────────────────────────────────────────────────────

_ACTION_DESCRIPTORS: Dict[str, Dict[str, Any]] = {
    "open_file": {
        "permission":  Permission.OPEN_FILE,
        "handler":     _handler_open_file,
        "description": "Ouvrir un fichier avec l'application par défaut",
    },
    "launch_application": {
        "permission":  Permission.LAUNCH_APPLICATION,
        "handler":     _handler_launch_application,
        "description": "Lancer une application",
    },
    "kill_process": {
        "permission":  Permission.KILL_PROCESS,
        "handler":     _handler_kill_process,
        "description": "Terminer un processus",
    },
    "move_files": {
        "permission":  Permission.MOVE_FILES,
        "handler":     _handler_move_files,
        "description": "Déplacer un fichier",
    },
    "cleanup_folder": {
        "permission":  Permission.CLEANUP_FOLDER,
        "handler":     _handler_cleanup_folder,
        "description": "Nettoyer un dossier (fichiers seulement)",
    },
    "backup_files": {
        "permission":  Permission.BACKUP_FILES,
        "handler":     _handler_backup_files,
        "description": "Sauvegarder fichiers vers un dossier",
    },
    # v1.9.7 — Modification contrôlée
    "edit_file_text": {
        "permission":  Permission.EDIT_FILE_TEXT,
        "handler":     _handler_edit_file_text,
        "description": "Remplacer une chaîne dans un fichier autorisé (backup automatique)",
    },
    "append_file_text": {
        "permission":  Permission.APPEND_FILE_TEXT,
        "handler":     _handler_append_file_text,
        "description": "Ajouter du texte à la fin d'un fichier autorisé (backup automatique)",
    },
}


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[ActionManager] = None


def get_action_manager() -> ActionManager:
    global _instance
    if _instance is None:
        _instance = ActionManager()
    return _instance
