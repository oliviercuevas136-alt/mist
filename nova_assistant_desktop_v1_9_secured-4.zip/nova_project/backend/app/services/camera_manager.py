"""
app/services/camera_manager.py
─────────────────────────────────────────────────────────────────────────────
Couche caméra optionnelle — Local Assistant V4.8

Supporte :
  • Webcam USB : index 0, 1, 2 ...
  • Flux RTSP  : rtsp://user:pass@ip:port/...
  • Flux HTTP/MJPEG : http://ip:port/video
  • Fichier vidéo local (tests)
  • GoPro en mode webcam USB (apparaît comme index 0/1/2 sur Windows)
  • GoPro en mode Wi-Fi réseau si URL fournie

Règles de sécurité :
  • Jamais de stockage d'image sans CAMERA_SAVE_SNAPSHOTS=true
  • Credentials uniquement via .env (jamais dans le code)
  • Thread séparé non-bloquant
  • Pas de crash si caméra absente — mode DEGRADED transparent
  • FPS limité par CAMERA_FPS_LIMIT pour économiser le CPU

Logs produits :
  [CAMERA] SOURCE_TEST source=...
  [CAMERA] CONNECTED  source=... backend=...
  [CAMERA] FAILED     source=... reason=...
  [CAMERA] RECONNECTING attempt=N
  [CAMERA] FRAME_OK   fps=...
  [CAMERA] DEGRADED_MODE reason=...
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import base64
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from app.utils.logger import get_logger

logger = get_logger("camera")

# ── OpenCV import optionnel ──────────────────────────────────────────────────
# L'application démarre normalement même si opencv-python n'est pas installé.
try:
    import cv2  # type: ignore

    _CV2_AVAILABLE = True
except ImportError:
    cv2 = None  # type: ignore
    _CV2_AVAILABLE = False
    logger.warning("[CAMERA] opencv-python non installé — caméra désactivée")


# ────────────────────────────────────────────────────────────────────────────
# Énumérations / dataclasses publiques
# ────────────────────────────────────────────────────────────────────────────


class CameraType(str, Enum):
    AUTO = "auto"
    USB = "usb"
    RTSP = "rtsp"
    HTTP = "http"
    FILE = "file"


class CameraState(str, Enum):
    IDLE = "idle"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    DEGRADED = "degraded"
    STOPPED = "stopped"


@dataclass
class CameraStatus:
    state: CameraState = CameraState.IDLE
    source_active: Optional[str] = None
    last_error: Optional[str] = None
    frame_count: int = 0
    last_frame_ts: Optional[float] = None
    fps_measured: float = 0.0
    snapshot_available: bool = False
    cv2_available: bool = _CV2_AVAILABLE


# ────────────────────────────────────────────────────────────────────────────
# Résolution de la source selon le type demandé
# ────────────────────────────────────────────────────────────────────────────


def _resolve_source(
    camera_type: str,
    camera_source: str,
    rtsp_url: str,
    http_url: str,
) -> tuple[str | int, CameraType]:
    """
    Retourne (source, type_résolu) selon la configuration.

    Règles AUTO :
      1. Si rtsp_url fournie → RTSP
      2. Si http_url fournie → HTTP
      3. Si camera_source est un entier → USB index
      4. Si camera_source est une URL → USB (laissé à OpenCV)
      5. Sinon → USB index 0
    """
    ctype = CameraType(camera_type) if camera_type in CameraType._value2member_map_ else CameraType.AUTO

    if ctype == CameraType.AUTO:
        if rtsp_url:
            return rtsp_url, CameraType.RTSP
        if http_url:
            return http_url, CameraType.HTTP
        # numeric index ?
        try:
            return int(camera_source), CameraType.USB
        except (ValueError, TypeError):
            if camera_source.startswith("rtsp://"):
                return camera_source, CameraType.RTSP
            if camera_source.startswith("http://") or camera_source.startswith("https://"):
                return camera_source, CameraType.HTTP
            return 0, CameraType.USB

    if ctype == CameraType.RTSP:
        src = rtsp_url or camera_source
        return src, CameraType.RTSP

    if ctype == CameraType.HTTP:
        src = http_url or camera_source
        return src, CameraType.HTTP

    if ctype == CameraType.FILE:
        return camera_source, CameraType.FILE

    # USB ou AUTO sans URL
    try:
        return int(camera_source), CameraType.USB
    except (ValueError, TypeError):
        return 0, CameraType.USB


# ────────────────────────────────────────────────────────────────────────────
# CameraManager
# ────────────────────────────────────────────────────────────────────────────


class CameraManager:
    """
    Gestionnaire de caméra thread-safe.

    Usage :
        mgr = CameraManager(settings)
        mgr.start()          # non-bloquant
        snap = mgr.snapshot_jpeg()   # bytes JPEG ou None
        mgr.stop()
    """

    # nombre max de tentatives de reconnexion consécutives avant DEGRADED
    _MAX_RECONNECT_ATTEMPTS = 10

    def __init__(self, settings) -> None:  # settings : app.config.Settings
        self._settings = settings
        self._status = CameraStatus()
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._cap = None  # cv2.VideoCapture or None
        self._last_frame: Optional[bytes] = None  # JPEG bytes

    # ── Propriétés publiques ──────────────────────────────────────────────

    @property
    def status(self) -> CameraStatus:
        with self._lock:
            # retourne une copie légère (dataclass mutable, mais lecture ok)
            return CameraStatus(
                state=self._status.state,
                source_active=self._status.source_active,
                last_error=self._status.last_error,
                frame_count=self._status.frame_count,
                last_frame_ts=self._status.last_frame_ts,
                fps_measured=self._status.fps_measured,
                snapshot_available=self._status.snapshot_available,
                cv2_available=_CV2_AVAILABLE,
            )

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ── Cycle de vie ─────────────────────────────────────────────────────

    def start(self) -> bool:
        """Lance le thread caméra. Retourne True si démarré, False sinon."""
        if not self._settings.camera_enabled:
            logger.info("[CAMERA] DEGRADED_MODE reason=camera_disabled")
            with self._lock:
                self._status.state = CameraState.DEGRADED
                self._status.last_error = "camera_disabled"
            return False

        if not _CV2_AVAILABLE:
            logger.warning("[CAMERA] DEGRADED_MODE reason=cv2_not_installed")
            with self._lock:
                self._status.state = CameraState.DEGRADED
                self._status.last_error = "cv2_not_installed"
            return False

        if self.is_running:
            return True

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="camera-manager",
            daemon=True,
        )
        self._thread.start()
        logger.info("[CAMERA] thread démarré")
        return True

    def stop(self) -> None:
        """Arrête le thread caméra proprement."""
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5.0)
        self._release_cap()
        with self._lock:
            self._status.state = CameraState.STOPPED
        logger.info("[CAMERA] arrêté")

    # ── Snapshot ─────────────────────────────────────────────────────────

    def snapshot_jpeg(self) -> Optional[bytes]:
        """Retourne le dernier frame en bytes JPEG, ou None."""
        with self._lock:
            return self._last_frame

    def snapshot_base64(self) -> Optional[str]:
        """Retourne le dernier frame encodé en base64 (pour JSON/API)."""
        data = self.snapshot_jpeg()
        if data is None:
            return None
        return base64.b64encode(data).decode("ascii")

    # ── Test de connectivité (sans démarrer le thread) ───────────────────

    def test_source(self, source: str | int | None = None) -> dict:
        """
        Teste une source caméra et retourne un dict de résultat.
        N'enregistre PAS d'image.
        Compatible avec les tests (mocké via mock_cv2).
        """
        if not _CV2_AVAILABLE:
            return {
                "ok": False,
                "source": str(source),
                "reason": "cv2_not_installed",
            }

        if source is None:
            src, _ = _resolve_source(
                self._settings.camera_type,
                self._settings.camera_source,
                self._settings.camera_rtsp_url,
                self._settings.camera_http_url,
            )
        else:
            src = source

        logger.info("[CAMERA] SOURCE_TEST source=%s", src)
        cap = None
        try:
            cap = cv2.VideoCapture(src)
            if not cap.isOpened():
                logger.warning("[CAMERA] FAILED source=%s reason=not_opened", src)
                return {"ok": False, "source": str(src), "reason": "not_opened"}
            ret, frame = cap.read()
            if not ret or frame is None:
                logger.warning("[CAMERA] FAILED source=%s reason=no_frame", src)
                return {"ok": False, "source": str(src), "reason": "no_frame"}
            logger.info("[CAMERA] CONNECTED source=%s", src)
            return {"ok": True, "source": str(src)}
        except Exception as exc:
            logger.error("[CAMERA] FAILED source=%s reason=%s", src, exc)
            return {"ok": False, "source": str(src), "reason": str(exc)}
        finally:
            if cap is not None:
                cap.release()

    # ── Test auto de plusieurs indexes USB ───────────────────────────────

    def detect_usb_cameras(self, max_index: int = 3) -> list[dict]:
        """
        Teste les index 0..max_index-1.
        Retourne la liste des caméras disponibles.
        """
        results = []
        for idx in range(max_index):
            result = self.test_source(idx)
            results.append({"index": idx, **result})
        return results

    # ── Boucle interne ───────────────────────────────────────────────────

    def _loop(self) -> None:
        reconnect_attempts = 0
        src, _ = _resolve_source(
            self._settings.camera_type,
            self._settings.camera_source,
            self._settings.camera_rtsp_url,
            self._settings.camera_http_url,
        )

        while not self._stop_event.is_set():
            # ── Connexion ──────────────────────────────────────────────
            with self._lock:
                self._status.state = CameraState.CONNECTING

            logger.info("[CAMERA] SOURCE_TEST source=%s", src)
            cap = self._open_capture(src)

            if cap is None or not cap.isOpened():
                reconnect_attempts += 1
                logger.warning(
                    "[CAMERA] FAILED source=%s reason=not_opened attempt=%d",
                    src,
                    reconnect_attempts,
                )
                with self._lock:
                    self._status.last_error = "not_opened"
                    if reconnect_attempts >= self._MAX_RECONNECT_ATTEMPTS:
                        self._status.state = CameraState.DEGRADED
                        logger.error("[CAMERA] DEGRADED_MODE reason=max_reconnect_reached")
                        break
                    self._status.state = CameraState.RECONNECTING
                logger.info("[CAMERA] RECONNECTING attempt=%d", reconnect_attempts)
                self._stop_event.wait(self._settings.camera_reconnect_delay_sec)
                continue

            # ── Caméra ouverte ─────────────────────────────────────────
            reconnect_attempts = 0
            self._cap = cap
            with self._lock:
                self._status.state = CameraState.CONNECTED
                self._status.source_active = str(src)
                self._status.last_error = None
            logger.info("[CAMERA] CONNECTED source=%s", src)

            # Configuration résolution
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._settings.camera_frame_width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._settings.camera_frame_height)

            # ── Boucle de lecture ──────────────────────────────────────
            self._read_loop(cap, src)

            # sortie propre → STOPPED
            if self._stop_event.is_set():
                break

            # déconnexion inattendue → reconnexion
            reconnect_attempts += 1
            with self._lock:
                self._status.state = CameraState.RECONNECTING
                self._status.last_error = "stream_lost"
            logger.warning("[CAMERA] RECONNECTING attempt=%d reason=stream_lost", reconnect_attempts)
            self._release_cap()
            self._stop_event.wait(self._settings.camera_reconnect_delay_sec)

    def _read_loop(self, cap, src) -> None:
        """Lit les frames de `cap` jusqu'à stop_event ou erreur."""
        fps_limit = max(1, self._settings.camera_fps_limit)
        frame_delay = 1.0 / fps_limit
        fps_window: list[float] = []
        save_snap = self._settings.camera_save_snapshots

        while not self._stop_event.is_set():
            t0 = time.monotonic()
            try:
                ret, frame = cap.read()
            except Exception as exc:
                logger.error("[CAMERA] FAILED source=%s reason=%s", src, exc)
                with self._lock:
                    self._status.last_error = str(exc)
                break

            if not ret or frame is None:
                with self._lock:
                    self._status.last_error = "no_frame"
                break

            # Encode JPEG en mémoire
            ok, buf = cv2.imencode(".jpg", frame)
            if ok:
                jpeg = bytes(buf)
                with self._lock:
                    self._last_frame = jpeg
                    self._status.frame_count += 1
                    self._status.last_frame_ts = time.time()
                    self._status.snapshot_available = True

                # Sauvegarde sur disque si explicitement activée
                if save_snap:
                    self._save_snapshot(jpeg)

                # Calcul FPS glissant (10 dernières mesures)
                elapsed = time.monotonic() - t0
                fps_window.append(elapsed)
                if len(fps_window) > 10:
                    fps_window.pop(0)
                avg = sum(fps_window) / len(fps_window)
                if avg > 0:
                    with self._lock:
                        self._status.fps_measured = round(1.0 / avg, 1)

                logger.debug("[CAMERA] FRAME_OK fps=%.1f", self._status.fps_measured)

            # Respect de la limite FPS (économie CPU)
            elapsed = time.monotonic() - t0
            sleep_time = frame_delay - elapsed
            if sleep_time > 0:
                self._stop_event.wait(sleep_time)

    def _open_capture(self, src: str | int):
        """Ouvre un cv2.VideoCapture avec timeout implicite."""
        try:
            return cv2.VideoCapture(src)
        except Exception as exc:
            logger.error("[CAMERA] FAILED source=%s reason=%s", src, exc)
            return None

    def _release_cap(self) -> None:
        if self._cap is not None:
            try:
                self._cap.release()
            except Exception:
                pass
            self._cap = None

    def _save_snapshot(self, jpeg: bytes) -> None:
        """Sauvegarde un snapshot JPEG sur disque (uniquement si autorisé)."""
        try:
            snap_dir = Path(self._settings.camera_snapshot_dir)
            snap_dir.mkdir(parents=True, exist_ok=True)
            ts = int(time.time())
            path = snap_dir / f"snapshot_{ts}.jpg"
            path.write_bytes(jpeg)
        except Exception as exc:
            logger.warning("[CAMERA] snapshot save failed: %s", exc)


# ────────────────────────────────────────────────────────────────────────────
# Instance globale (singleton) — initialisée par main.py
# ────────────────────────────────────────────────────────────────────────────

_manager_instance: Optional[CameraManager] = None


def get_camera_manager() -> Optional[CameraManager]:
    """Retourne l'instance globale, ou None si non initialisée."""
    return _manager_instance


def init_camera_manager(settings) -> CameraManager:
    """
    Crée et démarre le CameraManager global.
    Appelé une seule fois depuis main.py.
    """
    global _manager_instance
    _manager_instance = CameraManager(settings)
    if settings.camera_enabled:
        _manager_instance.start()
    else:
        logger.info("[CAMERA] DEGRADED_MODE reason=camera_disabled_in_config")
    return _manager_instance
