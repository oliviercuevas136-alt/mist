"""
embedding_client.py — Client local pour générer des embeddings via Ollama.

Conception honnête :
  - Si Ollama tourne et que le modèle d'embedding est installé → embeddings
    réels (recherche sémantique vraie).
  - Si Ollama indisponible ou modèle absent → mode dégradé : aucun embedding
    n'est produit, l'index reste utilisable en mode BM25/lexical pur.
  - On NE bloque PAS l'indexation pour autant. Honnête sur les capacités.

Modèles testés/recommandés (à `ollama pull` côté Oli) :
  - nomic-embed-text       : 768 dim, ~270 Mo, qualité correcte FR
  - mxbai-embed-large      : 1024 dim, ~670 Mo, meilleure qualité

Choix via settings.embedding_model (défaut: 'nomic-embed-text').
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import List, Optional

import numpy as np

from app.config import settings
from app.utils.logger import get_logger

logger = get_logger("embedding_client")

# Import tardif/optionnel — ollama Python client peut ne pas être installé
try:
    import ollama   # type: ignore
    _OLLAMA_LIB = True
except Exception:
    ollama = None
    _OLLAMA_LIB = False


@dataclass
class EmbeddingStatus:
    available:  bool
    model:      str
    dim:        int
    reason:     str = ""
    last_check: float = 0.0


class EmbeddingClient:
    """
    Singleton thread-safe pour générer des embeddings via Ollama.
    Cache l'état de disponibilité pour éviter les re-tests permanents.
    """

    # Re-tester la dispo Ollama au plus toutes les N secondes
    AVAILABILITY_TTL_SEC = 60.0

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._status: Optional[EmbeddingStatus] = None
        self._model = getattr(settings, "embedding_model", "nomic-embed-text")
        # Tenter une init paresseuse
        self._probed_once = False

    @property
    def model(self) -> str:
        return self._model

    def get_status(self, force_recheck: bool = False) -> EmbeddingStatus:
        with self._lock:
            now = time.time()
            if (not force_recheck and self._status is not None
                and (now - self._status.last_check) < self.AVAILABILITY_TTL_SEC):
                return self._status
            self._status = self._probe()
            return self._status

    def is_available(self) -> bool:
        return self.get_status().available

    def _probe(self) -> EmbeddingStatus:
        """
        Test de disponibilité réelle : tentative d'embedding sur une chaîne courte.
        Retourne un EmbeddingStatus avec available=False si quoi que ce soit échoue.
        """
        if not _OLLAMA_LIB:
            return EmbeddingStatus(False, self._model, 0,
                                    "lib 'ollama' non installée",
                                    last_check=time.time())
        try:
            # ollama.embeddings(...) → {"embedding": [...]}
            r = ollama.embeddings(model=self._model, prompt="probe")
            emb = r.get("embedding") or r.get("embeddings")
            if emb and isinstance(emb, list) and len(emb) > 0:
                # Cas où embeddings retourne List[List[float]]
                if isinstance(emb[0], list):
                    emb = emb[0]
                dim = len(emb)
                return EmbeddingStatus(True, self._model, dim,
                                        last_check=time.time())
            return EmbeddingStatus(False, self._model, 0,
                                    "réponse Ollama vide",
                                    last_check=time.time())
        except Exception as exc:
            return EmbeddingStatus(False, self._model, 0,
                                    f"Ollama embeddings indispos: {exc}",
                                    last_check=time.time())

    def embed(self, text: str) -> Optional[np.ndarray]:
        """
        Retourne le vecteur float32 normalisé pour `text`.
        None si embeddings indisponibles ou texte vide.
        """
        text = (text or "").strip()
        if not text:
            return None
        if not self.is_available():
            return None
        try:
            r = ollama.embeddings(model=self._model, prompt=text)
            emb = r.get("embedding") or r.get("embeddings")
            if emb and isinstance(emb[0], list):
                emb = emb[0]
            if not emb:
                return None
            v = np.asarray(emb, dtype=np.float32)
            # Normaliser pour similarité cosinus rapide
            norm = np.linalg.norm(v)
            if norm > 1e-9:
                v = v / norm
            return v
        except Exception as exc:
            logger.warning("[EMBED] échec embedding (%d chars): %s",
                            len(text), str(exc)[:100])
            # Invalider le cache pour retester rapidement
            with self._lock:
                self._status = None
            return None

    def embed_many(self, texts: List[str]) -> List[Optional[np.ndarray]]:
        """Embed par lots. Ollama embeddings n'a pas de vraie API batch ; on boucle."""
        out: List[Optional[np.ndarray]] = []
        for t in texts:
            out.append(self.embed(t))
        return out


# ── Helpers de sérialisation ───────────────────────────────────────────────

def vec_to_bytes(v: np.ndarray) -> bytes:
    """Sérialise un float32 ndarray pour stockage SQLite BLOB."""
    return v.astype(np.float32).tobytes()


def bytes_to_vec(b: bytes, dim: int) -> Optional[np.ndarray]:
    """Désérialise un BLOB SQLite vers ndarray float32."""
    if not b or dim <= 0:
        return None
    try:
        v = np.frombuffer(b, dtype=np.float32)
        if v.size != dim:
            return None
        return v
    except Exception:
        return None


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Similarité cosinus entre deux vecteurs (supposés normalisés)."""
    return float(np.dot(a, b))


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[EmbeddingClient] = None
_lock = threading.Lock()


def get_embedding_client() -> EmbeddingClient:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = EmbeddingClient()
    return _instance
