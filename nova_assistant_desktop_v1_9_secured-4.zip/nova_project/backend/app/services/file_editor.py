"""
file_editor.py — Modification contrôlée de fichiers locaux par Nova (v1.9.7).

Service de modification de fichiers utilisé via le workflow strict
propose → confirm → execute de l'ActionManager. JAMAIS appelé
directement par le LLM.

GARANTIES DE SÉCURITÉ
─────────────────────
  1. ALLOWLIST stricte : seuls les dossiers listés dans
     settings.allowed_write_dirs sont accessibles en écriture.
     Vide par défaut = aucune modification possible.

  2. BLOCKLIST absolue : utilise le même `_is_forbidden_path` que
     file_search (System32, /etc, .ssh, etc.) → toujours refusé
     même si listé dans allowed_write_dirs.

  3. PAS DE SUPPRESSION : aucune méthode `delete`. Les modifications
     sont des écritures par-dessus, jamais des destructions.

  4. PAS DE SYMLINKS : refusés pour empêcher l'évasion de sandbox.

  5. EXTENSIONS WHITELIST : seules les extensions texte connues
     (.txt .md .json .csv .py .js .ts .html .css .yml .yaml .ini
     .conf .env .log) sont modifiables. Pas de binaires, pas de .exe.

  6. BACKUP AUTOMATIQUE : avant toute modification, copie complète
     du fichier original dans <backup_dir>/<nom>.<ts>.bak.

  7. UTF-8 STRICT : lecture/écriture en utf-8 ; rejet sur autre encodage.

  8. TAILLE MAX : un fichier > FILE_EDIT_MAX_BYTES est refusé pour
     empêcher l'exhaustion mémoire.

Opérations supportées :
    - replace_text(path, old, new, *, count)
        Remplace une chaîne EXACTE par une autre.
        Pas de regex (trop facile d'erreur).
        `count` limite le nombre de remplacements (par défaut 1).

    - append_text(path, content)
        Ajoute du contenu à la fin d'un fichier existant.

    - write_text(path, content, *, must_exist=True)
        Écrit le contenu complet. Si must_exist=True, refuse de créer
        un nouveau fichier (mode strict).
"""

from __future__ import annotations

import datetime as _dt
import os
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.config import settings
from app.utils.logger import get_logger

logger = get_logger("file_editor")


# Extensions texte autorisées (whitelist explicite)
_ALLOWED_EXTENSIONS = {
    ".txt", ".md", ".markdown",
    ".json", ".csv", ".tsv",
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".html", ".htm", ".css", ".scss",
    ".yml", ".yaml", ".toml", ".ini", ".conf", ".cfg",
    ".env",     # uniquement lecture côté file_search, ici OK car contrôlé
    ".log",
    ".xml", ".svg",
    ".sh", ".bat",  # acceptés, mais sandbox refusera les chemins système
}

# Taille max d'un fichier modifiable (en octets). Par défaut 1 Mo.
_DEFAULT_MAX_BYTES = 1 * 1024 * 1024


# ── Helpers de validation ──────────────────────────────────────────────────

def _parse_dirs_csv(csv: str) -> List[Path]:
    """Parse ALLOWED_WRITE_DIRS (CSV) en liste de Path absolus résolus."""
    if not csv:
        return []
    out: List[Path] = []
    for raw in csv.split(","):
        raw = raw.strip()
        if not raw:
            continue
        try:
            p = Path(raw).expanduser().resolve(strict=False)
            out.append(p)
        except Exception as exc:
            logger.warning("[FILE_EDITOR] dir invalide '%s' ignoré: %s", raw, exc)
    return out


def get_allowed_write_dirs() -> List[Path]:
    csv = getattr(settings, "allowed_write_dirs", "") or ""
    return _parse_dirs_csv(csv)


def get_backup_dir() -> Path:
    """Dossier où sont stockés les backups. Créé à la demande."""
    csv = getattr(settings, "file_edit_backup_dir", "") or ""
    if csv:
        p = Path(csv).expanduser().resolve(strict=False)
    else:
        # Fallback : sous-dossier dans le projet
        p = Path.cwd() / "data" / "edit_backups"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        logger.error("[FILE_EDITOR] impossible de créer backup_dir %s: %s", p, exc)
    return p


def _max_bytes() -> int:
    val = getattr(settings, "file_edit_max_bytes", _DEFAULT_MAX_BYTES)
    try:
        return int(val) if val else _DEFAULT_MAX_BYTES
    except Exception:
        return _DEFAULT_MAX_BYTES


# ── Vérification path ──────────────────────────────────────────────────────

@dataclass
class PathCheck:
    """Résultat d'une vérification de chemin."""
    ok:        bool
    resolved:  Optional[Path] = None
    reason:    str = ""


def validate_path_for_write(raw_path: str) -> PathCheck:
    """
    Vérifie qu'un chemin est autorisé en écriture.

    Pipeline strict :
      1. Résolution absolue (Path.resolve), bloque les .. relatifs
      2. Refus si symlink
      3. Refus si dans la blocklist absolue (file_search)
      4. Doit appartenir à un des dossiers ALLOWED_WRITE_DIRS
      5. Extension dans la whitelist
      6. Si existe : pas un dossier, pas un device, et taille < max
    """
    # Import tardif pour éviter cycle
    from app.services.file_search import _is_forbidden_path

    if not raw_path or not isinstance(raw_path, str):
        return PathCheck(False, reason="chemin vide")

    # 1. Résolution
    try:
        resolved = Path(raw_path).expanduser().resolve(strict=False)
    except Exception as exc:
        return PathCheck(False, reason=f"chemin invalide: {exc}")

    # 2. Symlinks : on regarde le chemin tel quel (avant résolution complète)
    # plus le path résolu — refus si différent de la résolution naïve
    try:
        raw_p = Path(raw_path).expanduser()
        # Si le chemin existe et est un symlink → refus
        if raw_p.is_symlink():
            return PathCheck(False, reason="lien symbolique refusé")
        # Vérifier aussi les parents : un parent symlink → suspect
        for parent in resolved.parents:
            try:
                if parent.is_symlink():
                    return PathCheck(False, reason=f"parent symlink: {parent}")
            except (OSError, PermissionError):
                continue
    except (OSError, PermissionError):
        pass  # on accepte de continuer si stat échoue

    # 3. Blocklist absolue
    if _is_forbidden_path(resolved):
        return PathCheck(False, reason=f"chemin système protégé: {resolved}")

    # 4. Dans un dossier autorisé ?
    allowed_dirs = get_allowed_write_dirs()
    if not allowed_dirs:
        return PathCheck(False, reason=(
            "ALLOWED_WRITE_DIRS vide — aucune écriture possible. "
            "Définissez ALLOWED_WRITE_DIRS dans .env."
        ))
    in_allowed = False
    for d in allowed_dirs:
        try:
            resolved.relative_to(d)
            in_allowed = True
            break
        except ValueError:
            continue
    if not in_allowed:
        return PathCheck(False, reason=(
            f"chemin hors ALLOWED_WRITE_DIRS: {resolved} "
            f"(autorisés: {[str(d) for d in allowed_dirs]})"
        ))

    # 5. Extension
    ext = resolved.suffix.lower()
    if ext not in _ALLOWED_EXTENSIONS:
        return PathCheck(False, reason=(
            f"extension non autorisée: '{ext}'. "
            f"Autorisées: {sorted(_ALLOWED_EXTENSIONS)}"
        ))

    # 6. Si existe : checks supplémentaires
    if resolved.exists():
        if resolved.is_dir():
            return PathCheck(False, reason="cible est un dossier")
        try:
            if not resolved.is_file():
                return PathCheck(False, reason="cible n'est pas un fichier régulier")
            size = resolved.stat().st_size
            if size > _max_bytes():
                return PathCheck(False, reason=(
                    f"fichier trop grand: {size} octets > max {_max_bytes()}"
                ))
        except OSError as exc:
            return PathCheck(False, reason=f"stat échoué: {exc}")

    return PathCheck(True, resolved=resolved)


# ── Backup ─────────────────────────────────────────────────────────────────

@dataclass
class BackupResult:
    ok:           bool
    backup_path:  Optional[Path] = None
    reason:       str = ""
    size_bytes:   int = 0


def create_backup(path: Path) -> BackupResult:
    """
    Crée un backup horodaté du fichier. Si le fichier n'existe pas
    (cas d'une création), retourne ok=True sans backup.
    """
    if not path.exists():
        return BackupResult(ok=True, reason="fichier inexistant, pas de backup")
    try:
        ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = get_backup_dir()
        # Conserve l'arborescence pour éviter collisions
        # On préfixe par un hash court du chemin parent pour disambiguer
        import hashlib
        parent_hash = hashlib.sha256(str(path.parent).encode()).hexdigest()[:8]
        backup_name = f"{path.stem}_{parent_hash}_{ts}{path.suffix}.bak"
        backup_path = backup_dir / backup_name
        shutil.copy2(path, backup_path)
        size = backup_path.stat().st_size
        logger.info("[FILE_EDITOR] backup créé: %s (%d octets)", backup_path, size)
        return BackupResult(ok=True, backup_path=backup_path, size_bytes=size)
    except Exception as exc:
        logger.error("[FILE_EDITOR] backup échoué pour %s: %s", path, exc)
        return BackupResult(ok=False, reason=f"backup échoué: {exc}")


# ── Lecture sûre ──────────────────────────────────────────────────────────

def _read_text_strict(path: Path) -> Tuple[bool, str, str]:
    """Lit le fichier en UTF-8 strict. Retourne (ok, content, reason)."""
    try:
        content = path.read_text(encoding="utf-8")
        return True, content, ""
    except UnicodeDecodeError as exc:
        return False, "", f"fichier non UTF-8: {exc}"
    except OSError as exc:
        return False, "", f"lecture échouée: {exc}"


def _write_text_atomic(path: Path, content: str) -> Tuple[bool, str]:
    """
    Écriture atomique : écrit dans un .tmp puis renomme.
    Évite les fichiers à moitié écrits si crash en plein milieu.
    """
    try:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(content, encoding="utf-8")
        # os.replace est atomique sur même filesystem
        os.replace(str(tmp), str(path))
        return True, ""
    except Exception as exc:
        # Nettoyer le .tmp si laissé
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
        return False, f"écriture échouée: {exc}"


# ── Opérations ─────────────────────────────────────────────────────────────

@dataclass
class EditResult:
    ok:           bool
    operation:    str
    target:       Optional[str] = None
    backup_path:  Optional[str] = None
    diff_summary: Optional[str] = None
    reason:       str = ""
    bytes_before: int = 0
    bytes_after:  int = 0


def _summarize_change(old: str, new: str, max_chars: int = 400) -> str:
    """Résumé court du diff pour l'audit + l'aperçu de confirmation."""
    if old == new:
        return "(aucun changement)"
    n_old = len(old)
    n_new = len(new)
    delta = n_new - n_old
    sign = "+" if delta >= 0 else ""
    summary = f"taille: {n_old} → {n_new} ({sign}{delta} octets)"
    # Premier point de divergence
    i = 0
    while i < min(n_old, n_new) and old[i] == new[i]:
        i += 1
    if i < min(n_old, n_new):
        start = max(0, i - 20)
        old_excerpt = repr(old[start:i + 40])[:100]
        new_excerpt = repr(new[start:i + 40])[:100]
        summary += f" | 1ère divergence char {i}: AVANT={old_excerpt} APRÈS={new_excerpt}"
    return summary[:max_chars]


def preview_replace_text(path_str: str, old: str, new: str, count: int = 1) -> Dict[str, Any]:
    """
    Calcule le diff prévu SANS écrire.
    Utilisé par propose_action() pour produire l'aperçu de confirmation.
    """
    check = validate_path_for_write(path_str)
    if not check.ok:
        return {"ok": False, "reason": check.reason}

    path = check.resolved
    assert path is not None

    if not path.exists():
        return {"ok": False, "reason": "fichier inexistant"}

    ok, content, reason = _read_text_strict(path)
    if not ok:
        return {"ok": False, "reason": reason}

    if old not in content:
        return {"ok": False, "reason": f"chaîne 'old' non trouvée dans le fichier"}

    occurrences = content.count(old)
    effective_count = max(1, int(count) if count else 1)
    new_content = content.replace(old, new, effective_count)

    return {
        "ok":              True,
        "target":          str(path),
        "occurrences":     occurrences,
        "will_replace":    min(effective_count, occurrences),
        "diff_summary":    _summarize_change(content, new_content),
        "bytes_before":    len(content.encode("utf-8")),
        "bytes_after":     len(new_content.encode("utf-8")),
    }


def replace_text(path_str: str, old: str, new: str, count: int = 1) -> EditResult:
    """
    Effectue la modification après backup.
    NE DOIT JAMAIS être appelé sans passer par ActionManager.execute_action().
    """
    check = validate_path_for_write(path_str)
    if not check.ok:
        return EditResult(ok=False, operation="replace_text", reason=check.reason)

    path = check.resolved
    assert path is not None

    if not path.exists():
        return EditResult(ok=False, operation="replace_text",
                           target=str(path), reason="fichier inexistant")

    # Lecture
    ok, content, reason = _read_text_strict(path)
    if not ok:
        return EditResult(ok=False, operation="replace_text",
                           target=str(path), reason=reason)

    if old not in content:
        return EditResult(ok=False, operation="replace_text",
                           target=str(path), reason="chaîne 'old' non trouvée")

    effective_count = max(1, int(count) if count else 1)
    new_content = content.replace(old, new, effective_count)
    if new_content == content:
        return EditResult(ok=False, operation="replace_text",
                           target=str(path), reason="aucun changement effectif")

    # Backup
    bk = create_backup(path)
    if not bk.ok:
        return EditResult(ok=False, operation="replace_text",
                           target=str(path), reason=bk.reason)

    # Écriture atomique
    ok_w, err_w = _write_text_atomic(path, new_content)
    if not ok_w:
        return EditResult(ok=False, operation="replace_text",
                           target=str(path),
                           backup_path=str(bk.backup_path) if bk.backup_path else None,
                           reason=err_w)

    return EditResult(
        ok=True, operation="replace_text",
        target=str(path),
        backup_path=str(bk.backup_path) if bk.backup_path else None,
        diff_summary=_summarize_change(content, new_content),
        bytes_before=len(content.encode("utf-8")),
        bytes_after=len(new_content.encode("utf-8")),
    )


def preview_append_text(path_str: str, content_to_add: str) -> Dict[str, Any]:
    check = validate_path_for_write(path_str)
    if not check.ok:
        return {"ok": False, "reason": check.reason}
    path = check.resolved
    assert path is not None
    if not path.exists():
        return {"ok": False, "reason": "fichier inexistant (append refuse de créer)"}
    try:
        size_before = path.stat().st_size
    except OSError as exc:
        return {"ok": False, "reason": f"stat échoué: {exc}"}
    size_added = len(content_to_add.encode("utf-8"))
    if size_before + size_added > _max_bytes():
        return {"ok": False, "reason": "taille post-append > max"}
    return {
        "ok":              True,
        "target":          str(path),
        "bytes_before":    size_before,
        "bytes_after":     size_before + size_added,
        "diff_summary":    f"+ {size_added} octets ajoutés en fin de fichier",
    }


def append_text(path_str: str, content_to_add: str) -> EditResult:
    check = validate_path_for_write(path_str)
    if not check.ok:
        return EditResult(ok=False, operation="append_text", reason=check.reason)
    path = check.resolved
    assert path is not None
    if not path.exists():
        return EditResult(ok=False, operation="append_text",
                           target=str(path), reason="fichier inexistant")

    ok, current, reason = _read_text_strict(path)
    if not ok:
        return EditResult(ok=False, operation="append_text",
                           target=str(path), reason=reason)

    new_content = current + content_to_add
    if len(new_content.encode("utf-8")) > _max_bytes():
        return EditResult(ok=False, operation="append_text",
                           target=str(path), reason="taille post-append > max")

    bk = create_backup(path)
    if not bk.ok:
        return EditResult(ok=False, operation="append_text",
                           target=str(path), reason=bk.reason)

    ok_w, err_w = _write_text_atomic(path, new_content)
    if not ok_w:
        return EditResult(ok=False, operation="append_text",
                           target=str(path),
                           backup_path=str(bk.backup_path) if bk.backup_path else None,
                           reason=err_w)

    return EditResult(
        ok=True, operation="append_text",
        target=str(path),
        backup_path=str(bk.backup_path) if bk.backup_path else None,
        diff_summary=f"+ {len(content_to_add)} caractères ajoutés",
        bytes_before=len(current.encode("utf-8")),
        bytes_after=len(new_content.encode("utf-8")),
    )


# ── Inventaire backups ────────────────────────────────────────────────────

def list_backups(limit: int = 50) -> List[Dict[str, Any]]:
    """Liste les backups, les plus récents en premier."""
    backup_dir = get_backup_dir()
    if not backup_dir.exists():
        return []
    items = []
    try:
        for p in backup_dir.iterdir():
            if not p.is_file() or not p.name.endswith(".bak"):
                continue
            try:
                st = p.stat()
                items.append({
                    "name":    p.name,
                    "path":    str(p),
                    "size":    st.st_size,
                    "mtime":   st.st_mtime,
                })
            except OSError:
                continue
    except OSError:
        return []
    items.sort(key=lambda x: x["mtime"], reverse=True)
    return items[:limit]
