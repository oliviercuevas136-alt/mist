"""
file_search.py — Service de recherche locale de fichiers, strictement contraint.

Principe de sécurité :
    1. ALLOWLIST EXPLICITE : seuls les dossiers déclarés dans
       settings.allowed_search_dirs (CSV) sont parcourus.
       Vide par défaut → recherche disque entièrement désactivée.
    2. BLOCKLIST ABSOLUE : même si l'utilisateur ajoute par erreur
       un chemin système (C:\\Windows, /etc, AppData, etc.), il est
       refusé silencieusement.
    3. LECTURE SEULE : ce service N'A AUCUNE primitive d'écriture,
       de modification ou de suppression. Il ne peut que lister/lire.
    4. PLAFONDS : nombre de fichiers parcourus et taille de contenu lu
       sont bornés pour éviter DoS local.

Deux modes de recherche :
    - search_by_name(query, dirs=None)
    - search_by_content(query, dirs=None)   (uniquement extensions texte connues)

Retour : liste de dicts {path, name, size, modified_iso, snippet?}
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Iterable, List, Optional

from app.config import settings
from app.utils.logger import get_logger

logger = get_logger("file_search")


# ── Blocklist absolue ──────────────────────────────────────────────────────
#
# Patterns normalisés (lowercase, slashes unifiés) qui ne doivent JAMAIS
# être parcourus, quelle que soit la configuration utilisateur. Cette liste
# est non négociable et prévaut sur allowed_search_dirs.

_FORBIDDEN_PATTERNS = [
    # Windows
    "c:/windows",
    "c:/program files",
    "c:/program files (x86)",
    "c:/programdata",
    "c:/$recycle.bin",
    "c:/system volume information",
    "/appdata/local/microsoft",
    "/appdata/roaming/microsoft",
    "/appdata/local/packages",
    # Unix / macOS
    "/etc",
    "/proc",
    "/sys",
    "/boot",
    "/root",
    "/var/log",
    "/var/lib",
    "/usr/bin",
    "/usr/sbin",
    "/system/library",
    "/library/system",
    # Données sensibles classiques
    "/.ssh",
    "/.gnupg",
    "/.aws",
    "/.config/google-chrome",
    "/.mozilla",
]


def _normalize(p: str) -> str:
    """Normalisation pour comparaisons sécurisées : lowercase + slash unix."""
    return str(p).replace("\\", "/").lower().rstrip("/")


def _is_forbidden_path(path: Path) -> bool:
    """Vrai si le chemin tombe dans la blocklist absolue."""
    norm = _normalize(path)
    return any(forbidden in norm for forbidden in _FORBIDDEN_PATTERNS)


@dataclass
class SearchResult:
    path: str
    name: str
    size: int
    modified_iso: str
    snippet: Optional[str] = None


class FileSearchError(Exception):
    """Erreur métier (config invalide, dossier interdit, etc.)."""


class FileSearch:
    """
    Service de recherche local strictement borné.
    Instance créée à la demande via get_file_search().
    """

    def __init__(self) -> None:
        self._extensions = self._parse_extensions(settings.file_search_text_extensions)

    # ── Allowlist effective ────────────────────────────────────────────────

    @staticmethod
    def _parse_dirs_csv(csv: str) -> List[Path]:
        if not csv or not csv.strip():
            return []
        raw_items = [s.strip() for s in csv.split(",") if s.strip()]
        out: List[Path] = []
        for raw in raw_items:
            try:
                p = Path(raw).expanduser().resolve()
            except Exception:
                logger.warning("[FILESEARCH] chemin invalide ignoré : %s", raw)
                continue
            if not p.exists():
                logger.warning("[FILESEARCH] chemin inexistant ignoré : %s", p)
                continue
            if not p.is_dir():
                logger.warning("[FILESEARCH] pas un dossier, ignoré : %s", p)
                continue
            if _is_forbidden_path(p):
                logger.error(
                    "[FILESEARCH] chemin systeme refusé par la blocklist : %s", p
                )
                continue
            out.append(p)
        return out

    @staticmethod
    def _parse_extensions(csv: str) -> set:
        if not csv:
            return set()
        return {
            ("." + e.strip().lstrip(".").lower())
            for e in csv.split(",")
            if e.strip()
        }

    def get_allowed_dirs(self) -> List[Path]:
        """Retourne la liste effective des dossiers autorisés (config + filtres)."""
        return self._parse_dirs_csv(settings.allowed_search_dirs)

    def _validate_subset(self, requested: Optional[Iterable[str]]) -> List[Path]:
        """
        Si l'appelant fournit une liste de dossiers, vérifier que CHACUN
        est un sous-chemin d'un dossier autorisé. Sinon → erreur.
        Sans liste fournie → tous les dossiers autorisés.
        """
        allowed = self.get_allowed_dirs()
        if not allowed:
            raise FileSearchError(
                "Recherche fichier désactivée. "
                "Définissez ALLOWED_SEARCH_DIRS dans .env (CSV de dossiers absolus)."
            )

        if not requested:
            return allowed

        approved: List[Path] = []
        for raw in requested:
            try:
                p = Path(raw).expanduser().resolve()
            except Exception:
                raise FileSearchError(f"Chemin invalide : {raw}")
            if _is_forbidden_path(p):
                raise FileSearchError(f"Chemin systeme interdit : {p}")
            # Doit être sous-chemin d'un dossier autorisé
            ok = False
            for base in allowed:
                try:
                    p.relative_to(base)
                    ok = True
                    break
                except ValueError:
                    continue
            if not ok:
                raise FileSearchError(
                    f"Chemin hors allowlist : {p} (autorisés : "
                    + ", ".join(str(d) for d in allowed) + ")"
                )
            approved.append(p)
        return approved

    # ── Itération sûre du file system ──────────────────────────────────────

    def _walk_safe(self, roots: List[Path], max_scan: int):
        """
        Générateur de chemins fichiers, en respectant :
          - blocklist (sous-dossiers systèmes même dans un parent autorisé)
          - plafond de fichiers parcourus
          - skip des liens symboliques (anti pivot)
          - skip des dossiers cachés (.git, .venv, etc.)
        """
        scanned = 0
        for root in roots:
            for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
                # Skip dossiers cachés ou potentiellement systèmes
                dirnames[:] = [
                    d for d in dirnames
                    if not d.startswith(".")
                    and not _is_forbidden_path(Path(dirpath) / d)
                ]

                if _is_forbidden_path(Path(dirpath)):
                    continue

                for fn in filenames:
                    if fn.startswith("."):
                        continue
                    full = Path(dirpath) / fn
                    if _is_forbidden_path(full):
                        continue
                    yield full
                    scanned += 1
                    if scanned >= max_scan:
                        logger.info("[FILESEARCH] plafond scan atteint (%d)", max_scan)
                        return

    # ── Construction d'un résultat ─────────────────────────────────────────

    @staticmethod
    def _stat_to_result(path: Path, snippet: Optional[str] = None) -> SearchResult:
        try:
            st = path.stat()
            modified = datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%dT%H:%M:%S")
            size = st.st_size
        except OSError:
            modified = ""
            size = 0
        return SearchResult(
            path=str(path),
            name=path.name,
            size=size,
            modified_iso=modified,
            snippet=snippet,
        )

    # ── API publique : recherche par nom ───────────────────────────────────

    def search_by_name(
        self,
        query: str,
        dirs: Optional[Iterable[str]] = None,
        max_results: Optional[int] = None,
    ) -> List[dict]:
        """
        Recherche fichiers dont le NOM contient `query` (case-insensitive).
        Pas d'accès au CONTENU ici.
        """
        if not query or not query.strip():
            raise FileSearchError("Requête vide.")
        q = query.strip().lower()

        roots = self._validate_subset(dirs)
        cap = min(
            max_results or settings.file_search_max_results,
            settings.file_search_max_results,
        )
        t0 = time.perf_counter()

        results: List[SearchResult] = []
        scanned = 0
        for fpath in self._walk_safe(roots, settings.file_search_max_scan_files):
            scanned += 1
            if q in fpath.name.lower():
                results.append(self._stat_to_result(fpath))
                if len(results) >= cap:
                    break

        elapsed = int((time.perf_counter() - t0) * 1000)
        logger.info(
            "[FILESEARCH_BY_NAME] query=%r scanned=%d hits=%d ms=%d",
            q, scanned, len(results), elapsed,
        )
        return [asdict(r) for r in results]

    # ── API publique : recherche par contenu ───────────────────────────────

    def search_by_content(
        self,
        query: str,
        dirs: Optional[Iterable[str]] = None,
        max_results: Optional[int] = None,
    ) -> List[dict]:
        """
        Recherche fichiers TEXTE dont le CONTENU contient `query`
        (case-insensitive). Bornes :
          - extensions whitelistées (settings.file_search_text_extensions)
          - taille max scannée par fichier (settings.file_search_max_content_bytes)
        Renvoie aussi un snippet de contexte autour du match.
        """
        if not query or not query.strip():
            raise FileSearchError("Requête vide.")
        q = query.strip()
        q_lower = q.lower()

        roots = self._validate_subset(dirs)
        cap = min(
            max_results or settings.file_search_max_results,
            settings.file_search_max_results,
        )
        max_bytes = settings.file_search_max_content_bytes
        t0 = time.perf_counter()

        results: List[SearchResult] = []
        scanned = 0
        opened = 0
        for fpath in self._walk_safe(roots, settings.file_search_max_scan_files):
            scanned += 1
            if fpath.suffix.lower() not in self._extensions:
                continue
            try:
                with fpath.open("rb") as f:
                    data = f.read(max_bytes)
            except OSError:
                continue
            opened += 1
            try:
                text = data.decode("utf-8", errors="replace")
            except Exception:
                continue
            text_lower = text.lower()
            idx = text_lower.find(q_lower)
            if idx == -1:
                continue
            snippet = _make_snippet(text, idx, len(q))
            results.append(self._stat_to_result(fpath, snippet=snippet))
            if len(results) >= cap:
                break

        elapsed = int((time.perf_counter() - t0) * 1000)
        logger.info(
            "[FILESEARCH_BY_CONTENT] query=%r scanned=%d opened=%d hits=%d ms=%d",
            q, scanned, opened, len(results), elapsed,
        )
        return [asdict(r) for r in results]


    # ── API publique : lecture sécurisée d'un fichier ──────────────────────

    def read_file_safe(
        self,
        path: str,
        mode: str = "preview",
        max_bytes: Optional[int] = None,
    ) -> dict:
        """
        Lit un fichier UNIQUEMENT si :
          1. Son chemin résolu est sous un dossier autorisé (allowlist)
          2. Son chemin n'est pas dans la blocklist absolue
          3. Son extension est dans la liste des extensions texte autorisées
          4. Sa taille (bornée par max_bytes) ne dépasse pas le plafond

        Lecture seule. Aucune modification, aucune création.

        mode :
            "preview"  → lit max settings.file_read_preview_bytes
            "full"     → lit max settings.file_read_full_max_bytes
            Si max_bytes fourni explicitement, c'est lui qui prime (mais
            toujours plafonné par file_read_full_max_bytes).

        Retour : dict {
            path, name, extension, size, bytes_read, encoding, truncated,
            content (texte décodé), mode
        }
        """
        if not path or not path.strip():
            raise FileSearchError("Chemin vide.")

        # 1. Résolution sûre
        try:
            target = Path(path).expanduser().resolve()
        except Exception as exc:
            raise FileSearchError(f"Chemin invalide : {exc}")

        # 2. Blocklist (système)
        if _is_forbidden_path(target):
            raise FileSearchError(
                f"Lecture refusée : chemin système protégé ({target})."
            )

        # 3. Existence + type
        if not target.exists():
            raise FileSearchError(f"Fichier introuvable : {target}")
        if target.is_dir():
            raise FileSearchError(f"Cible est un dossier, pas un fichier : {target}")
        if not target.is_file():
            raise FileSearchError(f"Cible n'est pas un fichier régulier : {target}")
        if target.is_symlink():
            raise FileSearchError("Liens symboliques non autorisés (anti-pivot).")

        # 4. Allowlist : doit être sous un dossier autorisé
        allowed = self.get_allowed_dirs()
        if not allowed:
            raise FileSearchError(
                "Lecture désactivée : aucun dossier autorisé. "
                "Définissez ALLOWED_SEARCH_DIRS dans .env."
            )
        is_under_allowed = False
        for base in allowed:
            try:
                target.relative_to(base)
                is_under_allowed = True
                break
            except ValueError:
                continue
        if not is_under_allowed:
            raise FileSearchError(
                f"Lecture refusée : {target} hors dossiers autorisés "
                f"({', '.join(str(d) for d in allowed)})"
            )

        # 5. Extension whitelistée
        ext = target.suffix.lower()
        if ext not in self._extensions:
            raise FileSearchError(
                f"Extension {ext!r} non autorisée. "
                f"Autorisées : {sorted(self._extensions)}"
            )

        # 6. Borne de lecture selon mode
        hard_cap = int(settings.file_read_full_max_bytes)
        if mode == "preview":
            cap = int(settings.file_read_preview_bytes)
        elif mode == "full":
            cap = hard_cap
        else:
            raise FileSearchError(f"Mode invalide : {mode!r} (attendu : preview|full)")

        if max_bytes is not None:
            try:
                cap = min(int(max_bytes), hard_cap)
            except (TypeError, ValueError):
                raise FileSearchError("max_bytes invalide.")
        cap = max(1, cap)

        # 7. Stat + lecture bornée
        try:
            st = target.stat()
        except OSError as exc:
            raise FileSearchError(f"Stat impossible : {exc}")
        total_size = st.st_size

        try:
            with target.open("rb") as f:
                data = f.read(cap)
        except OSError as exc:
            raise FileSearchError(f"Lecture impossible : {exc}")

        bytes_read = len(data)
        truncated = bytes_read < total_size

        # 8. Décodage tolérant
        try:
            content = data.decode("utf-8")
            encoding = "utf-8"
        except UnicodeDecodeError:
            content = data.decode("utf-8", errors="replace")
            encoding = "utf-8-replace"

        modified_iso = datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%dT%H:%M:%S")

        logger.info(
            "[FILESEARCH_READ] mode=%s ext=%s bytes_read=%d/%d truncated=%s path=%s",
            mode, ext, bytes_read, total_size, truncated, target,
        )

        # Publier sur le bus central via le point d'entrée UNIQUE (CORE).
        # On utilise orchestrator.submit_event() — bus.publish direct est
        # désormais déprécié pour les nouveaux modules.
        try:
            from app.core.event_bus import CoreEvent, EventLevel
            from app.core.orchestrator import orchestrator as _core
            _core.submit_event(CoreEvent(
                type="file.read",
                source="file_search",
                level=EventLevel.LOW,
                message=f"Lecture {mode} : {target.name}",
                payload={
                    "path": str(target), "mode": mode,
                    "bytes_read": bytes_read, "size": total_size,
                    "truncated": truncated, "extension": ext,
                },
            ))
        except Exception as exc:
            logger.debug("[FILESEARCH] CORE submit skipped: %s", exc)

        return {
            "path":         str(target),
            "name":         target.name,
            "extension":    ext,
            "size":         total_size,
            "bytes_read":   bytes_read,
            "encoding":     encoding,
            "truncated":    truncated,
            "modified_iso": modified_iso,
            "mode":         mode,
            "content":      content,
        }


def _make_snippet(text: str, idx: int, match_len: int, radius: int = 60) -> str:
    """Extrait ~120 chars autour du match, sans casser brutalement les mots."""
    start = max(0, idx - radius)
    end   = min(len(text), idx + match_len + radius)
    fragment = text[start:end].replace("\n", " ").replace("\r", " ")
    prefix = "…" if start > 0 else ""
    suffix = "…" if end < len(text) else ""
    return prefix + fragment.strip() + suffix


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[FileSearch] = None


def get_file_search() -> FileSearch:
    global _instance
    if _instance is None:
        _instance = FileSearch()
    return _instance
