"""
mistral_client.py — Client Mistral API (fallback LLM cloud)

Utilisé UNIQUEMENT si :
  - USE_MISTRAL_FALLBACK=true dans .env
  - MISTRAL_API_KEY renseigné dans .env

N'est jamais appelé si Ollama répond correctement.
API compatible OpenAI — POST https://api.mistral.ai/v1/chat/completions

Compatible Windows 10 / Python 3.10+.
"""
import json
from typing import Dict, Generator, List

import requests

from app.utils.logger import get_logger

logger = get_logger("mistral_client")

_BASE_URL = "https://api.mistral.ai/v1"


class MistralClient:
    """Client HTTP minimal pour l'API Mistral AI.

    Pas de dépendance externe 'mistralai' — utilise requests (déjà présent).
    """

    def __init__(self, api_key: str, model: str, timeout: int = 30) -> None:
        if not api_key:
            raise ValueError("MISTRAL_API_KEY manquant — impossible d'instancier MistralClient.")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    # ── Non-streaming ─────────────────────────────────────────────────────────

    def chat(self, messages: List[Dict[str, str]]) -> str:
        """Appel bloquant — fallback de OllamaClient.chat().

        Lève une exception en cas d'erreur (le caller gère le log [LLM_ERROR]).
        """
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
        }
        logger.info(
            "[LLM] MISTRAL_FALLBACK model=%s msgs=%d",
            self.model, len(messages),
        )
        r = requests.post(
            f"{_BASE_URL}/chat/completions",
            headers=self._headers(),
            json=payload,
            timeout=self.timeout,
        )
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"].strip()
        if not content:
            raise RuntimeError("Réponse vide Mistral /chat/completions.")
        logger.info("[LLM] MISTRAL_OK chars=%d", len(content))
        return content

    # ── Streaming ─────────────────────────────────────────────────────────────

    def chat_stream(self, messages: List[Dict[str, str]]) -> Generator[str, None, None]:
        """Streaming SSE — fallback de OllamaClient.chat_stream().

        Yield chaque token Mistral dès réception.
        Format : data: {"choices":[{"delta":{"content":"..."}}]}
        """
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
        }
        logger.info(
            "[LLM] MISTRAL_FALLBACK stream model=%s msgs=%d",
            self.model, len(messages),
        )
        token_count = 0

        with requests.post(
            f"{_BASE_URL}/chat/completions",
            headers=self._headers(),
            json=payload,
            stream=True,
            timeout=self.timeout,
        ) as r:
            r.raise_for_status()
            for raw in r.iter_lines():
                if not raw:
                    continue
                line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                if not line.startswith("data: "):
                    continue
                data = line[6:].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                    delta = obj["choices"][0]["delta"].get("content", "")
                    if delta:
                        token_count += 1
                        yield delta
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue

        logger.info("[LLM] MISTRAL_OK tokens=%d", token_count)
