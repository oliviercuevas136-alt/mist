"""
risk_engine.py — Moteur de scoring de risque local.

Produit 3 scores 0..100 :
    - danger     : exposition immédiate (incidents critiques détectés)
    - anomaly    : déviation comportementale (events inhabituels récents)
    - confidence : confiance du système dans ses propres mesures
                   (élevé = données fraîches et nombreuses ; bas = sources indisponibles)

Architecture :
    - Aucun état persistant (recalcul à la demande)
    - Lecture seule : interroge SystemMonitor + journal du bus
    - Pas de side-effect : le RiskEngine ne décide pas, il SCORE
    - L'Orchestrator + CoreDecision décident ensuite quoi faire des scores
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

from app.utils.logger import get_logger

logger = get_logger("risk_engine")


@dataclass
class RiskScores:
    danger:     int     # 0..100
    anomaly:    int     # 0..100
    confidence: int     # 0..100
    factors:    List[Dict[str, Any]]   # contributeurs principaux
    timestamp:  float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# Poids par type d'event sur le score danger
_DANGER_WEIGHTS = {
    "vision.fall":               60,
    "alert.fall":                60,
    "alert.fall_escalated":      80,
    "alert.fall_confirmed":      40,
    "alert.manual":              50,
    "system.cpu_critical":       25,
    "system.ram_critical":       30,
    "system.disk_critical":      30,
    "system.cpu_high":           10,
    "system.ram_high":           10,
    "system.disk_high":          10,
    "system.swap_high":          15,
    "security.suspicious_proc":  35,
    "security.unauthorized":     50,
}

# Poids anomalie : événements rares ou hors profil
_ANOMALY_WEIGHTS = {
    "vision.absence_prolonged":   30,
    "alert.prolonged_silence":    25,
    "alert.prolonged_absence":    25,
    "system.swap_high":           15,
    "security.new_process":       10,
    "security.network_anomaly":   25,
}


class RiskEngine:

    def __init__(self, recent_window_sec: float = 300.0) -> None:
        """recent_window_sec : fenêtre d'analyse pour l'anomalie."""
        self._window = float(max(30.0, recent_window_sec))

    def compute(self) -> RiskScores:
        """
        Calcule les 3 scores à partir de :
            - les events récents du bus (journal central)
            - le snapshot système courant
        """
        factors: List[Dict[str, Any]] = []
        danger = 0
        anomaly = 0
        confidence_components: List[float] = []

        now = time.time()
        recent_events = self._get_recent_events(now)

        # ── Danger : addition pondérée des events critiques récents ────────
        for ev in recent_events:
            w = _DANGER_WEIGHTS.get(ev.get("type", ""), 0)
            if w > 0:
                # Décroissance temporelle douce : plus vieux = moins de poids
                age = max(0.0, now - ev.get("timestamp", now))
                decay = math.exp(-age / self._window)
                contrib = int(w * decay)
                if contrib > 0:
                    danger += contrib
                    factors.append({
                        "factor": "danger",
                        "event_type": ev["type"],
                        "weight": w,
                        "age_sec": int(age),
                        "contribution": contrib,
                    })

        # Empêcher dépassement
        danger = min(100, danger)

        # ── Anomalie : events de pattern inhabituel ────────────────────────
        for ev in recent_events:
            w = _ANOMALY_WEIGHTS.get(ev.get("type", ""), 0)
            if w > 0:
                age = max(0.0, now - ev.get("timestamp", now))
                decay = math.exp(-age / self._window)
                contrib = int(w * decay)
                if contrib > 0:
                    anomaly += contrib
                    factors.append({
                        "factor": "anomaly",
                        "event_type": ev["type"],
                        "weight": w,
                        "age_sec": int(age),
                        "contribution": contrib,
                    })

        # Bonus anomalie : si volume événementiel anormalement élevé
        if len(recent_events) > 100:
            burst = min(30, (len(recent_events) - 100) // 10)
            if burst > 0:
                anomaly += burst
                factors.append({
                    "factor": "anomaly", "event_type": "event_burst",
                    "count": len(recent_events), "contribution": burst,
                })

        anomaly = min(100, anomaly)

        # ── Confiance : qualité/fraîcheur des mesures ──────────────────────
        # +50 si SystemMonitor tourne et snapshot récent (<30s)
        # +30 si bus a au moins quelques events
        # +20 si journal a un volume normal (≥10 entrées)
        confidence_components.append(self._confidence_sysmon())
        confidence_components.append(self._confidence_bus(recent_events))
        confidence = int(min(100, sum(confidence_components)))

        scores = RiskScores(
            danger=danger, anomaly=anomaly, confidence=confidence,
            factors=factors[:20],   # top 20 contributeurs
            timestamp=now,
        )
        logger.info(
            "[RISK] danger=%d anomaly=%d confidence=%d events=%d",
            danger, anomaly, confidence, len(recent_events),
        )
        return scores

    # ── Sous-fonctions ────────────────────────────────────────────────────

    def _get_recent_events(self, now: float) -> List[Dict[str, Any]]:
        """Récupère le journal du bus filtré sur la fenêtre récente."""
        try:
            from app.core.event_bus import get_event_bus
            bus = get_event_bus()
            all_events = bus.get_journal(limit=500)
        except Exception as exc:
            logger.debug("[RISK] bus journal indisponible: %s", exc)
            return []
        cutoff = now - self._window
        return [e for e in all_events if e.get("timestamp", 0) >= cutoff]

    def _confidence_sysmon(self) -> float:
        """+50 si SystemMonitor actif avec snapshot récent."""
        try:
            from app.services.system_monitor import get_system_monitor
            sm = get_system_monitor()
            if not sm.is_running():
                return 10.0
            latest = sm.get_latest()
            if latest is None:
                return 15.0
            age = time.time() - latest.get("timestamp", 0)
            if age < 30:
                return 50.0
            if age < 120:
                return 30.0
            return 15.0
        except Exception:
            return 10.0

    def _confidence_bus(self, recent_events: List[Dict[str, Any]]) -> float:
        """Bonus selon volume d'events (modules vivants)."""
        n = len(recent_events)
        if n == 0:
            return 0.0
        if n < 10:
            return 20.0
        if n < 200:
            return 50.0
        # Volume excessif → confiance plus modérée (bruit)
        return 35.0


# ── Singleton ──────────────────────────────────────────────────────────────

_engine: Optional[RiskEngine] = None


def get_risk_engine() -> RiskEngine:
    global _engine
    if _engine is None:
        _engine = RiskEngine()
    return _engine
