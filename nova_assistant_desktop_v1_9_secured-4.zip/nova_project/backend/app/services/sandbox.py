"""
sandbox.py — Garde-fou strict pour les actions PC.

Centralise les RÈGLES DE REFUS ABSOLUES qui s'appliquent quelle que soit
la permission ou la confirmation utilisateur. Si la sandbox dit NON,
aucune action ne passe — même autorisée.

Trois couches :
    - chemins protégés (read/write/delete refusés)
    - processus protégés (kill refusé)
    - commandes/binaires interdits à l'exécution

Cette sandbox ne s'occupe PAS des permissions granulaires (cf. ActionManager).
Elle est le FOND : les permissions sont la couche du dessus.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional


# ── Chemins critiques toujours refusés ─────────────────────────────────────
#
# Patterns normalisés (lowercase, slashes unix) à comparer.
# Toute action sur un chemin contenant un de ces patterns est refusée.

_PROTECTED_PATH_PATTERNS = [
    # Windows
    "c:/windows", "c:/program files", "c:/programdata",
    "c:/$recycle.bin", "c:/system volume information",
    "/appdata/local/microsoft", "/appdata/roaming/microsoft",
    "/appdata/local/packages",
    # Unix
    "/etc", "/proc", "/sys", "/boot", "/root", "/var/log", "/var/lib",
    "/usr/bin", "/usr/sbin", "/bin/", "/sbin/",
    "/system/library", "/library/system",
    # Données sensibles
    "/.ssh", "/.gnupg", "/.aws",
    "/.config/google-chrome", "/.mozilla",
]


# ── Processus critiques toujours refusés à kill ────────────────────────────

_PROTECTED_PROCESS_NAMES = {
    # Windows critiques
    "system", "system idle process", "csrss.exe", "smss.exe",
    "wininit.exe", "services.exe", "lsass.exe", "winlogon.exe",
    "svchost.exe", "explorer.exe", "dwm.exe",
    "fontdrvhost.exe", "ctfmon.exe",
    # macOS critiques
    "kernel_task", "launchd", "windowserver", "loginwindow",
    # Linux critiques
    "init", "systemd", "kthreadd",
    # Nova lui-même (anti auto-kill)
    "python.exe", "nova.exe", "node.exe", "electron.exe",
}


# ── Binaires/commandes interdits à l'exécution ────────────────────────────

_FORBIDDEN_EXECUTABLES = {
    # Outils admin/destructifs
    "format", "format.com", "format.exe", "diskpart", "diskpart.exe",
    "shutdown", "shutdown.exe", "reboot",
    "del", "rm", "rmdir", "deltree",
    # Registre Windows
    "reg", "reg.exe", "regedit", "regedit.exe", "regedt32.exe",
    # PowerShell / cmd avec args dangereux
    "cipher.exe",   # peut effacer sécurisé
    "fdisk", "mkfs",
    # Réseau dangereux
    "net.exe", "netsh", "netsh.exe",
    # Scripts d'install
    "msiexec.exe",
}


# ── Extensions exécutables refusées par défaut au "lancer fichier" ────────

_EXECUTABLE_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".com", ".scr", ".vbs", ".vbe", ".js", ".jse",
    ".wsf", ".wsh", ".ps1", ".msi", ".msp", ".reg", ".jar", ".app",
    ".sh", ".bash", ".zsh",
}


# ── Décisions ──────────────────────────────────────────────────────────────

class SandboxDecision:
    ALLOW = "allow"
    DENY  = "deny"


def _normalize_path(p: str) -> str:
    return str(p).replace("\\", "/").lower().rstrip("/")


def check_path(path: str, operation: str = "read") -> tuple[str, Optional[str]]:
    """
    Vérifie si une opération est autorisée sur un chemin.

    Args:
        path      : chemin candidat
        operation : "read" | "write" | "delete" | "execute"

    Returns:
        (decision, reason) — decision = "allow" ou "deny" ; reason = phrase
    """
    if not path or not str(path).strip():
        return SandboxDecision.DENY, "chemin vide"

    norm = _normalize_path(path)

    # Path traversal patent
    if ".." in norm.split("/"):
        return SandboxDecision.DENY, "path traversal détecté"

    # Chemins protégés
    for pat in _PROTECTED_PATH_PATTERNS:
        if pat in norm:
            return SandboxDecision.DENY, f"chemin système protégé ({pat})"

    # Execute : refuser les extensions exécutables sans whitelist
    if operation == "execute":
        try:
            ext = Path(path).suffix.lower()
        except Exception:
            ext = ""
        if ext in _EXECUTABLE_EXTENSIONS:
            return SandboxDecision.DENY, f"exécution d'extension {ext} bloquée par sandbox"

    return SandboxDecision.ALLOW, None


def check_process_kill(name_or_pid: str) -> tuple[str, Optional[str]]:
    """Vérifie si un processus peut être tué."""
    if not name_or_pid:
        return SandboxDecision.DENY, "identifiant processus vide"
    lname = str(name_or_pid).lower().strip()
    if lname in _PROTECTED_PROCESS_NAMES:
        return SandboxDecision.DENY, f"processus système protégé : {name_or_pid}"
    # PID 0/1 protégés (System / init)
    try:
        pid = int(name_or_pid)
        if pid <= 1:
            return SandboxDecision.DENY, "PID système réservé (≤1)"
    except (ValueError, TypeError):
        pass
    return SandboxDecision.ALLOW, None


def check_executable(name: str) -> tuple[str, Optional[str]]:
    """Vérifie qu'un binaire/commande n'est pas dans la blocklist."""
    if not name:
        return SandboxDecision.DENY, "nom exécutable vide"
    base = _normalize_path(name).rsplit("/", 1)[-1]
    if base in _FORBIDDEN_EXECUTABLES:
        return SandboxDecision.DENY, f"exécutable interdit : {base}"
    return SandboxDecision.ALLOW, None


__all__ = [
    "SandboxDecision",
    "check_path", "check_process_kill", "check_executable",
]
