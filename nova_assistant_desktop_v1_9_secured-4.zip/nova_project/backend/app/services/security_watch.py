"""
security_watch.py — Surveillances sécurité de Nova.

Quatre familles de surveillance, toutes via le CORE :
    - ProcessWatcher       : diff entre snapshots de processus → nouveaux/disparus
    - NetworkWatcher       : connexions inhabituelles (heuristique configurable)
    - StartupWatcher       : démarrage Windows (Run/RunOnce dans registre)
    - SuspiciousFileWatcher: fichiers exécutables récents dans dossiers autorisés
    - DeviceWatcher        : accès webcam/micro (best-effort Windows, sinon stub honnête)

Chaque watcher publie sur orchestrator.submit_event() — JAMAIS d'action directe.
Tous best-effort : si une capacité OS n'est pas disponible, le watcher
retourne "unavailable" plutôt qu'un faux positif.

Architecture longue durée :
    - Pas de thread dédié — appel périodique depuis SystemMonitor (économie)
    - Caches d'état pour comparaisons (avant/après)
    - Cooldown propre via le bus (anti-spam intégré)
"""

from __future__ import annotations

import os
import platform
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from app.utils.logger import get_logger

logger = get_logger("security_watch")

try:
    import psutil
    _PSUTIL_OK = True
except ImportError:
    psutil = None  # type: ignore
    _PSUTIL_OK = False


# ── Helper : publication CORE ──────────────────────────────────────────────

def _publish(type_: str, level: str, message: str, payload: Dict[str, Any]) -> None:
    """Wrapper unique vers orchestrator.submit_event(). Toujours catch."""
    try:
        from app.core.event_bus import CoreEvent, EventLevel
        from app.core.orchestrator import orchestrator
        lvl_map = {
            "info":     EventLevel.INFO,
            "low":      EventLevel.LOW,
            "medium":   EventLevel.MEDIUM,
            "high":     EventLevel.HIGH,
            "critical": EventLevel.CRITICAL,
        }
        orchestrator.submit_event(CoreEvent(
            type=type_, source="security_watch",
            level=lvl_map.get(level, EventLevel.INFO),
            message=message, payload=payload,
        ))
    except Exception as exc:
        logger.debug("[SEC] CORE submit skipped: %s", exc)


# ── 1. ProcessWatcher ──────────────────────────────────────────────────────

# Noms de processus considérés "système attendu" — ne déclenchent pas d'alerte
_KNOWN_SYSTEM_PROCESSES = {
    # Windows
    "system", "system idle process", "registry", "smss.exe", "csrss.exe",
    "wininit.exe", "services.exe", "lsass.exe", "svchost.exe",
    "winlogon.exe", "fontdrvhost.exe", "dwm.exe", "explorer.exe",
    "ctfmon.exe", "runtimebroker.exe", "searchindexer.exe",
    "audiodg.exe", "spoolsv.exe", "taskhostw.exe",
    "memcompression", "secure system",
    # macOS
    "launchd", "kernel_task", "windowserver", "loginwindow", "syslogd",
    # Linux
    "init", "systemd", "kthreadd", "kworker", "ksoftirqd", "bash", "sh",
    # Nova lui-même
    "python.exe", "python", "node.exe", "node", "electron.exe", "electron",
    "uvicorn", "ollama.exe", "ollama",
}


# Mots-clés évoquant un processus suspect (heuristique simple)
_SUSPICIOUS_KEYWORDS = [
    "keylog", "cryptominer", "miner", "ransom", "trojan", "backdoor",
    "rootkit", "spyware", "stealer",
]


class ProcessWatcher:
    """
    Détecte les nouveaux processus entre deux snapshots successifs.
    """

    def __init__(self) -> None:
        self._previous_pids: Set[int] = set()
        self._initial_scan_done = False

    def scan(self) -> Dict[str, Any]:
        """
        Compare les pids actuels avec ceux de la dernière scan().
        Publie un event pour chaque nouveau processus.
        Retourne un dict de résumé.
        """
        if not _PSUTIL_OK:
            return {"available": False, "reason": "psutil indisponible"}

        try:
            current: Dict[int, Dict[str, Any]] = {}
            for p in psutil.process_iter(["pid", "name", "exe", "create_time", "username"]):
                try:
                    info = p.info
                    current[int(info["pid"])] = {
                        "pid":  int(info["pid"]),
                        "name": (info.get("name") or "?"),
                        "exe":  info.get("exe") or "",
                        "create_time": float(info.get("create_time") or 0),
                        "username":    info.get("username") or "",
                    }
                except Exception:
                    continue
        except Exception as exc:
            logger.warning("[SEC.PROCESS] scan échoué : %s", exc)
            return {"available": False, "reason": str(exc)}

        new_pids = set(current.keys()) - self._previous_pids
        gone_pids = self._previous_pids - set(current.keys())

        # Premier scan : on initialise sans alerter (sinon spam au démarrage)
        if not self._initial_scan_done:
            self._previous_pids = set(current.keys())
            self._initial_scan_done = True
            return {
                "available": True,
                "initial_scan": True,
                "total_processes": len(current),
                "new": [], "gone": [],
            }

        new_list: List[Dict[str, Any]] = []
        for pid in new_pids:
            info = current[pid]
            name = info["name"].lower()
            # Classification : known / suspicious / unknown
            classification = self._classify(name, info["exe"])
            entry = {**info, "classification": classification}
            new_list.append(entry)

            # Publier event selon classification
            if classification == "suspicious":
                _publish(
                    "security.suspicious_proc", "high",
                    f"Processus suspect détecté : {info['name']} (PID {pid})",
                    payload={"process": entry},
                )
            elif classification == "unknown":
                _publish(
                    "security.new_process", "medium",
                    f"Nouveau processus inconnu : {info['name']} (PID {pid})",
                    payload={"process": entry},
                )
            # known : pas d'event (anti-spam)

        self._previous_pids = set(current.keys())
        return {
            "available": True,
            "initial_scan": False,
            "total_processes": len(current),
            "new": new_list,
            "gone_count": len(gone_pids),
        }

    @staticmethod
    def _classify(name_lower: str, exe: str) -> str:
        """Retourne 'known' | 'unknown' | 'suspicious'."""
        if any(kw in name_lower for kw in _SUSPICIOUS_KEYWORDS):
            return "suspicious"
        if name_lower in _KNOWN_SYSTEM_PROCESSES:
            return "known"
        # Heuristique exe : binaires depuis %TEMP% sont suspects
        if exe:
            exe_lower = exe.replace("\\", "/").lower()
            if "/temp/" in exe_lower or "/tmp/" in exe_lower:
                return "suspicious"
            if "/appdata/local/temp" in exe_lower:
                return "suspicious"
        return "unknown"


# ── 2. NetworkWatcher ──────────────────────────────────────────────────────

# Ports considérés "rares" pour usage standard (heuristique simple)
_UNCOMMON_PORTS_THRESHOLD = 49152   # ports dynamiques au-dessus

# Listening interfaces inattendues (autre que loopback/local)
_LOCAL_HOSTS = {"127.0.0.1", "::1", "0.0.0.0", "::", ""}


class NetworkWatcher:
    """
    Liste les connexions réseau actives et détecte les patterns inhabituels.

    Limites :
        - net_connections() peut nécessiter des privilèges admin pour voir
          les connexions des autres processus → on attrape AccessDenied.
        - Heuristique simple : ports élevés + processus inconnu + état LISTEN
          sur interface publique = suspect.
    """

    def __init__(self) -> None:
        self._previous_listening: Set[Tuple[str, int]] = set()

    def scan(self) -> Dict[str, Any]:
        if not _PSUTIL_OK:
            return {"available": False, "reason": "psutil indisponible"}

        try:
            conns = psutil.net_connections(kind="inet")
        except (psutil.AccessDenied, PermissionError):
            return {"available": False, "reason": "access denied (privilèges admin requis)"}
        except Exception as exc:
            return {"available": False, "reason": str(exc)}

        listening: List[Dict[str, Any]] = []
        established: List[Dict[str, Any]] = []
        for c in conns:
            try:
                laddr = (c.laddr.ip, c.laddr.port) if c.laddr else ("", 0)
                raddr = (c.raddr.ip, c.raddr.port) if c.raddr else ("", 0)
                entry = {
                    "pid":    c.pid,
                    "status": c.status,
                    "laddr":  f"{laddr[0]}:{laddr[1]}",
                    "raddr":  f"{raddr[0]}:{raddr[1]}",
                    "type":   "tcp" if c.type == 1 else "udp",
                }
                if c.status == "LISTEN":
                    listening.append(entry)
                elif c.status == "ESTABLISHED":
                    established.append(entry)
            except Exception:
                continue

        # Détecter nouveaux listeners (signal d'ouverture de port inattendue)
        cur_listening = {(e["laddr"], e["pid"] or -1) for e in listening}
        if self._previous_listening:
            new_listeners = cur_listening - self._previous_listening
            for laddr_str, pid in new_listeners:
                # Heuristique : LISTEN sur interface publique + port haut
                try:
                    ip, port_str = laddr_str.rsplit(":", 1)
                    port = int(port_str)
                except ValueError:
                    continue
                if ip not in _LOCAL_HOSTS and port >= _UNCOMMON_PORTS_THRESHOLD:
                    _publish(
                        "security.network_anomaly", "high",
                        f"Nouveau LISTEN sur port {port} interface {ip} (PID {pid})",
                        payload={"laddr": laddr_str, "pid": pid, "port": port},
                    )
        self._previous_listening = cur_listening

        return {
            "available":   True,
            "listening":   listening,
            "established_count": len(established),
            "total":       len(conns),
        }


# ── 3. StartupWatcher (Windows registre) ───────────────────────────────────

_REGISTRY_RUN_KEYS = [
    ("HKEY_CURRENT_USER",  r"Software\Microsoft\Windows\CurrentVersion\Run"),
    ("HKEY_CURRENT_USER",  r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
    ("HKEY_LOCAL_MACHINE", r"Software\Microsoft\Windows\CurrentVersion\Run"),
    ("HKEY_LOCAL_MACHINE", r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
]


class StartupWatcher:
    """
    Inspecte les entrées de démarrage Windows (registre Run/RunOnce).
    Détecte les nouvelles entrées par diff avec snapshot précédent.

    Sur non-Windows : retourne available=False sans erreur.
    """

    def __init__(self) -> None:
        self._previous_entries: Optional[Set[Tuple[str, str, str]]] = None

    def scan(self) -> Dict[str, Any]:
        if platform.system() != "Windows":
            return {"available": False, "reason": "Windows uniquement"}
        try:
            import winreg  # type: ignore
        except ImportError:
            return {"available": False, "reason": "winreg indisponible"}

        entries: List[Dict[str, Any]] = []
        hive_map = {
            "HKEY_CURRENT_USER":  winreg.HKEY_CURRENT_USER,   # type: ignore
            "HKEY_LOCAL_MACHINE": winreg.HKEY_LOCAL_MACHINE,  # type: ignore
        }
        for hive_name, subkey in _REGISTRY_RUN_KEYS:
            try:
                with winreg.OpenKey(hive_map[hive_name], subkey) as k:  # type: ignore
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(k, i)  # type: ignore
                            entries.append({
                                "hive":   hive_name,
                                "subkey": subkey,
                                "name":   name,
                                "value":  str(value),
                            })
                            i += 1
                        except OSError:
                            break
            except FileNotFoundError:
                continue
            except (PermissionError, OSError) as exc:
                logger.debug("[SEC.STARTUP] %s\\%s skipped: %s", hive_name, subkey, exc)

        # Détecter nouvelles entrées
        current_set = {(e["hive"], e["subkey"], e["name"]) for e in entries}
        if self._previous_entries is not None:
            new = current_set - self._previous_entries
            removed = self._previous_entries - current_set
            for hive, subkey, name in new:
                entry = next((e for e in entries if (e["hive"], e["subkey"], e["name"]) == (hive, subkey, name)), None)
                _publish(
                    "security.startup_added", "high",
                    f"Nouvelle entrée démarrage Windows : {name}",
                    payload={"entry": entry},
                )
            for hive, subkey, name in removed:
                _publish(
                    "security.startup_removed", "medium",
                    f"Entrée démarrage Windows supprimée : {name}",
                    payload={"hive": hive, "subkey": subkey, "name": name},
                )
        self._previous_entries = current_set

        return {
            "available":   True,
            "entries":     entries,
            "count":       len(entries),
        }


# ── 4. SuspiciousFileWatcher ───────────────────────────────────────────────

# Extensions considérées exécutables/script
_SUSPICIOUS_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".ps1", ".vbs", ".vbe",
    ".scr", ".com", ".pif", ".msi", ".jse", ".wsf", ".hta",
}


class SuspiciousFileWatcher:
    """
    Scanne les dossiers autorisés (settings.allowed_search_dirs) pour
    repérer des fichiers à extension dangereuse récemment modifiés.
    Configuration : seuls les dossiers DÉJÀ autorisés à la recherche
    fichier sont scannés — pas d'élargissement de surface.
    """

    def __init__(self) -> None:
        self._seen: Dict[str, float] = {}     # path → mtime déjà signalé

    def scan(self, max_age_sec: float = 86400.0, max_results: int = 50) -> Dict[str, Any]:
        # Réutilise la même allowlist + blocklist que FileSearch
        from app.services.file_search import get_file_search, _is_forbidden_path

        fs = get_file_search()
        roots = fs.get_allowed_dirs()
        if not roots:
            return {"available": False, "reason": "ALLOWED_SEARCH_DIRS vide"}

        now = time.time()
        cutoff = now - max_age_sec
        found: List[Dict[str, Any]] = []
        scanned = 0

        for root in roots:
            for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
                # skip cachés + protégés
                dirnames[:] = [
                    d for d in dirnames
                    if not d.startswith(".") and not _is_forbidden_path(Path(dirpath) / d)
                ]
                if _is_forbidden_path(Path(dirpath)):
                    continue
                for fn in filenames:
                    if fn.startswith("."):
                        continue
                    p = Path(dirpath) / fn
                    if p.suffix.lower() not in _SUSPICIOUS_EXTENSIONS:
                        continue
                    try:
                        st = p.stat()
                    except OSError:
                        continue
                    scanned += 1
                    if st.st_mtime < cutoff:
                        continue

                    path_str = str(p)
                    # Anti-doublon : ne pas re-signaler si déjà vu avec même mtime
                    if self._seen.get(path_str) == st.st_mtime:
                        continue
                    self._seen[path_str] = st.st_mtime

                    entry = {
                        "path":      path_str,
                        "name":      fn,
                        "extension": p.suffix.lower(),
                        "size":      st.st_size,
                        "mtime":     st.st_mtime,
                        "age_sec":   int(now - st.st_mtime),
                    }
                    found.append(entry)
                    _publish(
                        "security.suspicious_file", "medium",
                        f"Fichier exécutable récent : {fn}",
                        payload=entry,
                    )
                    if len(found) >= max_results:
                        break
            if len(found) >= max_results:
                break

        return {
            "available": True,
            "found": found,
            "scanned": scanned,
            "max_age_sec": max_age_sec,
        }


# ── 5. DeviceWatcher (webcam / mic) ────────────────────────────────────────
#
# Limites honnêtes :
#   - Sous Windows, l'API native (registre ConsentStore) ou WMI permettent
#     de lister précisément quels processus utilisent la caméra/micro,
#     MAIS nécessitent pywin32 ou pywinrt. Hors stack Python pure.
#   - Approche pragmatique sans dépendance lourde : on inspecte les handles
#     ouverts par chaque processus et on cherche des noms de devices liés.
#   - Sous Linux : /dev/video* et /dev/snd/*. Sous macOS : pas d'API publique.
#
# Le watcher retourne TOUJOURS un résultat structuré. Si la détection
# n'est pas fiable sur la plateforme, available=False avec raison.

# Noms de devices considérés liés à webcam/micro
_WEBCAM_KEYWORDS = ["video", "camera", "webcam", "ksenumeratedevice"]
_MIC_KEYWORDS    = ["audio", "microphone", "snd/pcm", "snd/control"]


class DeviceWatcher:
    """
    Détection best-effort des processus qui détiennent un handle de
    périphérique correspondant à une webcam ou un microphone.
    """

    def __init__(self) -> None:
        self._webcam_users_prev: Set[int] = set()
        self._mic_users_prev: Set[int] = set()

    def scan(self) -> Dict[str, Any]:
        if not _PSUTIL_OK:
            return {"available": False, "reason": "psutil indisponible"}

        system = platform.system()
        if system not in ("Linux", "Windows"):
            return {"available": False, "reason": f"non supporté sur {system}"}

        webcam_users: List[Dict[str, Any]] = []
        mic_users: List[Dict[str, Any]] = []
        denied_count = 0

        for p in psutil.process_iter(["pid", "name"]):
            try:
                files = p.open_files()
            except (psutil.AccessDenied, PermissionError):
                denied_count += 1
                continue
            except (psutil.NoSuchProcess, Exception):
                continue

            paths_lower = [str(f.path).lower() for f in files]
            for path_lower in paths_lower:
                if any(kw in path_lower for kw in _WEBCAM_KEYWORDS):
                    webcam_users.append({
                        "pid": p.info["pid"],
                        "name": p.info.get("name") or "?",
                        "device": path_lower,
                    })
                    break
            for path_lower in paths_lower:
                if any(kw in path_lower for kw in _MIC_KEYWORDS):
                    mic_users.append({
                        "pid": p.info["pid"],
                        "name": p.info.get("name") or "?",
                        "device": path_lower,
                    })
                    break

        # Publier transitions (nouveau processus accède au device)
        webcam_pids = {u["pid"] for u in webcam_users}
        mic_pids    = {u["pid"] for u in mic_users}

        for pid in webcam_pids - self._webcam_users_prev:
            entry = next(u for u in webcam_users if u["pid"] == pid)
            _publish(
                "security.webcam_access", "high",
                f"Accès webcam détecté : {entry['name']} (PID {pid})",
                payload=entry,
            )
        for pid in mic_pids - self._mic_users_prev:
            entry = next(u for u in mic_users if u["pid"] == pid)
            _publish(
                "security.mic_access", "high",
                f"Accès microphone détecté : {entry['name']} (PID {pid})",
                payload=entry,
            )

        self._webcam_users_prev = webcam_pids
        self._mic_users_prev    = mic_pids

        # Reliability : si trop de denied, signaler que la détection est partielle
        reliability = "full"
        if denied_count > 0:
            reliability = f"partial ({denied_count} processus inaccessibles, "
            reliability += "privilèges admin requis pour scan complet)"

        return {
            "available":  True,
            "platform":   system,
            "webcam_users": webcam_users,
            "mic_users":    mic_users,
            "denied_count": denied_count,
            "reliability":  reliability,
        }


# ── Singletons ──────────────────────────────────────────────────────────────

_process_watcher:    Optional[ProcessWatcher] = None
_network_watcher:    Optional[NetworkWatcher] = None
_startup_watcher:    Optional[StartupWatcher] = None
_suspicious_watcher: Optional[SuspiciousFileWatcher] = None
_device_watcher:     Optional[DeviceWatcher] = None


def get_process_watcher() -> ProcessWatcher:
    global _process_watcher
    if _process_watcher is None:
        _process_watcher = ProcessWatcher()
    return _process_watcher


def get_network_watcher() -> NetworkWatcher:
    global _network_watcher
    if _network_watcher is None:
        _network_watcher = NetworkWatcher()
    return _network_watcher


def get_startup_watcher() -> StartupWatcher:
    global _startup_watcher
    if _startup_watcher is None:
        _startup_watcher = StartupWatcher()
    return _startup_watcher


def get_suspicious_file_watcher() -> SuspiciousFileWatcher:
    global _suspicious_watcher
    if _suspicious_watcher is None:
        _suspicious_watcher = SuspiciousFileWatcher()
    return _suspicious_watcher


def get_device_watcher() -> DeviceWatcher:
    global _device_watcher
    if _device_watcher is None:
        _device_watcher = DeviceWatcher()
    return _device_watcher


def scan_all() -> Dict[str, Any]:
    """
    Lance un cycle complet de toutes les surveillances.
    Utile pour : appel périodique depuis SystemMonitor, ou endpoint manuel.
    """
    return {
        "timestamp":  time.time(),
        "processes":  get_process_watcher().scan(),
        "network":    get_network_watcher().scan(),
        "startup":    get_startup_watcher().scan(),
        "files":      get_suspicious_file_watcher().scan(),
        "devices":    get_device_watcher().scan(),
    }
