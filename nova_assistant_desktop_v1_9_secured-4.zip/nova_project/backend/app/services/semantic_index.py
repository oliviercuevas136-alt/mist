"""
semantic_index.py — Index local intelligent pour Nova (v1.9.8).

Pipeline d'indexation :
    1. Pour chaque fichier dans ALLOWED_INDEX_DIRS (extensions whitelist) :
       - extraire le texte (selon extension)
       - hash sha256 du contenu pour détection incrémentale
       - chunker en ~500 chars
       - générer embeddings via EmbeddingClient (si Ollama dispo)
       - stocker dans DB (IndexedDocument + IndexedChunk)

    2. Catégorisation par règles déterministes (chemin + mots-clés).

Pipeline de recherche :
    1. Si embeddings dispo + query non vide : embed la query, cosinus sur
       tous les chunks → top K. Score sémantique [0..1].
    2. Toujours : score lexical BM25 simplifié (TF + IDF + length-norm).
    3. Score final = 0.6 × sémantique + 0.4 × lexical (configurable).
    4. Agrégation par document, max(scores des chunks).

Garde-fous mémoire :
    - Chunks chargés en streaming depuis SQLite, pas tous en RAM.
    - Embeddings désérialisés à la volée.
    - Indexation : 1 fichier à la fois, pas de parallélisme.
    - Plafond MAX_INDEXED_BYTES par fichier (défaut 2 Mo).

Sécurité :
    - Réutilise blocklist absolue de file_search (_is_forbidden_path).
    - Ne suit JAMAIS de symlinks.
    - Refuse les extensions hors whitelist (pas de .exe, .dll, .bin).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np

from app.config import settings
from app.utils.logger import get_logger

logger = get_logger("semantic_index")

# Imports tardifs pour PDF — optionnels
try:
    import pypdf  # type: ignore
    _PDF_LIB = True
except Exception:
    pypdf = None
    _PDF_LIB = False


# ── Extensions indexables ──────────────────────────────────────────────────

_TEXT_EXTENSIONS = {
    ".txt", ".md", ".markdown",
    ".json", ".csv", ".tsv", ".yml", ".yaml", ".toml", ".ini", ".conf",
    ".log",
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".html", ".htm", ".css", ".scss",
    ".xml", ".svg",
    ".sh", ".bat", ".rst",
}
_PDF_EXTENSIONS = {".pdf"}
_INDEXABLE = _TEXT_EXTENSIONS | _PDF_EXTENSIONS


# ── Catégorisation ─────────────────────────────────────────────────────────
# Règles déterministes : appartenance d'un mot-clé dans path ou contenu.
# L'ordre des catégories importe (la première qui matche gagne).

_CATEGORY_RULES = [
    # (catégorie, regex sur path OU contenu)
    ("securité",     re.compile(r"\b(security|sandbox|action_manager|risk_engine|"
                                  r"sécur|password|token|crypto|authent|vuln)\b", re.I)),
    ("ia",           re.compile(r"\b(llm|embed|prompt|ollama|whisper|tts|stt|"
                                  r"agent|model[ée]l[ée]|inférence|neural)\b", re.I)),
    ("trading",      re.compile(r"\b(trading|binance|crypto|portfolio|arkéon|adam|"
                                  r"trade|order|p&l|backtest|lstm|ppo)\b", re.I)),
    ("mémoire",      re.compile(r"\b(memory|m[ée]moire|recall|knowledge|notes?|"
                                  r"journal|episodic|rkhea)\b", re.I)),
    ("caméra",       re.compile(r"\b(camera|cam[ée]ra|webcam|vision_analyzer|"
                                  r"snapshot|video)\b", re.I)),
    ("système",      re.compile(r"\b(systemd?|monitor|process|service|"
                                  r"backup|log|kernel|cpu|ram|disk)\b", re.I)),
    ("développement", re.compile(r"\b(code|dev|repo|github|commit|api|"
                                  r"backend|frontend|router|endpoint|tests?)\b", re.I)),
    ("personnel",    re.compile(r"\b(perso|priv[ée]|famille|sant[ée]|"
                                  r"agenda|rdv|contact)\b", re.I)),
]


def _categorize(path: Path, content_snippet: str) -> str:
    """Retourne la catégorie d'un document selon path + début du contenu."""
    haystack = f"{path} {content_snippet[:500]}"
    for cat, pattern in _CATEGORY_RULES:
        if pattern.search(haystack):
            return cat
    return "autres"


# ── Chunking ───────────────────────────────────────────────────────────────

_CHUNK_TARGET = 500     # caractères
_CHUNK_OVERLAP = 80     # chevauchement pour éviter de couper au milieu d'une idée


def _chunk_text(text: str, target: int = _CHUNK_TARGET,
                 overlap: int = _CHUNK_OVERLAP) -> List[str]:
    """
    Découpe en chunks de ~target chars en privilégiant les coupures sur
    fin de paragraphe / phrase quand possible.
    """
    text = (text or "").strip()
    if not text:
        return []
    if len(text) <= target:
        return [text]

    chunks: List[str] = []
    start = 0
    while start < len(text):
        end = min(start + target, len(text))
        # Préférer couper sur paragraphe / fin phrase si on est proche
        if end < len(text):
            # Chercher \n\n ou .!? dans les 100 derniers chars
            window = text[max(start, end - 100):end]
            for sep in ("\n\n", ". ", "! ", "? ", "\n", ". "):
                idx = window.rfind(sep)
                if idx > 0:
                    end = max(start, end - 100) + idx + len(sep)
                    break
        chunks.append(text[start:end].strip())
        if end == len(text):
            break
        start = max(start + 1, end - overlap)
    return [c for c in chunks if c.strip()]


# ── Extraction du contenu selon type ───────────────────────────────────────

def _max_bytes_indexed() -> int:
    return int(getattr(settings, "index_max_bytes_per_file", 2_000_000) or 2_000_000)


def _extract_text_file(path: Path) -> Tuple[bool, str, str]:
    """Lit un fichier texte en UTF-8 strict. (ok, content, reason)."""
    try:
        size = path.stat().st_size
        if size > _max_bytes_indexed():
            return False, "", f"fichier trop grand: {size} octets"
        return True, path.read_text(encoding="utf-8", errors="replace"), ""
    except (OSError, UnicodeDecodeError) as exc:
        return False, "", str(exc)


def _extract_pdf(path: Path) -> Tuple[bool, str, str]:
    """Extrait le texte d'un PDF via pypdf."""
    if not _PDF_LIB:
        return False, "", "pypdf non installé (pip install pypdf)"
    try:
        size = path.stat().st_size
        if size > _max_bytes_indexed():
            return False, "", f"fichier trop grand: {size} octets"
        reader = pypdf.PdfReader(str(path))
        parts: List[str] = []
        for page in reader.pages:
            try:
                txt = page.extract_text() or ""
                if txt.strip():
                    parts.append(txt)
            except Exception:
                continue
        return True, "\n\n".join(parts), ""
    except Exception as exc:
        return False, "", f"erreur PDF: {exc}"


def _extract(path: Path) -> Tuple[bool, str, str]:
    ext = path.suffix.lower()
    if ext in _PDF_EXTENSIONS:
        return _extract_pdf(path)
    if ext in _TEXT_EXTENSIONS:
        return _extract_text_file(path)
    return False, "", f"extension non indexable: {ext}"


# ── Allowlist & blocklist ──────────────────────────────────────────────────

def _parse_dirs_csv(csv: str) -> List[Path]:
    if not csv:
        return []
    out: List[Path] = []
    for raw in csv.split(","):
        raw = raw.strip()
        if not raw:
            continue
        try:
            out.append(Path(raw).expanduser().resolve(strict=False))
        except Exception:
            continue
    return out


def get_allowed_index_dirs() -> List[Path]:
    csv = getattr(settings, "allowed_index_dirs", "") or ""
    return _parse_dirs_csv(csv)


def _path_allowed(path: Path) -> Tuple[bool, str]:
    """Vérifie qu'un chemin est dans la zone d'indexation autorisée."""
    from app.services.file_search import _is_forbidden_path
    try:
        resolved = Path(path).expanduser().resolve(strict=False)
    except Exception as exc:
        return False, f"path invalide: {exc}"
    if path.is_symlink() if hasattr(path, "is_symlink") else False:
        return False, "symlink refusé"
    if _is_forbidden_path(resolved):
        return False, "chemin système protégé"
    allowed = get_allowed_index_dirs()
    if not allowed:
        return False, "ALLOWED_INDEX_DIRS vide"
    for d in allowed:
        try:
            resolved.relative_to(d)
            return True, ""
        except ValueError:
            continue
    return False, "hors ALLOWED_INDEX_DIRS"


# ── BM25 simplifié ─────────────────────────────────────────────────────────

_TOKEN_RE = re.compile(r"\b\w+\b", re.UNICODE)


def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN_RE.findall(text or "")]


def _bm25_score(query_tokens: List[str], doc_tokens: List[str],
                 avgdl: float, idf: Dict[str, float],
                 k1: float = 1.5, b: float = 0.75) -> float:
    """BM25 classique. avgdl = longueur moyenne des docs."""
    if not query_tokens or not doc_tokens:
        return 0.0
    dl = len(doc_tokens)
    # tf rapide
    tf: Dict[str, int] = {}
    for t in doc_tokens:
        tf[t] = tf.get(t, 0) + 1
    score = 0.0
    for q in query_tokens:
        f = tf.get(q, 0)
        if f == 0:
            continue
        qidf = idf.get(q, 0.5)
        score += qidf * ((f * (k1 + 1)) / (f + k1 * (1 - b + b * (dl / max(avgdl, 1.0)))))
    return score


# ── Statistiques d'utilisation ─────────────────────────────────────────────

def _record_access(db, doc_id: int) -> None:
    """Incrémente le compteur d'accès d'un document."""
    from app.db.models import IndexedDocument
    from datetime import datetime, timezone
    try:
        doc = db.query(IndexedDocument).get(doc_id)
        if doc:
            doc.access_count = (doc.access_count or 0) + 1
            doc.accessed_at = datetime.now(timezone.utc)
            db.commit()
    except Exception:
        db.rollback()


# ── Service principal ─────────────────────────────────────────────────────

@dataclass
class IndexStats:
    documents:        int = 0
    chunks:           int = 0
    by_category:      Optional[Dict[str, int]] = None
    by_extension:     Optional[Dict[str, int]] = None
    embedding_status: Optional[Dict[str, Any]] = None
    last_indexed_at:  Optional[float] = None


class SemanticIndex:
    """
    Service singleton — pas d'état partagé entre threads sauf via DB.
    Toutes les méthodes prennent une session DB en paramètre.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # Cache IDF léger pour BM25 — recalculé périodiquement
        self._idf_cache: Optional[Dict[str, float]] = None
        self._avgdl_cache: float = 0.0
        self._idf_cache_at: float = 0.0
        self.IDF_CACHE_TTL = 300.0   # 5 min

    # ── Indexation ────────────────────────────────────────────────────────

    def index_file(self, db, file_path: str, *, force: bool = False) -> Dict[str, Any]:
        """
        Indexe (ou ré-indexe) un fichier unique.
        Détection incrémentale via hash : si hash inchangé et !force → skip.
        """
        from app.db.models import IndexedDocument, IndexedChunk
        from app.services.embedding_client import get_embedding_client, vec_to_bytes

        path = Path(file_path).expanduser()
        ok, reason = _path_allowed(path)
        if not ok:
            return {"ok": False, "reason": reason, "path": str(path)}

        if not path.exists() or not path.is_file():
            return {"ok": False, "reason": "fichier inexistant", "path": str(path)}

        ext = path.suffix.lower()
        if ext not in _INDEXABLE:
            return {"ok": False, "reason": f"extension non indexable: {ext}",
                    "path": str(path)}

        # Extraire
        ok, content, ext_reason = _extract(path)
        if not ok:
            return {"ok": False, "reason": ext_reason, "path": str(path)}

        # Hash
        content_hash = hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()
        size = path.stat().st_size
        source_path = str(path.resolve())

        # Existe déjà ?
        existing = db.query(IndexedDocument).filter_by(source_path=source_path).first()
        if existing and existing.content_hash == content_hash and not force:
            return {
                "ok": True, "skipped": True, "reason": "hash inchangé",
                "document_id": existing.id, "chunks": existing.chunk_count,
            }

        # Catégorisation
        category = _categorize(path, content[:1000])

        # Chunking
        chunks = _chunk_text(content)
        if not chunks:
            return {"ok": False, "reason": "contenu vide après extraction",
                    "path": str(path)}

        # Embeddings (best-effort)
        emb_client = get_embedding_client()
        embeddings: List[Optional[np.ndarray]] = [None] * len(chunks)
        if emb_client.is_available():
            embeddings = emb_client.embed_many(chunks)
        dim = next((e.shape[0] for e in embeddings if e is not None), 0)

        # Upsert document
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        if existing:
            existing.title = path.name
            existing.extension = ext
            existing.category = category
            existing.size_bytes = size
            existing.content_hash = content_hash
            existing.chunk_count = len(chunks)
            existing.indexed_at = now
            # Effacer les anciens chunks
            db.query(IndexedChunk).filter_by(document_id=existing.id).delete()
            doc = existing
        else:
            doc = IndexedDocument(
                source_type="file",
                source_path=source_path,
                title=path.name,
                extension=ext,
                category=category,
                size_bytes=size,
                content_hash=content_hash,
                chunk_count=len(chunks),
                indexed_at=now,
                accessed_at=now,
                access_count=0,
            )
            db.add(doc)
            db.flush()  # pour récupérer doc.id

        # Insérer chunks
        for i, (text, vec) in enumerate(zip(chunks, embeddings)):
            chunk = IndexedChunk(
                document_id=doc.id, chunk_index=i, content=text,
                embedding=vec_to_bytes(vec) if vec is not None else b"",
                embedding_dim=int(vec.shape[0]) if vec is not None else 0,
            )
            db.add(chunk)

        db.commit()
        # Invalider cache IDF
        self._idf_cache = None
        return {
            "ok": True, "document_id": doc.id, "chunks": len(chunks),
            "category": category, "size_bytes": size,
            "has_embeddings": dim > 0, "embedding_dim": dim,
        }

    def index_directory(self, db, root: str, *, force: bool = False,
                         max_files: int = 500) -> Dict[str, Any]:
        """Indexe tout le contenu indexable d'un dossier (récursif)."""
        from app.services.file_search import _is_forbidden_path
        root_path = Path(root).expanduser().resolve(strict=False)
        ok, reason = _path_allowed(root_path)
        if not ok:
            return {"ok": False, "reason": reason, "root": str(root_path)}
        if not root_path.is_dir():
            return {"ok": False, "reason": "non un dossier", "root": str(root_path)}

        indexed = 0; skipped = 0; failed = 0; details: List[Dict[str, Any]] = []
        for dirpath, dirnames, filenames in os.walk(root_path, followlinks=False):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")
                            and not _is_forbidden_path(Path(dirpath) / d)]
            for fn in filenames:
                if fn.startswith("."):
                    continue
                p = Path(dirpath) / fn
                if p.suffix.lower() not in _INDEXABLE:
                    continue
                if indexed + skipped + failed >= max_files:
                    break
                r = self.index_file(db, str(p), force=force)
                if r.get("ok"):
                    if r.get("skipped"):
                        skipped += 1
                    else:
                        indexed += 1
                else:
                    failed += 1
                # ne stocker que les échecs pour debug
                if not r.get("ok"):
                    details.append({"path": str(p), "reason": r.get("reason", "?")})
            if indexed + skipped + failed >= max_files:
                break
        return {
            "ok": True, "root": str(root_path),
            "indexed": indexed, "skipped": skipped, "failed": failed,
            "failures_sample": details[:10],
        }

    def remove_missing(self, db) -> Dict[str, Any]:
        """Supprime de l'index les documents dont le fichier source n'existe plus."""
        from app.db.models import IndexedDocument, IndexedChunk
        removed = 0
        for doc in db.query(IndexedDocument).filter_by(source_type="file").all():
            p = Path(doc.source_path)
            if not p.exists():
                db.query(IndexedChunk).filter_by(document_id=doc.id).delete()
                db.delete(doc)
                removed += 1
        db.commit()
        if removed > 0:
            self._idf_cache = None
        return {"ok": True, "removed": removed}

    # ── Recherche ────────────────────────────────────────────────────────

    def _build_idf(self, db) -> Tuple[Dict[str, float], float]:
        """(Re)construit le cache IDF + avgdl pour BM25."""
        from app.db.models import IndexedChunk
        if (self._idf_cache is not None
            and (time.time() - self._idf_cache_at) < self.IDF_CACHE_TTL):
            return self._idf_cache, self._avgdl_cache

        df: Dict[str, int] = {}
        n_docs = 0
        total_len = 0
        for chunk in db.query(IndexedChunk).all():
            tokens = set(_tokenize(chunk.content))
            for t in tokens:
                df[t] = df.get(t, 0) + 1
            n_docs += 1
            total_len += len(_tokenize(chunk.content))

        if n_docs == 0:
            self._idf_cache = {}
            self._avgdl_cache = 1.0
            self._idf_cache_at = time.time()
            return {}, 1.0

        idf = {t: max(0.0, np.log((n_docs - c + 0.5) / (c + 0.5) + 1.0))
                for t, c in df.items()}
        avgdl = total_len / max(n_docs, 1)
        self._idf_cache = idf
        self._avgdl_cache = avgdl
        self._idf_cache_at = time.time()
        return idf, avgdl

    def search(self, db, query: str, *, k: int = 5,
                semantic_weight: float = 0.6,
                category: Optional[str] = None) -> Dict[str, Any]:
        """
        Recherche hybride sémantique + lexicale.
        Retourne {"results": [{document_id, title, score, ...}], ...}.
        """
        from app.db.models import IndexedDocument, IndexedChunk
        from app.services.embedding_client import (
            get_embedding_client, bytes_to_vec, cosine_similarity,
        )

        q = (query or "").strip()
        if not q:
            return {"ok": False, "reason": "query vide", "results": []}

        # Lexical (toujours)
        idf, avgdl = self._build_idf(db)
        q_tokens = _tokenize(q)

        # Semantic (si dispo)
        emb_client = get_embedding_client()
        q_vec = emb_client.embed(q) if emb_client.is_available() else None
        use_semantic = q_vec is not None

        # Scores par chunk
        chunk_scores: List[Tuple[int, int, float, float, str]] = []
        # ^ (doc_id, chunk_id, sem_score, lex_score, preview)
        query_chunks_iter: Iterable[IndexedChunk]
        if category:
            doc_ids = [d.id for d in
                        db.query(IndexedDocument).filter_by(category=category).all()]
            if not doc_ids:
                return {"ok": True, "results": [], "use_semantic": use_semantic}
            query_chunks_iter = db.query(IndexedChunk).filter(
                IndexedChunk.document_id.in_(doc_ids)
            )
        else:
            query_chunks_iter = db.query(IndexedChunk)

        for chunk in query_chunks_iter:
            tokens = _tokenize(chunk.content)
            lex = _bm25_score(q_tokens, tokens, avgdl, idf)
            sem = 0.0
            if use_semantic and chunk.embedding_dim > 0:
                v = bytes_to_vec(chunk.embedding, chunk.embedding_dim)
                if v is not None:
                    sem = max(0.0, cosine_similarity(q_vec, v))
            chunk_scores.append((chunk.document_id, chunk.id, sem, lex,
                                   chunk.content[:300]))

        if not chunk_scores:
            return {"ok": True, "results": [], "use_semantic": use_semantic}

        # Normaliser lexical pour combinaison
        max_lex = max((s[3] for s in chunk_scores), default=1.0) or 1.0
        normalized = [
            (doc_id, chunk_id,
              semantic_weight * sem + (1 - semantic_weight) * (lex / max_lex),
              sem, lex, preview)
            for doc_id, chunk_id, sem, lex, preview in chunk_scores
        ]

        # Agrégation par document : prendre le meilleur chunk
        by_doc: Dict[int, Tuple[float, float, float, str, int]] = {}
        # doc_id → (combined, sem, lex, preview, chunk_id)
        for doc_id, chunk_id, combined, sem, lex, preview in normalized:
            cur = by_doc.get(doc_id)
            if cur is None or combined > cur[0]:
                by_doc[doc_id] = (combined, sem, lex, preview, chunk_id)

        top = sorted(by_doc.items(), key=lambda x: x[1][0], reverse=True)[:k]

        results = []
        for doc_id, (combined, sem, lex, preview, chunk_id) in top:
            doc = db.query(IndexedDocument).get(doc_id)
            if not doc:
                continue
            results.append({
                "document_id": doc.id,
                "source_path": doc.source_path,
                "title":       doc.title,
                "category":    doc.category,
                "extension":   doc.extension,
                "score":       round(combined, 4),
                "semantic":    round(sem, 4),
                "lexical":     round(lex, 4),
                "preview":     preview,
                "best_chunk":  chunk_id,
            })

        return {
            "ok": True,
            "query": q,
            "use_semantic": use_semantic,
            "results": results,
        }

    # ── Stats / inventaire ───────────────────────────────────────────────

    def stats(self, db) -> Dict[str, Any]:
        from app.db.models import IndexedDocument, IndexedChunk
        from app.services.embedding_client import get_embedding_client
        st = IndexStats()
        st.documents = db.query(IndexedDocument).count()
        st.chunks = db.query(IndexedChunk).count()
        cat: Dict[str, int] = {}
        for c, in db.query(IndexedDocument.category).all():
            cat[c] = cat.get(c, 0) + 1
        st.by_category = cat
        ext: Dict[str, int] = {}
        for e, in db.query(IndexedDocument.extension).all():
            ext[e] = ext.get(e, 0) + 1
        st.by_extension = ext
        last = db.query(IndexedDocument).order_by(
            IndexedDocument.indexed_at.desc()).first()
        if last:
            st.last_indexed_at = last.indexed_at.timestamp()
        emb_status = get_embedding_client().get_status()
        st.embedding_status = asdict(emb_status)
        return asdict(st)

    def recent(self, db, *, limit: int = 20) -> List[Dict[str, Any]]:
        """Fichiers récemment consultés (selon accessed_at + access_count)."""
        from app.db.models import IndexedDocument
        docs = db.query(IndexedDocument).order_by(
            IndexedDocument.accessed_at.desc()).limit(limit).all()
        return [{
            "id":             d.id,
            "title":          d.title,
            "source_path":    d.source_path,
            "category":       d.category,
            "access_count":   d.access_count,
            "accessed_at":    d.accessed_at.timestamp() if d.accessed_at else None,
            "indexed_at":     d.indexed_at.timestamp() if d.indexed_at else None,
        } for d in docs]


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[SemanticIndex] = None
_singleton_lock = threading.Lock()


def get_semantic_index() -> SemanticIndex:
    global _instance
    if _instance is None:
        with _singleton_lock:
            if _instance is None:
                _instance = SemanticIndex()
    return _instance
