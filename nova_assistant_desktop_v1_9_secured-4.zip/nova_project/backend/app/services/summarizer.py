"""
summarizer.py — Résumés automatiques via Ollama (v1.9.8).

Génère des résumés courts pour :
    - un fichier indexé (par document_id)
    - un dossier (concaténation des résumés des fichiers contenus, plafonné)
    - une conversation (par conversation_id, via les messages stockés)

Le résumé est mis en cache dans IndexedDocument.summary pour éviter de
rappeler le LLM à chaque fois. Invalidé si content_hash change.

LIMITES HONNÊTES :
    - Un résumé via llama3.2:3b prend 5-30 secondes sur CPU. Donc :
      → Toujours déclenché par l'utilisateur, jamais en boucle.
      → Plafonné : un contenu > 8 Ko est tronqué pour éviter d'exploser
        le contexte du modèle.
    - Si Ollama n'est pas joignable → retour "summary indisponible" honnête.
"""

from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from app.config import settings
from app.utils.logger import get_logger

logger = get_logger("summarizer")

try:
    import ollama  # type: ignore
    _OLLAMA_LIB = True
except Exception:
    ollama = None
    _OLLAMA_LIB = False


# ── Prompts ────────────────────────────────────────────────────────────────

_FILE_SUMMARY_PROMPT = (
    "Tu es Nova, assistant local d'Oli. Résume le texte ci-dessous en 3-5 phrases "
    "courtes, en français, factuel, sans paraphrase ni listes à puces. "
    "Mets en avant : sujet principal, données clés, intentions ou conclusions.\n\n"
    "TEXTE :\n{content}\n\nRÉSUMÉ :"
)

_CONVERSATION_SUMMARY_PROMPT = (
    "Voici les messages d'une conversation. Résume-la en 3 phrases : sujet, "
    "décisions, et prochaines actions s'il y en a. Français, factuel.\n\n"
    "{content}\n\nRÉSUMÉ :"
)

_FOLDER_SUMMARY_PROMPT = (
    "Voici les résumés courts de plusieurs fichiers d'un même dossier. "
    "Donne un résumé global en 4-6 phrases : nature du dossier, thèmes "
    "communs, état d'avancement perçu.\n\n{content}\n\nRÉSUMÉ :"
)


# ── Helpers ────────────────────────────────────────────────────────────────

_MAX_INPUT_CHARS = 8000     # plafond pour ne pas exploser le contexte
_MAX_OUTPUT_TOKENS = 250


def _truncate(text: str, max_chars: int = _MAX_INPUT_CHARS) -> str:
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 200] + "\n\n[...contenu tronqué...]\n\n" + text[-200:]


@dataclass
class SummaryResult:
    ok:        bool
    summary:   str = ""
    elapsed_ms: int = 0
    reason:    str = ""
    cached:    bool = False
    model:     str = ""


class Summarizer:
    """Singleton thread-safe pour générer des résumés via Ollama."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        configured = getattr(settings, "summary_model", "") or ""
        self._model = configured.strip() or getattr(settings, "llm_model", "llama3.2:3b")

    @property
    def model(self) -> str:
        return self._model

    # ── Appel bas niveau ─────────────────────────────────────────────────

    def _call_llm(self, prompt: str) -> SummaryResult:
        if not _OLLAMA_LIB:
            return SummaryResult(False, reason="lib 'ollama' non installée",
                                  model=self._model)
        t0 = time.perf_counter()
        try:
            r = ollama.generate(
                model=self._model, prompt=prompt,
                options={"num_predict": _MAX_OUTPUT_TOKENS, "temperature": 0.2},
                stream=False,
            )
            out = (r.get("response") or "").strip()
            elapsed = int((time.perf_counter() - t0) * 1000)
            if not out:
                return SummaryResult(False, reason="réponse LLM vide",
                                      elapsed_ms=elapsed, model=self._model)
            return SummaryResult(True, summary=out,
                                  elapsed_ms=elapsed, model=self._model)
        except Exception as exc:
            elapsed = int((time.perf_counter() - t0) * 1000)
            return SummaryResult(False, reason=f"Ollama erreur: {exc}",
                                  elapsed_ms=elapsed, model=self._model)

    # ── Résumé d'un fichier indexé (avec cache DB) ───────────────────────

    def summarize_document(self, db, document_id: int,
                            *, force: bool = False) -> SummaryResult:
        from app.db.models import IndexedDocument, IndexedChunk
        doc = db.query(IndexedDocument).get(document_id)
        if not doc:
            return SummaryResult(False, reason="document inconnu", model=self._model)

        # Cache : si résumé déjà présent et !force, on retourne
        if doc.summary and not force:
            return SummaryResult(
                True, summary=doc.summary, cached=True, model=self._model,
            )

        # Reconstituer le contenu via les chunks
        chunks = db.query(IndexedChunk).filter_by(
            document_id=document_id).order_by(IndexedChunk.chunk_index).all()
        if not chunks:
            return SummaryResult(False, reason="aucun chunk", model=self._model)
        content = "\n".join(c.content for c in chunks)
        content = _truncate(content)

        prompt = _FILE_SUMMARY_PROMPT.format(content=content)
        res = self._call_llm(prompt)

        if res.ok:
            from datetime import datetime, timezone
            try:
                doc.summary = res.summary
                doc.summary_at = datetime.now(timezone.utc)
                db.commit()
            except Exception:
                db.rollback()
        return res

    # ── Résumé d'un dossier ──────────────────────────────────────────────

    def summarize_folder(self, db, folder_path: str,
                          *, max_files: int = 20) -> SummaryResult:
        """Résumé de second niveau : agrège les résumés des fichiers."""
        from app.db.models import IndexedDocument
        from app.services.semantic_index import _path_allowed
        from pathlib import Path as _P

        path = _P(folder_path).expanduser().resolve(strict=False)
        ok, reason = _path_allowed(path)
        if not ok:
            return SummaryResult(False, reason=reason, model=self._model)

        # Chercher tous les docs dont source_path commence par folder/
        like_pattern = str(path) + os.sep + "%"
        docs = (db.query(IndexedDocument)
                  .filter(IndexedDocument.source_path.like(like_pattern))
                  .filter_by(source_type="file")
                  .limit(max_files).all())
        if not docs:
            return SummaryResult(False,
                                  reason="aucun document indexé dans ce dossier",
                                  model=self._model)

        # S'assurer que chaque doc a son résumé
        summaries: List[str] = []
        for d in docs:
            if not d.summary:
                sub = self.summarize_document(db, d.id)
                if sub.ok:
                    summaries.append(f"- {d.title}: {sub.summary}")
            else:
                summaries.append(f"- {d.title}: {d.summary}")

        if not summaries:
            return SummaryResult(False, reason="aucun résumé disponible",
                                  model=self._model)

        content = "\n".join(summaries)[:_MAX_INPUT_CHARS]
        return self._call_llm(_FOLDER_SUMMARY_PROMPT.format(content=content))

    # ── Résumé d'une conversation ────────────────────────────────────────

    def summarize_conversation(self, db, conversation_id: int) -> SummaryResult:
        from app.db.models import Conversation, Message
        conv = db.query(Conversation).get(conversation_id)
        if not conv:
            return SummaryResult(False, reason="conversation inconnue",
                                  model=self._model)

        # Cache : si la conversation a déjà un summary, on le réutilise
        # mais pas d'âge max ici (la consigne ne précise pas)
        if conv.summary:
            return SummaryResult(True, summary=conv.summary, cached=True,
                                  model=self._model)

        msgs = (db.query(Message)
                  .filter_by(conversation_id=conversation_id)
                  .order_by(Message.id).all())
        if not msgs:
            return SummaryResult(False, reason="conversation vide",
                                  model=self._model)
        lines = [f"{m.role.upper()}: {m.content[:500]}" for m in msgs]
        content = _truncate("\n".join(lines))
        res = self._call_llm(_CONVERSATION_SUMMARY_PROMPT.format(content=content))
        if res.ok:
            try:
                conv.summary = res.summary
                db.commit()
            except Exception:
                db.rollback()
        return res


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[Summarizer] = None
_lock = threading.Lock()


def get_summarizer() -> Summarizer:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = Summarizer()
    return _instance
