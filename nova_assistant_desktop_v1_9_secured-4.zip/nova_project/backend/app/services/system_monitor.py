"""
system_monitor.py — Surveillance système longue durée.

Mesure périodique via psutil :
    - CPU (%, par cœur, fréquence)
    - RAM (%, used, available)
    - Disques (%, par partition)
    - Réseau (envoyé/reçu, par interface)
    - Processus (top N par CPU/RAM, count total)
    - Optionnel : GPU et température (si dispo)

Architecture :
    - Thread dédié, intervalle configurable
    - Snapshots gardés en mémoire (deque, capé)
    - Publie sur le CORE via orchestrator.submit_event()
    - Seuils configurables → events HIGH/CRITICAL
    - Anti-flap : cooldown automatique via le bus

Conception longue durée :
    - Pas de fuite mémoire (deque capée)
    - Try/except sur chaque mesure (psutil peut lever sur certains OS)
    - Thread daemon, arrêt propre via stop_event
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from typing import Any, Deque, Dict, List, Optional

try:
    import psutil
    _PSUTIL_OK = True
except ImportError:
    psutil = None  # type: ignore
    _PSUTIL_OK = False

from app.utils.logger import get_logger

logger = get_logger("system_monitor")


@dataclass
class SystemSnapshot:
    """Instantané système à un moment donné."""
    timestamp:        float
    cpu_percent:      float
    cpu_count:        int
    cpu_per_core:     List[float]
    cpu_freq_mhz:     Optional[float]
    ram_percent:      float
    ram_used_mb:      float
    ram_available_mb: float
    swap_percent:     float
    disk_usage:       Dict[str, Dict[str, Any]]  # par mountpoint
    net_io:           Dict[str, Any]
    process_count:    int
    top_processes:    List[Dict[str, Any]]
    boot_time:        float
    uptime_sec:       float
    # Optionnels — None si non dispo sur la plateforme
    temperatures:     Optional[Dict[str, List[Dict[str, float]]]] = None
    gpu:              Optional[List[Dict[str, Any]]] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# Seuils par défaut (modifiables via SystemMonitor.set_thresholds())
DEFAULT_THRESHOLDS = {
    "cpu_high":      80.0,    # %
    "cpu_critical":  95.0,
    "ram_high":      85.0,
    "ram_critical":  95.0,
    "disk_high":     85.0,
    "disk_critical": 95.0,
    "swap_high":     50.0,
}


class SystemMonitor:
    """
    Thread de surveillance système avec publication CORE.

    Cycle de vie :
        sm.start()                 # démarre le thread
        sm.get_latest()            # dernier snapshot
        sm.get_history(50)         # historique
        sm.set_thresholds(...)     # ajuster
        sm.stop()                  # arrêt propre
    """

    def __init__(
        self,
        interval_sec: float = 5.0,
        history_size: int = 720,         # 1h à 5s/sample
        top_n_processes: int = 5,
    ) -> None:
        self._interval = float(max(1.0, interval_sec))
        self._top_n = int(max(0, top_n_processes))
        self._history: Deque[SystemSnapshot] = deque(maxlen=history_size)
        self._thresholds = dict(DEFAULT_THRESHOLDS)
        self._latest: Optional[SystemSnapshot] = None
        # Dernier net_io pour calcul delta
        self._last_net_counters: Optional[Any] = None
        self._last_net_time: Optional[float] = None
        # Thread
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._lock = threading.RLock()
        # États précédents pour transitions (ex: passe HIGH → CRITICAL)
        self._last_levels: Dict[str, str] = {}

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def start(self) -> bool:
        if not _PSUTIL_OK:
            logger.warning("[SYSMON] psutil indisponible — surveillance désactivée")
            return False
        with self._lock:
            if self._thread and self._thread.is_alive():
                return True
            self._stop.clear()
            self._thread = threading.Thread(
                target=self._loop, name="nova-sysmon", daemon=True,
            )
            self._thread.start()
        logger.info("[SYSMON] démarré | interval=%.1fs", self._interval)
        # Prime cpu_percent (premier appel renvoie 0.0)
        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass
        return True

    def stop(self) -> None:
        self._stop.set()
        thread = self._thread
        if thread:
            thread.join(timeout=self._interval + 2.0)
        logger.info("[SYSMON] arrêté")

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # ── Boucle de mesure ──────────────────────────────────────────────────

    def _loop(self) -> None:
        # Cadences indépendantes — pour éviter de scanner trop souvent
        last_security_scan = 0.0
        SECURITY_SCAN_INTERVAL = 30.0   # toutes les 30s
        last_startup_scan = 0.0
        STARTUP_SCAN_INTERVAL = 300.0   # toutes les 5min (registre = lent)
        last_files_scan = 0.0
        FILES_SCAN_INTERVAL = 120.0     # toutes les 2min

        while not self._stop.is_set():
            t0 = time.perf_counter()
            try:
                snap = self._take_snapshot()
                with self._lock:
                    self._latest = snap
                    self._history.append(snap)
                self._publish_if_needed(snap)
            except Exception as exc:
                logger.error("[SYSMON] erreur cycle snapshot : %s", exc)

            # Surveillances sécurité (cadences plus lentes pour ne pas noyer)
            now = time.time()
            if now - last_security_scan >= SECURITY_SCAN_INTERVAL:
                last_security_scan = now
                self._run_security_scans()
            if now - last_startup_scan >= STARTUP_SCAN_INTERVAL:
                last_startup_scan = now
                self._run_startup_scan()
            if now - last_files_scan >= FILES_SCAN_INTERVAL:
                last_files_scan = now
                self._run_suspicious_files_scan()

            elapsed = time.perf_counter() - t0
            wait = max(0.0, self._interval - elapsed)
            self._stop.wait(wait)

    def _run_security_scans(self) -> None:
        """Scans rapides : process diff, network, devices. Try/except chacun."""
        try:
            from app.services.security_watch import (
                get_process_watcher, get_network_watcher, get_device_watcher,
            )
            try:
                get_process_watcher().scan()
            except Exception as exc:
                logger.debug("[SYSMON] process scan: %s", exc)
            try:
                get_network_watcher().scan()
            except Exception as exc:
                logger.debug("[SYSMON] network scan: %s", exc)
            try:
                get_device_watcher().scan()
            except Exception as exc:
                logger.debug("[SYSMON] device scan: %s", exc)
        except ImportError:
            pass

    def _run_startup_scan(self) -> None:
        try:
            from app.services.security_watch import get_startup_watcher
            get_startup_watcher().scan()
        except Exception as exc:
            logger.debug("[SYSMON] startup scan: %s", exc)

    def _run_suspicious_files_scan(self) -> None:
        try:
            from app.services.security_watch import get_suspicious_file_watcher
            get_suspicious_file_watcher().scan()
        except Exception as exc:
            logger.debug("[SYSMON] suspicious files scan: %s", exc)

    # ── Snapshot ──────────────────────────────────────────────────────────

    def _take_snapshot(self) -> SystemSnapshot:
        """Capture l'état système. Robuste : chaque sous-mesure protégée."""
        now = time.time()

        # CPU
        try:
            cpu_pct = psutil.cpu_percent(interval=None)
        except Exception:
            cpu_pct = 0.0
        try:
            cpu_per_core = list(psutil.cpu_percent(interval=None, percpu=True))
        except Exception:
            cpu_per_core = []
        try:
            cpu_count = psutil.cpu_count(logical=True) or 1
        except Exception:
            cpu_count = 1
        try:
            freq = psutil.cpu_freq()
            cpu_freq_mhz = float(freq.current) if freq else None
        except Exception:
            cpu_freq_mhz = None

        # RAM
        try:
            vm = psutil.virtual_memory()
            ram_pct = vm.percent
            ram_used_mb = vm.used / (1024 * 1024)
            ram_available_mb = vm.available / (1024 * 1024)
        except Exception:
            ram_pct = 0.0
            ram_used_mb = 0.0
            ram_available_mb = 0.0
        try:
            swap = psutil.swap_memory()
            swap_pct = swap.percent
        except Exception:
            swap_pct = 0.0

        # Disque
        disk_usage: Dict[str, Dict[str, Any]] = {}
        try:
            for part in psutil.disk_partitions(all=False):
                # Skip CD-ROM vides, network drives non montés
                if part.fstype in ("", "squashfs"):
                    continue
                try:
                    u = psutil.disk_usage(part.mountpoint)
                    disk_usage[part.mountpoint] = {
                        "device":  part.device,
                        "fstype":  part.fstype,
                        "percent": u.percent,
                        "total_gb": round(u.total / (1024**3), 2),
                        "used_gb":  round(u.used  / (1024**3), 2),
                        "free_gb":  round(u.free  / (1024**3), 2),
                    }
                except (PermissionError, OSError):
                    continue
        except Exception:
            pass

        # Réseau (delta depuis dernier sample)
        net_io: Dict[str, Any] = {"sent_kbs": 0.0, "recv_kbs": 0.0, "total_bytes_sent": 0, "total_bytes_recv": 0}
        try:
            cur = psutil.net_io_counters()
            if self._last_net_counters is not None and self._last_net_time is not None:
                dt = max(0.001, now - self._last_net_time)
                sent_delta = cur.bytes_sent - self._last_net_counters.bytes_sent
                recv_delta = cur.bytes_recv - self._last_net_counters.bytes_recv
                net_io["sent_kbs"] = round(max(0, sent_delta) / 1024 / dt, 2)
                net_io["recv_kbs"] = round(max(0, recv_delta) / 1024 / dt, 2)
            net_io["total_bytes_sent"] = int(cur.bytes_sent)
            net_io["total_bytes_recv"] = int(cur.bytes_recv)
            self._last_net_counters = cur
            self._last_net_time = now
        except Exception:
            pass

        # Processus
        process_count = 0
        top_processes: List[Dict[str, Any]] = []
        try:
            procs = []
            for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
                try:
                    procs.append(p.info)
                except Exception:
                    continue
            process_count = len(procs)
            if self._top_n > 0:
                procs.sort(key=lambda p: p.get("cpu_percent") or 0.0, reverse=True)
                top_processes = [
                    {
                        "pid":     int(p.get("pid") or 0),
                        "name":    str(p.get("name") or "?"),
                        "cpu":     round(float(p.get("cpu_percent") or 0.0), 1),
                        "mem":     round(float(p.get("memory_percent") or 0.0), 1),
                    }
                    for p in procs[:self._top_n]
                ]
        except Exception:
            pass

        # Boot time + uptime
        try:
            boot_time = float(psutil.boot_time())
            uptime_sec = max(0.0, now - boot_time)
        except Exception:
            boot_time = 0.0
            uptime_sec = 0.0

        # Températures (souvent vide sur Windows sans drivers spécifiques)
        temperatures = None
        try:
            if hasattr(psutil, "sensors_temperatures"):
                raw = psutil.sensors_temperatures()
                if raw:
                    temperatures = {
                        name: [
                            {"label": s.label or "", "current": s.current,
                             "high": s.high, "critical": s.critical}
                            for s in sensors
                        ]
                        for name, sensors in raw.items()
                    }
        except Exception:
            temperatures = None

        return SystemSnapshot(
            timestamp=now,
            cpu_percent=cpu_pct, cpu_count=cpu_count,
            cpu_per_core=cpu_per_core, cpu_freq_mhz=cpu_freq_mhz,
            ram_percent=ram_pct, ram_used_mb=round(ram_used_mb, 1),
            ram_available_mb=round(ram_available_mb, 1),
            swap_percent=swap_pct,
            disk_usage=disk_usage, net_io=net_io,
            process_count=process_count, top_processes=top_processes,
            boot_time=boot_time, uptime_sec=uptime_sec,
            temperatures=temperatures,
            gpu=None,    # nécessite GPUtil/pynvml externe — laissé None
        )

    # ── Détection seuils + publication CORE ───────────────────────────────

    def _publish_if_needed(self, snap: SystemSnapshot) -> None:
        """Émet un event CORE si un seuil est franchi."""
        # CPU
        self._check_metric("cpu", snap.cpu_percent,
                           self._thresholds["cpu_high"],
                           self._thresholds["cpu_critical"],
                           snap)
        # RAM
        self._check_metric("ram", snap.ram_percent,
                           self._thresholds["ram_high"],
                           self._thresholds["ram_critical"],
                           snap)
        # Swap
        if snap.swap_percent >= self._thresholds["swap_high"]:
            self._emit_event(
                "system.swap_high", "high" if snap.swap_percent < 90 else "critical",
                f"Swap élevé : {snap.swap_percent:.0f}%",
                {"swap_percent": snap.swap_percent},
            )
        # Disque par partition
        for mp, info in snap.disk_usage.items():
            self._check_metric(
                f"disk:{mp}", info["percent"],
                self._thresholds["disk_high"],
                self._thresholds["disk_critical"],
                snap, extra={"mountpoint": mp, "free_gb": info["free_gb"]},
            )

    def _check_metric(
        self, name: str, value: float, high: float, critical: float,
        snap: SystemSnapshot, extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        level = "info"
        if value >= critical:
            level = "critical"
        elif value >= high:
            level = "high"
        prev = self._last_levels.get(name, "info")
        if level == "info" and prev != "info":
            # Retour à la normale → low-level event
            self._emit_event(
                f"system.{name.split(':')[0]}_normal", "info",
                f"{name} revenu normal : {value:.0f}%",
                {"metric": name, "value": value, **(extra or {})},
            )
            self._last_levels[name] = level
            return
        if level == "info":
            return
        # Émettre seulement à la transition (anti-spam)
        if level != prev:
            self._emit_event(
                f"system.{name.split(':')[0]}_{level}", level,
                f"{name} {level} : {value:.0f}%",
                {"metric": name, "value": value, "threshold": high if level == "high" else critical,
                 **(extra or {})},
            )
        self._last_levels[name] = level

    def _emit_event(self, type_: str, level_str: str, message: str, payload: Dict[str, Any]) -> None:
        """Publie via le CORE (point d'entrée unique)."""
        try:
            # Import tardif : éviter cycle
            from app.core.event_bus import CoreEvent, EventLevel
            from app.core.orchestrator import orchestrator
            level_map = {
                "info":     EventLevel.INFO,
                "low":      EventLevel.LOW,
                "medium":   EventLevel.MEDIUM,
                "high":     EventLevel.HIGH,
                "critical": EventLevel.CRITICAL,
            }
            orchestrator.submit_event(CoreEvent(
                type=type_, source="system_monitor",
                level=level_map.get(level_str, EventLevel.INFO),
                message=message, payload=payload,
            ))
        except Exception as exc:
            logger.debug("[SYSMON] CORE submit skipped: %s", exc)

    # ── API publique ───────────────────────────────────────────────────────

    def get_latest(self) -> Optional[Dict[str, Any]]:
        with self._lock:
            return self._latest.to_dict() if self._latest else None

    def get_history(self, limit: int = 60) -> List[Dict[str, Any]]:
        with self._lock:
            items = list(self._history)
        return [s.to_dict() for s in items[-limit:]]

    def set_thresholds(self, **kwargs) -> Dict[str, float]:
        with self._lock:
            for k, v in kwargs.items():
                if k in self._thresholds:
                    self._thresholds[k] = float(v)
            return dict(self._thresholds)

    def get_thresholds(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._thresholds)


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[SystemMonitor] = None
_inst_lock = threading.Lock()


def get_system_monitor() -> SystemMonitor:
    global _instance
    if _instance is None:
        with _inst_lock:
            if _instance is None:
                _instance = SystemMonitor()
    return _instance
