"""
tts_streaming.py — Interface pour TTS LOCAL STREAMING (Phase B, non actif).

STATUT v1.9.9 : interface uniquement. Aucun moteur réel branché par défaut.
Le TTS courant reste pyttsx3 (synchrone, voix système).

But :
    Permettre à Oli d'installer plus tard piper-tts sans changer le code coeur.

Différence essentielle avec pyttsx3 :
    pyttsx3            : synchrone, bloquant, voix système Windows.
                          → Latence : la phrase entière doit être synthétisée
                            avant le premier son.
    StreamingTTSEngine : asynchrone, yield des chunks audio par phrase.
                          → Premier son audible en ~200-500 ms.

Engine attendu (à implémenter par dépendance native) :
    class MyPiperEngine(StreamingTTSEngine):
        def is_available(self) -> bool: ...
        def synthesize_stream(self, text: str) -> Iterator[bytes]:
            # yield des chunks WAV/PCM

Côté Oli, pour activer plus tard :
    1. pip install piper-tts
    2. Télécharger un modèle FR (~50 Mo, ex: fr_FR-siwis-medium)
    3. Implémenter MyPiperEngine
    4. set_engine(MyPiperEngine())

Aucune dépendance ne sera ajoutée par défaut.
"""

from __future__ import annotations

import abc
import threading
from dataclasses import dataclass
from typing import Iterator, Optional

from app.utils.logger import get_logger

logger = get_logger("tts_streaming")


@dataclass
class StreamingTTSStatus:
    available:   bool
    engine_name: str = ""
    sample_rate: int = 22050
    reason:      str = ""


class StreamingTTSEngine(abc.ABC):
    """Interface qu'un moteur réel (Piper) doit implémenter."""

    @property
    @abc.abstractmethod
    def name(self) -> str: ...

    @property
    def sample_rate(self) -> int:
        return 22050

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def synthesize_stream(self, text: str) -> Iterator[bytes]:
        """
        Synthèse en streaming. Yield des chunks PCM 16-bit mono.
        L'appelant peut envoyer chaque chunk au navigateur en temps réel.
        """


class _NoopStreamingTTS(StreamingTTSEngine):
    @property
    def name(self) -> str:
        return "noop"

    def is_available(self) -> bool:
        return False

    def synthesize_stream(self, text: str) -> Iterator[bytes]:
        return iter([])


class StreamingTTSService:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._engine: StreamingTTSEngine = _NoopStreamingTTS()

    def set_engine(self, engine: StreamingTTSEngine) -> None:
        with self._lock:
            self._engine = engine
            logger.info("[TTS_STREAM] engine = %s (available=%s)",
                          engine.name, engine.is_available())

    def get_status(self) -> StreamingTTSStatus:
        with self._lock:
            e = self._engine
        return StreamingTTSStatus(
            available=e.is_available(),
            engine_name=e.name,
            sample_rate=e.sample_rate,
            reason="" if e.is_available()
                    else "Aucun engine streaming branché. pyttsx3 reste actif.",
        )

    def synthesize_stream(self, text: str) -> Iterator[bytes]:
        with self._lock:
            e = self._engine
        if not e.is_available():
            return iter([])
        return e.synthesize_stream(text)


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[StreamingTTSService] = None
_lock = threading.Lock()


def get_streaming_tts() -> StreamingTTSService:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = StreamingTTSService()
    return _instance
