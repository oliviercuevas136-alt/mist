"""
voice_enhancers.py — Améliorations qualitatives du pipeline vocal.

Trois sous-modules :

    1. VADCalibrator
       Apprend le seuil de bruit ambiant en mode IDLE, expose des
       paramètres à passer à Faster-Whisper (vad_filter + vad_parameters).
       Ce N'EST PAS un VAD audio temps réel : c'est une calibration
       statistique des seuils utilisés par Whisper.

    2. TextWakeWordDetector
       Détecte un mot-clé dans une transcription DÉJÀ FAITE.
       Honnête : ce n'est PAS un vrai wake word audio (qui écoute en
       continu avant le STT). C'est un filtre post-STT pour ignorer
       les transcriptions qui ne commencent pas par "Nova" / mot configuré.
       Économise des appels LLM, n'évite pas le coût audio.
       Pour un vrai wake word, il faudrait Porcupine ou OpenWakeWord.

    3. TranscriptPostCorrector
       Corrections déterministes courantes sur la sortie Whisper FR :
         - majuscule en début
         - ponctuation finale si manquante
         - remplacements connus (mots souvent ratés)
         - filtre des transcriptions creuses ("Sous-titres réalisés par...")
"""

from __future__ import annotations

import re
import threading
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Deque, Dict, List, Optional, Tuple

from app.utils.logger import get_logger

logger = get_logger("voice_enhancers")


# ── 1. VAD Calibrator ──────────────────────────────────────────────────────

@dataclass
class VADParams:
    """Paramètres à passer à Faster-Whisper transcribe()."""
    vad_filter:                bool   = True
    min_silence_duration_ms:   int    = 500
    threshold:                 float  = 0.5
    min_speech_duration_ms:    int    = 250
    speech_pad_ms:             int    = 400

    def to_whisper_dict(self) -> Dict[str, Any]:
        """Format attendu par WhisperModel.transcribe(vad_parameters=...)."""
        return {
            "min_silence_duration_ms": self.min_silence_duration_ms,
            "threshold":               self.threshold,
            "min_speech_duration_ms":  self.min_speech_duration_ms,
            "speech_pad_ms":           self.speech_pad_ms,
        }


class VADCalibrator:
    """
    Adapte les paramètres VAD en fonction des sessions passées :
      - si beaucoup de transcriptions vides → assouplir VAD (threshold ↓)
      - si beaucoup de hallucinations (segments très courts) → durcir
      - si stable → laisser les défauts

    Pas d'analyse audio temps réel — calibration basée sur le RÉSULTAT
    des transcriptions accumulées.
    """

    HISTORY_SIZE = 30

    def __init__(self) -> None:
        self._history: Deque[Dict[str, Any]] = deque(maxlen=self.HISTORY_SIZE)
        self._params = VADParams()
        self._lock = threading.Lock()

    def record_result(self, *, text: str, duration_s: float, transcribe_ms: int) -> None:
        """Enregistre le résultat d'une transcription."""
        with self._lock:
            self._history.append({
                "ts":            time.time(),
                "text_len":      len(text or ""),
                "duration_s":    duration_s,
                "transcribe_ms": transcribe_ms,
                "is_empty":      not bool((text or "").strip()),
            })
        self._maybe_recalibrate()

    def _maybe_recalibrate(self) -> None:
        """Recalcule les paramètres si historique significatif."""
        with self._lock:
            if len(self._history) < 10:
                return
            recent = list(self._history)
            empty_rate = sum(1 for r in recent if r["is_empty"]) / len(recent)
            avg_text_len = sum(r["text_len"] for r in recent) / len(recent)

            # Beaucoup de vides + audios courts → VAD trop strict
            if empty_rate > 0.5 and avg_text_len < 10:
                self._params.threshold = max(0.3, self._params.threshold - 0.05)
                self._params.min_speech_duration_ms = max(150, self._params.min_speech_duration_ms - 50)
                logger.info(
                    "[VAD_CALIB] assouplissement (empty_rate=%.2f) → threshold=%.2f",
                    empty_rate, self._params.threshold,
                )
            # Beaucoup d'hallucinations (textes très longs vs audio court) → durcir
            elif empty_rate < 0.1 and avg_text_len > 200:
                self._params.threshold = min(0.7, self._params.threshold + 0.05)
                logger.info(
                    "[VAD_CALIB] durcissement (long_text) → threshold=%.2f",
                    self._params.threshold,
                )

    def get_params(self) -> VADParams:
        with self._lock:
            return VADParams(**asdict(self._params))

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            if not self._history:
                return {"samples": 0, "empty_rate": 0.0,
                        "params": asdict(self._params)}
            samples = list(self._history)
            empty_rate = sum(1 for r in samples if r["is_empty"]) / len(samples)
            avg_ms = sum(r["transcribe_ms"] for r in samples) / len(samples)
            return {
                "samples":               len(samples),
                "empty_rate":            round(empty_rate, 3),
                "avg_transcribe_ms":     int(avg_ms),
                "params":                asdict(self._params),
            }


# ── 2. Text Wake Word ──────────────────────────────────────────────────────

class TextWakeWordDetector:
    """
    Détecte un mot d'éveil dans une transcription faite.

    LIMITES (à dire honnêtement à l'utilisateur) :
        Ce n'est pas un vrai wake word audio. L'audio doit déjà
        avoir été capturé + transcrit. Cela économise les appels LLM
        et permet de filtrer les transcriptions parasites, mais ne
        permet PAS de garder le micro ouvert en permanence avec
        consommation minimale.

        Vrai wake word = Porcupine, OpenWakeWord, snowboy (out of scope).
    """

    def __init__(self, words: Optional[List[str]] = None) -> None:
        self._words = [w.lower().strip() for w in (words or ["nova"]) if w.strip()]
        self._enabled = True

    def configure(self, words: List[str], enabled: bool = True) -> None:
        self._words = [w.lower().strip() for w in words if w.strip()]
        self._enabled = bool(enabled)

    def is_enabled(self) -> bool:
        return self._enabled

    def matches(self, text: str) -> Tuple[bool, Optional[str]]:
        """
        Retourne (matched, command).
        Si matché : command = le texte AVEC le wake-word retiré du début.
        Sinon : (False, None).
        """
        if not self._enabled:
            return True, (text or "").strip()
        if not text:
            return False, None
        # Normalisation : retirer ponctuation initiale
        normalized = re.sub(r"^[\s,\.\!\?\;\:]+", "", text.lower())
        for w in self._words:
            # Mot suivi d'un séparateur ou en fin de phrase
            pattern = r"^" + re.escape(w) + r"(?:[\s,\.\!\?]+(.*))?$"
            m = re.match(pattern, normalized)
            if m:
                rest = (m.group(1) or "").strip()
                # Restaurer la casse depuis l'original
                # Simple : on prend l'original après les premiers chars du wake
                idx = text.lower().find(w)
                if idx >= 0:
                    original_rest = text[idx + len(w):]
                    original_rest = re.sub(r"^[\s,\.\!\?\;\:]+", "", original_rest)
                    return True, original_rest.strip()
                return True, rest
        return False, None

    def get_config(self) -> Dict[str, Any]:
        return {"words": list(self._words), "enabled": self._enabled}


# ── 3. Transcript Post-Correction ──────────────────────────────────────────

# Phrases parasites que Faster-Whisper sort sur audio vide/bruit
_WHISPER_HALLUCINATIONS = [
    "sous-titres réalisés par la communauté d'amara.org",
    "sous-titrage st' 501",
    "merci d'avoir regardé cette vidéo",
    "abonnez-vous",
    "thanks for watching",
    "please subscribe",
    "♪",
    "[musique]",
    "[applaudissements]",
]

# Corrections fréquentes en français (Whisper tiny rate)
_COMMON_FIXES = [
    # (regex, remplacement)
    (re.compile(r"\bno va\b", re.IGNORECASE), "Nova"),
    (re.compile(r"\bno-va\b", re.IGNORECASE), "Nova"),
    (re.compile(r"\bnovah\b", re.IGNORECASE), "Nova"),
    (re.compile(r"\bok va\b", re.IGNORECASE), "Nova"),
]


class TranscriptPostCorrector:
    """
    Applique des corrections déterministes sur la sortie Whisper :
        1. Filtre les hallucinations connues (audio bruit/vide)
        2. Corrige les confusions fréquentes ("no va" → "Nova")
        3. Capitalise le début, ajoute ponctuation finale
    """

    def correct(self, text: str) -> Tuple[str, Dict[str, Any]]:
        """Retourne (texte_corrigé, info_diagnostic)."""
        if not text:
            return "", {"changed": False, "reason": "empty"}

        original = text
        info: Dict[str, Any] = {"changed": False, "applied": []}

        # 1. Hallucinations
        lowered = text.strip().lower()
        for h in _WHISPER_HALLUCINATIONS:
            if h in lowered:
                info["applied"].append(f"halluc:{h[:30]}")
                return "", {**info, "changed": True, "reason": "hallucination_filtered"}

        # 2. Substitutions communes
        corrected = text
        for rx, repl in _COMMON_FIXES:
            new = rx.sub(repl, corrected)
            if new != corrected:
                info["applied"].append(f"fix:{rx.pattern}")
                corrected = new

        # 3. Capitalisation initiale
        stripped = corrected.strip()
        if stripped and stripped[0].islower():
            corrected = stripped[0].upper() + stripped[1:]
            info["applied"].append("capitalize")
        else:
            corrected = stripped

        # 4. Ponctuation finale (juste pour le confort de lecture)
        if corrected and corrected[-1] not in ".!?…":
            corrected = corrected + "."
            info["applied"].append("punct")

        info["changed"] = corrected != original
        return corrected, info


# ── Singletons ─────────────────────────────────────────────────────────────

_vad_calibrator:    Optional[VADCalibrator] = None
_wake_detector:     Optional[TextWakeWordDetector] = None
_post_corrector:    Optional[TranscriptPostCorrector] = None
_lock = threading.Lock()


def get_vad_calibrator() -> VADCalibrator:
    global _vad_calibrator
    if _vad_calibrator is None:
        with _lock:
            if _vad_calibrator is None:
                _vad_calibrator = VADCalibrator()
    return _vad_calibrator


def get_wake_detector() -> TextWakeWordDetector:
    global _wake_detector
    if _wake_detector is None:
        with _lock:
            if _wake_detector is None:
                from app.config import settings
                words_csv = getattr(settings, "wake_words", "nova")
                enabled = getattr(settings, "wake_word_enabled", False)
                words = [w.strip() for w in (words_csv or "").split(",") if w.strip()]
                _wake_detector = TextWakeWordDetector(words or ["nova"])
                _wake_detector.configure(words or ["nova"], enabled=enabled)
    return _wake_detector


def get_post_corrector() -> TranscriptPostCorrector:
    global _post_corrector
    if _post_corrector is None:
        with _lock:
            if _post_corrector is None:
                _post_corrector = TranscriptPostCorrector()
    return _post_corrector
