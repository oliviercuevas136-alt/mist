"""
voice_metrics.py — Instrumentation latence du pipeline vocal (v1.9.9).

Mesure chaque tour vocal en 5 phases :
    record_ms : temps depuis début capture micro jusqu'à fin (frontend → backend)
    stt_ms   : temps de transcription Whisper
    llm_ms   : temps total LLM (assistant_start → assistant_end)
    tts_ms   : temps TTS si applicable (pyttsx3 sync, piper streaming, ou navigateur)
    total_ms : record + stt + llm + tts (latence perçue utilisateur)

Stockage : ring buffer en RAM (capacity_default = 200 turns) + persisté en
DB optionnellement via MonitoringEvent pour analyse à plus long terme.

Pas d'état partagé global au-delà du singleton thread-safe.
Pas de dépendance lourde — juste collections.deque + threading.Lock.

Usage côté API :
    metrics = get_voice_metrics()
    turn_id = metrics.start_turn()
    metrics.mark(turn_id, "record_ms", 1234)
    metrics.mark(turn_id, "stt_ms", 412)
    ...
    metrics.complete(turn_id)
"""

from __future__ import annotations

import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, asdict, field
from typing import Any, Deque, Dict, List, Optional

from app.utils.logger import get_logger

logger = get_logger("voice_metrics")


# Phases mesurées (clés autorisées dans mark())
_VALID_PHASES = {"record_ms", "stt_ms", "llm_ms", "tts_ms", "total_ms"}


@dataclass
class VoiceTurnMetric:
    """Mesures d'un tour vocal — initialisées à None, remplies au fur et à mesure."""
    turn_id:     str
    started_at:  float
    completed_at: Optional[float] = None
    record_ms:   Optional[int] = None
    stt_ms:      Optional[int] = None
    llm_ms:      Optional[int] = None
    tts_ms:      Optional[int] = None
    total_ms:    Optional[int] = None
    # Métadonnées libres : modèle, length transcript, errors
    meta:        Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    def is_complete(self) -> bool:
        return self.completed_at is not None


class VoiceMetricsCollector:
    """Singleton — collecte et expose les latences du pipeline vocal."""

    DEFAULT_CAPACITY = 200       # nb max de tours en mémoire

    def __init__(self, capacity: int = DEFAULT_CAPACITY) -> None:
        self._lock = threading.RLock()
        self._history: Deque[VoiceTurnMetric] = deque(maxlen=capacity)
        # turn_id → VoiceTurnMetric en cours
        self._inflight: Dict[str, VoiceTurnMetric] = {}

    # ── Cycle de vie d'un tour ──────────────────────────────────────────

    def start_turn(self) -> str:
        """Démarre un nouveau tour. Retourne le turn_id."""
        turn_id = uuid.uuid4().hex[:12]
        m = VoiceTurnMetric(turn_id=turn_id, started_at=time.time())
        with self._lock:
            self._inflight[turn_id] = m
            # Anti-fuite : si trop d'inflight (frontend mauvais), drop les vieux
            if len(self._inflight) > 50:
                to_drop = sorted(self._inflight.items(),
                                  key=lambda kv: kv[1].started_at)[:10]
                for tid, _ in to_drop:
                    self._inflight.pop(tid, None)
        return turn_id

    def mark(self, turn_id: str, phase: str, value_ms: int,
              meta: Optional[Dict[str, Any]] = None) -> bool:
        """Marque la fin d'une phase. Retourne True si OK."""
        if phase not in _VALID_PHASES:
            return False
        try:
            v = int(value_ms)
        except (TypeError, ValueError):
            return False
        with self._lock:
            m = self._inflight.get(turn_id)
            if not m:
                return False
            setattr(m, phase, v)
            if meta:
                m.meta.update(meta)
        return True

    def complete(self, turn_id: str,
                  meta: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """Finalise un tour : calcule total_ms et l'archive."""
        with self._lock:
            m = self._inflight.pop(turn_id, None)
            if not m:
                return None
            if meta:
                m.meta.update(meta)
            # Calculer total_ms s'il n'a pas été marqué explicitement
            if m.total_ms is None:
                m.total_ms = int((time.time() - m.started_at) * 1000)
            m.completed_at = time.time()
            self._history.append(m)
            d = m.to_dict()
        logger.debug(
            "[VOICE_METRIC] turn=%s record=%s stt=%s llm=%s tts=%s total=%sms",
            turn_id, m.record_ms, m.stt_ms, m.llm_ms, m.tts_ms, m.total_ms,
        )
        return d

    def cancel(self, turn_id: str, reason: str = "") -> bool:
        """Annule un tour en cours (timeout, erreur, interruption)."""
        with self._lock:
            m = self._inflight.pop(turn_id, None)
            if not m:
                return False
            m.meta["cancelled"] = True
            m.meta["cancel_reason"] = reason
            m.completed_at = time.time()
            m.total_ms = int((m.completed_at - m.started_at) * 1000)
            self._history.append(m)
        logger.info("[VOICE_METRIC] turn=%s ANNULÉ (%s)", turn_id, reason)
        return True

    # ── Lecture / agrégation ────────────────────────────────────────────

    def get_history(self, limit: int = 50,
                     completed_only: bool = True) -> List[Dict[str, Any]]:
        with self._lock:
            items = list(self._history)
        if completed_only:
            items = [m for m in items if m.is_complete()]
        return [m.to_dict() for m in items[-limit:]]

    def get_inflight(self) -> List[Dict[str, Any]]:
        """Tours actuellement en cours (utile pour le watchdog)."""
        with self._lock:
            return [m.to_dict() for m in self._inflight.values()]

    def aggregate(self, last_n: int = 50) -> Dict[str, Any]:
        """
        Statistiques sur les N derniers tours complétés.
        Retourne moyennes + médianes + p95 pour chaque phase.
        """
        with self._lock:
            items = [m for m in self._history if m.is_complete()][-last_n:]

        if not items:
            return {
                "samples": 0,
                "phases": {},
                "cancelled_rate": 0.0,
            }

        def stats(values: List[int]) -> Dict[str, float]:
            if not values:
                return {"count": 0}
            s = sorted(values)
            n = len(s)
            mean = sum(s) / n
            median = s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2
            p95_idx = max(0, int(n * 0.95) - 1)
            p95 = s[p95_idx]
            return {
                "count":  n,
                "mean":   round(mean, 1),
                "median": round(median, 1),
                "p95":    p95,
                "min":    s[0],
                "max":    s[-1],
            }

        phases: Dict[str, Dict[str, float]] = {}
        for phase in _VALID_PHASES:
            vals = [getattr(m, phase) for m in items if getattr(m, phase) is not None]
            phases[phase] = stats(vals)

        cancelled = sum(1 for m in items if m.meta.get("cancelled"))
        return {
            "samples":        len(items),
            "phases":         phases,
            "cancelled":      cancelled,
            "cancelled_rate": round(cancelled / len(items), 3),
            "window_seconds": int((items[-1].completed_at or 0) -
                                    (items[0].started_at or 0)) if items else 0,
        }

    def clear(self) -> int:
        with self._lock:
            n = len(self._history)
            self._history.clear()
            self._inflight.clear()
        return n


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[VoiceMetricsCollector] = None
_lock = threading.Lock()


def get_voice_metrics() -> VoiceMetricsCollector:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = VoiceMetricsCollector()
    return _instance
