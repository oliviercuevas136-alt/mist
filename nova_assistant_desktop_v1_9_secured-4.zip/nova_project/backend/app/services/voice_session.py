"""
voice_session.py — État conversationnel vocal de Nova.

Modélise une session vocale comme une machine d'état :

    IDLE ──► LISTENING ──► THINKING ──► SPEAKING ──► IDLE
       └──────────► (interruption utilisateur) ◄──┘

Chaque transition publie un event sur le CORE :
    voice.state.idle
    voice.state.listening
    voice.state.thinking
    voice.state.speaking
    voice.state.interrupted

Tient aussi une mémoire courte vocale (N derniers échanges) pour
contextualiser le LLM sans dépendre de la base SQL principale.

Ce module ne fait PAS d'audio. Il coordonne les états et la mémoire.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Deque, Dict, List, Optional

from app.utils.logger import get_logger

logger = get_logger("voice_session")


class VoiceState(str, Enum):
    IDLE        = "idle"           # rien en cours
    LISTENING   = "listening"      # micro ouvert, capture en cours
    THINKING    = "thinking"       # STT terminé, LLM en cours
    SPEAKING    = "speaking"       # TTS / probe en cours
    INTERRUPTED = "interrupted"    # utilisateur a coupé pendant SPEAKING


@dataclass
class VoiceTurn:
    """Un échange vocal : user (transcript) + assistant (response)."""
    timestamp:        float
    user_text:        str
    assistant_text:   str
    stt_duration_ms:  Optional[int] = None
    llm_duration_ms:  Optional[int] = None
    tts_duration_ms:  Optional[int] = None
    interrupted:      bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class VoiceSession:
    """Machine d'état + mémoire courte par utilisateur (singleton ici)."""

    # Transitions valides (un peu permissif pour robustesse)
    _ALLOWED = {
        VoiceState.IDLE:        {VoiceState.LISTENING},
        VoiceState.LISTENING:   {VoiceState.THINKING, VoiceState.IDLE, VoiceState.INTERRUPTED},
        VoiceState.THINKING:    {VoiceState.SPEAKING, VoiceState.IDLE, VoiceState.INTERRUPTED},
        VoiceState.SPEAKING:    {VoiceState.IDLE, VoiceState.INTERRUPTED, VoiceState.LISTENING},
        VoiceState.INTERRUPTED: {VoiceState.IDLE, VoiceState.LISTENING},
    }

    def __init__(self, memory_size: int = 8) -> None:
        self._state: VoiceState = VoiceState.IDLE
        self._state_since: float = time.time()
        self._memory: Deque[VoiceTurn] = deque(maxlen=memory_size)
        self._current_turn_start: Optional[float] = None
        self._lock = threading.RLock()
        # Compteur d'interruptions consécutives — pour ne pas relancer en boucle
        self._interruption_count = 0

    # ── État ────────────────────────────────────────────────────────────────

    def get_state(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "state":           self._state.value,
                "since_sec":       round(time.time() - self._state_since, 2),
                "memory_turns":    len(self._memory),
                "interruptions":   self._interruption_count,
            }

    def transition(self, new_state: VoiceState, *, force: bool = False) -> bool:
        """
        Transition vers un nouvel état. Publie un event CORE.
        Retourne True si effectif, False si refusé.
        """
        with self._lock:
            cur = self._state
            if not force and new_state not in self._ALLOWED.get(cur, set()):
                # Pas dans les transitions valides — log et ignore
                if cur != new_state:   # silencieux si même état
                    logger.debug(
                        "[VOICE_SESSION] transition refusée %s → %s",
                        cur.value, new_state.value,
                    )
                return False
            self._state = new_state
            self._state_since = time.time()
            if new_state == VoiceState.INTERRUPTED:
                self._interruption_count += 1
            if new_state == VoiceState.IDLE:
                self._interruption_count = 0

        self._publish_state_event(new_state)
        return True

    def is_active(self) -> bool:
        with self._lock:
            return self._state != VoiceState.IDLE

    # ── Mémoire conversationnelle ──────────────────────────────────────────

    def append_turn(self, turn: VoiceTurn) -> None:
        with self._lock:
            self._memory.append(turn)

    def get_recent_turns(self, n: int = 4) -> List[Dict[str, Any]]:
        with self._lock:
            return [t.to_dict() for t in list(self._memory)[-n:]]

    def build_context_string(self, n: int = 3) -> str:
        """
        Construit un bref contexte texte des N derniers échanges,
        utilisable comme préfixe LLM. Court par design (< 600 chars).
        """
        with self._lock:
            turns = list(self._memory)[-n:]
        if not turns:
            return ""
        lines = ["[Contexte vocal récent]"]
        for t in turns:
            user_short = (t.user_text or "")[:120]
            asst_short = (t.assistant_text or "")[:120]
            lines.append(f"U: {user_short}")
            lines.append(f"A: {asst_short}")
        return "\n".join(lines)

    def clear_memory(self) -> int:
        with self._lock:
            n = len(self._memory)
            self._memory.clear()
        return n

    # ── Helpers ───────────────────────────────────────────────────────────

    def start_turn(self) -> float:
        with self._lock:
            self._current_turn_start = time.time()
            return self._current_turn_start

    def get_current_turn_age(self) -> float:
        with self._lock:
            if self._current_turn_start is None:
                return 0.0
            return time.time() - self._current_turn_start

    # ── Publication CORE ──────────────────────────────────────────────────

    def _publish_state_event(self, state: VoiceState) -> None:
        try:
            from app.core.event_bus import CoreEvent, EventLevel
            from app.core.orchestrator import orchestrator
            level = EventLevel.LOW
            # interrupted/listening sont des transitions notables → INFO
            if state in (VoiceState.INTERRUPTED, VoiceState.LISTENING):
                level = EventLevel.INFO
            orchestrator.submit_event(CoreEvent(
                type=f"voice.state.{state.value}",
                source="voice_session",
                level=level,
                message=f"Voix : {state.value}",
                payload={"state": state.value, "ts": time.time()},
            ))
        except Exception as exc:
            logger.debug("[VOICE_SESSION] CORE submit skipped: %s", exc)


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[VoiceSession] = None
_lock = threading.Lock()


def get_voice_session() -> VoiceSession:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = VoiceSession()
    return _instance
