"""
voice_watchdog.py — Surveille les sessions vocales bloquées (v1.9.9).

Symptôme adressé :
    Si le frontend bloque en LISTENING (micro freeze, navigateur tabbé out),
    en THINKING (Ollama down ou très lent), ou en SPEAKING (TTS qui ne
    revient pas), la VoiceSession reste dans cet état indéfiniment et
    aucun nouveau tour ne peut démarrer.

Solution :
    Un thread daemon vérifie périodiquement la durée passée dans l'état
    actuel. Si > seuil, force la transition vers IDLE et publie un event
    'voice.watchdog.timeout' sur le CORE.

Seuils par état (configurables via settings) :
    LISTENING : 60s  — un user peut parler longtemps mais pas 1 min en continu
    THINKING  : 90s  — Ollama lent OK, mais 90s = problème
    SPEAKING  : 120s — TTS peut être long sur grande réponse, mais pas plus

Le watchdog ne kill rien — il publie un event et reset l'état. Le frontend
verra `voice.watchdog.timeout` sur le bus et peut décider de relancer
une boucle ou afficher une erreur.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Optional

from app.utils.logger import get_logger

logger = get_logger("voice_watchdog")


@dataclass
class WatchdogConfig:
    check_interval_sec:    float = 5.0
    listening_timeout_sec: float = 60.0
    thinking_timeout_sec:  float = 90.0
    speaking_timeout_sec:  float = 120.0
    # Seuil global : tour en cours dans voice_metrics depuis plus de N sec → annule
    inflight_timeout_sec:  float = 180.0


class VoiceWatchdog:
    """Thread daemon de surveillance. Démarrage / arrêt explicites."""

    def __init__(self, config: Optional[WatchdogConfig] = None) -> None:
        self.config = config or WatchdogConfig()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        # Compteur de timeouts par type — exposé via REST
        self._stats = {
            "listening_timeouts": 0,
            "thinking_timeouts":  0,
            "speaking_timeouts":  0,
            "inflight_cancelled": 0,
            "last_check_ts":      0.0,
        }

    def start(self) -> bool:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return False
            self._stop.clear()
            self._thread = threading.Thread(
                target=self._loop, name="voice-watchdog", daemon=True,
            )
            self._thread.start()
            logger.info("[VOICE_WATCHDOG] démarré (check=%.1fs)",
                          self.config.check_interval_sec)
            return True

    def stop(self) -> bool:
        with self._lock:
            if not self._thread or not self._thread.is_alive():
                return False
            self._stop.set()
            self._thread.join(timeout=5.0)
            logger.info("[VOICE_WATCHDOG] arrêté")
            return True

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def get_stats(self) -> dict:
        with self._lock:
            return {**self._stats, "running": self.is_running()}

    # ── Boucle principale ────────────────────────────────────────────────

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._check_once()
            except Exception as exc:
                logger.error("[VOICE_WATCHDOG] erreur cycle : %s", exc)
            self._stats["last_check_ts"] = time.time()
            self._stop.wait(self.config.check_interval_sec)

    def _check_once(self) -> None:
        # 1. Vérifier état VoiceSession
        self._check_session_state()
        # 2. Vérifier les tours bloqués dans voice_metrics
        self._check_inflight_metrics()

    def _check_session_state(self) -> None:
        """Si la VoiceSession est dans un état actif depuis trop longtemps."""
        try:
            from app.services.voice_session import get_voice_session, VoiceState
        except Exception:
            return

        session = get_voice_session()
        state = session.get_state()
        since = state.get("since_sec", 0.0)
        current = state.get("state", "idle")

        threshold_map = {
            "listening": (self.config.listening_timeout_sec, "listening_timeouts"),
            "thinking":  (self.config.thinking_timeout_sec,  "thinking_timeouts"),
            "speaking":  (self.config.speaking_timeout_sec,  "speaking_timeouts"),
        }
        if current not in threshold_map:
            return

        threshold, stat_key = threshold_map[current]
        if since < threshold:
            return

        # Timeout détecté → force reset
        logger.warning(
            "[VOICE_WATCHDOG] state=%s bloqué %.1fs > %.1fs — reset forcé",
            current, since, threshold,
        )
        with self._lock:
            self._stats[stat_key] += 1

        # Publier event sur le CORE puis forcer IDLE
        self._publish_timeout_event(current, since, threshold)
        try:
            session.transition(VoiceState.IDLE, force=True)
        except Exception as exc:
            logger.error("[VOICE_WATCHDOG] reset IDLE échec : %s", exc)

    def _check_inflight_metrics(self) -> None:
        """Annule les tours métriques bloqués trop longtemps."""
        try:
            from app.services.voice_metrics import get_voice_metrics
        except Exception:
            return

        metrics = get_voice_metrics()
        now = time.time()
        inflight = metrics.get_inflight()

        for turn in inflight:
            age = now - turn["started_at"]
            if age > self.config.inflight_timeout_sec:
                logger.warning(
                    "[VOICE_WATCHDOG] turn %s bloqué %.1fs — annulé",
                    turn["turn_id"], age,
                )
                metrics.cancel(turn["turn_id"],
                                reason=f"watchdog timeout {age:.0f}s")
                with self._lock:
                    self._stats["inflight_cancelled"] += 1

    def _publish_timeout_event(self, state: str, since: float,
                                 threshold: float) -> None:
        try:
            from app.core.event_bus import CoreEvent, EventLevel
            from app.core.orchestrator import orchestrator
            orchestrator.submit_event(CoreEvent(
                type=f"voice.watchdog.timeout",
                source="voice_watchdog",
                level=EventLevel.MEDIUM,
                message=(
                    f"Pipeline vocal bloqué en {state} depuis {since:.0f}s "
                    f"(seuil {threshold:.0f}s) — reset forcé"
                ),
                payload={
                    "stuck_state": state,
                    "since_sec":   since,
                    "threshold_sec": threshold,
                },
            ))
        except Exception as exc:
            logger.debug("[VOICE_WATCHDOG] CORE submit skip : %s", exc)


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[VoiceWatchdog] = None
_lock = threading.Lock()


def get_voice_watchdog() -> VoiceWatchdog:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = VoiceWatchdog()
    return _instance
