"""
wake_word_local.py — Interface pour wake word audio LOCAL (Phase B, non actif).

STATUT v1.9.9 : interface uniquement. Aucun moteur réel branché par défaut.

But :
    Permettre à Oli d'installer plus tard pvporcupine ou openwakeword sans
    modifier le code coeur — il suffira de fournir une implémentation
    concrète et de la brancher via set_engine().

Différence essentielle avec TextWakeWordDetector (v1.9.5) :
    TextWakeWordDetector  : filtre POST-STT. L'audio doit déjà avoir été
                            capté ET transcrit. Économise les LLM, pas le STT.
    WakeWordLocalEngine    : analyse l'AUDIO en continu (bytes PCM). Permet
                            de garder le micro ouvert avec consommation
                            minimale et de ne déclencher le STT QUE quand
                            "Nova" est détecté.

Engine attendu (à implémenter par dépendance native) :
    class MyEngine(WakeWordEngine):
        def is_available(self) -> bool: ...
        def process_audio(self, pcm_frame: bytes) -> Optional[str]:
            # Retourne le wake word matché, ou None.

Côté Oli, pour activer plus tard :
    1. pip install pvporcupine     # ~5 Mo binaires
       OU
       pip install openwakeword    # plus complexe
    2. Implémenter une classe qui suit WakeWordEngine (~30 lignes)
    3. set_engine(MyEngine())
    4. Le frontend continu peut alors capturer en boucle et n'envoyer au
       backend que les segments qui suivent un wake word.

Aucune dépendance ne sera ajoutée par défaut.
"""

from __future__ import annotations

import abc
import threading
from dataclasses import dataclass
from typing import Optional

from app.utils.logger import get_logger

logger = get_logger("wake_word_local")


@dataclass
class WakeWordStatus:
    available:    bool
    engine_name:  str = ""
    sample_rate:  int = 16000
    frame_length: int = 512
    reason:       str = ""


class WakeWordEngine(abc.ABC):
    """Interface qu'un moteur réel (Porcupine, etc.) doit implémenter."""

    @property
    @abc.abstractmethod
    def name(self) -> str: ...

    @property
    def sample_rate(self) -> int:
        return 16000

    @property
    def frame_length(self) -> int:
        """Nombre d'échantillons par frame attendu (Porcupine = 512)."""
        return 512

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def process_audio(self, pcm_frame: bytes) -> Optional[str]:
        """
        Reçoit une frame PCM 16-bit mono. Retourne le wake word détecté,
        ou None si aucun.
        """


class _NoopEngine(WakeWordEngine):
    """Engine inactif par défaut. Aucune détection."""

    @property
    def name(self) -> str:
        return "noop"

    def is_available(self) -> bool:
        return False

    def process_audio(self, pcm_frame: bytes) -> Optional[str]:
        return None


class WakeWordLocalService:
    """Singleton — façade sur l'engine actuellement branché."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._engine: WakeWordEngine = _NoopEngine()

    def set_engine(self, engine: WakeWordEngine) -> None:
        """Branche un engine réel (à appeler manuellement par Oli, plus tard)."""
        with self._lock:
            self._engine = engine
            logger.info("[WAKE_LOCAL] engine = %s (available=%s)",
                          engine.name, engine.is_available())

    def get_status(self) -> WakeWordStatus:
        with self._lock:
            e = self._engine
        return WakeWordStatus(
            available=e.is_available(),
            engine_name=e.name,
            sample_rate=e.sample_rate,
            frame_length=e.frame_length,
            reason="" if e.is_available()
                    else "Aucun engine réel branché. Voir wake_word_local.py.",
        )

    def process_audio(self, pcm_frame: bytes) -> Optional[str]:
        with self._lock:
            e = self._engine
        if not e.is_available():
            return None
        try:
            return e.process_audio(pcm_frame)
        except Exception as exc:
            logger.warning("[WAKE_LOCAL] erreur engine %s : %s", e.name, exc)
            return None


# ── Singleton ──────────────────────────────────────────────────────────────

_instance: Optional[WakeWordLocalService] = None
_lock = threading.Lock()


def get_wake_word_local() -> WakeWordLocalService:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = WakeWordLocalService()
    return _instance
