const output = document.getElementById("output");
const chatBox = document.getElementById("chat-box");
const messageInput = document.getElementById("message-input");
const chatForm = document.getElementById("chat-form");
const newConversationBtn = document.getElementById("new-conversation-btn");

const memoryList = document.getElementById("memory-list");
const notesList = document.getElementById("notes-list");
const documentsList = document.getElementById("documents-list");
const conversationsList = document.getElementById("conversations-list");
const conversationDetail = document.getElementById("conversation-detail");

const navButtons = document.querySelectorAll(".nav-btn");
const tabs = document.querySelectorAll(".tab-content");
const panelTitle = document.getElementById("panel-title");
const panelSubtitle = document.getElementById("panel-subtitle");
const recordBtn = document.getElementById("record-btn");
const stopRecordBtn = document.getElementById("stop-record-btn");
const speakLastBtn = document.getElementById("speak-last-btn");

let mediaRecorder = null;
let audioChunks = [];
let lastAssistantReply = "";
let conversationId = null;
let notesCache = {};

const TAB_META = {
  chat: {
    title: "Chat",
    subtitle: "Discussion avec l’assistant local"
  },
  memory: {
    title: "Mémoire",
    subtitle: "Ajout, recherche et suppression des souvenirs"
  },
  notes: {
    title: "Notes",
    subtitle: "Création, édition, recherche et suppression des notes"
  },
  documents: {
    title: "Documents",
    subtitle: "Lecture, indexation et recherche documentaire locale"
  },
  conversations: {
    title: "Conversations",
    subtitle: "Historique complet des discussions enregistrées"
  },
  system: {
    title: "Système",
    subtitle: "Santé, exports et informations de fonctionnement"
  }
};

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function setOutput(data) {
  if (typeof data === "string") {
    output.textContent = data;
    return;
  }
  output.textContent = JSON.stringify(data, null, 2);
}

function switchTab(tabName) {
  navButtons.forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === tabName);
  });

  tabs.forEach(tab => {
    tab.classList.toggle("active", tab.id === `tab-${tabName}`);
  });

  const meta = TAB_META[tabName];
  if (meta) {
    panelTitle.textContent = meta.title;
    panelSubtitle.textContent = meta.subtitle;
  }
}

function addMessage(role, content) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;

  const label = document.createElement("span");
  label.className = "label";
  label.textContent = role === "user" ? "Toi" : "Assistant";

  const body = document.createElement("div");
  body.textContent = content;

  wrapper.appendChild(label);
  wrapper.appendChild(body);
  chatBox.appendChild(wrapper);
  chatBox.scrollTop = chatBox.scrollHeight;
  if (role === "assistant") {
  lastAssistantReply = content;
  }  
}


function clearChat() {
  chatBox.innerHTML = "";
}

function renderCardList(container, items, renderItem) {
  container.innerHTML = "";
  if (!items || items.length === 0) {
    container.innerHTML = `<div class="muted">Aucun résultat.</div>`;
    return;
  }

  items.forEach(item => {
    const card = document.createElement("div");
    card.className = "card-item";
    renderItem(card, item);
    container.appendChild(card);
  });
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || "Erreur inconnue");
  }

  return data;
}

async function sendMessage(message) {
  const payload = {
    message,
    conversation_id: conversationId
  };

  const data = await fetchJson("/api/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  conversationId = data.conversation_id;
  return data;
}

async function checkHealth() {
  setOutput("Vérification en cours...");
  try {
    const data = await fetchJson("/api/health");
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function loadMemoryList() {
  setOutput("Chargement mémoire...");
  try {
    const data = await fetchJson("/api/memory/list");
    renderCardList(memoryList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.category)}</strong>
        <div>${escapeHtml(item.content)}</div>
        <div class="muted">importance=${item.importance} | source=${escapeHtml(item.source)}</div>
        <div class="card-actions"></div>
      `;

      const actions = card.querySelector(".card-actions");
      const deleteBtn = document.createElement("button");
      deleteBtn.className = "danger";
      deleteBtn.textContent = "Supprimer";
      deleteBtn.addEventListener("click", () => deleteMemory(item.id));
      actions.appendChild(deleteBtn);
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function addMemory(event) {
  event.preventDefault();

  const payload = {
    content: document.getElementById("memory-content").value.trim(),
    category: document.getElementById("memory-category").value.trim() || "general",
    importance: parseInt(document.getElementById("memory-importance").value || "3", 10),
    source: document.getElementById("memory-source").value.trim() || "manual"
  };

  try {
    const data = await fetchJson("/api/memory/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    setOutput(data);
    event.target.reset();
    document.getElementById("memory-importance").value = 3;
    await loadMemoryList();
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function searchMemory(event) {
  event.preventDefault();

  const payload = {
    query: document.getElementById("memory-search-query").value.trim(),
    limit: 20
  };

  try {
    const data = await fetchJson("/api/memory/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    renderCardList(memoryList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.category)}</strong>
        <div>${escapeHtml(item.content)}</div>
        <div class="muted">importance=${item.importance} | source=${escapeHtml(item.source)}</div>
        <div class="card-actions"></div>
      `;

      const actions = card.querySelector(".card-actions");
      const deleteBtn = document.createElement("button");
      deleteBtn.className = "danger";
      deleteBtn.textContent = "Supprimer";
      deleteBtn.addEventListener("click", () => deleteMemory(item.id));
      actions.appendChild(deleteBtn);
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function deleteMemory(id) {
  try {
    const data = await fetchJson(`/api/memory/${id}`, {
      method: "DELETE"
    });
    setOutput(data);
    await loadMemoryList();
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

function prefillNoteUpdateById(id) {
  const note = notesCache[id];

  if (!note) {
    setOutput(`Erreur: note introuvable pour l'ID ${id}`);
    return;
  }

  document.getElementById("note-update-id").value = note.id;
  document.getElementById("note-update-title").value = note.title;
  document.getElementById("note-update-content").value = note.content;
  document.getElementById("note-update-tags").value = note.tags || "";
  switchTab("notes");
}

async function loadNotesList() {
  setOutput("Chargement notes...");
  try {
    const data = await fetchJson("/api/notes/list");

    notesCache = {};
    data.forEach(item => {
      notesCache[item.id] = item;
    });

    renderCardList(notesList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.title)}</strong>
        <div>${escapeHtml(item.content)}</div>
        <div class="muted">tags=${escapeHtml(item.tags || "")}</div>
        <div class="card-actions"></div>
      `;

      const actions = card.querySelector(".card-actions");

      const editBtn = document.createElement("button");
      editBtn.className = "secondary";
      editBtn.textContent = "Préremplir modif";
      editBtn.addEventListener("click", () => prefillNoteUpdateById(item.id));

      const deleteBtn = document.createElement("button");
      deleteBtn.className = "danger";
      deleteBtn.textContent = "Supprimer";
      deleteBtn.addEventListener("click", () => deleteNote(item.id));

      actions.appendChild(editBtn);
      actions.appendChild(deleteBtn);
    });

    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function createNote(event) {
  event.preventDefault();

  const payload = {
    title: document.getElementById("note-title").value.trim(),
    content: document.getElementById("note-content").value.trim(),
    tags: document.getElementById("note-tags").value.trim()
  };

  try {
    const data = await fetchJson("/api/notes/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    setOutput(data);
    event.target.reset();
    await loadNotesList();
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function updateNote(event) {
  event.preventDefault();

  const noteId = document.getElementById("note-update-id").value.trim();
  if (!noteId) {
    setOutput("Erreur: ID note manquant.");
    return;
  }

  const payload = {
    title: document.getElementById("note-update-title").value.trim(),
    content: document.getElementById("note-update-content").value.trim(),
    tags: document.getElementById("note-update-tags").value.trim()
  };

  try {
    const data = await fetchJson(`/api/notes/${noteId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    setOutput(data);
    await loadNotesList();
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function searchNotes(event) {
  event.preventDefault();

  const payload = {
    query: document.getElementById("note-search-query").value.trim(),
    limit: 20
  };

  try {
    const data = await fetchJson("/api/notes/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    notesCache = {};
    data.forEach(item => {
      notesCache[item.id] = item;
    });

    renderCardList(notesList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.title)}</strong>
        <div>${escapeHtml(item.content)}</div>
        <div class="muted">tags=${escapeHtml(item.tags || "")}</div>
        <div class="card-actions"></div>
      `;

      const actions = card.querySelector(".card-actions");

      const editBtn = document.createElement("button");
      editBtn.className = "secondary";
      editBtn.textContent = "Préremplir modif";
      editBtn.addEventListener("click", () => prefillNoteUpdateById(item.id));

      const deleteBtn = document.createElement("button");
      deleteBtn.className = "danger";
      deleteBtn.textContent = "Supprimer";
      deleteBtn.addEventListener("click", () => deleteNote(item.id));

      actions.appendChild(editBtn);
      actions.appendChild(deleteBtn);
    });

    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function deleteNote(id) {
  try {
    const data = await fetchJson(`/api/notes/${id}`, {
      method: "DELETE"
    });
    setOutput(data);
    delete notesCache[id];
    await loadNotesList();
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function deleteNoteFromForm(event) {
  event.preventDefault();
  const noteId = document.getElementById("note-delete-id").value.trim();
  if (!noteId) {
    setOutput("Erreur: ID note manquant.");
    return;
  }
  await deleteNote(noteId);
}

async function listFiles(event) {
  event.preventDefault();

  const payload = {
    relative_dir: document.getElementById("files-relative-dir").value.trim()
  };

  try {
    const data = await fetchJson("/api/files/list", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    renderCardList(documentsList, data, (card, item) => {
      card.innerHTML = `
        <strong>${escapeHtml(item.name)}</strong>
        <div>${escapeHtml(item.relative_path)}</div>
        <div class="muted">${item.is_dir ? "DIR" : "FILE"} ${item.size ? `| ${item.size} octets` : ""}</div>
      `;
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function readFile(event) {
  event.preventDefault();

  const payload = {
    relative_path: document.getElementById("file-read-path").value.trim()
  };

  try {
    const data = await fetchJson("/api/files/read", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    renderCardList(documentsList, [data], (card, item) => {
      card.innerHTML = `
        <strong>${escapeHtml(item.filename)}</strong>
        <div class="muted">${escapeHtml(item.relative_path)}</div>
        <div>${escapeHtml(item.content)}</div>
      `;
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function indexFile(event) {
  event.preventDefault();

  const payload = {
    relative_path: document.getElementById("file-index-path").value.trim()
  };

  try {
    const data = await fetchJson("/api/files/index", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    setOutput(data);
    await loadDocumentsList();
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function loadDocumentsList() {
  setOutput("Chargement documents...");
  try {
    const data = await fetchJson("/api/files/documents");
    renderCardList(documentsList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.filename)}</strong>
        <div>${escapeHtml(item.path)}</div>
        <div class="muted">${escapeHtml(item.content_preview || "")}</div>
      `;
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function searchDocuments(event) {
  event.preventDefault();

  const payload = {
    query: document.getElementById("documents-search-query").value.trim(),
    limit: 20
  };

  try {
    const data = await fetchJson("/api/files/documents/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    renderCardList(documentsList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.filename)}</strong>
        <div>${escapeHtml(item.path)}</div>
        <div class="muted">${escapeHtml(item.content_preview || "")}</div>
      `;
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function loadConversationsList() {
  setOutput("Chargement conversations...");
  try {
    const data = await fetchJson("/api/conversations/list");
    renderCardList(conversationsList, data, (card, item) => {
      card.innerHTML = `
        <strong>[${item.id}] ${escapeHtml(item.title)}</strong>
        <div class="card-actions"></div>
      `;

      const actions = card.querySelector(".card-actions");

      const readBtn = document.createElement("button");
      readBtn.textContent = "Lire";
      readBtn.addEventListener("click", () => readConversationById(item.id));

      const resumeBtn = document.createElement("button");
      resumeBtn.className = "secondary";
      resumeBtn.textContent = "Reprendre";
      resumeBtn.addEventListener("click", () => resumeConversation(item.id));

      actions.appendChild(readBtn);
      actions.appendChild(resumeBtn);
    });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

async function readConversation(event) {
  event.preventDefault();
  const id = document.getElementById("conversation-read-id").value.trim();
  if (!id) {
    setOutput("Erreur: ID conversation manquant.");
    return;
  }
  await readConversationById(id);
}

async function readConversationById(id) {
  try {
    const data = await fetchJson(`/api/conversations/${id}`);
    conversationDetail.innerHTML = "";

    if (!data.messages || data.messages.length === 0) {
      conversationDetail.innerHTML = `<div class="muted">Aucun message.</div>`;
      setOutput(data);
      return;
    }

    data.messages.forEach(msg => {
      const card = document.createElement("div");
      card.className = "card-item";
      card.innerHTML = `
        <strong>${escapeHtml(msg.role)}</strong>
        <div>${escapeHtml(msg.content)}</div>
      `;
      conversationDetail.appendChild(card);
    });

    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

function resumeConversation(id) {
  conversationId = Number(id);
  switchTab("chat");
  setOutput(`Conversation active définie sur ID ${id}`);
}

async function exportData(url) {
  setOutput("Export en cours...");
  try {
    const data = await fetchJson(url, { method: "POST" });
    setOutput(data);
  } catch (error) {
    setOutput(`Erreur: ${error.message}`);
  }
}

function resetConversation() {
  conversationId = null;
  clearChat();
  setOutput("Nouvelle conversation prête.");
}

async function sendAudioForTranscription(blob) {
  const formData = new FormData();
  formData.append("file", blob, "recording.webm");

  const response = await fetch("/api/voice/transcribe", {
    method: "POST",
    body: formData
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || "Erreur transcription");
  }

  return data;
}

async function startRecording() {
  setOutput("Bouton Enregistrer cliqué...");

  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setOutput("Erreur: getUserMedia non disponible dans ce navigateur.");
      return;
    }

    if (typeof MediaRecorder === "undefined") {
      setOutput("Erreur: MediaRecorder non disponible.");
      return;
    }

    setOutput("Demande d'accès au micro...");

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    setOutput("Micro autorisé. Préparation de l'enregistrement...");

    audioChunks = [];
    mediaRecorder = new MediaRecorder(stream);

    // Désactiver le bouton enregistrer pendant l'enregistrement
    if (recordBtn) recordBtn.disabled = true;
    if (stopRecordBtn) stopRecordBtn.disabled = false;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        audioChunks.push(event.data);
      }
    };

    mediaRecorder.onerror = (event) => {
      setOutput(`Erreur MediaRecorder: ${event.error ? event.error.message : "erreur inconnue"}`);
      if (recordBtn) recordBtn.disabled = false;
      if (stopRecordBtn) stopRecordBtn.disabled = true;
    };

    mediaRecorder.onstart = () => {
      setOutput("🔴 Enregistrement démarré — parlez puis cliquez Arrêter.");
    };

    mediaRecorder.onstop = async () => {
      setOutput("Enregistrement arrêté. Transcription en cours...");
      if (recordBtn) recordBtn.disabled = false;
      if (stopRecordBtn) stopRecordBtn.disabled = true;

      try {
        const blob = new Blob(audioChunks, { type: "audio/webm" });
        const result = await sendAudioForTranscription(blob);

        if (result.is_empty || !result.text) {
          // Transcription vide : message explicite, ne pas écraser le champ
          setOutput("⚠️ Transcription vide — aucun texte détecté. Vérifiez le micro ou parlez plus fort.");
        } else {
          messageInput.value = result.text;
          setOutput(`✅ Transcription OK : "${result.text}"`);
        }
      } catch (error) {
        setOutput(`Erreur transcription: ${error.message}`);
      } finally {
        stream.getTracks().forEach(track => track.stop());
      }
    };

    mediaRecorder.start();
  } catch (error) {
    setOutput(`Erreur micro: ${error.message}`);
    if (recordBtn) recordBtn.disabled = false;
    if (stopRecordBtn) stopRecordBtn.disabled = true;
  }
}

function stopRecording() {
  if (mediaRecorder && mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
  } else {
    setOutput("Aucun enregistrement en cours.");
  }
}

async function speakLastReply() {
  if (!lastAssistantReply.trim()) {
    setOutput("Aucune réponse assistant à lire.");
    return;
  }

  setOutput("Synthèse vocale en cours...");

  try {
    const response = await fetch("/api/voice/speak", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text: lastAssistantReply })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "Erreur TTS");
    }

    setOutput("✅ Lecture terminée.");
  } catch (error) {
    setOutput(`Erreur synthèse: ${error.message}`);
  }
}

// ============================================================
// MODULE : CONVERSATION VOCALE CONTINUE v5
// ACK immédiat + SSE streaming LLM + TTS parallèle
// Métriques : first_feedback / first_audio / total
// ============================================================

const VoiceLoop = (() => {

  // ── Paramètres ──────────────────────────────────────────────
  const SILENCE_THRESHOLD   = 0.015;   // RMS seuil parole
  const SILENCE_DURATION_MS = 800;     // silence → fin énoncé
  const MIN_SPEECH_MS       = 400;     // durée min audio valide
  const MAX_WAIT_MS         = 15000;   // timeout écoute max

  // ── État ────────────────────────────────────────────────────
  let _active      = false;
  let _sessionStart = 0;

  // ── UI ──────────────────────────────────────────────────────
  const _startBtn = document.getElementById("voice-loop-btn");
  const _stopBtn  = document.getElementById("voice-loop-stop-btn");

  // Panneau diagnostic
  let _diagEl = document.getElementById("voice-diag");
  if (!_diagEl) {
    _diagEl = document.createElement("div");
    _diagEl.id = "voice-diag";
    _diagEl.style.cssText = [
      "display:none","font-family:monospace","font-size:0.80em",
      "background:#1a1a1a","color:#d4d4d4","border:1px solid #333",
      "border-radius:4px","padding:8px 10px","margin-top:6px","line-height:1.7",
    ].join(";");
    const outputEl = document.getElementById("output");
    if (outputEl?.parentNode) outputEl.parentNode.insertBefore(_diagEl, outputEl.nextSibling);
  }

  const _diagRows = {};

  function _diagInit() {
    _diagEl.innerHTML = "";
    Object.keys(_diagRows).forEach(k => delete _diagRows[k]);
    [
      ["status",      "État",            "#9cdcfe"],
      ["record",      "🎙 Enreg.",       "#ce9178"],
      ["stt",         "📝 STT",          "#4ec9b0"],
      ["feedback",    "⚡ 1er feedback", "#4ec9b0"],
      ["first_audio", "🔊 1er audio",    "#c586c0"],
      ["llm",         "🧠 LLM",          "#dcdcaa"],
      ["total",       "⏱ TOTAL",         "#f0f0f0"],
    ].forEach(([key, label, color]) => {
      const row = document.createElement("div");
      const lbl = document.createElement("span");
      const val = document.createElement("span");
      lbl.textContent = label.padEnd(14, " ");
      lbl.style.cssText = `color:${color};margin-right:6px;`;
      val.textContent = "—";
      val.style.color = "#888";
      row.append(lbl, val);
      _diagEl.appendChild(row);
      _diagRows[key] = val;
    });
  }

  function _diagSet(key, value, color) {
    if (_diagRows[key]) {
      _diagRows[key].textContent = value;
      if (color) _diagRows[key].style.color = color;
    }
  }

  function _c(ms, good, warn) {
    return ms == null ? "#888" : ms < good ? "#4ec9b0" : ms < warn ? "#dcdcaa" : "#f44747";
  }

  function _diagShow(on) {
    _diagEl.style.display = on ? "block" : "none";
    if (on) _diagInit();
  }

  function _ui(running) {
    if (_startBtn)     _startBtn.style.display  = running ? "none" : "";
    if (_stopBtn)      _stopBtn.style.display   = running ? ""     : "none";
    if (recordBtn)     recordBtn.disabled        = running;
    if (stopRecordBtn) stopRecordBtn.disabled     = running;
    if (speakLastBtn)  speakLastBtn.disabled      = running;
    _diagShow(running);
  }

  function _status(msg) {
    setOutput(msg);
    _diagSet("status", msg, "#9cdcfe");
  }

  function _stop(reason) {
    _active = false;
    fetch("/api/voice/stop", { method: "POST" }).catch(() => {});
    _ui(false);
    _status(reason || "🛑 Conversation arrêtée.");
  }

  // ── Bulle assistant ──────────────────────────────────────────
  function _newBubble() {
    const wrapper = document.createElement("div");
    wrapper.className = "message assistant";
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = "Assistant";
    const body = document.createElement("div");
    wrapper.append(label, body);
    if (typeof chatBox !== "undefined") {
      chatBox.appendChild(wrapper);
      chatBox.scrollTop = chatBox.scrollHeight;
    }
    return body;
  }

  function _typewriter(el, text, ms = 45) {
    const words = text.split(" ");
    let i = 0;
    const tick = () => {
      if (i < words.length) {
        el.textContent += (i === 0 ? "" : " ") + words[i++];
        if (typeof chatBox !== "undefined") chatBox.scrollTop = chatBox.scrollHeight;
        setTimeout(tick, ms);
      }
    };
    tick();
  }

  // ── Enregistrement RMS ───────────────────────────────────────
  async function _recordUntilSilence() {
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      _stop("❌ Micro inaccessible : " + err.message);
      return null;
    }

    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const source   = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 512;
    source.connect(analyser);

    const bufLen  = analyser.fftSize;
    const dataBuf = new Float32Array(bufLen);
    const recorder = new MediaRecorder(stream);
    const chunks   = [];
    recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.start(80);

    const t0 = Date.now();
    let silenceStart = null, speechSeen = false;

    console.log(`[VOICE_RECORD_START] ts=${new Date().toISOString().slice(11,23)}`);

    await new Promise(resolve => {
      const tick = () => {
        if (!_active) { resolve(); return; }
        analyser.getFloatTimeDomainData(dataBuf);
        let sum = 0;
        for (let i = 0; i < bufLen; i++) sum += dataBuf[i] * dataBuf[i];
        const rms = Math.sqrt(sum / bufLen);
        if (rms > SILENCE_THRESHOLD) {
          speechSeen = true; silenceStart = null;
        } else if (speechSeen) {
          if (!silenceStart) silenceStart = Date.now();
          if (Date.now() - silenceStart >= SILENCE_DURATION_MS) { resolve(); return; }
        } else if (Date.now() - t0 > MAX_WAIT_MS) { resolve(); return; }
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });

    const record_ms = Date.now() - t0;
    console.log(`[VOICE_RECORD_END] duration_ms=${record_ms} speech=${speechSeen}`);

    if (recorder.state !== "inactive") recorder.stop();
    await new Promise(r => { recorder.onstop = r; });
    stream.getTracks().forEach(t => t.stop());
    audioCtx.close();

    if (!speechSeen || record_ms < MIN_SPEECH_MS) return null;
    _diagSet("record", `${record_ms} ms`, _c(record_ms, 3000, 8000));
    return { blob: new Blob(chunks, { type: "audio/webm" }), record_ms };
  }

  // ── STT ──────────────────────────────────────────────────────
  async function _transcribe(blob) {
    const fd = new FormData();
    fd.append("file", blob, "conv.webm");
    const resp = await fetch("/api/voice/transcribe", { method: "POST", body: fd });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || "Erreur STT");
    _diagSet("stt", `${data.stt_time_ms ?? "?"} ms`, _c(data.stt_time_ms, 1500, 3000));
    return { text: (data.text || "").trim(), is_empty: data.is_empty, stt_ms: data.stt_time_ms ?? 0 };
  }

  // ── Pipeline SSE ─────────────────────────────────────────────
  async function _runStream(text) {
    addMessage("user", text);

    const replyBody = _newBubble();
    replyBody.style.cssText = "color:#888;font-style:italic";
    replyBody.textContent = "…";

    let fullReply = "";

    try {
      const resp = await fetch("/api/voice/stream", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ message: text, fast_mode: true }),
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.detail || `HTTP ${resp.status}`);
      }

      const reader  = resp.body.getReader();
      const decoder = new TextDecoder();
      let   sseBuffer = "";

      const parseEvents = (chunk) => {
        sseBuffer += chunk;
        const events = [];
        const blocks = sseBuffer.split("\n\n");
        sseBuffer = blocks.pop() || "";
        for (const block of blocks) {
          let event = "message", data = "";
          for (const line of block.split("\n")) {
            if (line.startsWith("event: ")) event = line.slice(7).trim();
            if (line.startsWith("data: "))  data  = line.slice(6).trim();
          }
          if (data) events.push({ event, data });
        }
        return events;
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        for (const { event, data } of parseEvents(decoder.decode(value, { stream: true }))) {
          let obj;
          try { obj = JSON.parse(data); } catch { continue; }

          if (event === "ack") {
            replyBody.style.cssText = "";
            replyBody.textContent = obj.text;
            _diagSet("feedback", `${obj.time_to_feedback_ms} ms`, _c(obj.time_to_feedback_ms, 300, 800));
            _status("🔊 Je réponds…");
          }

          else if (event === "instant") {
            replyBody.style.cssText = "";
            fullReply = obj.reply;
            lastAssistantReply = fullReply;
            _typewriter(replyBody, fullReply);
            _diagSet("feedback", `⚡ ${obj.time_to_feedback_ms} ms`, "#4ec9b0");
          }

          else if (event === "token") {
            fullReply += (obj.t || "");
            lastAssistantReply = fullReply;
            replyBody.style.cssText = "";
            replyBody.textContent = fullReply;
            if (typeof chatBox !== "undefined") chatBox.scrollTop = chatBox.scrollHeight;
          }

          else if (event === "fallback") {
            fullReply = obj.text || fullReply;
            replyBody.textContent = fullReply;
            lastAssistantReply = fullReply;
          }

          else if (event === "done") {
            if (obj.reply) {
              fullReply = obj.reply;
              lastAssistantReply = fullReply;
              replyBody.textContent = fullReply;
            }
          }

          else if (event === "metrics") {
            const { time_to_first_feedback_ms: fb,
                    time_to_first_spoken_audio_ms: fa,
                    full_turn_total_ms: tot,
                    llm_ms, mode } = obj;
            _diagSet("feedback",    `${fb} ms`,  _c(fb, 300, 800));
            _diagSet("first_audio", `${fa} ms`,  _c(fa, 2500, 4000));
            _diagSet("llm",         `${llm_ms} ms`, _c(llm_ms, 2000, 3500));
            _diagSet("total",
              `${(tot/1000).toFixed(2)} s  (${tot} ms)`,
              _c(tot, 3500, 5000));

            const ts = new Date().toISOString().slice(11,23);
            console.group(`[VOICE_TOTAL_END] ${ts}  mode=${mode}`);
            console.log("[time_to_first_feedback_ms]    ", fb);
            console.log("[time_to_first_token_ms]       ", obj.time_to_first_token_ms);
            console.log("[time_to_first_spoken_audio_ms]", fa);
            console.log("[full_turn_total_ms]           ", tot);
            console.log("[llm_ms]                       ", llm_ms);
            console.groupEnd();
          }
        }
      }

    } catch (err) {
      replyBody.style.cssText = "color:#f44747";
      replyBody.textContent = `⚠️ ${err.message}`;
      console.error("[VoiceLoop] stream error:", err);
    }

    return fullReply;
  }

  // ── Boucle principale ────────────────────────────────────────
  async function _loop() {
    while (_active) {
      _status("🎙 Je vous écoute…");

      const recorded = await _recordUntilSilence();
      if (!_active) break;
      if (!recorded) {
        await new Promise(r => setTimeout(r, 150));
        continue;
      }

      _status("📝 Je transcris…");
      let sttResult;
      try {
        sttResult = await _transcribe(recorded.blob);
      } catch (err) {
        _status("⚠️ STT : " + err.message);
        await new Promise(r => setTimeout(r, 800));
        continue;
      }

      if (!_active) break;
      if (sttResult.is_empty || !sttResult.text || sttResult.text.length < 2) {
        _status("🎙 Je vous écoute…");
        continue;
      }

      _status("🧠 Je réfléchis…");
      await _runStream(sttResult.text);

      if (!_active) break;

      // Pause anti-écho avant de réécouter
      await new Promise(r => setTimeout(r, 400));
    }
  }

  // ── Démarrage ────────────────────────────────────────────────
  async function start() {
    if (_active) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      _status("❌ Micro non disponible.");
      return;
    }
    _active = true;
    _sessionStart = Date.now();
    _ui(true);
    _status("🤖 Conversation démarrée — parlez !");
    await _loop();
  }

  if (_startBtn) _startBtn.addEventListener("click", start);
  if (_stopBtn)  _stopBtn.addEventListener("click", () => _stop());

  return { start, stop: _stop };
})();

// ============================================================
// FIN MODULE CONVERSATION VOCALE v5
// ============================================================

// ============================================================



function bindEvents() {
  navButtons.forEach(btn => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });

  chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = messageInput.value.trim();
    if (!message) {
      return;
    }

    addMessage("user", message);
    messageInput.value = "";
    setOutput("Traitement en cours...");

    try {
      const data = await sendMessage(message);
      addMessage("assistant", data.reply);
      setOutput(data);
    } catch (error) {
      addMessage("assistant", `Erreur: ${error.message}`);
      setOutput(`Erreur: ${error.message}`);
    }
  });

  newConversationBtn.addEventListener("click", resetConversation);

  document.getElementById("memory-form").addEventListener("submit", addMemory);
  document.getElementById("memory-search-form").addEventListener("submit", searchMemory);
  document.getElementById("refresh-memory-btn").addEventListener("click", loadMemoryList);

  document.getElementById("note-form").addEventListener("submit", createNote);
  document.getElementById("note-update-form").addEventListener("submit", updateNote);
  document.getElementById("note-search-form").addEventListener("submit", searchNotes);
  document.getElementById("note-delete-form").addEventListener("submit", deleteNoteFromForm);
  document.getElementById("refresh-notes-btn").addEventListener("click", loadNotesList);

  document.getElementById("files-list-form").addEventListener("submit", listFiles);
  document.getElementById("file-read-form").addEventListener("submit", readFile);
  document.getElementById("file-index-form").addEventListener("submit", indexFile);
  document.getElementById("documents-search-form").addEventListener("submit", searchDocuments);
  document.getElementById("refresh-documents-btn").addEventListener("click", loadDocumentsList);

  document.getElementById("refresh-conversations-btn").addEventListener("click", loadConversationsList);
  document.getElementById("conversation-read-form").addEventListener("submit", readConversation);

  document.getElementById("check-health-btn").addEventListener("click", checkHealth);
  document.getElementById("export-memories-btn").addEventListener("click", () => exportData("/api/exports/memories"));
  document.getElementById("export-notes-btn").addEventListener("click", () => exportData("/api/exports/notes"));
  document.getElementById("export-conversations-btn").addEventListener("click", () => exportData("/api/exports/conversations"));
  document.getElementById("export-all-btn").addEventListener("click", () => exportData("/api/exports/all"));

// ===== VOIX =====
if (recordBtn) {
  recordBtn.addEventListener("click", startRecording);
}

if (stopRecordBtn) {
  stopRecordBtn.addEventListener("click", stopRecording);
}

if (speakLastBtn) {
  speakLastBtn.addEventListener("click", speakLastReply);
}

}

window.deleteMemory = deleteMemory;
window.deleteNote = deleteNote;
window.readConversationById = readConversationById;
window.resumeConversation = resumeConversation;
window.prefillNoteUpdateById = prefillNoteUpdateById;

bindEvents();
switchTab("chat");
// ============================================================
// MODULE SURVEILLANCE — ajouté sans modifier le code existant
// ============================================================

// ---- État local surveillance ----
let monitoringActive = false;
let visionActive = false;
let micActive = false;
let pollInterval = null;
let probeInterval = null;

// ---- Utilitaires ----
function showToast(msg, duration = 5000) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), duration);
}

function formatTime(isoStr) {
  if (!isoStr) return '—';
  try {
    const d = new Date(isoStr);
    return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch { return isoStr; }
}

function updateStatusBar() {
  const camDot = document.getElementById('status-cam');
  const micDot = document.getElementById('status-mic');
  const monDot = document.getElementById('status-monitor');
  if (camDot) {
    camDot.className = 'status-dot ' + (visionActive ? 'on' : 'off');
    camDot.title = visionActive ? 'Caméra active' : 'Caméra inactive';
  }
  if (micDot) {
    micDot.className = 'status-dot ' + (micActive ? 'on' : 'off');
    micDot.title = micActive ? 'Micro actif' : 'Micro inactif';
  }
  if (monDot) {
    monDot.className = 'status-dot ' + (monitoringActive ? 'on' : 'off');
    monDot.title = monitoringActive ? 'Surveillance active' : 'Surveillance inactive';
  }
}

// ---- État machine actuel ----
let currentIncidentState = 'idle';
let incidentProgressTimer = null;

// ---- Mise à jour state machine display ----
function updateStateMachineDisplay(state) {
  const steps = ['IDLE', 'DETECTION', 'CHECK', 'CONFIRM', 'ALERT', 'ESCALATE'];
  steps.forEach(s => {
    const el = document.getElementById('sm-' + s);
    if (el) {
      el.classList.remove('active', 'done');
    }
  });

  const upper = (state || 'idle').toUpperCase();
  const el = document.getElementById('sm-' + upper);
  if (el) el.classList.add('active');
}

// ---- Bannière incident actif ----
function updateIncidentBanner(incident) {
  const banner   = document.getElementById('incident-banner');
  const title    = document.getElementById('incident-title');
  const msg      = document.getElementById('incident-msg');
  const icon     = document.getElementById('incident-icon');
  const fill     = document.getElementById('incident-progress-fill');
  if (!banner) return;

  const state = (incident && incident.state) ? incident.state : 'idle';
  currentIncidentState = state;

  const activeStates = ['detection', 'check'];
  const warnStates   = ['confirm'];
  const critStates   = ['alert', 'escalate'];

  if (activeStates.includes(state)) {
    banner.classList.remove('hidden', 'warning');
    if (icon) icon.textContent = state === 'check' ? '⏳' : '⚠️';
    if (title) title.textContent = state === 'check'
      ? '⏳ Vérification en cours — Appuyez si vous allez bien'
      : '⚠️ Chute possible détectée';
    if (msg) msg.textContent = incident.tts_sent
      ? `"${incident.tts_sent}"`
      : 'Appuyez sur "Je vais bien" si vous êtes conscient.';
    if (fill) {
      fill.style.background = '#ef4444';
      // Barre de progression de la fenêtre de confirmation
      if (state === 'check') {
        fill.style.width = '100%';
        fill.style.transition = 'width 12s linear';
        setTimeout(() => { if (fill) fill.style.width = '0%'; }, 50);
      } else {
        fill.style.width = '100%';
        fill.style.transition = 'none';
      }
    }
  } else if (critStates.includes(state)) {
    banner.classList.remove('hidden', 'warning');
    if (icon) icon.textContent = '🚨';
    if (title) title.textContent = '🚨 ALERTE — Secours prévenus';
    if (msg)  msg.textContent   = 'Pas de réponse. Les secours ont été contactés.';
    if (fill) { fill.style.background = '#ef4444'; fill.style.width = '100%'; }
  } else if (warnStates.includes(state)) {
    banner.classList.remove('hidden');
    banner.classList.add('warning');
    if (icon) icon.textContent = '✅';
    if (title) title.textContent = '✅ Tout va bien';
    if (msg)  msg.textContent   = 'Réponse reçue. Incident résolu.';
    if (fill) { fill.style.background = '#22c55e'; fill.style.width = '100%'; }
    setTimeout(() => { if (banner) banner.classList.add('hidden'); }, 5000);
  } else {
    // IDLE — cacher la bannière
    banner.classList.add('hidden');
    banner.classList.remove('warning');
    if (fill) { fill.style.width = '0%'; fill.style.transition = 'none'; }
  }
}

// ---- Mise à jour statut monitoring ----
async function refreshMonitoringStatus() {
  try {
    const res = await fetch('/api/monitoring/status');
    if (!res.ok) return;
    const data = await res.json();
    const mon = data.monitoring || {};
    const vis = data.vision || {};
    const inc = data.incident || {};

    monitoringActive = mon.active || false;
    visionActive = vis.active || false;
    updateStatusBar();

    // State machine
    updateStateMachineDisplay(inc.state || 'idle');
    updateIncidentBanner(inc);

    // Statut détaillé
    const box = document.getElementById('monitoring-status-box');
    if (box) {
      const stateLabel = {
        idle: '✅ En veille', detection: '⚠️ Détection', check: '⏳ Vérification',
        confirm: '✅ Confirmé', alert: '🚨 ALERTE', escalate: '📞 ESCALADE'
      }[inc.state || 'idle'] || (inc.state || '—');
      box.innerHTML = `
        <div class="row"><span>Surveillance</span><strong>${mon.active ? '✅ Active' : '❌ Inactive'}</strong></div>
        <div class="row"><span>État incident</span><strong>${stateLabel}</strong></div>
        <div class="row"><span>Silence depuis</span><strong>${mon.silence_minutes ? Math.round(mon.silence_minutes) + ' min' : '—'}</strong></div>
        <div class="row"><span>Absence depuis</span><strong>${mon.absence_minutes ? Math.round(mon.absence_minutes) + ' min' : '—'}</strong></div>
        <div class="row"><span>Chutes aujourd'hui</span><strong>${mon.fall_count_today ?? 0}</strong></div>
        <div class="row"><span>Alertes totales</span><strong>${mon.alert_count ?? 0}</strong></div>
        <div class="row"><span>Démarré à</span><strong>${formatTime(mon.started_at)}</strong></div>
      `;
    }

    // Vision
    const vbox = document.getElementById('vision-detail-box');
    const camText = document.getElementById('cam-status-text');
    const camCard = document.getElementById('cam-card');
    if (vbox && camText) {
      if (vis.active) {
        camText.textContent = 'Active';
        camText.className = 'sensor-status active';
        if (camCard) camCard.style.borderColor = '#22c55e';
        vbox.innerHTML = `
          <div>Présence: <strong>${vis.person_present ? '👤 Oui' : '—'}</strong></div>
          <div>Chute suspectée: <strong>${vis.fall_suspected ? '⚠️ Oui' : 'Non'}</strong></div>
          <div>Confiance: <strong>${vis.fall_confidence > 0 ? (vis.fall_confidence * 100).toFixed(0) + '%' : '—'}</strong></div>
          <div>Absence: <strong>${vis.absence_minutes ?? 0} min</strong></div>
          <div>Frames analysées: <strong>${vis.frame_count ?? 0}</strong></div>
          ${vis.error ? `<div style="color:#f87171">Erreur: ${vis.error}</div>` : ''}
        `;
      } else {
        camText.textContent = vis.error ? 'Erreur' : 'Inactive';
        camText.className = 'sensor-status ' + (vis.error ? 'alert' : 'inactive');
        if (camCard) camCard.style.borderColor = '';
        vbox.textContent = vis.error || 'Caméra non démarrée';
      }
    }

    // Journal événements
    const evlog = document.getElementById('events-log');
    if (evlog && data.recent_events) {
      if (data.recent_events.length === 0) {
        evlog.innerHTML = '<p class="muted">Aucun événement</p>';
      } else {
        const events = [...data.recent_events].reverse().slice(0, 50);
        evlog.innerHTML = events.map(e => `
          <div class="event-entry">
            <span class="event-time">${formatTime(e.timestamp)}</span>
            <span class="event-source ${e.source}">${e.source}</span>
            ${escapeHtml(e.description)}
          </div>
        `).join('');
      }
    }

    // Alertes
    await refreshAlerts();

  } catch (err) {
    // Silencieux si l'API n'est pas encore disponible
  }
}

async function refreshAlerts() {
  try {
    const res = await fetch('/api/alerts?limit=20');
    if (!res.ok) return;
    const data = await res.json();
    const alog = document.getElementById('alerts-log');
    if (!alog) return;
    const alerts = data.alerts || [];
    if (alerts.length === 0) {
      alog.innerHTML = '<p class="muted">Aucune alerte</p>';
      return;
    }
    alog.innerHTML = [...alerts].reverse().map(a => `
      <div class="alert-card ${a.level}">
        <span class="alert-level">${a.level}</span>
        <span>${escapeHtml(a.message)}</span>
        <div style="font-size:11px;color:var(--muted);margin-top:4px">${formatTime(a.timestamp)}</div>
      </div>
    `).join('');
  } catch {}
}

// ---- Polling probe vocal ----
async function checkVocalProbe() {
  try {
    const res = await fetch('/api/monitoring/probe');
    if (!res.ok) return;
    const data = await res.json();
    if (data.probe && data.message) {
      // Toast visible (en grand si alerte critique)
      const isUrgent = data.alert_level === 'critical' || data.alert_level === 'urgent';
      showToast((isUrgent ? '🚨 ' : '🔔 ') + data.message, isUrgent ? 15000 : 8000);
      // TTS si disponible
      try {
        await fetch('/api/voice/speak', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({text: data.message})
        });
      } catch {}
    }
  } catch {}
}

// ---- Réponse "Je vais bien" ----
async function respondImOk() {
  try {
    const res = await fetch('/api/monitoring/respond', {method: 'POST'});
    const data = await res.json();
    showToast('✅ Réponse envoyée — Tout va bien !', 5000);
    await refreshMonitoringStatus();
  } catch (err) {
    showToast('Erreur: ' + err.message, 3000);
  }
}

// ---- Charger l'historique depuis SQLite ----
async function loadHistory() {
  const level   = document.getElementById('history-filter-level')?.value || '';
  const type    = document.getElementById('history-filter-type')?.value || '';
  const hlog    = document.getElementById('history-log');
  if (!hlog) return;

  hlog.innerHTML = '<p class="muted">Chargement…</p>';

  try {
    let url = '/api/monitoring/history?limit=100';
    if (level) url += '&alert_level=' + encodeURIComponent(level);
    if (type)  url += '&alert_type='  + encodeURIComponent(type);

    const res  = await fetch(url);
    const data = await res.json();

    if (data.error) {
      hlog.innerHTML = `<p style="color:#f87171">Erreur DB: ${escapeHtml(data.error)}</p>`;
      return;
    }

    const alerts = data.alerts || [];
    if (alerts.length === 0) {
      hlog.innerHTML = '<p class="muted">Aucune alerte dans l\'historique</p>';
      return;
    }

    const levelIcon = { critical: '🚨', urgent: '❗', warning: '⚠️', info: 'ℹ️' };
    hlog.innerHTML = `<p class="muted" style="margin-bottom:8px">Total : ${data.total} alerte(s)</p>` +
      alerts.map(a => `
        <div class="alert-card ${a.level}" style="margin-bottom:8px">
          <span class="alert-level">${levelIcon[a.level] || ''} ${a.level}</span>
          <span>${escapeHtml(a.message)}</span>
          ${a.acknowledged ? '<span style="float:right;font-size:11px;color:#4ade80">✓ acquitté</span>' : ''}
          <div style="font-size:11px;color:var(--muted);margin-top:4px">
            ${formatTime(a.timestamp)} — type: ${a.type}
          </div>
        </div>
      `).join('');

  } catch (err) {
    hlog.innerHTML = `<p style="color:#f87171">Erreur: ${escapeHtml(err.message)}</p>`;
  }
}

// ---- Actions ----
async function startMonitoring(withVision = false) {
  try {
    const res = await fetch('/api/monitoring/start', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({enable_vision: withVision, camera_index: 0}),
    });
    const data = await res.json();
    setOutput(data);
    await refreshMonitoringStatus();
  } catch (err) {
    setOutput('Erreur démarrage: ' + err.message);
  }
}

async function stopMonitoring() {
  try {
    const res = await fetch('/api/monitoring/stop', {method: 'POST'});
    const data = await res.json();
    setOutput(data);
    monitoringActive = false;
    visionActive = false;
    updateStatusBar();
    await refreshMonitoringStatus();
  } catch (err) {
    setOutput('Erreur arrêt: ' + err.message);
  }
}

async function testAlert() {
  try {
    const res = await fetch('/api/alerts/test', {method: 'POST'});
    const data = await res.json();
    setOutput(data);
    await refreshAlerts();
  } catch (err) {
    setOutput('Erreur test: ' + err.message);
  }
}

async function triggerEmergency() {
  const confirmed = window.confirm('⚠️ Confirmer l\'appel d\'urgence ?');
  if (!confirmed) return;
  try {
    const res = await fetch('/api/alerts/emergency', {method: 'POST'});
    const data = await res.json();
    setOutput(data);
    showToast('🆘 Urgence déclenchée ! Contact prévenu.', 10000);
    await refreshAlerts();
  } catch (err) {
    setOutput('Erreur urgence: ' + err.message);
  }
}

async function saveCommsConfig() {
  const cfg = {
    email_enabled: document.getElementById('cfg-email-enabled')?.checked || false,
    smtp_host: document.getElementById('cfg-smtp-host')?.value || null,
    smtp_port: 587,
    smtp_user: document.getElementById('cfg-smtp-user')?.value || null,
    smtp_password: document.getElementById('cfg-smtp-password')?.value || null,
    recipient: document.getElementById('cfg-recipient')?.value || null,
    sender_name: 'Assistant Personnel',
    webhook_enabled: document.getElementById('cfg-webhook-enabled')?.checked || false,
    webhook_url: document.getElementById('cfg-webhook-url')?.value || null,
    resident_name: document.getElementById('cfg-resident')?.value || 'Résident',
    emergency_contact_name: document.getElementById('cfg-contact-name')?.value || 'Contact d\'urgence',
  };
  try {
    const res = await fetch('/api/monitoring/configure-comms', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(cfg),
    });
    const data = await res.json();
    setOutput(data);
    showToast('✅ Configuration sauvegardée', 3000);
  } catch (err) {
    setOutput('Erreur config: ' + err.message);
  }
}

// ---- Mise à jour statut micro (relié au recorder existant) ----
function updateMicStatus(active) {
  micActive = active;
  const micText = document.getElementById('mic-status-text');
  const micCard = document.getElementById('mic-card');
  if (micText) {
    micText.textContent = active ? 'Active' : 'Inactive';
    micText.className = 'sensor-status ' + (active ? 'active' : 'inactive');
  }
  if (micCard) {
    micCard.style.borderColor = active ? '#22c55e' : '';
  }
  updateStatusBar();
}

// ---- Bind surveillance events ----
function bindSurveillanceEvents() {
  const startBtn = document.getElementById('start-monitoring-btn');
  if (startBtn) startBtn.addEventListener('click', () => startMonitoring(false));

  const stopBtn = document.getElementById('stop-monitoring-btn');
  if (stopBtn) stopBtn.addEventListener('click', stopMonitoring);

  const visionBtn = document.getElementById('start-vision-btn');
  if (visionBtn) visionBtn.addEventListener('click', () => startMonitoring(true));

  const testBtn = document.getElementById('test-alert-btn');
  if (testBtn) testBtn.addEventListener('click', testAlert);

  const emergencyBtn = document.getElementById('emergency-btn');
  if (emergencyBtn) emergencyBtn.addEventListener('click', triggerEmergency);

  const saveCommsBtn = document.getElementById('save-comms-btn');
  if (saveCommsBtn) saveCommsBtn.addEventListener('click', saveCommsConfig);

  const refreshEventsBtn = document.getElementById('refresh-events-btn');
  if (refreshEventsBtn) refreshEventsBtn.addEventListener('click', refreshMonitoringStatus);

  // ---- Bouton "Je vais bien" ----
  const imOkBtn = document.getElementById('im-ok-btn');
  if (imOkBtn) imOkBtn.addEventListener('click', respondImOk);

  // ---- Historique ----
  const loadHistoryBtn = document.getElementById('load-history-btn');
  if (loadHistoryBtn) loadHistoryBtn.addEventListener('click', loadHistory);

  const historyLevel = document.getElementById('history-filter-level');
  if (historyLevel) historyLevel.addEventListener('change', loadHistory);

  const historyType = document.getElementById('history-filter-type');
  if (historyType) historyType.addEventListener('change', loadHistory);
}

// ---- Patch du recorder pour signaler le micro ----
const _origBindEvents = window.bindEvents;
function patchMicEvents() {
  const orig_start = window.startRecording;
  const orig_stop = window.stopRecording;
  if (typeof orig_start === 'function') {
    window.startRecording = function() {
      updateMicStatus(true);
      return orig_start.apply(this, arguments);
    };
  }
  if (typeof orig_stop === 'function') {
    window.stopRecording = function() {
      updateMicStatus(false);
      return orig_stop.apply(this, arguments);
    };
  }
}

// ---- Initialisation surveillance ----
function initSurveillance() {
  bindSurveillanceEvents();
  patchMicEvents();

  // Poll statut toutes les 10s
  pollInterval = setInterval(refreshMonitoringStatus, 10000);

  // Poll probe vocal toutes les 3s (fenêtre de confirmation = 12s)
  probeInterval = setInterval(checkVocalProbe, 3000);

  // Statut initial
  refreshMonitoringStatus();
  updateStatusBar();
}

// Ajout TAB_META pour surveillance
TAB_META['surveillance'] = {
  title: 'Surveillance',
  subtitle: 'Caméra, micro, alertes et sécurité en temps réel'
};

// Lance à l'init
document.addEventListener('DOMContentLoaded', initSurveillance);
// Fallback si DOMContentLoaded déjà passé
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(initSurveillance, 100);
}
