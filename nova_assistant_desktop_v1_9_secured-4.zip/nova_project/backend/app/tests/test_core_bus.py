"""
test_core_bus.py — Tests unitaires bus d'événements + décisions CORE.

Exécuter :
    cd backend
    python -m pytest app/tests/test_core_bus.py -v

ou sans pytest installé :
    python app/tests/test_core_bus.py
"""

from __future__ import annotations

import sys
import time
import unittest

# Permettre exécution standalone
sys.path.insert(0, ".")

from app.core.event_bus import (
    CoreDecision, Event, EventBus, EventLevel,
    CooldownTracker, get_event_bus,
)
from app.core.core_decision import (
    CoreDecisionEngine, Decision, get_decision_engine,
)


# ── EventBus ───────────────────────────────────────────────────────────────

class TestEventBus(unittest.TestCase):

    def setUp(self):
        # Bus frais à chaque test (pas le singleton)
        self.bus = EventBus(journal_size=100)
        self.received = []
        self.bus.subscribe(lambda ev: self.received.append(ev))

    def test_publish_basic(self):
        ev = Event(type="t1", source="src", level=EventLevel.INFO, message="hello")
        ok = self.bus.publish(ev)
        self.assertTrue(ok)
        self.assertEqual(len(self.received), 1)
        self.assertEqual(self.received[0].type, "t1")

    def test_format_standardise(self):
        """Tous les champs de la consigne doivent être présents."""
        ev = Event(type="t", source="s", level=EventLevel.HIGH, message="m",
                   payload={"k": "v"}, requires_action=True)
        d = ev.to_dict()
        for field in ["type", "source", "level", "message", "timestamp",
                      "payload", "requires_action", "id"]:
            self.assertIn(field, d, f"champ {field} manquant")
        self.assertEqual(d["level"], "high")
        self.assertTrue(d["requires_action"])

    def test_priorite_critical_avant_info(self):
        """Les events CRITICAL sont dispatched avant INFO."""
        # On publie sans dispatch immédiat puis on déclenche manuellement
        order = []
        self.bus.unsubscribe(self.bus._handlers[0])  # retirer le handler de setUp
        self.bus.subscribe(lambda ev: order.append(ev.type))

        self.bus.publish(Event(type="low_a",  source="s", level=EventLevel.INFO,     message=""), dispatch=False)
        self.bus.publish(Event(type="hi_b",   source="s", level=EventLevel.CRITICAL, message=""), dispatch=False)
        self.bus.publish(Event(type="med_c",  source="s", level=EventLevel.MEDIUM,   message=""), dispatch=False)
        self.bus._drain()

        # Ordre attendu : CRITICAL → MEDIUM → INFO
        self.assertEqual(order, ["hi_b", "med_c", "low_a"])

    def test_cooldown_anti_spam(self):
        """Même type+source publié rapidement → drop."""
        e1 = Event(type="voice.activity", source="voice_engine",
                   level=EventLevel.INFO, message="parle")
        e2 = Event(type="voice.activity", source="voice_engine",
                   level=EventLevel.INFO, message="parle encore")
        self.assertTrue(self.bus.publish(e1))
        self.assertFalse(self.bus.publish(e2))   # drop par cooldown
        stats = self.bus.get_stats()
        self.assertEqual(stats["dropped_spam"], 1)
        self.assertEqual(stats["published"], 1)

    def test_cooldown_jamais_critical(self):
        """Les CRITICAL ne sont jamais bloqués."""
        e1 = Event(type="vision.fall", source="vision",
                   level=EventLevel.CRITICAL, message="chute")
        e2 = Event(type="vision.fall", source="vision",
                   level=EventLevel.CRITICAL, message="chute 2")
        self.assertTrue(self.bus.publish(e1))
        self.assertTrue(self.bus.publish(e2))   # critical = jamais bloqué

    def test_journal_central(self):
        """Le journal conserve les N derniers événements."""
        for i in range(150):
            self.bus.publish(Event(type=f"t{i}", source="src",
                                   level=EventLevel.INFO, message=""))
        # Le bus a un cooldown sur "info" (10s par défaut sur type starting with "info")
        # mais "tN" n'est pas "info.*" donc tous publiés sauf 1er drop possible
        journal = self.bus.get_journal(limit=200)
        # Au moins quelques events stockés ; journal_size=100 → max 100
        self.assertLessEqual(len(journal), 100)

    def test_filtre_journal_par_niveau(self):
        self.bus.publish(Event(type="a", source="s", level=EventLevel.INFO,     message=""))
        self.bus.publish(Event(type="b", source="s", level=EventLevel.CRITICAL, message=""))
        self.bus.publish(Event(type="c", source="s", level=EventLevel.HIGH,     message=""))

        high_plus = self.bus.get_journal(level_min=EventLevel.HIGH)
        # Doivent rester : critical + high
        levels = {e["level"] for e in high_plus}
        self.assertIn("critical", levels)
        self.assertIn("high", levels)
        self.assertNotIn("info", levels)

    def test_handler_erreur_pas_bloquant(self):
        """Une erreur dans un handler ne stoppe pas les autres."""
        order = []
        # Retirer le handler par défaut
        self.bus._handlers.clear()

        def bad(_): raise RuntimeError("boom")
        def good(ev): order.append(ev.type)

        self.bus.subscribe(bad)
        self.bus.subscribe(good)
        self.bus.publish(Event(type="t", source="s", level=EventLevel.MEDIUM, message=""))

        self.assertEqual(order, ["t"])
        self.assertEqual(self.bus.get_stats()["handler_errors"], 1)

    def test_unsubscribe(self):
        h = lambda ev: None
        self.bus.subscribe(h)
        before = len(self.bus._handlers)
        self.bus.unsubscribe(h)
        self.assertEqual(len(self.bus._handlers), before - 1)


# ── CoreDecisionEngine ─────────────────────────────────────────────────────

class TestCoreDecision(unittest.TestCase):

    def setUp(self):
        self.engine = CoreDecisionEngine()

    def _ev(self, type="t", level=EventLevel.INFO, requires_action=False, payload=None):
        return Event(type=type, source="test", level=level, message="",
                     payload=payload or {}, requires_action=requires_action)

    def test_critical_whitelist_trigger(self):
        """vision.fall + CRITICAL → trigger_emergency_protocol (whitelisté)."""
        d = self.engine.decide(self._ev(type="vision.fall", level=EventLevel.CRITICAL))
        self.assertEqual(d.decision, CoreDecision.TRIGGER_ACTION)
        self.assertEqual(d.action_name, "trigger_emergency_protocol")

    def test_critical_non_whitelist_notify(self):
        """CRITICAL sur type non whitelisté → NOTIFY seulement, pas d'action."""
        d = self.engine.decide(self._ev(type="custom.unknown_critical", level=EventLevel.CRITICAL))
        self.assertEqual(d.decision, CoreDecision.NOTIFY)
        self.assertIsNone(d.action_name)

    def test_requires_action_force_confirm(self):
        """requires_action=True → REQUEST_CONFIRM, peu importe le niveau."""
        d = self.engine.decide(self._ev(type="t", level=EventLevel.LOW, requires_action=True))
        self.assertEqual(d.decision, CoreDecision.REQUEST_CONFIRM)

    def test_high_notify(self):
        d = self.engine.decide(self._ev(level=EventLevel.HIGH))
        self.assertEqual(d.decision, CoreDecision.NOTIFY)

    def test_type_remember(self):
        d = self.engine.decide(self._ev(type="user.command", level=EventLevel.INFO))
        self.assertEqual(d.decision, CoreDecision.REMEMBER)

    def test_medium_remember(self):
        d = self.engine.decide(self._ev(type="random.medium_event", level=EventLevel.MEDIUM))
        self.assertEqual(d.decision, CoreDecision.REMEMBER)

    def test_info_log(self):
        # v1.9.2 : INFO non-listé → LOG (était IGNORE en v1.9.1)
        d = self.engine.decide(self._ev(type="random.heartbeat", level=EventLevel.INFO))
        self.assertEqual(d.decision, CoreDecision.LOG)

    def test_low_log(self):
        # v1.9.2 : LOW non-listé → LOG (était IGNORE en v1.9.1)
        d = self.engine.decide(self._ev(type="random.tick", level=EventLevel.LOW))
        self.assertEqual(d.decision, CoreDecision.LOG)

    def test_history_conserve(self):
        for i in range(10):
            self.engine.decide(self._ev(type=f"t{i}", level=EventLevel.MEDIUM))
        h = self.engine.get_history(limit=20)
        self.assertEqual(len(h), 10)


# ── Integration : bus + decision ──────────────────────────────────────────

class TestIntegrationBusDecision(unittest.TestCase):

    def test_event_flowing_through_bus_to_decision(self):
        """Pipeline complet : publier event → handler décide → trace."""
        bus = EventBus()
        engine = CoreDecisionEngine()
        decisions_taken = []

        def core_handler(ev):
            d = engine.decide(ev)
            decisions_taken.append(d)

        bus.subscribe(core_handler)

        bus.publish(Event(type="vision.fall", source="vision_engine",
                          level=EventLevel.CRITICAL, message="chute détectée"))
        bus.publish(Event(type="random.tick", source="heartbeat",
                          level=EventLevel.INFO, message=""))

        self.assertEqual(len(decisions_taken), 2)
        # v1.9.2 : alias TRIGGER_ACTION = EXECUTE_AUTHORIZED_ACTION (même Enum)
        self.assertEqual(decisions_taken[0].decision, CoreDecision.EXECUTE_AUTHORIZED_ACTION)
        # v1.9.2 : INFO non-listé → LOG
        self.assertEqual(decisions_taken[1].decision, CoreDecision.LOG)


# ── Cooldown stand-alone ──────────────────────────────────────────────────

class TestCooldown(unittest.TestCase):

    def test_cooldown_par_cle(self):
        c = CooldownTracker(default_cooldown_sec=10.0)
        e_a = Event(type="a", source="s1", level=EventLevel.MEDIUM, message="")
        e_b = Event(type="a", source="s2", level=EventLevel.MEDIUM, message="")
        self.assertTrue(c.should_emit(e_a))
        self.assertFalse(c.should_emit(e_a))   # même clé → drop
        self.assertTrue(c.should_emit(e_b))    # source différente → passe


# ── Runner standalone ─────────────────────────────────────────────────────

if __name__ == "__main__":
    unittest.main(verbosity=2)
