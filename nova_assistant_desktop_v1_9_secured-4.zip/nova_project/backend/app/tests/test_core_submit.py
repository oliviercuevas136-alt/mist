"""
test_core_submit.py — Tests dédiés au point d'entrée UNIQUE submit_event/decide_event (v1.9.2).

Couvre :
  - création CoreEvent (avec priority auto + explicite)
  - submit_event (accepté / refusé cooldown / erreur)
  - priorité (level + priority numérique)
  - cooldown (avec exception CRITICAL)
  - decide_event (toutes les décisions canoniques)
  - fallback (erreur dans decision_engine → garantie de non-crash)

Exécuter :
    cd backend
    python -m unittest app.tests.test_core_submit -v
"""

from __future__ import annotations

import sys
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, ".")

from app.core.event_bus import (
    CoreEvent, EventLevel, CoreDecision,
    EventBus, CooldownTracker,
    _LEVEL_DEFAULT_PRIORITY,
)
from app.core.core_decision import CoreDecisionEngine


# ── CoreEvent : création, priority, validation ────────────────────────────

class TestCoreEvent(unittest.TestCase):

    def test_creation_champs_obligatoires(self):
        """Champs minimaux : type, source, level."""
        e = CoreEvent(type="x", source="y", level=EventLevel.INFO)
        self.assertEqual(e.type, "x")
        self.assertEqual(e.source, "y")
        self.assertEqual(e.level, EventLevel.INFO)
        self.assertEqual(e.message, "")
        self.assertEqual(e.payload, {})
        self.assertFalse(e.requires_action)
        self.assertIsNotNone(e.id)
        self.assertIsNotNone(e.timestamp)

    def test_priority_auto_depuis_level(self):
        """priority déduit du level si non fourni."""
        for level, expected in _LEVEL_DEFAULT_PRIORITY.items():
            e = CoreEvent(type="t", source="s", level=level)
            self.assertEqual(e.priority, expected, f"level={level}")

    def test_priority_explicite(self):
        """priority fournie surcharge le défaut."""
        e = CoreEvent(type="t", source="s", level=EventLevel.INFO, priority=85)
        self.assertEqual(e.priority, 85)

    def test_priority_clamp_0_100(self):
        """Valeurs hors bornes ramenées dans [0, 100]."""
        e_low = CoreEvent(type="t", source="s", level=EventLevel.INFO, priority=-10)
        e_hi  = CoreEvent(type="t", source="s", level=EventLevel.INFO, priority=999)
        self.assertEqual(e_low.priority, 0)
        self.assertEqual(e_hi.priority, 100)

    def test_to_dict_a_tous_les_champs(self):
        e = CoreEvent(type="t", source="s", level=EventLevel.HIGH,
                      message="m", payload={"k": 1}, requires_action=True)
        d = e.to_dict()
        for f in ["type", "source", "level", "message", "timestamp",
                  "payload", "requires_action", "priority", "id"]:
            self.assertIn(f, d, f"champ {f} manquant dans to_dict()")
        self.assertEqual(d["level"], "high")
        self.assertEqual(d["priority"], 70)
        self.assertTrue(d["requires_action"])


# ── submit_event : pipeline complet ───────────────────────────────────────

class TestSubmitEvent(unittest.TestCase):

    def setUp(self):
        # Import tardif pour récupérer le singleton après reset éventuel
        from app.core.orchestrator import orchestrator
        self.core = orchestrator
        # Vider tout cooldown préalable pour ne pas interférer entre tests
        self.core._bus._cooldown._last_seen.clear()

    def test_submit_accepte_coreevent(self):
        ev = CoreEvent(type="test.submit_1", source="test",
                       level=EventLevel.LOW, message="ok")
        result = self.core.submit_event(ev)
        self.assertTrue(result["accepted"])
        self.assertEqual(result["event_id"], ev.id)

    def test_submit_accepte_dict(self):
        """Tolérant : accepter un dict équivalent."""
        result = self.core.submit_event({
            "type": "test.submit_dict",
            "source": "test",
            "level": EventLevel.MEDIUM,
            "message": "via dict",
        })
        self.assertTrue(result["accepted"])

    def test_submit_refuse_type_invalide(self):
        result = self.core.submit_event("not an event")
        self.assertFalse(result["accepted"])
        self.assertIn("not a CoreEvent", result["dropped_reason"])

    def test_submit_refuse_dict_invalide(self):
        result = self.core.submit_event({"type": "x"})  # manque source + level
        self.assertFalse(result["accepted"])
        self.assertTrue(result["dropped_reason"].startswith("invalid_dict"))

    def test_submit_cooldown_drop(self):
        """Deuxième submit identique en INFO → drop cooldown."""
        ev1 = CoreEvent(type="test.cooldown_x", source="src",
                        level=EventLevel.INFO)
        r1 = self.core.submit_event(ev1)
        ev2 = CoreEvent(type="test.cooldown_x", source="src",
                        level=EventLevel.INFO)
        r2 = self.core.submit_event(ev2)
        self.assertTrue(r1["accepted"])
        self.assertFalse(r2["accepted"])
        self.assertEqual(r2["dropped_reason"], "cooldown")

    def test_submit_critical_jamais_drop(self):
        ev1 = CoreEvent(type="vision.fall", source="vision",
                        level=EventLevel.CRITICAL)
        ev2 = CoreEvent(type="vision.fall", source="vision",
                        level=EventLevel.CRITICAL)
        r1 = self.core.submit_event(ev1)
        r2 = self.core.submit_event(ev2)
        self.assertTrue(r1["accepted"])
        self.assertTrue(r2["accepted"])

    def test_submit_ne_leve_jamais(self):
        """Robustesse : même un None ne fait pas crasher submit_event."""
        result = self.core.submit_event(None)
        self.assertFalse(result["accepted"])
        # Pas d'exception remontée — on est revenu d'un dict
        self.assertIn("dropped_reason", result)


# ── decide_event : décisions canoniques ───────────────────────────────────

class TestDecideEvent(unittest.TestCase):

    def setUp(self):
        from app.core.orchestrator import orchestrator
        self.core = orchestrator

    def test_decision_critical_whitelist(self):
        ev = CoreEvent(type="vision.fall", source="vision",
                       level=EventLevel.CRITICAL)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "execute_authorized_action")
        self.assertEqual(d["action_name"], "trigger_emergency_protocol")

    def test_decision_critical_non_whitelist(self):
        ev = CoreEvent(type="random.boom", source="x",
                       level=EventLevel.CRITICAL)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "notify")

    def test_decision_requires_action(self):
        ev = CoreEvent(type="user.something", source="x",
                       level=EventLevel.LOW, requires_action=True)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "ask_confirmation")

    def test_decision_high_notify(self):
        ev = CoreEvent(type="x", source="y", level=EventLevel.HIGH)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "notify")

    def test_decision_remember_type(self):
        ev = CoreEvent(type="user.command", source="voice",
                       level=EventLevel.INFO)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "memorize")

    def test_decision_medium_memorize(self):
        ev = CoreEvent(type="x.heartbeat", source="x", level=EventLevel.MEDIUM)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "memorize")

    def test_decision_low_log(self):
        """INFO/LOW non listés → décision 'log' (trace seule)."""
        ev = CoreEvent(type="x.tick", source="x", level=EventLevel.INFO)
        d = self.core.decide_event(ev)
        self.assertEqual(d["decision"], "log")

    def test_decide_event_accepte_dict(self):
        d = self.core.decide_event({
            "type": "user.command", "source": "voice",
            "level": EventLevel.INFO,
        })
        self.assertEqual(d["decision"], "memorize")

    def test_decide_event_fallback_sur_erreur(self):
        """Si decision_engine lève, fallback retourne décision sûre, pas de crash."""
        ev = CoreEvent(type="t", source="s", level=EventLevel.INFO)
        with patch.object(self.core._decision_engine, "decide",
                          side_effect=RuntimeError("boom intentionnel")):
            d = self.core.decide_event(ev)
        self.assertTrue(d.get("error"))
        self.assertEqual(d["decision"], "log")  # fallback déterministe
        self.assertIn("fallback_after_error", d["reason"])

    def test_decide_event_input_invalide(self):
        d = self.core.decide_event("not_an_event")
        self.assertEqual(d["decision"], "ignore")
        self.assertTrue(d["error"])


# ── Priorité numérique fine ───────────────────────────────────────────────

class TestPriorityOrdering(unittest.TestCase):

    def test_drain_ordre_par_priority_a_level_egal(self):
        """À level égal, priority numérique départage."""
        bus = EventBus()
        order = []
        bus.subscribe(lambda ev: order.append((ev.type, ev.priority)))

        # 3 events MEDIUM avec priority différentes
        bus.publish(CoreEvent(type="a", source="s", level=EventLevel.MEDIUM, priority=30), dispatch=False)
        bus.publish(CoreEvent(type="b", source="s", level=EventLevel.MEDIUM, priority=60), dispatch=False)
        bus.publish(CoreEvent(type="c", source="s", level=EventLevel.MEDIUM, priority=45), dispatch=False)
        bus._drain()

        # Ordre attendu : priority décroissante (60, 45, 30)
        priorities = [p for _, p in order]
        self.assertEqual(priorities, [60, 45, 30])

    def test_level_prime_sur_priority(self):
        """Un CRITICAL prio=0 passe avant un INFO prio=100."""
        bus = EventBus()
        order = []
        bus.subscribe(lambda ev: order.append(ev.type))

        # Critical avec priority basse, Info avec priority haute
        bus.publish(CoreEvent(type="info_high", source="s",
                              level=EventLevel.INFO, priority=99), dispatch=False)
        bus.publish(CoreEvent(type="crit_low", source="s",
                              level=EventLevel.CRITICAL, priority=1), dispatch=False)
        bus._drain()

        # Critical doit être traité en premier
        self.assertEqual(order, ["crit_low", "info_high"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
