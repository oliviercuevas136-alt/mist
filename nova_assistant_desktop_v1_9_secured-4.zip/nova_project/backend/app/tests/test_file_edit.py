"""
test_file_edit.py — Tests v1.9.7 : modification contrôlée de fichiers.

Ce fichier valide les GARANTIES DE SÉCURITÉ — pas juste le happy path.
La modification de fichiers locaux par un LLM est une surface d'attaque
sérieuse, donc on teste exhaustivement les CAS DE REFUS.

Exécution :
    cd backend
    ENABLE_STT=false ENABLE_TTS=false python -m unittest \\
        app.tests.test_file_edit -v
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, ".")


# ── Setup helper ───────────────────────────────────────────────────────────

class FileEditTestBase(unittest.TestCase):
    """Configure un dossier autorisé temporaire + un backup_dir + un dossier hors allowlist."""

    def setUp(self):
        from app.config import settings
        # Sauvegarder les originaux
        self._orig_allowed_write = settings.allowed_write_dirs
        self._orig_backup_dir    = settings.file_edit_backup_dir
        self._orig_allowed_pc    = settings.allowed_pc_actions

        # Créer 2 dossiers temporaires : un autorisé, un hors-allowlist
        self.allowed_dir  = Path(tempfile.mkdtemp(prefix="nova_write_allowed_"))
        self.outside_dir  = Path(tempfile.mkdtemp(prefix="nova_outside_"))
        self.backup_dir   = Path(tempfile.mkdtemp(prefix="nova_backups_"))

        settings.allowed_write_dirs = str(self.allowed_dir)
        settings.file_edit_backup_dir = str(self.backup_dir)
        # Accorder les permissions PC pour les tests de workflow
        settings.allowed_pc_actions = "edit_file_text,append_file_text"

    def tearDown(self):
        from app.config import settings
        settings.allowed_write_dirs   = self._orig_allowed_write
        settings.file_edit_backup_dir = self._orig_backup_dir
        settings.allowed_pc_actions   = self._orig_allowed_pc
        shutil.rmtree(self.allowed_dir, ignore_errors=True)
        shutil.rmtree(self.outside_dir, ignore_errors=True)
        shutil.rmtree(self.backup_dir,  ignore_errors=True)

    def _create_file(self, name: str, content: str, where: Path = None) -> Path:
        target = (where or self.allowed_dir) / name
        target.write_text(content, encoding="utf-8")
        return target


# ── 1. Validation de chemin — sécurité ─────────────────────────────────────

class TestPathValidation(FileEditTestBase):

    def test_chemin_vide_refuse(self):
        from app.services.file_editor import validate_path_for_write
        r = validate_path_for_write("")
        self.assertFalse(r.ok)
        self.assertIn("vide", r.reason)

    def test_chemin_hors_allowlist_refuse(self):
        from app.services.file_editor import validate_path_for_write
        # Créer un fichier hors allowlist
        p = self._create_file("evil.txt", "x", where=self.outside_dir)
        r = validate_path_for_write(str(p))
        self.assertFalse(r.ok)
        self.assertIn("hors ALLOWED_WRITE_DIRS", r.reason)

    def test_chemin_systeme_refuse(self):
        """Même si on l'ajoutait dans allowed_write_dirs, /etc reste blocklisté."""
        from app.config import settings
        from app.services.file_editor import validate_path_for_write
        settings.allowed_write_dirs = "/etc"
        r = validate_path_for_write("/etc/passwd")
        self.assertFalse(r.ok)
        # Soit blocklist soit extension non autorisée — les deux refusent
        self.assertTrue(
            "système protégé" in r.reason or "extension" in r.reason,
            r.reason,
        )

    def test_extension_non_autorisee_refuse(self):
        from app.services.file_editor import validate_path_for_write
        p = self._create_file("malware.exe", "x")
        r = validate_path_for_write(str(p))
        self.assertFalse(r.ok)
        self.assertIn("extension", r.reason)

    def test_path_traversal_resolu(self):
        """Un chemin avec ../ doit être résolu avant validation."""
        from app.services.file_editor import validate_path_for_write
        # Essayer d'évader avec ..
        evil = str(self.allowed_dir / ".." / "outside" / "x.txt")
        r = validate_path_for_write(evil)
        self.assertFalse(r.ok)
        # Doit être refusé car résolution sort de allowed
        self.assertIn("hors", r.reason.lower())

    def test_symlink_refuse(self):
        """Un fichier qui est un symlink doit être refusé."""
        from app.services.file_editor import validate_path_for_write
        target = self._create_file("real.txt", "x")
        link = self.allowed_dir / "link.txt"
        try:
            os.symlink(str(target), str(link))
        except (OSError, NotImplementedError):
            self.skipTest("symlinks non supportés sur ce système")
        r = validate_path_for_write(str(link))
        self.assertFalse(r.ok)
        self.assertIn("symbolique", r.reason)

    def test_dossier_refuse(self):
        from app.services.file_editor import validate_path_for_write
        sub = self.allowed_dir / "sub.txt"
        sub.mkdir()                   # ce sera un dossier avec extension .txt
        r = validate_path_for_write(str(sub))
        self.assertFalse(r.ok)
        self.assertIn("dossier", r.reason)

    def test_fichier_trop_grand_refuse(self):
        from app.config import settings
        from app.services.file_editor import validate_path_for_write
        settings.file_edit_max_bytes = 100   # 100 octets max
        # Créer un fichier de 200 octets
        big = self._create_file("big.txt", "x" * 200)
        r = validate_path_for_write(str(big))
        self.assertFalse(r.ok)
        self.assertIn("trop grand", r.reason)
        settings.file_edit_max_bytes = 1048576  # restaurer

    def test_chemin_valide_accepte(self):
        from app.services.file_editor import validate_path_for_write
        p = self._create_file("ok.txt", "hello")
        r = validate_path_for_write(str(p))
        self.assertTrue(r.ok, r.reason)
        self.assertIsNotNone(r.resolved)


# ── 2. Backup automatique ──────────────────────────────────────────────────

class TestBackup(FileEditTestBase):

    def test_backup_cree_avant_modification(self):
        from app.services.file_editor import create_backup
        p = self._create_file("doc.md", "version originale")
        bk = create_backup(p)
        self.assertTrue(bk.ok)
        self.assertIsNotNone(bk.backup_path)
        self.assertTrue(bk.backup_path.exists())
        self.assertEqual(bk.backup_path.read_text(encoding="utf-8"),
                         "version originale")

    def test_backup_horodate(self):
        """Le nom du backup doit contenir un timestamp."""
        from app.services.file_editor import create_backup
        p = self._create_file("doc.md", "x")
        bk = create_backup(p)
        # Format : <stem>_<hash>_<YYYYMMDD>_<HHMMSS><suffix>.bak
        import re
        self.assertRegex(bk.backup_path.name, r"_\d{8}_\d{6}.*\.bak$")

    def test_backup_inexistant_ok(self):
        """Un backup d'un fichier inexistant est OK (cas création)."""
        from app.services.file_editor import create_backup
        bk = create_backup(self.allowed_dir / "nonexistent.md")
        self.assertTrue(bk.ok)
        self.assertIsNone(bk.backup_path)


# ── 3. replace_text avec backup ────────────────────────────────────────────

class TestReplaceText(FileEditTestBase):

    def test_replace_simple_avec_backup(self):
        from app.services.file_editor import replace_text
        p = self._create_file("a.txt", "Bonjour le monde")
        res = replace_text(str(p), "monde", "Nova")
        self.assertTrue(res.ok, res.reason)
        self.assertEqual(p.read_text(), "Bonjour le Nova")
        # Backup créé
        self.assertIsNotNone(res.backup_path)
        self.assertTrue(Path(res.backup_path).exists())
        self.assertEqual(Path(res.backup_path).read_text(),
                         "Bonjour le monde")  # contenu original

    def test_replace_old_non_trouve(self):
        from app.services.file_editor import replace_text
        p = self._create_file("a.txt", "Bonjour")
        res = replace_text(str(p), "absent", "x")
        self.assertFalse(res.ok)
        self.assertIn("non trouvée", res.reason)
        # Aucun backup créé (fail avant)
        backups = list((self.backup_dir).iterdir())
        self.assertEqual(len(backups), 0)

    def test_replace_n_occurrences(self):
        from app.services.file_editor import replace_text
        p = self._create_file("a.txt", "x x x x")
        # count=2 → ne remplace que les 2 premiers
        res = replace_text(str(p), "x", "Y", count=2)
        self.assertTrue(res.ok)
        self.assertEqual(p.read_text(), "Y Y x x")

    def test_replace_dans_chemin_systeme_refuse(self):
        from app.services.file_editor import replace_text
        res = replace_text("/etc/passwd", "root", "hacker")
        self.assertFalse(res.ok)

    def test_replace_dans_hors_allowlist_refuse(self):
        from app.services.file_editor import replace_text
        p = self._create_file("evil.txt", "data", where=self.outside_dir)
        res = replace_text(str(p), "data", "hacked")
        self.assertFalse(res.ok)
        # Le fichier n'a PAS été modifié
        self.assertEqual(p.read_text(), "data")

    def test_replace_extension_exe_refuse(self):
        from app.services.file_editor import replace_text
        p = self._create_file("x.exe", "binary")
        res = replace_text(str(p), "binary", "hacked")
        self.assertFalse(res.ok)


# ── 4. append_text ─────────────────────────────────────────────────────────

class TestAppendText(FileEditTestBase):

    def test_append_simple(self):
        from app.services.file_editor import append_text
        p = self._create_file("log.txt", "ligne 1\n")
        res = append_text(str(p), "ligne 2\n")
        self.assertTrue(res.ok, res.reason)
        self.assertEqual(p.read_text(), "ligne 1\nligne 2\n")
        # Backup créé
        self.assertTrue(Path(res.backup_path).exists())

    def test_append_refuse_si_fichier_inexistant(self):
        from app.services.file_editor import append_text
        res = append_text(str(self.allowed_dir / "nonexistent.md"), "x")
        self.assertFalse(res.ok)


# ── 5. Workflow complet propose → confirm → execute ────────────────────────

class TestActionManagerWorkflow(FileEditTestBase):

    def _new_manager(self):
        """ActionManager neuf (les permissions sont lues dynamiquement)."""
        import app.services.action_manager as am_mod
        # Reset singleton
        am_mod._instance = None
        return am_mod.get_action_manager()

    def test_workflow_complet_edit(self):
        am = self._new_manager()
        p = self._create_file("readme.md", "Hello Foo")

        # Phase 1 : propose
        r1 = am.propose_action("edit_file_text", {
            "path": str(p), "old": "Foo", "new": "Bar",
        })
        self.assertTrue(r1["ok"], r1.get("denied_reason"))
        self.assertIn("preview", r1)
        # La consigne demande : fichier ciblé, changement prévu
        self.assertEqual(r1["preview"]["target"], str(p))
        self.assertIn("diff_summary", r1["preview"])
        # confirmation_token présent
        ctok = r1["confirmation_token"]

        # Fichier toujours intact
        self.assertEqual(p.read_text(), "Hello Foo")

        # Phase 2 : confirm
        r2 = am.confirm_action(ctok)
        self.assertTrue(r2["ok"])
        etok = r2["execution_token"]

        # Toujours intact
        self.assertEqual(p.read_text(), "Hello Foo")

        # Phase 3 : execute
        r3 = am.execute_action(etok)
        self.assertTrue(r3["ok"], r3.get("denied_reason"))
        # Modification effective
        self.assertEqual(p.read_text(), "Hello Bar")
        # Backup référencé dans le résultat
        self.assertIn("backup_path", r3["result"])
        self.assertTrue(Path(r3["result"]["backup_path"]).exists())

    def test_workflow_refuse_sans_permission(self):
        from app.config import settings
        settings.allowed_pc_actions = ""   # AUCUNE permission
        am = self._new_manager()
        p = self._create_file("readme.md", "x")
        r = am.propose_action("edit_file_text", {
            "path": str(p), "old": "x", "new": "y",
        })
        self.assertFalse(r["ok"])
        self.assertIn("permission", r["denied_reason"].lower())

    def test_workflow_refuse_path_hors_allowlist(self):
        am = self._new_manager()
        p = self._create_file("evil.txt", "x", where=self.outside_dir)
        r = am.propose_action("edit_file_text", {
            "path": str(p), "old": "x", "new": "y",
        })
        self.assertFalse(r["ok"])

    def test_workflow_refuse_old_inexistant_au_propose(self):
        am = self._new_manager()
        p = self._create_file("a.txt", "Hello")
        r = am.propose_action("edit_file_text", {
            "path": str(p), "old": "ABSENT", "new": "y",
        })
        # propose doit refuser via preview
        self.assertFalse(r["ok"])
        self.assertIn("preview", r.get("denied_reason", "").lower())

    def test_workflow_execute_sans_propose_refuse(self):
        """Bypass workflow : appeler execute sans token valide."""
        am = self._new_manager()
        r = am.execute_action("token_inventé")
        self.assertFalse(r["ok"])

    def test_workflow_confirm_token_unique(self):
        """Un confirmation_token ne peut être confirmé qu'une fois."""
        am = self._new_manager()
        p = self._create_file("a.txt", "Hello")
        r1 = am.propose_action("edit_file_text",
                                {"path": str(p), "old": "Hello", "new": "World"})
        ctok = r1["confirmation_token"]
        r2 = am.confirm_action(ctok)
        self.assertTrue(r2["ok"])
        # Deuxième confirm avec le même token → refus
        r3 = am.confirm_action(ctok)
        self.assertFalse(r3["ok"])

    def test_aperçu_propose_contient_diff(self):
        """La consigne demande explicitement d'afficher le changement prévu."""
        am = self._new_manager()
        p = self._create_file("a.txt", "version1")
        r = am.propose_action("edit_file_text", {
            "path": str(p), "old": "1", "new": "2",
        })
        self.assertTrue(r["ok"])
        preview = r["preview"]
        self.assertIn("diff_summary", preview)
        self.assertIn("bytes_before", preview)
        self.assertIn("bytes_after", preview)
        self.assertIn("occurrences", preview)


# ── 6. Pas d'actions destructives ─────────────────────────────────────────

class TestNoDestructiveOps(FileEditTestBase):

    def test_pas_de_handler_delete(self):
        """Aucune action ne doit s'appeler 'delete_file' ou 'remove'."""
        from app.services.action_manager import _ACTION_DESCRIPTORS
        for forbidden in ("delete_file", "remove_file", "rm",
                           "shell_exec", "execute_command", "system"):
            self.assertNotIn(forbidden, _ACTION_DESCRIPTORS,
                             f"action interdite présente: {forbidden}")

    def test_pas_de_permission_destructive(self):
        from app.services.action_manager import Permission, _ALL_PERMISSIONS
        for forbidden in ("delete_file", "shell_exec", "rm", "execute_command"):
            self.assertNotIn(forbidden, _ALL_PERMISSIONS)


# ── 7. Non-régression ─────────────────────────────────────────────────────

class TestNonRegression(FileEditTestBase):

    def test_existing_actions_inchanged(self):
        """v1.9.3 : open_file, launch_application, kill_process, move_files,
        cleanup_folder, backup_files doivent toujours être enregistrées."""
        from app.services.action_manager import _ACTION_DESCRIPTORS
        for required in ("open_file", "launch_application", "kill_process",
                          "move_files", "cleanup_folder", "backup_files"):
            self.assertIn(required, _ACTION_DESCRIPTORS,
                          f"action manquante après v1.9.7: {required}")

    def test_sandbox_existant_inchange(self):
        from app.services.sandbox import check_path, SandboxDecision
        # /etc/passwd toujours refusé
        d, _ = check_path("/etc/passwd", "write")
        self.assertEqual(d, SandboxDecision.DENY)


if __name__ == "__main__":
    unittest.main(verbosity=2)
