"""
test_security_stack.py — Tests Sandbox / ActionManager / RiskEngine / SystemMonitor.

Exécuter :
    cd backend
    ENABLE_STT=false ENABLE_TTS=false python -m unittest app.tests.test_security_stack -v
"""

from __future__ import annotations

import sys
import time
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, ".")

from app.services.sandbox import (
    SandboxDecision, check_path, check_process_kill, check_executable,
)


# ── Sandbox ────────────────────────────────────────────────────────────────

class TestSandbox(unittest.TestCase):

    def test_path_systeme_refuse(self):
        for path in [
            "C:/Windows/System32/cmd.exe",
            "/etc/passwd",
            "/root/.ssh/id_rsa",
            "/proc/cpuinfo",
            "C:\\Program Files\\app",
            "/home/oli/.ssh/known_hosts",
        ]:
            d, r = check_path(path, "read")
            self.assertEqual(d, SandboxDecision.DENY, f"{path} aurait dû être refusé")
            self.assertIsNotNone(r)

    def test_path_traversal_refuse(self):
        d, r = check_path("/tmp/../etc/shadow", "read")
        # /etc est dans la blocklist donc deny via _PROTECTED_PATH_PATTERNS
        self.assertEqual(d, SandboxDecision.DENY)

    def test_path_user_autorise(self):
        d, r = check_path("/home/oli/Documents/notes.md", "read")
        self.assertEqual(d, SandboxDecision.ALLOW)

    def test_execute_blocked_extensions(self):
        for ext in ["x.exe", "y.bat", "z.cmd", "w.scr", "v.ps1"]:
            d, r = check_path(f"/home/x/{ext}", "execute")
            self.assertEqual(d, SandboxDecision.DENY, f"{ext} aurait dû être bloqué")

    def test_process_kill_protege(self):
        for name in ["explorer.exe", "svchost.exe", "lsass.exe",
                     "kernel_task", "systemd", "init"]:
            d, r = check_process_kill(name)
            self.assertEqual(d, SandboxDecision.DENY, f"{name} aurait dû être protégé")

    def test_process_kill_pid_systeme(self):
        for pid in [0, 1]:
            d, r = check_process_kill(str(pid))
            self.assertEqual(d, SandboxDecision.DENY)

    def test_process_kill_user_autorise(self):
        d, r = check_process_kill("firefox.exe")
        self.assertEqual(d, SandboxDecision.ALLOW)

    def test_executable_dangereux_refuse(self):
        for cmd in ["format", "diskpart", "regedit", "shutdown", "netsh.exe"]:
            d, r = check_executable(cmd)
            self.assertEqual(d, SandboxDecision.DENY, f"{cmd}")

    def test_executable_normal_autorise(self):
        for cmd in ["notepad.exe", "code.exe", "firefox"]:
            d, r = check_executable(cmd)
            self.assertEqual(d, SandboxDecision.ALLOW, f"{cmd}")


# ── ActionManager ──────────────────────────────────────────────────────────

class TestActionManager(unittest.TestCase):

    def setUp(self):
        from app.services.action_manager import ActionManager, get_action_manager
        from app.config import settings
        # Fresh manager pour ne pas polluer l'audit global
        self.am = ActionManager()
        # Sauvegarder + reset config
        self._original_perms = settings.allowed_pc_actions
        settings.allowed_pc_actions = ""

    def tearDown(self):
        from app.config import settings
        settings.allowed_pc_actions = self._original_perms

    def _grant(self, *perms):
        from app.config import settings
        settings.allowed_pc_actions = ",".join(perms)

    def test_action_inconnue_refusee(self):
        r = self.am.propose_action("erase_all_files", {})
        self.assertFalse(r["ok"])
        self.assertIn("inconnue", r["denied_reason"])

    def test_permission_vide_refuse_tout(self):
        r = self.am.propose_action("open_file", {"path": "/home/x/file.txt"})
        self.assertFalse(r["ok"])
        self.assertIn("permission refusée", r["denied_reason"])

    def test_permission_accordee_propose(self):
        self._grant("open_file")
        r = self.am.propose_action("open_file", {"path": "/home/x/notes.md"})
        self.assertTrue(r["ok"])
        self.assertIn("confirmation_token", r)

    def test_sandbox_refuse_chemin_systeme(self):
        self._grant("open_file")
        r = self.am.propose_action("open_file", {"path": "/etc/passwd"})
        self.assertFalse(r["ok"])
        self.assertIn("système", r["denied_reason"].lower())

    def test_sandbox_refuse_kill_process_protege(self):
        self._grant("kill_process")
        r = self.am.propose_action("kill_process", {"target": "explorer.exe"})
        self.assertFalse(r["ok"])

    def test_workflow_complet_3_phases(self):
        """Propose → confirm → execute avec mock du handler."""
        self._grant("open_file")
        # Mock du handler pour ne pas vraiment ouvrir
        from app.services import action_manager as am_mod
        original = am_mod._ACTION_DESCRIPTORS["open_file"]["handler"]
        am_mod._ACTION_DESCRIPTORS["open_file"]["handler"] = \
            lambda params: {"mock_opened": params["path"]}
        try:
            r1 = self.am.propose_action("open_file", {"path": "/home/x/notes.md"})
            self.assertTrue(r1["ok"])
            conf_token = r1["confirmation_token"]

            r2 = self.am.confirm_action(conf_token)
            self.assertTrue(r2["ok"])
            exec_token = r2["execution_token"]

            r3 = self.am.execute_action(exec_token)
            self.assertTrue(r3["ok"])
            self.assertIn("mock_opened", r3["result"])
        finally:
            am_mod._ACTION_DESCRIPTORS["open_file"]["handler"] = original

    def test_token_unique_usage(self):
        """Le token d'exécution ne peut servir qu'une fois."""
        self._grant("open_file")
        from app.services import action_manager as am_mod
        original = am_mod._ACTION_DESCRIPTORS["open_file"]["handler"]
        am_mod._ACTION_DESCRIPTORS["open_file"]["handler"] = lambda params: {"ok": True}
        try:
            r1 = self.am.propose_action("open_file", {"path": "/home/x/a.md"})
            r2 = self.am.confirm_action(r1["confirmation_token"])
            r3 = self.am.execute_action(r2["execution_token"])
            self.assertTrue(r3["ok"])
            # Réutilisation du même execution_token
            r4 = self.am.execute_action(r2["execution_token"])
            self.assertFalse(r4["ok"])
        finally:
            am_mod._ACTION_DESCRIPTORS["open_file"]["handler"] = original

    def test_confirmation_token_inconnu(self):
        r = self.am.confirm_action("fake_token_xxxxxxxxxxxxxxxx")
        self.assertFalse(r["ok"])

    def test_cleanup_folder_max_files(self):
        """Cleanup refuse si > max_files."""
        import tempfile, os
        self._grant("cleanup_folder")
        with tempfile.TemporaryDirectory() as tmp:
            # Créer 5 fichiers
            for i in range(5):
                with open(f"{tmp}/f{i}.tmp", "w") as f:
                    f.write("x")
            r1 = self.am.propose_action("cleanup_folder",
                                        {"folder": tmp, "max_files": 2})
            self.assertTrue(r1["ok"])  # propose OK (sandbox autorise /tmp)
            r2 = self.am.confirm_action(r1["confirmation_token"])
            r3 = self.am.execute_action(r2["execution_token"])
            # execute refuse car 5 > max_files=2
            self.assertFalse(r3["ok"])
            self.assertIn("max_files", r3["denied_reason"])


# ── RiskEngine ─────────────────────────────────────────────────────────────

class TestRiskEngine(unittest.TestCase):

    def test_compute_returns_three_scores(self):
        from app.services.risk_engine import RiskEngine
        engine = RiskEngine()
        scores = engine.compute()
        self.assertIsInstance(scores.danger, int)
        self.assertIsInstance(scores.anomaly, int)
        self.assertIsInstance(scores.confidence, int)
        self.assertTrue(0 <= scores.danger <= 100)
        self.assertTrue(0 <= scores.anomaly <= 100)
        self.assertTrue(0 <= scores.confidence <= 100)

    def test_danger_increase_with_fall_event(self):
        """Un event vision.fall doit augmenter le score danger."""
        from app.services.risk_engine import RiskEngine
        from app.core.event_bus import get_event_bus, CoreEvent, EventLevel

        bus = get_event_bus()
        # Nettoyer cooldown pour ce type
        bus._cooldown._last_seen.pop("vision.fall|test", None)
        bus.publish(CoreEvent(
            type="vision.fall", source="test",
            level=EventLevel.CRITICAL, message="chute test",
        ))
        engine = RiskEngine()
        scores = engine.compute()
        self.assertGreater(scores.danger, 0, "danger doit augmenter après vision.fall")


# ── SystemMonitor (smoke) ──────────────────────────────────────────────────

class TestSystemMonitor(unittest.TestCase):

    def test_snapshot_structure(self):
        """Snapshot a tous les champs documentés."""
        from app.services.system_monitor import SystemMonitor, _PSUTIL_OK
        if not _PSUTIL_OK:
            self.skipTest("psutil non disponible")
        sm = SystemMonitor(interval_sec=10.0)
        snap = sm._take_snapshot()
        d = snap.to_dict()
        for f in ["timestamp", "cpu_percent", "cpu_count", "ram_percent",
                  "ram_used_mb", "disk_usage", "net_io", "process_count",
                  "top_processes", "boot_time", "uptime_sec"]:
            self.assertIn(f, d, f"champ {f} manquant")

    def test_thresholds_default(self):
        from app.services.system_monitor import SystemMonitor
        sm = SystemMonitor()
        t = sm.get_thresholds()
        self.assertIn("cpu_high", t)
        self.assertIn("ram_critical", t)

    def test_thresholds_update(self):
        from app.services.system_monitor import SystemMonitor
        sm = SystemMonitor()
        new = sm.set_thresholds(cpu_high=70.0, ram_critical=90.0)
        self.assertEqual(new["cpu_high"], 70.0)
        self.assertEqual(new["ram_critical"], 90.0)

    def test_start_stop_propre(self):
        """Thread doit démarrer puis s'arrêter sans laisser de zombie."""
        from app.services.system_monitor import SystemMonitor, _PSUTIL_OK
        if not _PSUTIL_OK:
            self.skipTest("psutil indispo")
        sm = SystemMonitor(interval_sec=0.5, history_size=10)
        self.assertFalse(sm.is_running())
        sm.start()
        time.sleep(1.2)  # laisser au moins un cycle
        self.assertTrue(sm.is_running())
        self.assertIsNotNone(sm.get_latest())
        sm.stop()
        self.assertFalse(sm.is_running())


if __name__ == "__main__":
    unittest.main(verbosity=2)
