"""
test_security_watch.py — Tests unitaires pour les surveillances sécurité.

Couvre :
  - ProcessWatcher : diff entre snapshots, classification, init silencieux
  - SuspiciousFileWatcher : scan extensions, déduplication, allowlist
  - NetworkWatcher : structure de retour
  - DeviceWatcher : structure + comportement multiplateforme
  - StartupWatcher : stub propre sur non-Windows
  - Vérification : tous les watchers publient via orchestrator.submit_event()
  - Non-régression : permissions et sandbox inchangées
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, ".")


# ── ProcessWatcher ─────────────────────────────────────────────────────────

class TestProcessWatcher(unittest.TestCase):

    def setUp(self):
        from app.services.security_watch import ProcessWatcher
        self.w = ProcessWatcher()

    def test_scan_disponible(self):
        result = self.w.scan()
        self.assertTrue(result.get("available"))
        # Premier scan : initial_scan=True, pas d'alerte
        self.assertTrue(result.get("initial_scan"))
        self.assertGreater(result.get("total_processes", 0), 0)

    def test_second_scan_compare(self):
        """Deuxième scan ne déclenche plus initial_scan."""
        self.w.scan()
        r2 = self.w.scan()
        self.assertFalse(r2.get("initial_scan"))
        self.assertIn("new", r2)
        self.assertIn("gone_count", r2)

    def test_detect_nouveau_processus_unknown(self):
        """Si un nouveau processus apparaît avec nom inconnu → event publié."""
        from app.services.security_watch import ProcessWatcher
        w = ProcessWatcher()
        # Premier scan vide via mock
        with patch("app.services.security_watch.psutil.process_iter") as mock_pi:
            mock_pi.return_value = []
            r1 = w.scan()
            self.assertTrue(r1["initial_scan"])

        # Second scan : processus "unknown_app.bin"
        fake_p = MagicMock()
        fake_p.info = {"pid": 99999, "name": "unknown_app.bin",
                       "exe": "/home/x/unknown_app.bin",
                       "create_time": time.time(), "username": "oli"}
        published = []

        def fake_publish(*args, **kwargs):
            published.append((args, kwargs))

        with patch("app.services.security_watch.psutil.process_iter", return_value=[fake_p]), \
             patch("app.services.security_watch._publish", side_effect=fake_publish):
            r2 = w.scan()

        self.assertEqual(len(r2["new"]), 1)
        self.assertEqual(r2["new"][0]["classification"], "unknown")
        # Un event publié
        self.assertEqual(len(published), 1)
        self.assertEqual(published[0][0][0], "security.new_process")
        self.assertEqual(published[0][0][1], "medium")

    def test_detect_suspicious_par_temp(self):
        """Processus depuis /tmp/ → classification suspicious."""
        from app.services.security_watch import ProcessWatcher
        w = ProcessWatcher()
        with patch("app.services.security_watch.psutil.process_iter", return_value=[]):
            w.scan()

        fake_p = MagicMock()
        fake_p.info = {"pid": 77777, "name": "anything.exe",
                       "exe": "/tmp/anything.exe",
                       "create_time": time.time(), "username": "oli"}
        published = []
        with patch("app.services.security_watch.psutil.process_iter", return_value=[fake_p]), \
             patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published.append((a, kw))):
            w.scan()
        self.assertEqual(len(published), 1)
        self.assertEqual(published[0][0][0], "security.suspicious_proc")
        self.assertEqual(published[0][0][1], "high")

    def test_detect_suspicious_keyword(self):
        """Nom contenant 'keylog' → suspicious."""
        from app.services.security_watch import ProcessWatcher
        w = ProcessWatcher()
        with patch("app.services.security_watch.psutil.process_iter", return_value=[]):
            w.scan()
        fake_p = MagicMock()
        fake_p.info = {"pid": 1234, "name": "stealth_keylogger.exe",
                       "exe": "/home/x/stealth_keylogger.exe",
                       "create_time": time.time(), "username": "oli"}
        published = []
        with patch("app.services.security_watch.psutil.process_iter", return_value=[fake_p]), \
             patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published.append((a, kw))):
            w.scan()
        self.assertEqual(published[0][0][0], "security.suspicious_proc")

    def test_known_system_pas_alerte(self):
        """Un nouveau process 'svchost.exe' = known → pas d'event."""
        from app.services.security_watch import ProcessWatcher
        w = ProcessWatcher()
        with patch("app.services.security_watch.psutil.process_iter", return_value=[]):
            w.scan()
        fake_p = MagicMock()
        fake_p.info = {"pid": 1500, "name": "svchost.exe",
                       "exe": "C:/Windows/System32/svchost.exe",
                       "create_time": time.time(), "username": "SYSTEM"}
        published = []
        with patch("app.services.security_watch.psutil.process_iter", return_value=[fake_p]), \
             patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published.append(a)):
            w.scan()
        self.assertEqual(len(published), 0)


# ── SuspiciousFileWatcher ──────────────────────────────────────────────────

class TestSuspiciousFileWatcher(unittest.TestCase):

    def setUp(self):
        from app.config import settings
        self.tmp = tempfile.mkdtemp(prefix="nova_sec_files_")
        self._original_allowed = settings.allowed_search_dirs
        settings.allowed_search_dirs = self.tmp

        # Reset singleton FileSearch (sinon il garde l'ancien)
        import app.services.file_search as fs_mod
        fs_mod._instance = None

        from app.services.security_watch import SuspiciousFileWatcher
        self.w = SuspiciousFileWatcher()

    def tearDown(self):
        import shutil
        from app.config import settings
        settings.allowed_search_dirs = self._original_allowed
        shutil.rmtree(self.tmp, ignore_errors=True)
        import app.services.file_search as fs_mod
        fs_mod._instance = None

    def _create(self, name, content="x"):
        p = Path(self.tmp) / name
        p.write_text(content)
        return p

    def test_detecte_exe_recent(self):
        self._create("malware_test.exe")
        published = []
        with patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published.append(a)):
            r = self.w.scan(max_age_sec=3600)
        self.assertTrue(r["available"])
        self.assertEqual(len(r["found"]), 1)
        self.assertEqual(r["found"][0]["extension"], ".exe")
        self.assertEqual(len(published), 1)
        self.assertEqual(published[0][0], "security.suspicious_file")

    def test_ignore_extension_normale(self):
        self._create("notes.txt")
        self._create("script.py")
        r = self.w.scan(max_age_sec=3600)
        self.assertEqual(len(r["found"]), 0)

    def test_detecte_toutes_extensions_demandees(self):
        # Consigne : .exe, .bat, .cmd, .ps1, .vbs
        for ext in (".exe", ".bat", ".cmd", ".ps1", ".vbs"):
            self._create(f"f{ext}")
        published = []
        with patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published.append(a)):
            r = self.w.scan(max_age_sec=3600)
        found_exts = sorted({f["extension"] for f in r["found"]})
        for ext in (".exe", ".bat", ".cmd", ".ps1", ".vbs"):
            self.assertIn(ext, found_exts, f"{ext} non détecté")
        self.assertEqual(len(published), 5)

    def test_ignore_fichier_ancien(self):
        p = self._create("old.exe")
        # Vieillir le fichier
        old_time = time.time() - 100000
        os.utime(p, (old_time, old_time))
        r = self.w.scan(max_age_sec=3600)
        self.assertEqual(len(r["found"]), 0)

    def test_pas_de_doublon(self):
        """Deuxième scan sur même fichier non modifié → pas re-signalé."""
        self._create("a.exe")
        published1 = []
        with patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published1.append(a)):
            self.w.scan(max_age_sec=3600)
        # Second scan immédiat — fichier inchangé
        published2 = []
        with patch("app.services.security_watch._publish",
                   side_effect=lambda *a, **kw: published2.append(a)):
            self.w.scan(max_age_sec=3600)
        self.assertEqual(len(published1), 1)
        self.assertEqual(len(published2), 0, "doublon : ne doit pas re-signaler")

    def test_indisponible_sans_allowlist(self):
        from app.config import settings
        settings.allowed_search_dirs = ""
        import app.services.file_search as fs_mod
        fs_mod._instance = None
        from app.services.security_watch import SuspiciousFileWatcher
        w = SuspiciousFileWatcher()
        r = w.scan()
        self.assertFalse(r["available"])
        self.assertIn("ALLOWED_SEARCH_DIRS", r["reason"])


# ── NetworkWatcher ─────────────────────────────────────────────────────────

class TestNetworkWatcher(unittest.TestCase):

    def test_scan_retour_structure(self):
        from app.services.security_watch import NetworkWatcher
        w = NetworkWatcher()
        r = w.scan()
        # Peut être available=True ou False selon permissions sandbox
        self.assertIn("available", r)
        if r["available"]:
            self.assertIn("listening", r)
            self.assertIn("total", r)
            self.assertIsInstance(r["listening"], list)


# ── DeviceWatcher ──────────────────────────────────────────────────────────

class TestDeviceWatcher(unittest.TestCase):

    def test_scan_retour_structure(self):
        from app.services.security_watch import DeviceWatcher
        w = DeviceWatcher()
        r = w.scan()
        self.assertIn("available", r)
        if r["available"]:
            self.assertIn("webcam_users", r)
            self.assertIn("mic_users", r)
            self.assertIn("reliability", r)


# ── StartupWatcher ─────────────────────────────────────────────────────────

class TestStartupWatcher(unittest.TestCase):

    def test_stub_propre_sur_non_windows(self):
        import platform
        from app.services.security_watch import StartupWatcher
        w = StartupWatcher()
        r = w.scan()
        if platform.system() != "Windows":
            self.assertFalse(r["available"])
            self.assertIn("Windows", r.get("reason", ""))
        else:
            # Sur Windows : doit retourner des entries (peut être vide)
            self.assertTrue(r["available"])
            self.assertIsInstance(r["entries"], list)


# ── Intégration : tous les events passent par le CORE ─────────────────────

class TestCorePublication(unittest.TestCase):

    def test_publish_appelle_orchestrator_submit_event(self):
        """Le helper _publish doit appeler orchestrator.submit_event."""
        from app.services import security_watch
        submitted = []

        class FakeOrch:
            def submit_event(self, ev):
                submitted.append(ev)
                return {"accepted": True, "event_id": ev.id}

        # Monkeypatch l'import dans _publish
        # (l'import est tardif dans la fonction → doit-être patchable)
        with patch("app.core.orchestrator.orchestrator", FakeOrch()):
            security_watch._publish(
                "security.test_event", "info", "test message",
                payload={"k": "v"},
            )
        self.assertEqual(len(submitted), 1)
        ev = submitted[0]
        self.assertEqual(ev.type, "security.test_event")
        self.assertEqual(ev.source, "security_watch")
        self.assertEqual(ev.payload["k"], "v")


# ── Non-régression : permissions et sandbox ───────────────────────────────

class TestNonRegression(unittest.TestCase):
    """S'assure que les modules permissions/sandbox n'ont pas été modifiés."""

    def test_sandbox_path_systeme_toujours_refuse(self):
        from app.services.sandbox import check_path, SandboxDecision
        d, _ = check_path("/etc/passwd", "read")
        self.assertEqual(d, SandboxDecision.DENY)
        d, _ = check_path("C:/Windows/System32/cmd.exe", "read")
        self.assertEqual(d, SandboxDecision.DENY)

    def test_action_manager_workflow_3_phases(self):
        from app.services.action_manager import ActionManager
        from app.config import settings
        original = settings.allowed_pc_actions
        try:
            settings.allowed_pc_actions = "open_file"
            am = ActionManager()
            r = am.propose_action("open_file", {"path": "/home/x/notes.md"})
            self.assertTrue(r["ok"])
            self.assertIn("confirmation_token", r)
        finally:
            settings.allowed_pc_actions = original


if __name__ == "__main__":
    unittest.main(verbosity=2)
