"""
test_semantic_index.py — Tests v1.9.8 : index sémantique local.

Couvre :
  - Indexation : extraction, chunking, hash, incrémental
  - Sécurité : allowlist, blocklist, extensions, symlinks
  - Catégorisation : règles déterministes
  - Recherche : BM25 (toujours), sémantique (skip si Ollama indispo)
  - Performance : indexation 50 fichiers < 5s, recherche < 1s
  - Non-régression : DB existante intacte

Exécution :
    cd backend
    ENABLE_STT=false ENABLE_TTS=false python -m unittest \\
        app.tests.test_semantic_index -v
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, ".")


class SemanticIndexTestBase(unittest.TestCase):
    """Setup commun : DB en mémoire + dossier autorisé + dossier hors-allowlist."""

    def setUp(self):
        from app.config import settings

        # Backup settings
        self._orig_allowed_index = settings.allowed_index_dirs

        # Dossiers temporaires
        self.allowed_dir = Path(tempfile.mkdtemp(prefix="nova_index_"))
        self.outside_dir = Path(tempfile.mkdtemp(prefix="nova_outside_"))
        settings.allowed_index_dirs = str(self.allowed_dir)

        # DB en mémoire isolée par test
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from app.db.database import Base
        from app.db import models  # noqa: F401 — force enregistrement des modèles
        self.engine = create_engine(
            "sqlite:///:memory:",
            connect_args={"check_same_thread": False},
        )
        Base.metadata.create_all(bind=self.engine)
        self.SessionLocal = sessionmaker(bind=self.engine)
        self.db = self.SessionLocal()

        # Reset singletons pour repartir propre
        import app.services.semantic_index as si_mod
        si_mod._instance = None

    def tearDown(self):
        from app.config import settings
        settings.allowed_index_dirs = self._orig_allowed_index
        try:
            self.db.close()
        except Exception:
            pass
        shutil.rmtree(self.allowed_dir, ignore_errors=True)
        shutil.rmtree(self.outside_dir, ignore_errors=True)
        import app.services.semantic_index as si_mod
        si_mod._instance = None

    def _create_file(self, name: str, content: str,
                      where: Path = None) -> Path:
        target = (where or self.allowed_dir) / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return target


# ── 1. Sécurité : allowlist + blocklist ───────────────────────────────────

class TestSecurity(SemanticIndexTestBase):

    def test_indexation_hors_allowlist_refusee(self):
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("x.txt", "hello", where=self.outside_dir)
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertFalse(r["ok"])
        self.assertIn("hors", r["reason"].lower())

    def test_systeme_protege_refuse(self):
        from app.config import settings
        from app.services.semantic_index import get_semantic_index
        # Même en l'ajoutant dans allowed_index_dirs, /etc reste blocklisté
        settings.allowed_index_dirs = "/etc"
        # Reset singleton
        import app.services.semantic_index as si_mod
        si_mod._instance = None
        r = get_semantic_index().index_file(self.db, "/etc/hosts")
        self.assertFalse(r["ok"])

    def test_extension_non_indexable_refusee(self):
        from app.services.semantic_index import get_semantic_index
        # Créer un fichier au sein de l'allowlist mais avec extension interdite
        p = self.allowed_dir / "malware.exe"
        p.write_bytes(b"\x00\x01\x02")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertFalse(r["ok"])
        self.assertIn("extension", r["reason"].lower())

    def test_allowlist_vide_refuse_tout(self):
        from app.config import settings
        from app.services.semantic_index import get_semantic_index
        settings.allowed_index_dirs = ""
        import app.services.semantic_index as si_mod
        si_mod._instance = None
        # Créer quand même un fichier
        p = self._create_file("x.txt", "hello")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertFalse(r["ok"])
        self.assertIn("ALLOWED_INDEX_DIRS", r["reason"])


# ── 2. Indexation basique ─────────────────────────────────────────────────

class TestIndexing(SemanticIndexTestBase):

    def test_indexation_simple(self):
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("notes.md", "# Mes notes\n\nNova est mon assistant.")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertTrue(r["ok"], r.get("reason"))
        self.assertEqual(r["chunks"], 1)
        self.assertGreater(r["size_bytes"], 0)

    def test_indexation_chunking_grand_fichier(self):
        from app.services.semantic_index import get_semantic_index
        # Forcer plusieurs chunks
        big = "ligne d'exemple\n" * 200    # ~3000 chars
        p = self._create_file("big.txt", big)
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertTrue(r["ok"])
        self.assertGreater(r["chunks"], 1)

    def test_indexation_idempotente(self):
        """Deuxième indexation sans changement → skipped."""
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("a.md", "Hello world")
        si = get_semantic_index()
        r1 = si.index_file(self.db, str(p))
        self.assertTrue(r1["ok"])
        self.assertFalse(r1.get("skipped"))
        r2 = si.index_file(self.db, str(p))
        self.assertTrue(r2["ok"])
        self.assertTrue(r2["skipped"], "deuxième indexation doit être skip")

    def test_reindexation_si_modifie(self):
        """Si le contenu change, le hash diffère → réindexation effective."""
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("a.md", "v1")
        si = get_semantic_index()
        si.index_file(self.db, str(p))
        # Modifier
        p.write_text("v2 - différent")
        r = si.index_file(self.db, str(p))
        self.assertTrue(r["ok"])
        self.assertFalse(r.get("skipped", False))

    def test_indexation_directory(self):
        from app.services.semantic_index import get_semantic_index
        for i in range(5):
            self._create_file(f"file{i}.txt", f"Contenu {i}")
        r = get_semantic_index().index_directory(self.db, str(self.allowed_dir))
        self.assertTrue(r["ok"])
        self.assertEqual(r["indexed"], 5)
        self.assertEqual(r["failed"], 0)

    def test_cleanup_supprime_fichiers_disparus(self):
        from app.services.semantic_index import get_semantic_index
        from app.db.models import IndexedDocument
        si = get_semantic_index()
        p = self._create_file("temp.md", "x")
        si.index_file(self.db, str(p))
        self.assertEqual(self.db.query(IndexedDocument).count(), 1)
        # Supprimer le fichier physiquement
        p.unlink()
        r = si.remove_missing(self.db)
        self.assertEqual(r["removed"], 1)
        self.assertEqual(self.db.query(IndexedDocument).count(), 0)


# ── 3. Catégorisation ─────────────────────────────────────────────────────

class TestCategorization(SemanticIndexTestBase):

    def test_securite_categorisee(self):
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("sandbox.py", "from app.services.sandbox import check_path")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertEqual(r["category"], "securité")

    def test_trading_categorise(self):
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("arkéon.md", "Notes sur le bot Binance et le portfolio")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertEqual(r["category"], "trading")

    def test_ia_categorise(self):
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("ollama_notes.md", "Comment utiliser Ollama avec llama")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertEqual(r["category"], "ia")

    def test_autre_si_aucun_match(self):
        from app.services.semantic_index import get_semantic_index
        p = self._create_file("xyz.txt", "blah blah générique")
        r = get_semantic_index().index_file(self.db, str(p))
        self.assertEqual(r["category"], "autres")


# ── 4. Recherche ─────────────────────────────────────────────────────────

class TestSearch(SemanticIndexTestBase):

    def test_recherche_lexicale_marche_sans_embeddings(self):
        """BM25 fonctionne même sans embeddings."""
        from app.services.semantic_index import get_semantic_index
        from unittest.mock import patch

        si = get_semantic_index()
        # Indexer quelques docs
        self._create_file("a.md", "Le chien court vite dans le parc")
        self._create_file("b.md", "Une voiture rapide sur la route")
        self._create_file("c.md", "Recette de tarte aux pommes")
        si.index_directory(self.db, str(self.allowed_dir))

        # Forcer fallback sans embeddings
        with patch("app.services.embedding_client.EmbeddingClient.is_available",
                    return_value=False):
            r = si.search(self.db, "chien parc", k=3)
        self.assertTrue(r["ok"])
        self.assertFalse(r["use_semantic"])
        self.assertGreater(len(r["results"]), 0)
        # Le premier résultat doit être a.md
        self.assertIn("chien", r["results"][0]["preview"].lower())

    def test_recherche_query_vide(self):
        from app.services.semantic_index import get_semantic_index
        r = get_semantic_index().search(self.db, "")
        self.assertFalse(r["ok"])

    def test_recherche_filtre_categorie(self):
        from app.services.semantic_index import get_semantic_index
        from unittest.mock import patch
        si = get_semantic_index()
        self._create_file("sec.py", "from app.services.sandbox import x")
        self._create_file("ia.md", "Ollama llama embedding model")
        si.index_directory(self.db, str(self.allowed_dir))

        with patch("app.services.embedding_client.EmbeddingClient.is_available",
                    return_value=False):
            r = si.search(self.db, "x", k=10, category="securité")
        self.assertTrue(r["ok"])
        # Tous les résultats doivent être dans 'securité'
        for res in r["results"]:
            self.assertEqual(res["category"], "securité")

    def test_recherche_retourne_score(self):
        from app.services.semantic_index import get_semantic_index
        from unittest.mock import patch
        si = get_semantic_index()
        self._create_file("note.md", "Important : Nova fonctionne en local sur Windows")
        si.index_directory(self.db, str(self.allowed_dir))

        with patch("app.services.embedding_client.EmbeddingClient.is_available",
                    return_value=False):
            r = si.search(self.db, "Nova local", k=5)
        self.assertTrue(r["ok"])
        for res in r["results"]:
            self.assertIn("score", res)
            self.assertIn("semantic", res)
            self.assertIn("lexical", res)


# ── 5. Suivi d'accès ─────────────────────────────────────────────────────

class TestAccessTracking(SemanticIndexTestBase):

    def test_recent_apres_indexation(self):
        from app.services.semantic_index import get_semantic_index
        si = get_semantic_index()
        self._create_file("a.md", "x")
        self._create_file("b.md", "y")
        si.index_directory(self.db, str(self.allowed_dir))
        recent = si.recent(self.db, limit=10)
        self.assertEqual(len(recent), 2)

    def test_acces_compteur(self):
        from app.services.semantic_index import (
            get_semantic_index, _record_access)
        from app.db.models import IndexedDocument
        si = get_semantic_index()
        p = self._create_file("a.md", "x")
        r = si.index_file(self.db, str(p))
        doc_id = r["document_id"]
        _record_access(self.db, doc_id)
        _record_access(self.db, doc_id)
        doc = self.db.query(IndexedDocument).get(doc_id)
        self.assertEqual(doc.access_count, 2)


# ── 6. Stats ──────────────────────────────────────────────────────────────

class TestStats(SemanticIndexTestBase):

    def test_stats_format(self):
        from app.services.semantic_index import get_semantic_index
        si = get_semantic_index()
        self._create_file("a.md", "x")
        si.index_directory(self.db, str(self.allowed_dir))
        st = si.stats(self.db)
        for key in ("documents", "chunks", "by_category",
                     "by_extension", "embedding_status"):
            self.assertIn(key, st)
        self.assertEqual(st["documents"], 1)


# ── 7. Performance (smoke) ────────────────────────────────────────────────

class TestPerformance(SemanticIndexTestBase):

    def test_indexation_50_fichiers_rapide(self):
        from app.services.semantic_index import get_semantic_index
        si = get_semantic_index()
        for i in range(50):
            self._create_file(f"doc{i:03d}.md", f"Document {i}\n" * 5)
        t0 = time.perf_counter()
        r = si.index_directory(self.db, str(self.allowed_dir), max_files=100)
        elapsed = time.perf_counter() - t0
        self.assertEqual(r["indexed"], 50)
        # Sans embeddings (sandbox), 50 fichiers texte ≤ 5s sur CI normal
        self.assertLess(elapsed, 5.0,
                         f"indexation trop lente : {elapsed:.2f}s")

    def test_recherche_rapide(self):
        from app.services.semantic_index import get_semantic_index
        from unittest.mock import patch
        si = get_semantic_index()
        for i in range(50):
            self._create_file(f"d{i}.md", f"Sujet {i} avec contenu varié")
        si.index_directory(self.db, str(self.allowed_dir))
        with patch("app.services.embedding_client.EmbeddingClient.is_available",
                    return_value=False):
            t0 = time.perf_counter()
            r = si.search(self.db, "sujet 23", k=5)
            elapsed = time.perf_counter() - t0
        self.assertTrue(r["ok"])
        self.assertLess(elapsed, 1.0,
                         f"recherche trop lente : {elapsed:.2f}s")


# ── 8. Documents similaires (related) ─────────────────────────────────────

class TestRelated(SemanticIndexTestBase):

    def test_related_sans_embeddings_retourne_empty(self):
        from app.services.semantic_index import get_semantic_index
        si = get_semantic_index()
        p = self._create_file("a.md", "Bonjour")
        r = si.index_file(self.db, str(p))
        self.assertTrue(r["ok"])
        # Sans embeddings, embedding_dim sera 0 → related vide
        from app.db.models import IndexedChunk
        chunk = self.db.query(IndexedChunk).filter_by(document_id=r["document_id"]).first()
        self.assertEqual(chunk.embedding_dim, 0)


# ── 9. Non-régression ────────────────────────────────────────────────────

class TestNonRegression(SemanticIndexTestBase):

    def test_tables_existantes_inchangees(self):
        """Les anciennes tables (Conversation, Message, etc.) doivent
        toujours être créables et insérables."""
        from app.db.models import Conversation, Message
        from datetime import datetime, timezone
        c = Conversation(title="test")
        self.db.add(c)
        self.db.commit()
        self.assertIsNotNone(c.id)
        m = Message(conversation_id=c.id, role="user", content="hello")
        self.db.add(m)
        self.db.commit()
        self.assertIsNotNone(m.id)


if __name__ == "__main__":
    unittest.main(verbosity=2)
