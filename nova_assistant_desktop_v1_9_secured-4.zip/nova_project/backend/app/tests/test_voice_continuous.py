"""
test_voice_continuous.py — Tests v1.9.6 : finalisation mode vocal continu.

Vérifie spécifiquement :
  - L'alias /api/voice/interrupt (nouveau v1.9.6) répond et a le bon contrat
  - Il stoppe le TTS et fait transitionner la VoiceSession
  - L'event 'voice.state.interrupted' est publié sur le CORE
  - L'ancien /api/voice-extras/interrupt fonctionne toujours (non-régression)
  - L'ancien /api/voice/stop fonctionne toujours
  - Mode wake-word strict : transcript sans wake → rejet
  - Mode wake-word non strict : tout passe

Exécution :
    cd backend
    ENABLE_STT=false ENABLE_TTS=false python -m unittest app.tests.test_voice_continuous -v

    # Pour tester les routes /api/voice/* :
    ENABLE_STT=false ENABLE_TTS=true STT_WARMUP=false python -m unittest app.tests.test_voice_continuous -v
"""

from __future__ import annotations

import os
import sys
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, ".")

# ── Mock Whisper pour permettre l'import du voice router en sandbox ────────
# Avant tout import qui pourrait charger faster_whisper, on neutralise.
if "faster_whisper" not in sys.modules:
    _mock_fw = MagicMock()
    _mock_fw.WhisperModel = MagicMock(return_value=MagicMock())
    sys.modules["faster_whisper"] = _mock_fw


def _try_import_app():
    try:
        from app.main import app
        return app
    except ModuleNotFoundError as exc:
        return f"skip:{exc}"


def _voice_router_active(app) -> bool:
    """True si les routes /api/voice/* sont effectivement enregistrées."""
    paths = [getattr(r, "path", "") for r in app.routes]
    return "/api/voice/interrupt" in paths


def _setup_client_or_skip(testcase):
    """Helper : retourne TestClient ou raise skipTest."""
    from fastapi.testclient import TestClient
    app_or_msg = _try_import_app()
    if isinstance(app_or_msg, str) and app_or_msg.startswith("skip:"):
        raise unittest.SkipTest(app_or_msg)
    if not _voice_router_active(app_or_msg):
        raise unittest.SkipTest(
            "voice router désactivé (ENABLE_STT=false et ENABLE_TTS=false). "
            "Active au moins l'un pour tester les routes /api/voice/*."
        )
    return TestClient(app_or_msg)


# ── 1. Endpoint /api/voice/interrupt (nouvel alias v1.9.6) ─────────────────

class TestVoiceInterruptAlias(unittest.TestCase):
    """L'alias /api/voice/interrupt doit exister et faire le même travail."""

    @classmethod
    def setUpClass(cls):
        cls.client = _setup_client_or_skip(cls)

    def test_endpoint_exists(self):
        resp = self.client.post("/api/voice/interrupt")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertIn("ok", body)
        self.assertIn("stopped_tts", body)
        self.assertIn("session_transitioned", body)

    def test_interrupt_after_speaking_transitions_session(self):
        """Mettre en SPEAKING puis interrompre doit donner état 'interrupted'."""
        c = self.client
        c.post("/api/voice-extras/state", json={"state": "listening"})
        c.post("/api/voice-extras/state", json={"state": "thinking"})
        c.post("/api/voice-extras/state", json={"state": "speaking"})
        resp = c.post("/api/voice/interrupt")
        body = resp.json()
        self.assertTrue(body["ok"])
        self.assertTrue(body["session_transitioned"])
        state = c.get("/api/voice-extras/state").json()
        self.assertEqual(state["state"], "interrupted")


# ── 2. Non-régression endpoints existants ──────────────────────────────────

class TestExistingEndpointsUnchanged(unittest.TestCase):
    """Les endpoints v1.9.5 doivent fonctionner inchangés."""

    @classmethod
    def setUpClass(cls):
        cls.client = _setup_client_or_skip(cls)

    def test_voice_extras_interrupt_still_works(self):
        resp = self.client.post("/api/voice-extras/interrupt")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("ok", resp.json())

    def test_voice_stop_still_works(self):
        resp = self.client.post("/api/voice/stop")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("stopped", resp.json())

    def test_voice_extras_state_still_works(self):
        resp = self.client.get("/api/voice-extras/state")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("state", resp.json())

    def test_voice_extras_wake_word_still_works(self):
        resp = self.client.get("/api/voice-extras/wake-word")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("words", resp.json())

    def test_required_routes_present(self):
        # Si setUpClass a skip, on n'arrive jamais ici → safe
        from app.main import app
        routes = [getattr(r, "path", None) for r in app.routes]
        for required in [
            "/api/voice/transcribe",
            "/api/voice/stop",
            "/api/voice/interrupt",        # nouveau v1.9.6
            "/api/voice-extras/state",
            "/api/voice-extras/interrupt",
            "/api/voice-extras/wake-word",
            "/api/voice-extras/vad",
            "/api/voice-extras/memory",
        ]:
            self.assertIn(required, routes,
                          f"route manquante après v1.9.6 : {required}")


# ── 3. Publication CORE sur interruption ───────────────────────────────────

class TestInterruptPublishesOnCore(unittest.TestCase):
    """L'interruption doit publier voice.state.interrupted sur le bus."""

    @classmethod
    def setUpClass(cls):
        cls.client = _setup_client_or_skip(cls)

    def test_voice_interrupt_alias_publishes(self):
        """L'alias /api/voice/interrupt doit publier sur le CORE."""
        c = self.client
        # Préparer un état actif (sinon idle→interrupted refusé sans force)
        c.post("/api/voice-extras/state", json={"state": "listening"})
        c.post("/api/voice/interrupt")
        # Vérifier l'event dans le journal CORE
        events = c.get("/api/core/bus/journal?limit=30").json().get("events", [])
        types = [e["type"] for e in events]
        self.assertIn("voice.state.interrupted", types,
                      f"voice.state.interrupted absent ; trouvés: {set(types)}")


# ── 4. Mode wake-word strict (consigne pt 3) ───────────────────────────────

class TestWakeWordStrictMode(unittest.TestCase):

    def test_strict_filtre_phrase_sans_wake(self):
        """Strict ON : phrase sans 'nova' → wake_matched=False."""
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=True)
        matched, cmd = d.matches("quelle heure est-il")
        self.assertFalse(matched)
        self.assertIsNone(cmd)

    def test_strict_accepte_avec_wake(self):
        """Strict ON : phrase avec 'Nova' → wake_matched=True + command extrait."""
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=True)
        matched, cmd = d.matches("Nova quelle heure est-il")
        self.assertTrue(matched)
        self.assertEqual(cmd, "quelle heure est-il")

    def test_strict_accepte_variants_hey_nova(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova", "hey nova", "ok nova"])
        d.configure(["nova", "hey nova", "ok nova"], enabled=True)
        for phrase in ["Hey Nova allume la lumière",
                        "ok nova quelle heure est-il",
                        "Nova, ferme la fenêtre"]:
            matched, cmd = d.matches(phrase)
            self.assertTrue(matched, f"strict doit accepter : {phrase!r}")

    def test_non_strict_accepte_tout(self):
        """Strict OFF : tout passe."""
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=False)
        matched, cmd = d.matches("phrase arbitraire sans rien")
        self.assertTrue(matched)

    def test_runtime_reconfig_strict(self):
        """Pouvoir activer/désactiver à chaud via /api/voice-extras/wake-word."""
        # Cette route est dans voice_extras → toujours présente (pas conditionnelle)
        from fastapi.testclient import TestClient
        app_or_msg = _try_import_app()
        if isinstance(app_or_msg, str) and app_or_msg.startswith("skip:"):
            self.skipTest(app_or_msg)
        client = TestClient(app_or_msg)
        # Activer strict
        r = client.post("/api/voice-extras/wake-word",
                        json={"words": ["nova"], "enabled": True})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()["config"]["enabled"])
        # Désactiver
        r = client.post("/api/voice-extras/wake-word",
                        json={"words": ["nova"], "enabled": False})
        self.assertEqual(r.status_code, 200)
        self.assertFalse(r.json()["config"]["enabled"])


# ── 5. Publication CORE — contrat VoiceSession ────────────────────────────

class TestVoiceSessionCoreContract(unittest.TestCase):

    def test_interrupt_uses_orchestrator(self):
        """L'interruption doit passer par submit_event() → bus CORE."""
        from app.services.voice_session import VoiceSession, VoiceState
        s = VoiceSession()
        s.transition(VoiceState.LISTENING)
        s.transition(VoiceState.THINKING)
        s.transition(VoiceState.SPEAKING)

        published = []

        class FakeOrch:
            def submit_event(self, ev):
                published.append(ev)
                return {"accepted": True, "event_id": ev.id}

        with patch("app.core.orchestrator.orchestrator", FakeOrch()):
            s.transition(VoiceState.INTERRUPTED, force=True)

        self.assertEqual(len(published), 1)
        self.assertEqual(published[0].type, "voice.state.interrupted")
        self.assertEqual(published[0].source, "voice_session")


# ── 6. Garde-fous : robustesse de l'endpoint interrupt ─────────────────────

class TestInterruptRobustness(unittest.TestCase):
    """L'endpoint /interrupt ne doit JAMAIS planter même si TTS/session échouent."""

    @classmethod
    def setUpClass(cls):
        cls.client = _setup_client_or_skip(cls)

    def test_interrupt_when_tts_unavailable(self):
        """Si tts_engine.stop() lève → endpoint répond quand même 200."""
        with patch("app.api.voice.tts_engine.stop", side_effect=RuntimeError("TTS down")):
            resp = self.client.post("/api/voice/interrupt")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertFalse(body["stopped_tts"])  # signalé honnêtement
        self.assertTrue(body["ok"])

    def test_interrupt_multiple_times_safe(self):
        """Appeler /interrupt plusieurs fois de suite ne doit pas planter."""
        for _ in range(5):
            resp = self.client.post("/api/voice/interrupt")
            self.assertEqual(resp.status_code, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)
