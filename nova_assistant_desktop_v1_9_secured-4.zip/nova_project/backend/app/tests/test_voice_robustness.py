"""
test_voice_robustness.py — Tests v1.9.9 : métriques + watchdog + robustesse.

Couvre :
  - voice_metrics : start/mark/complete/cancel, agrégation, inflight
  - voice_watchdog : timeouts par état, recovery, stats
  - Robustesse : TTS down, STT lent, sessions bloquées
  - Phase B stubs : interfaces propres et statuts honnêtes
  - Non-régression : endpoints v1.9.5/6/7 fonctionnent

Exécution :
    cd backend
    ENABLE_STT=false ENABLE_TTS=false python -m unittest \\
        app.tests.test_voice_robustness -v
"""

from __future__ import annotations

import sys
import time
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, ".")


# Mock Faster-Whisper pour permettre l'import du voice router (idem v1.9.6)
if "faster_whisper" not in sys.modules:
    from unittest.mock import MagicMock
    _mock_fw = MagicMock()
    _mock_fw.WhisperModel = MagicMock(return_value=MagicMock())
    sys.modules["faster_whisper"] = _mock_fw


# ── 1. VoiceMetrics — cycle de vie d'un tour ───────────────────────────────

class TestVoiceMetricsLifecycle(unittest.TestCase):

    def setUp(self):
        import app.services.voice_metrics as vm_mod
        vm_mod._instance = None
        self.m = vm_mod.get_voice_metrics()

    def test_start_turn_renvoie_id_unique(self):
        a = self.m.start_turn()
        b = self.m.start_turn()
        self.assertNotEqual(a, b)
        self.assertEqual(len(a), 12)

    def test_mark_remplit_phase(self):
        turn = self.m.start_turn()
        ok = self.m.mark(turn, "stt_ms", 420)
        self.assertTrue(ok)
        inflight = self.m.get_inflight()
        self.assertEqual(len(inflight), 1)
        self.assertEqual(inflight[0]["stt_ms"], 420)

    def test_mark_phase_invalide_refusee(self):
        turn = self.m.start_turn()
        ok = self.m.mark(turn, "phase_inventee", 100)
        self.assertFalse(ok)

    def test_mark_turn_inconnu_refuse(self):
        ok = self.m.mark("inconnu", "stt_ms", 100)
        self.assertFalse(ok)

    def test_complete_calcule_total_ms(self):
        turn = self.m.start_turn()
        time.sleep(0.05)
        d = self.m.complete(turn)
        self.assertIsNotNone(d)
        self.assertIsNotNone(d["total_ms"])
        self.assertGreaterEqual(d["total_ms"], 50)
        # Plus dans inflight
        self.assertEqual(len(self.m.get_inflight()), 0)

    def test_complete_avec_total_ms_explicite(self):
        turn = self.m.start_turn()
        self.m.mark(turn, "total_ms", 1234)
        d = self.m.complete(turn)
        self.assertEqual(d["total_ms"], 1234)

    def test_cancel_archive_avec_meta(self):
        turn = self.m.start_turn()
        ok = self.m.cancel(turn, reason="user interrupt")
        self.assertTrue(ok)
        hist = self.m.get_history(limit=10)
        self.assertEqual(len(hist), 1)
        self.assertTrue(hist[0]["meta"]["cancelled"])
        self.assertEqual(hist[0]["meta"]["cancel_reason"], "user interrupt")

    def test_history_completed_only_filtre(self):
        # 2 complete + 1 cancel
        a = self.m.start_turn(); self.m.complete(a)
        b = self.m.start_turn(); self.m.complete(b)
        c = self.m.start_turn(); self.m.cancel(c, reason="x")
        self.assertEqual(len(self.m.get_history(completed_only=True)), 3)


# ── 2. VoiceMetrics — agrégation ──────────────────────────────────────────

class TestVoiceMetricsAggregation(unittest.TestCase):

    def setUp(self):
        import app.services.voice_metrics as vm_mod
        vm_mod._instance = None
        self.m = vm_mod.get_voice_metrics()

    def test_aggregate_vide(self):
        agg = self.m.aggregate()
        self.assertEqual(agg["samples"], 0)
        self.assertEqual(agg["cancelled_rate"], 0.0)

    def test_aggregate_calcule_p95(self):
        # 100 tours avec stt_ms en croissance linéaire
        for i in range(100):
            t = self.m.start_turn()
            self.m.mark(t, "stt_ms", i * 10)   # 0, 10, 20, ..., 990
            self.m.complete(t)
        agg = self.m.aggregate(last_n=100)
        self.assertEqual(agg["samples"], 100)
        stt = agg["phases"]["stt_ms"]
        self.assertEqual(stt["count"], 100)
        # p95 d'une distrib 0..990 par pas de 10 → ~940-950
        self.assertGreaterEqual(stt["p95"], 940)
        self.assertLessEqual(stt["p95"], 990)
        self.assertEqual(stt["min"], 0)
        self.assertEqual(stt["max"], 990)

    def test_aggregate_cancelled_rate(self):
        for _ in range(8):
            t = self.m.start_turn(); self.m.complete(t)
        for _ in range(2):
            t = self.m.start_turn(); self.m.cancel(t, "x")
        agg = self.m.aggregate(last_n=20)
        self.assertEqual(agg["samples"], 10)
        self.assertEqual(agg["cancelled"], 2)
        self.assertAlmostEqual(agg["cancelled_rate"], 0.2, places=2)


# ── 3. VoiceMetrics — inflight et anti-fuite ──────────────────────────────

class TestVoiceMetricsInflightAntiLeak(unittest.TestCase):

    def setUp(self):
        import app.services.voice_metrics as vm_mod
        vm_mod._instance = None
        self.m = vm_mod.get_voice_metrics()

    def test_drop_vieux_inflight_si_overflow(self):
        # Créer 60 tours sans les compléter → seuls les ~50 plus récents restent
        ids = [self.m.start_turn() for _ in range(60)]
        inflight = self.m.get_inflight()
        # Anti-fuite : doit avoir reduit
        self.assertLessEqual(len(inflight), 50)


# ── 4. VoiceWatchdog — comportement de base ───────────────────────────────

class TestVoiceWatchdogBasic(unittest.TestCase):

    def setUp(self):
        import app.services.voice_watchdog as wd_mod
        wd_mod._instance = None

    def tearDown(self):
        import app.services.voice_watchdog as wd_mod
        if wd_mod._instance:
            try:
                wd_mod._instance.stop()
            except Exception:
                pass

    def test_start_stop(self):
        from app.services.voice_watchdog import get_voice_watchdog
        wd = get_voice_watchdog()
        self.assertFalse(wd.is_running())
        ok = wd.start()
        self.assertTrue(ok)
        self.assertTrue(wd.is_running())
        ok = wd.stop()
        self.assertTrue(ok)
        self.assertFalse(wd.is_running())

    def test_double_start_refuse(self):
        from app.services.voice_watchdog import get_voice_watchdog
        wd = get_voice_watchdog()
        wd.start()
        self.assertFalse(wd.start())   # déjà démarré

    def test_stats_format(self):
        from app.services.voice_watchdog import get_voice_watchdog
        s = get_voice_watchdog().get_stats()
        for key in ("listening_timeouts", "thinking_timeouts",
                     "speaking_timeouts", "inflight_cancelled", "running"):
            self.assertIn(key, s)


# ── 5. VoiceWatchdog — détecte session bloquée ────────────────────────────

class TestVoiceWatchdogDetection(unittest.TestCase):
    """Le watchdog doit forcer un reset si état actif > seuil."""

    def setUp(self):
        # Reset singletons
        import app.services.voice_watchdog as wd_mod
        import app.services.voice_session as vs_mod
        wd_mod._instance = None
        vs_mod._instance = None

    def tearDown(self):
        import app.services.voice_watchdog as wd_mod
        if wd_mod._instance:
            try:
                wd_mod._instance.stop()
            except Exception:
                pass

    def test_watchdog_reset_listening_apres_seuil(self):
        from app.services.voice_session import get_voice_session, VoiceState
        from app.services.voice_watchdog import get_voice_watchdog, WatchdogConfig

        # Config très agressive pour le test
        wd = get_voice_watchdog()
        wd.config = WatchdogConfig(
            check_interval_sec=0.1,
            listening_timeout_sec=0.3,
            thinking_timeout_sec=0.3,
            speaking_timeout_sec=0.3,
            inflight_timeout_sec=10.0,
        )

        session = get_voice_session()
        session.transition(VoiceState.LISTENING)
        self.assertEqual(session.get_state()["state"], "listening")

        wd.start()
        # Attendre 1s : 0.3s seuil + temps de check
        time.sleep(1.0)
        wd.stop()

        # Doit avoir été reset en idle
        self.assertEqual(session.get_state()["state"], "idle")
        self.assertGreater(wd.get_stats()["listening_timeouts"], 0)

    def test_watchdog_annule_inflight_metric(self):
        from app.services.voice_metrics import get_voice_metrics
        from app.services.voice_watchdog import get_voice_watchdog, WatchdogConfig

        # Reset singletons
        import app.services.voice_metrics as vm_mod
        vm_mod._instance = None
        m = get_voice_metrics()

        wd = get_voice_watchdog()
        wd.config = WatchdogConfig(
            check_interval_sec=0.1,
            listening_timeout_sec=300.0,    # désactivé
            thinking_timeout_sec=300.0,
            speaking_timeout_sec=300.0,
            inflight_timeout_sec=0.3,        # ← seuil rapide
        )

        turn = m.start_turn()
        self.assertEqual(len(m.get_inflight()), 1)

        wd.start()
        time.sleep(1.0)
        wd.stop()

        # Le tour doit avoir été annulé
        self.assertEqual(len(m.get_inflight()), 0)
        self.assertGreater(wd.get_stats()["inflight_cancelled"], 0)
        # Et archivé avec cancel meta
        hist = m.get_history(limit=5)
        self.assertEqual(len(hist), 1)
        self.assertTrue(hist[0]["meta"]["cancelled"])


# ── 6. Robustesse : TTS indispo n'altère pas /interrupt ───────────────────

class TestRobustnessTTSDown(unittest.TestCase):

    def test_interrupt_endpoint_ok_si_tts_leve(self):
        from fastapi.testclient import TestClient
        try:
            from app.main import app
        except ModuleNotFoundError as exc:
            self.skipTest(f"app non importable : {exc}")
        # Skip si voice router pas chargé
        routes = [getattr(r, "path", "") for r in app.routes]
        if "/api/voice/interrupt" not in routes:
            self.skipTest("voice router désactivé (ENABLE_STT/TTS=false)")
        client = TestClient(app)
        with patch("app.api.voice.tts_engine.stop",
                    side_effect=RuntimeError("TTS down")):
            r = client.post("/api/voice/interrupt")
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertFalse(body["stopped_tts"])  # honnête
        self.assertTrue(body["ok"])


# ── 7. Robustesse : STT lent → métrique le note ───────────────────────────

class TestRobustnessSTTSlow(unittest.TestCase):

    def setUp(self):
        import app.services.voice_metrics as vm_mod
        vm_mod._instance = None

    def test_stt_lent_archive_avec_total_ms(self):
        """Un tour STT lent (3s) doit être loggé proprement."""
        from app.services.voice_metrics import get_voice_metrics
        m = get_voice_metrics()
        turn = m.start_turn()
        m.mark(turn, "stt_ms", 3000)
        d = m.complete(turn)
        self.assertGreaterEqual(d["stt_ms"], 3000)
        # total_ms auto >= temps réel écoulé
        self.assertIsNotNone(d["total_ms"])


# ── 8. Phase B stubs : interfaces propres ────────────────────────────────

class TestPhaseBStubs(unittest.TestCase):

    def test_wake_word_local_default_unavailable(self):
        from app.services.wake_word_local import get_wake_word_local
        st = get_wake_word_local().get_status()
        self.assertFalse(st.available)
        self.assertEqual(st.engine_name, "noop")
        # Doit retourner None sur process_audio
        self.assertIsNone(get_wake_word_local().process_audio(b"\x00" * 1024))

    def test_wake_word_local_set_engine(self):
        from app.services.wake_word_local import (
            get_wake_word_local, WakeWordEngine,
        )
        # Reset
        import app.services.wake_word_local as wwl
        wwl._instance = None

        class FakeEngine(WakeWordEngine):
            @property
            def name(self): return "fake"
            def is_available(self): return True
            def process_audio(self, frame): return "nova" if frame else None

        svc = get_wake_word_local()
        svc.set_engine(FakeEngine())
        st = svc.get_status()
        self.assertTrue(st.available)
        self.assertEqual(st.engine_name, "fake")
        self.assertEqual(svc.process_audio(b"\x01"), "nova")

    def test_tts_streaming_default_unavailable(self):
        from app.services.tts_streaming import get_streaming_tts
        st = get_streaming_tts().get_status()
        self.assertFalse(st.available)
        self.assertEqual(st.engine_name, "noop")
        # Empty iterator
        chunks = list(get_streaming_tts().synthesize_stream("test"))
        self.assertEqual(chunks, [])


# ── 9. Endpoints REST métriques ────────────────────────────────────────────

class TestMetricsEndpoints(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        try:
            from app.main import app
        except ModuleNotFoundError as exc:
            raise unittest.SkipTest(f"app non importable : {exc}")
        cls.client = TestClient(app)
        # Reset metrics
        import app.services.voice_metrics as vm_mod
        vm_mod._instance = None

    def test_metrics_endpoint_format(self):
        # Générer quelques tours
        from app.services.voice_metrics import get_voice_metrics
        m = get_voice_metrics()
        for i in range(5):
            t = m.start_turn()
            m.mark(t, "stt_ms", 100 + i * 50)
            m.complete(t)
        r = self.client.get("/api/voice-extras/metrics")
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertEqual(body["samples"], 5)
        self.assertIn("phases", body)
        self.assertIn("stt_ms", body["phases"])
        self.assertEqual(body["phases"]["stt_ms"]["count"], 5)

    def test_metrics_history_endpoint(self):
        r = self.client.get("/api/voice-extras/metrics/history?limit=10")
        self.assertEqual(r.status_code, 200)
        self.assertIn("turns", r.json())

    def test_metrics_inflight_endpoint(self):
        r = self.client.get("/api/voice-extras/metrics/inflight")
        self.assertEqual(r.status_code, 200)
        self.assertIn("inflight", r.json())

    def test_watchdog_endpoint_status(self):
        r = self.client.get("/api/voice-extras/watchdog")
        self.assertEqual(r.status_code, 200)
        self.assertIn("running", r.json())

    def test_watchdog_endpoint_control(self):
        # Arrêt
        r = self.client.post("/api/voice-extras/watchdog",
                              json={"action": "stop"})
        self.assertEqual(r.status_code, 200)
        # Redémarrage
        r = self.client.post("/api/voice-extras/watchdog",
                              json={"action": "start"})
        self.assertEqual(r.status_code, 200)


# ── 10. Non-régression endpoints v1.9.5+ ──────────────────────────────────

class TestNonRegression(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        try:
            from app.main import app
        except ModuleNotFoundError as exc:
            raise unittest.SkipTest(f"app non importable : {exc}")
        cls.client = TestClient(app)

    def test_routes_v195_v196_v197_toujours_la(self):
        from app.main import app
        routes = [getattr(r, "path", "") for r in app.routes]
        for required in [
            "/api/voice-extras/state",
            "/api/voice-extras/interrupt",
            "/api/voice-extras/wake-word",
            "/api/voice-extras/vad",
            "/api/voice-extras/memory",
            "/api/security/action/propose",
            "/api/index/stats",
        ]:
            self.assertIn(required, routes,
                          f"route manquante après v1.9.9 : {required}")

    def test_nouvelles_routes_metrics_watchdog_presentes(self):
        from app.main import app
        routes = [getattr(r, "path", "") for r in app.routes]
        for new in [
            "/api/voice-extras/metrics",
            "/api/voice-extras/metrics/history",
            "/api/voice-extras/metrics/inflight",
            "/api/voice-extras/watchdog",
        ]:
            self.assertIn(new, routes, f"nouvelle route v1.9.9 absente : {new}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
