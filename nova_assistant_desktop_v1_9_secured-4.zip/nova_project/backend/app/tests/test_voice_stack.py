"""
test_voice_stack.py — Tests v1.9.5 : VoiceSession, VAD, wake word, post-correction.

Exécuter :
    cd backend
    ENABLE_STT=false ENABLE_TTS=false python -m unittest app.tests.test_voice_stack -v
"""

from __future__ import annotations

import sys
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, ".")


# ── VoiceSession ───────────────────────────────────────────────────────────

class TestVoiceSession(unittest.TestCase):

    def setUp(self):
        from app.services.voice_session import VoiceSession, VoiceState
        self.session = VoiceSession()
        self.VoiceState = VoiceState

    def test_initial_state_idle(self):
        self.assertEqual(self.session.get_state()["state"], "idle")
        self.assertFalse(self.session.is_active())

    def test_transition_idle_to_listening_ok(self):
        ok = self.session.transition(self.VoiceState.LISTENING)
        self.assertTrue(ok)
        self.assertEqual(self.session.get_state()["state"], "listening")
        self.assertTrue(self.session.is_active())

    def test_transition_idle_to_speaking_refusee(self):
        """idle → speaking n'est pas dans les transitions autorisées."""
        ok = self.session.transition(self.VoiceState.SPEAKING)
        self.assertFalse(ok)
        self.assertEqual(self.session.get_state()["state"], "idle")

    def test_transition_force_passe_outre(self):
        ok = self.session.transition(self.VoiceState.SPEAKING, force=True)
        self.assertTrue(ok)
        self.assertEqual(self.session.get_state()["state"], "speaking")

    def test_pipeline_complet(self):
        s = self.session; VS = self.VoiceState
        self.assertTrue(s.transition(VS.LISTENING))
        self.assertTrue(s.transition(VS.THINKING))
        self.assertTrue(s.transition(VS.SPEAKING))
        self.assertTrue(s.transition(VS.IDLE))
        self.assertEqual(s.get_state()["state"], "idle")

    def test_interruption_depuis_speaking(self):
        s = self.session; VS = self.VoiceState
        s.transition(VS.LISTENING)
        s.transition(VS.THINKING)
        s.transition(VS.SPEAKING)
        ok = s.transition(VS.INTERRUPTED)
        self.assertTrue(ok)
        self.assertEqual(s.get_state()["state"], "interrupted")
        self.assertGreaterEqual(s.get_state()["interruptions"], 1)

    def test_memory_append_and_get(self):
        from app.services.voice_session import VoiceTurn
        for i in range(5):
            self.session.append_turn(VoiceTurn(
                timestamp=time.time(), user_text=f"u{i}",
                assistant_text=f"a{i}",
            ))
        recent = self.session.get_recent_turns(n=3)
        self.assertEqual(len(recent), 3)
        # Les 3 derniers
        self.assertEqual(recent[0]["user_text"], "u2")
        self.assertEqual(recent[2]["user_text"], "u4")

    def test_memory_clear(self):
        from app.services.voice_session import VoiceTurn
        self.session.append_turn(VoiceTurn(
            timestamp=time.time(), user_text="x", assistant_text="y",
        ))
        n = self.session.clear_memory()
        self.assertEqual(n, 1)
        self.assertEqual(self.session.get_recent_turns(), [])

    def test_build_context_string_short(self):
        from app.services.voice_session import VoiceTurn
        self.session.append_turn(VoiceTurn(
            timestamp=time.time(), user_text="quelle heure est-il",
            assistant_text="Il est 14h30.",
        ))
        ctx = self.session.build_context_string(n=3)
        self.assertIn("U: quelle heure", ctx)
        self.assertIn("A: Il est 14h30", ctx)


# ── TextWakeWordDetector ───────────────────────────────────────────────────

class TestWakeWord(unittest.TestCase):

    def test_disabled_passe_tout(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=False)
        matched, cmd = d.matches("rien à voir avec Nova")
        self.assertTrue(matched)

    def test_match_simple(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=True)
        matched, cmd = d.matches("Nova quelle heure est-il")
        self.assertTrue(matched)
        self.assertEqual(cmd, "quelle heure est-il")

    def test_no_match(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=True)
        matched, cmd = d.matches("Bonjour comment ça va")
        self.assertFalse(matched)
        self.assertIsNone(cmd)

    def test_match_avec_ponctuation(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=True)
        for variant in ["Nova, allume la lumière.",
                        "nova ! allume.",
                        "  Nova    aide-moi"]:
            matched, cmd = d.matches(variant)
            self.assertTrue(matched, f"failed for: {variant!r}")
            self.assertIn("allume", cmd.lower()) if "allume" in variant else None

    def test_match_seul_wake_word(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova"])
        d.configure(["nova"], enabled=True)
        matched, cmd = d.matches("Nova")
        self.assertTrue(matched)
        self.assertEqual(cmd, "")

    def test_multi_wake_words(self):
        from app.services.voice_enhancers import TextWakeWordDetector
        d = TextWakeWordDetector(["nova", "hey nova"])
        d.configure(["nova", "hey nova"], enabled=True)
        m1, _ = d.matches("hey nova aide-moi")
        m2, _ = d.matches("nova help")
        self.assertTrue(m1)
        self.assertTrue(m2)


# ── TranscriptPostCorrector ────────────────────────────────────────────────

class TestPostCorrection(unittest.TestCase):

    def test_hallucination_filtree(self):
        from app.services.voice_enhancers import TranscriptPostCorrector
        c = TranscriptPostCorrector()
        text, info = c.correct("Sous-titres réalisés par la communauté d'Amara.org")
        self.assertEqual(text, "")
        self.assertEqual(info["reason"], "hallucination_filtered")

    def test_capitalisation(self):
        from app.services.voice_enhancers import TranscriptPostCorrector
        c = TranscriptPostCorrector()
        text, info = c.correct("bonjour nova")
        self.assertTrue(text.startswith("B"))

    def test_fix_no_va(self):
        from app.services.voice_enhancers import TranscriptPostCorrector
        c = TranscriptPostCorrector()
        text, info = c.correct("Hé no va, ça va")
        self.assertIn("Nova", text)
        self.assertNotIn("no va", text)

    def test_ponctuation_finale(self):
        from app.services.voice_enhancers import TranscriptPostCorrector
        c = TranscriptPostCorrector()
        text, info = c.correct("Bonjour comment ça va")
        self.assertTrue(text.endswith(".") or text.endswith("!") or text.endswith("?"))

    def test_pas_de_double_ponctuation(self):
        from app.services.voice_enhancers import TranscriptPostCorrector
        c = TranscriptPostCorrector()
        text, info = c.correct("Salut !")
        # Doit pas devenir "Salut !." par exemple
        self.assertFalse(text.endswith("!."))
        self.assertFalse(text.endswith("?."))

    def test_vide_reste_vide(self):
        from app.services.voice_enhancers import TranscriptPostCorrector
        c = TranscriptPostCorrector()
        text, info = c.correct("")
        self.assertEqual(text, "")


# ── VADCalibrator ──────────────────────────────────────────────────────────

class TestVADCalibrator(unittest.TestCase):

    def test_params_par_defaut(self):
        from app.services.voice_enhancers import VADCalibrator
        c = VADCalibrator()
        p = c.get_params()
        self.assertTrue(p.vad_filter)
        self.assertIn("min_silence_duration_ms", p.to_whisper_dict())

    def test_record_vide_assouplit_progressivement(self):
        """Si beaucoup de transcriptions vides → threshold diminue."""
        from app.services.voice_enhancers import VADCalibrator
        c = VADCalibrator()
        initial_threshold = c.get_params().threshold
        # 12 résultats vides courts
        for _ in range(12):
            c.record_result(text="", duration_s=1.0, transcribe_ms=100)
        new_threshold = c.get_params().threshold
        self.assertLessEqual(new_threshold, initial_threshold,
                             "threshold doit baisser sur historique vide")

    def test_stats_format(self):
        from app.services.voice_enhancers import VADCalibrator
        c = VADCalibrator()
        c.record_result(text="bonjour", duration_s=2.0, transcribe_ms=200)
        stats = c.get_stats()
        self.assertIn("samples", stats)
        self.assertIn("empty_rate", stats)
        self.assertIn("params", stats)


# ── Intégration CORE ──────────────────────────────────────────────────────

class TestVoiceCorePublication(unittest.TestCase):

    def test_state_transition_publish_event(self):
        """Chaque transition d'état doit publier un event sur le CORE."""
        from app.services.voice_session import VoiceSession, VoiceState
        s = VoiceSession()
        published = []

        class FakeOrch:
            def submit_event(self, ev):
                published.append(ev)
                return {"accepted": True, "event_id": ev.id}

        with patch("app.core.orchestrator.orchestrator", FakeOrch()):
            s.transition(VoiceState.LISTENING)
            s.transition(VoiceState.THINKING)
            s.transition(VoiceState.SPEAKING)
            s.transition(VoiceState.IDLE)

        self.assertEqual(len(published), 4)
        types = [e.type for e in published]
        self.assertEqual(types, [
            "voice.state.listening",
            "voice.state.thinking",
            "voice.state.speaking",
            "voice.state.idle",
        ])


# ── Non-régression ─────────────────────────────────────────────────────────

class TestVoiceNonRegression(unittest.TestCase):

    def test_existing_voice_endpoint_unchanged(self):
        """L'endpoint /api/voice/transcribe doit toujours exister."""
        try:
            from app.api import voice
        except ModuleNotFoundError as exc:
            # pyttsx3 / faster_whisper non installés dans le sandbox CI
            self.skipTest(f"dépendance vocale absente : {exc}")
        self.assertTrue(hasattr(voice, "transcribe_audio"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
