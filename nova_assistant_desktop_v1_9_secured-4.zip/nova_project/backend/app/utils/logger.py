"""
logger.py — Système de logs multi-fichiers.

Logs séparés par domaine :
  logs/assistant.log  → log général (déjà existant)
  logs/voice.log      → pipeline vocal STT/TTS/LLM
  logs/security.log   → accès, chemins, actions sensibles
  logs/actions.log    → actions exécutées (outils, commandes)
"""
import logging
import logging.handlers
from pathlib import Path


_LOG_DIR   = Path(__file__).resolve().parent.parent.parent / "logs"
_FORMATTER = logging.Formatter(
    "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# Niveau global
_LEVEL = logging.INFO


def _make_file_handler(filename: str) -> logging.FileHandler:
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(
        _LOG_DIR / filename,
        maxBytes=5 * 1024 * 1024,  # 5 MB
        backupCount=3,
        encoding="utf-8",
    )
    handler.setFormatter(_FORMATTER)
    handler.setLevel(_LEVEL)
    return handler


def _make_console_handler() -> logging.StreamHandler:
    handler = logging.StreamHandler()
    handler.setFormatter(_FORMATTER)
    handler.setLevel(_LEVEL)
    return handler


# ── Loggers spécialisés ────────────────────────────────────────────────────────

def _setup_logger(name: str, filename: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # déjà configuré
    logger.setLevel(_LEVEL)
    logger.addHandler(_make_file_handler(filename))
    logger.addHandler(_make_file_handler("assistant.log"))  # tout dans le log principal aussi
    logger.addHandler(_make_console_handler())
    logger.propagate = False
    return logger


# Registre des loggers par préfixe de nom
_ROUTING = {
    "api.voice":      "voice.log",
    "voice_engine":   "voice.log",
    "tts_engine":     "voice.log",
    "voice_memory":   "voice.log",
    "voice_commands": "voice.log",
    "tool.":          "actions.log",
    "tool_router":    "actions.log",
    "safety":         "security.log",
    "api.tools":      "actions.log",
    "llm":            "assistant.log",
}


def get_logger(name: str) -> logging.Logger:
    """
    Retourne un logger configuré.
    Les logs vont toujours dans assistant.log + un fichier spécialisé selon le préfixe.
    """
    target_file = "assistant.log"
    for prefix, logfile in _ROUTING.items():
        if name.startswith(prefix):
            target_file = logfile
            break

    return _setup_logger(name, target_file)
