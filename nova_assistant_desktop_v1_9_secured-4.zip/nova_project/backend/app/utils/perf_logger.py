"""
perf_logger.py — Collecteur de métriques de performance IA.

Mesure précise, sans modifier la logique conversationnelle :
  - time_to_first_token_ms  : latence avant le 1er token Ollama
  - total_response_ms       : durée totale de la réponse complète
  - token_count             : nombre de tokens générés
  - tokens_per_second       : débit calculé
  - ollama_call_ms          : temps du seul appel réseau Ollama
  - model                   : modèle utilisé
  - backend                 : "ollama" | "mistral"

Usage pattern (dans llm.py) :
    session = perf.start_session(model="llama3.2:3b")
    session.mark_ollama_start()
    # ... appel réseau ...
    session.mark_first_token()
    # ... yield tokens ...
    session.mark_end(token_count, backend="ollama")
    perf.record(session)

Thread-safe : les sessions sont isolées ; record() est protégé par un Lock.
"""
import threading
import time
from collections import deque
from typing import Any, Deque, Dict, Optional

from app.utils.logger import get_logger

logger = get_logger("perf")

# Taille du buffer circulaire des dernières sessions
_HISTORY_MAX = 100


class PerfSession:
    """Mesure d'une seule inférence IA. Instancié par PerfCollector.start_session()."""

    def __init__(self, model: str) -> None:
        self.model = model
        self._t_start     = time.perf_counter()   # début absolu (réception msg user)
        self._t_ollama     = self._t_start         # début appel réseau Ollama
        self._t_first_token: Optional[float] = None
        self._t_end:         Optional[float] = None
        self.token_count   = 0
        self.backend       = "ollama"

    # ── Marqueurs ──────────────────────────────────────────────────────────

    def mark_ollama_start(self) -> None:
        """Marque le début de l'appel réseau vers Ollama."""
        self._t_ollama = time.perf_counter()

    def mark_first_token(self) -> None:
        """Marque la réception du 1er token (appeler exactement une fois)."""
        if self._t_first_token is None:
            self._t_first_token = time.perf_counter()

    def mark_end(self, token_count: int, backend: str = "ollama") -> None:
        """Marque la fin du streaming et enregistre le nombre de tokens."""
        self._t_end    = time.perf_counter()
        self.token_count = token_count
        self.backend   = backend

    # ── Calculs ────────────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        now = time.perf_counter()
        t_end = self._t_end if self._t_end is not None else now

        total_ms = int((t_end - self._t_start) * 1000)
        ollama_ms = int((t_end - self._t_ollama) * 1000)

        first_token_ms: Optional[int] = None
        if self._t_first_token is not None:
            first_token_ms = int((self._t_first_token - self._t_ollama) * 1000)

        tps: Optional[float] = None
        if self._t_first_token is not None and self._t_end is not None and self.token_count > 1:
            gen_s = self._t_end - self._t_first_token
            if gen_s > 0:
                tps = round(self.token_count / gen_s, 2)

        return {
            "model":                  self.model,
            "backend":                self.backend,
            "time_to_first_token_ms": first_token_ms,
            "total_response_ms":      total_ms,
            "ollama_call_ms":         ollama_ms,
            "token_count":            self.token_count,
            "tokens_per_second":      tps,
        }


class PerfCollector:
    """
    Singleton global de collecte des métriques de performance IA.
    Thread-safe. Conserve les _HISTORY_MAX dernières sessions.
    """

    def __init__(self) -> None:
        self._lock:    threading.Lock            = threading.Lock()
        self._history: Deque[Dict[str, Any]]    = deque(maxlen=_HISTORY_MAX)
        self._last:    Optional[Dict[str, Any]] = None

    def start_session(self, model: str) -> PerfSession:
        """Crée et retourne une nouvelle session de mesure."""
        return PerfSession(model=model)

    def record(self, session: PerfSession) -> Dict[str, Any]:
        """
        Finalise la session, log les métriques, et les stocke en mémoire.
        Retourne le dict des métriques (utile pour l'envoyer au frontend).
        """
        metrics = session.to_dict()
        with self._lock:
            self._history.append(metrics)
            self._last = metrics

        _log_metrics(metrics)
        return metrics

    def get_last(self) -> Optional[Dict[str, Any]]:
        """Retourne les métriques de la dernière session enregistrée."""
        with self._lock:
            return self._last

    def get_history(self, n: int = 20) -> list:
        """Retourne les n dernières sessions (plus récente en dernier)."""
        with self._lock:
            history = list(self._history)
        return history[-n:]

    def get_summary(self) -> Dict[str, Any]:
        """
        Statistiques agrégées sur l'ensemble de l'historique :
        moyenne / min / max pour les métriques numériques clés.
        """
        with self._lock:
            history = list(self._history)

        if not history:
            return {"sessions": 0}

        def _stats(key: str) -> Dict[str, Any]:
            vals = [s[key] for s in history if s.get(key) is not None]
            if not vals:
                return {"avg": None, "min": None, "max": None}
            return {
                "avg": round(sum(vals) / len(vals), 1),
                "min": min(vals),
                "max": max(vals),
            }

        return {
            "sessions":              len(history),
            "time_to_first_token_ms": _stats("time_to_first_token_ms"),
            "total_response_ms":      _stats("total_response_ms"),
            "ollama_call_ms":         _stats("ollama_call_ms"),
            "token_count":            _stats("token_count"),
            "tokens_per_second":      _stats("tokens_per_second"),
        }


def _log_metrics(m: Dict[str, Any]) -> None:
    """Émet un log structuré lisible en console et fichier."""
    ttft  = f"{m['time_to_first_token_ms']}ms" if m['time_to_first_token_ms'] is not None else "n/a"
    total = f"{m['total_response_ms']}ms"
    tps   = f"{m['tokens_per_second']} tok/s" if m['tokens_per_second'] is not None else "n/a"

    logger.info(
        "[PERF] model=%-20s backend=%-8s | "
        "first_token=%-8s total=%-8s ollama_call=%-8s | "
        "tokens=%-4d  speed=%s",
        m["model"],
        m["backend"],
        ttft,
        total,
        f"{m['ollama_call_ms']}ms",
        m["token_count"],
        tps,
    )


# ── Singleton global ───────────────────────────────────────────────────────
perf = PerfCollector()
