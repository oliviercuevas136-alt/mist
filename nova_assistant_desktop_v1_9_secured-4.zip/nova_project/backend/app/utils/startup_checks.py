from pathlib import Path

from app.config import settings


def run_startup_checks() -> dict:
    results = {
        "static_exists": settings.static_path.exists(),
        "data_exists": settings.data_path.exists(),
        "notes_exists": settings.notes_path.exists(),
        "uploads_exists": settings.uploads_path.exists(),
        "exports_exists": settings.export_path.exists(),
        "log_dir_exists": settings.log_path.exists(),
        "allowed_dirs": [str(p) for p in settings.allowed_base_paths],
    }

    return results