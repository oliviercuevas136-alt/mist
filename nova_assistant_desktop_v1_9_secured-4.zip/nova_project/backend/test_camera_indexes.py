"""
test_camera_indexes.py — Nova Assistant Desktop
Utilitaire de diagnostic : liste les indexes webcam disponibles sur ce PC.

Usage (depuis le dossier backend/) :
    .venv\\Scripts\\python test_camera_indexes.py
"""

import sys


def check_opencv():
    try:
        import cv2
        return cv2
    except ImportError:
        print("[ERREUR] OpenCV non installé.")
        print("         Installez-le via : .venv\\Scripts\\pip install opencv-python-headless")
        sys.exit(1)


def list_camera_indexes(max_index: int = 6):
    cv2 = check_opencv()
    print("\n=== Détection des caméras disponibles ===\n")
    found = []
    for idx in range(max_index):
        # CAP_DSHOW = pilote DirectShow natif Windows (plus fiable sur Win10)
        cap = cv2.VideoCapture(idx, cv2.CAP_DSHOW)
        if cap is not None and cap.isOpened():
            w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            ret, _ = cap.read()
            status = "OK — lecture réussie" if ret else "Ouvert mais lecture échouée"
            print(f"  Index {idx} : {w}x{h} @ {fps:.0f} fps — {status}")
            found.append(idx)
        cap.release()

    print()
    if found:
        print(f"  ✓ {len(found)} caméra(s) détectée(s) : indexes {found}")
        print()
        print("  → Dans backend\\.env, utilisez :")
        print(f"       CAMERA_ENABLED=true")
        print(f"       CAMERA_SOURCE={found[0]}   ← premier index disponible")
        if len(found) > 1:
            print(f"       # Autres disponibles : {found[1:]}")
    else:
        print(f"  ✗ Aucune caméra détectée (indexes 0 à {max_index - 1} testés).")
        print("    Vérifiez que votre webcam est branchée et non utilisée par une autre app.")
    print()


if __name__ == "__main__":
    list_camera_indexes()
