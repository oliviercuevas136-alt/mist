"""
tests/test_camera.py
─────────────────────────────────────────────────────────────────────────────
Tests couche caméra v4.8 — isolation complète, aucune vraie caméra requise.

cv2 est TOUJOURS mocké — même si opencv-python est installé.
Aucun accès réseau, aucun périphérique physique.

Classes :
  TestCameraConfig          (6)  — champs config Settings
  TestResolvSource          (8)  — logique résolution source
  TestCameraManagerNoCV2    (6)  — comportement sans opencv
  TestCameraManagerCV2      (10) — comportement avec cv2 mocké
  TestCameraManagerThread   (6)  — thread start/stop
  TestCameraAPIStatus       (5)  — GET /api/camera/status
  TestCameraAPITest         (5)  — POST /api/camera/test
  TestCameraAPIStartStop    (4)  — POST /api/camera/start + /stop
  TestCameraAPISnapshot     (4)  — GET /api/camera/snapshot
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import sys
import types
import time
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

# ── Capture Settings AVANT que d'autres modules de test polluent sys.modules ─
# test_llm_client.py remplace sys.modules["app.config"] à l'import.
# test_camera.py est collecté en premier (ordre alphabétique), donc on sauvegarde
# la vraie classe Settings ici au niveau module — avant toute pollution.
from app.config import Settings as _RealSettings

# ── Stub minimal pour pydantic_settings (si besoin) ──────────────────────────
# conftest.py ajoute déjà sys.path — on ne re-configure pas ici.

# ── Helpers cv2 mock ─────────────────────────────────────────────────────────


def _make_cv2_mock(opened: bool = True, read_ok: bool = True, frame=None):
    """Construit un module cv2 fictif complet."""
    import numpy as np

    if frame is None and read_ok:
        frame = np.zeros((480, 640, 3), dtype="uint8")

    mock_cap = MagicMock()
    mock_cap.isOpened.return_value = opened
    mock_cap.read.return_value = (read_ok, frame)
    mock_cap.release = MagicMock()
    mock_cap.set = MagicMock()

    cv2_mock = types.ModuleType("cv2")
    cv2_mock.VideoCapture = MagicMock(return_value=mock_cap)
    cv2_mock.CAP_PROP_FRAME_WIDTH = 3
    cv2_mock.CAP_PROP_FRAME_HEIGHT = 4

    buf = np.frombuffer(b"\xff\xd8\xff" + b"\x00" * 97, dtype="uint8")
    cv2_mock.imencode = MagicMock(return_value=(True, buf))

    return cv2_mock, mock_cap


def _make_settings(
    camera_enabled: bool = True,
    camera_source: str = "0",
    camera_type: str = "auto",
    rtsp_url: str = "",
    http_url: str = "",
    reconnect_delay: int = 0,
    fps_limit: int = 10,
    save_snapshots: bool = False,
    frame_width: int = 640,
    frame_height: int = 480,
    snapshot_dir: str = "/tmp/snapshots_test",
):
    s = MagicMock()
    s.camera_enabled = camera_enabled
    s.camera_source = camera_source
    s.camera_type = camera_type
    s.camera_rtsp_url = rtsp_url
    s.camera_http_url = http_url
    s.camera_reconnect_delay_sec = reconnect_delay
    s.camera_fps_limit = fps_limit
    s.camera_save_snapshots = save_snapshots
    s.camera_frame_width = frame_width
    s.camera_frame_height = frame_height
    s.camera_snapshot_dir = snapshot_dir
    return s


# ─────────────────────────────────────────────────────────────────────────────
# 1. TestCameraConfig
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraConfig:
    # Utilise _RealSettings capturée avant toute pollution de sys.modules["app.config"]
    def test_camera_enabled_default_false(self):
        """CAMERA_ENABLED doit être False par défaut."""
        s = _RealSettings()
        assert s.camera_enabled is False

    def test_camera_source_default_zero(self):
        s = _RealSettings()
        assert s.camera_source == "0"

    def test_camera_type_default_auto(self):
        s = _RealSettings()
        assert s.camera_type == "auto"

    def test_camera_rtsp_url_default_empty(self):
        s = _RealSettings()
        assert s.camera_rtsp_url == ""

    def test_camera_http_url_default_empty(self):
        s = _RealSettings()
        assert s.camera_http_url == ""

    def test_camera_fps_limit_default_10(self):
        s = _RealSettings()
        assert s.camera_fps_limit == 10

    def test_camera_save_snapshots_default_false(self):
        s = _RealSettings()
        assert s.camera_save_snapshots is False

    def test_camera_reconnect_delay_default_5(self):
        s = _RealSettings()
        assert s.camera_reconnect_delay_sec == 5


# ─────────────────────────────────────────────────────────────────────────────
# 2. TestResolveSource
# ─────────────────────────────────────────────────────────────────────────────


class TestResolveSource:
    def _rs(self, camera_type, camera_source, rtsp="", http=""):
        from app.services.camera_manager import _resolve_source
        return _resolve_source(camera_type, camera_source, rtsp, http)

    def test_auto_numeric_returns_usb(self):
        src, ctype = self._rs("auto", "0")
        from app.services.camera_manager import CameraType
        assert src == 0
        assert ctype == CameraType.USB

    def test_auto_rtsp_url_priority(self):
        src, ctype = self._rs("auto", "0", rtsp="rtsp://192.168.1.100:554/live")
        from app.services.camera_manager import CameraType
        assert src == "rtsp://192.168.1.100:554/live"
        assert ctype == CameraType.RTSP

    def test_auto_http_url_second(self):
        src, ctype = self._rs("auto", "0", http="http://192.168.1.100:8080/video")
        from app.services.camera_manager import CameraType
        assert src == "http://192.168.1.100:8080/video"
        assert ctype == CameraType.HTTP

    def test_explicit_rtsp_type(self):
        src, ctype = self._rs("rtsp", "1", rtsp="rtsp://cam/stream")
        from app.services.camera_manager import CameraType
        assert ctype == CameraType.RTSP
        assert src == "rtsp://cam/stream"

    def test_explicit_http_type(self):
        src, ctype = self._rs("http", "1", http="http://cam/mjpeg")
        from app.services.camera_manager import CameraType
        assert ctype == CameraType.HTTP
        assert src == "http://cam/mjpeg"

    def test_usb_index_1(self):
        src, ctype = self._rs("usb", "1")
        from app.services.camera_manager import CameraType
        assert src == 1
        assert ctype == CameraType.USB

    def test_file_type(self):
        src, ctype = self._rs("file", "test_video.mp4")
        from app.services.camera_manager import CameraType
        assert src == "test_video.mp4"
        assert ctype == CameraType.FILE

    def test_auto_rtsp_prefix_in_source(self):
        src, ctype = self._rs("auto", "rtsp://192.168.1.10/stream")
        from app.services.camera_manager import CameraType
        assert ctype == CameraType.RTSP

    def test_auto_http_prefix_in_source(self):
        src, ctype = self._rs("auto", "http://192.168.1.10:8080/video")
        from app.services.camera_manager import CameraType
        assert ctype == CameraType.HTTP

    def test_invalid_type_falls_back_to_auto(self):
        src, ctype = self._rs("unknown_xyz", "0")
        from app.services.camera_manager import CameraType
        assert ctype == CameraType.USB
        assert src == 0


# ─────────────────────────────────────────────────────────────────────────────
# 3. TestCameraManagerNoCV2
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraManagerNoCV2:
    """Simule l'absence d'opencv-python."""

    def setup_method(self):
        # Forcer _CV2_AVAILABLE = False dans le module
        import app.services.camera_manager as cam_mod
        self._orig = cam_mod._CV2_AVAILABLE
        cam_mod._CV2_AVAILABLE = False
        # Forcer cv2 = None
        self._orig_cv2 = cam_mod.cv2
        cam_mod.cv2 = None

    def teardown_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = self._orig
        cam_mod.cv2 = self._orig_cv2

    def test_start_returns_false_without_cv2(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=True)
        mgr = CameraManager(s)
        result = mgr.start()
        assert result is False

    def test_state_degraded_without_cv2(self):
        from app.services.camera_manager import CameraManager, CameraState
        s = _make_settings(camera_enabled=True)
        mgr = CameraManager(s)
        mgr.start()
        assert mgr.status.state == CameraState.DEGRADED

    def test_last_error_cv2_not_installed(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=True)
        mgr = CameraManager(s)
        mgr.start()
        assert "cv2" in (mgr.status.last_error or "")

    def test_test_source_returns_not_available(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=True)
        mgr = CameraManager(s)
        result = mgr.test_source(0)
        assert result["ok"] is False
        assert "cv2" in result["reason"]

    def test_snapshot_jpeg_returns_none(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=True)
        mgr = CameraManager(s)
        assert mgr.snapshot_jpeg() is None

    def test_snapshot_base64_returns_none(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=True)
        mgr = CameraManager(s)
        assert mgr.snapshot_base64() is None


# ─────────────────────────────────────────────────────────────────────────────
# 4. TestCameraManagerCV2
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraManagerCV2:
    """Tests avec cv2 mocké — caméra répond correctement."""

    def _make_manager(self, opened=True, read_ok=True, **kw):
        import numpy as np
        import app.services.camera_manager as cam_mod

        frame = np.zeros((480, 640, 3), dtype="uint8")
        buf = np.frombuffer(b"\xff\xd8\xff" + b"\x00" * 97, dtype="uint8")

        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = opened
        mock_cap.read.return_value = (read_ok, frame if read_ok else None)
        mock_cap.release = MagicMock()
        mock_cap.set = MagicMock()

        cv2_mock = types.ModuleType("cv2")
        cv2_mock.VideoCapture = MagicMock(return_value=mock_cap)
        cv2_mock.CAP_PROP_FRAME_WIDTH = 3
        cv2_mock.CAP_PROP_FRAME_HEIGHT = 4
        cv2_mock.imencode = MagicMock(return_value=(True, buf))

        cam_mod._CV2_AVAILABLE = True
        cam_mod.cv2 = cv2_mock

        s = _make_settings(**kw)
        mgr = cam_mod.CameraManager(s)
        return mgr, mock_cap, cv2_mock, cam_mod

    def test_test_source_opened_ok(self):
        mgr, _, _, cam_mod = self._make_manager()
        result = mgr.test_source(0)
        assert result["ok"] is True
        assert result["source"] == "0"
        # nettoyage
        import app.services.camera_manager as m
        m._CV2_AVAILABLE = False

    def test_test_source_not_opened(self):
        mgr, _, _, cam_mod = self._make_manager(opened=False)
        result = mgr.test_source(0)
        assert result["ok"] is False
        assert result["reason"] == "not_opened"
        import app.services.camera_manager as m
        m._CV2_AVAILABLE = False

    def test_test_source_no_frame(self):
        mgr, _, _, cam_mod = self._make_manager(opened=True, read_ok=False)
        result = mgr.test_source(0)
        assert result["ok"] is False
        assert result["reason"] == "no_frame"
        import app.services.camera_manager as m
        m._CV2_AVAILABLE = False

    def test_detect_usb_cameras_returns_list(self):
        mgr, _, _, cam_mod = self._make_manager()
        results = mgr.detect_usb_cameras(max_index=3)
        assert len(results) == 3
        for r in results:
            assert "index" in r
            assert "ok" in r
        import app.services.camera_manager as m
        m._CV2_AVAILABLE = False

    def test_detect_usb_cameras_index_present(self):
        mgr, _, _, _ = self._make_manager()
        results = mgr.detect_usb_cameras(max_index=2)
        assert results[0]["index"] == 0
        assert results[1]["index"] == 1
        import app.services.camera_manager as m
        m._CV2_AVAILABLE = False

    def test_test_source_videocapture_exception(self):
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = True

        cv2_mock = types.ModuleType("cv2")
        cv2_mock.VideoCapture = MagicMock(side_effect=RuntimeError("camera error"))
        cam_mod.cv2 = cv2_mock

        s = _make_settings()
        mgr = cam_mod.CameraManager(s)
        result = mgr.test_source(0)
        assert result["ok"] is False
        assert "camera error" in result["reason"]
        cam_mod._CV2_AVAILABLE = False

    def test_camera_disabled_start_returns_false(self):
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = True
        s = _make_settings(camera_enabled=False)
        mgr = cam_mod.CameraManager(s)
        result = mgr.start()
        assert result is False
        from app.services.camera_manager import CameraState
        assert mgr.status.state == CameraState.DEGRADED
        cam_mod._CV2_AVAILABLE = False

    def test_status_cv2_available_field(self):
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = True
        s = _make_settings(camera_enabled=False)
        mgr = cam_mod.CameraManager(s)
        # cv2_available reflète l'état au moment du test
        st = mgr.status
        assert isinstance(st.cv2_available, bool)
        cam_mod._CV2_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# 5. TestCameraManagerThread
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraManagerThread:
    """Tests du thread avec caméra qui se déconnecte rapidement."""

    def test_stop_before_start(self):
        """stop() sans start() préalable ne doit pas crasher."""
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=False)
        mgr = CameraManager(s)
        mgr.stop()  # ne doit pas lever d'exception
        from app.services.camera_manager import CameraState
        assert mgr.status.state == CameraState.STOPPED

    def test_start_disabled_not_running(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=False)
        mgr = CameraManager(s)
        mgr.start()
        assert not mgr.is_running

    def test_start_no_cv2_not_running(self):
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = False
        s = _make_settings(camera_enabled=True)
        mgr = cam_mod.CameraManager(s)
        mgr.start()
        assert not mgr.is_running

    def test_snapshot_returns_none_before_connection(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=False)
        mgr = CameraManager(s)
        assert mgr.snapshot_jpeg() is None

    def test_double_stop_safe(self):
        from app.services.camera_manager import CameraManager
        s = _make_settings(camera_enabled=False)
        mgr = CameraManager(s)
        mgr.stop()
        mgr.stop()  # idempotent — pas de crash

    def test_init_camera_manager_disabled(self):
        """init_camera_manager avec camera_enabled=False crée le manager mais ne démarre pas."""
        import app.services.camera_manager as cam_mod
        s = _make_settings(camera_enabled=False)
        mgr = cam_mod.init_camera_manager(s)
        assert mgr is not None
        assert not mgr.is_running


# ─────────────────────────────────────────────────────────────────────────────
# Fixture FastAPI pour les tests API
# ─────────────────────────────────────────────────────────────────────────────


def _make_api_settings(**kw):
    from app.config import Settings
    import os
    overrides = {
        "camera_enabled": kw.get("camera_enabled", False),
        "camera_source": kw.get("camera_source", "0"),
        "camera_type": kw.get("camera_type", "auto"),
        "camera_rtsp_url": kw.get("camera_rtsp_url", ""),
        "camera_http_url": kw.get("camera_http_url", ""),
        "camera_reconnect_delay_sec": kw.get("camera_reconnect_delay_sec", 5),
        "camera_fps_limit": kw.get("camera_fps_limit", 10),
        "camera_save_snapshots": kw.get("camera_save_snapshots", False),
        "camera_frame_width": kw.get("camera_frame_width", 640),
        "camera_frame_height": kw.get("camera_frame_height", 480),
        "camera_snapshot_dir": kw.get("camera_snapshot_dir", "/tmp/snap_test"),
    }
    return overrides


def _build_test_client(camera_enabled=False, has_frame=False):
    """
    Construit un TestClient FastAPI isolé pour les endpoints caméra.
    Mocke : cv2, db, WhisperModel, pyttsx3, faster_whisper.
    """
    import sqlite3
    import app.db.database as _db_mod

    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE IF NOT EXISTS _dummy (id INTEGER PRIMARY KEY)")

    # Stub db
    from sqlalchemy import create_engine, event as sa_event
    from sqlalchemy.orm import sessionmaker
    real_engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
    )
    from app.db.database import Base
    import app.db.models  # noqa
    Base.metadata.create_all(bind=real_engine)
    _db_mod.engine = real_engine
    _db_mod.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=real_engine)

    # Stubs lourds
    import numpy as np
    buf = np.frombuffer(b"\xff\xd8\xff" + b"\x00" * 97, dtype="uint8")

    mock_cap = MagicMock()
    mock_cap.isOpened.return_value = True
    mock_cap.read.return_value = (True, np.zeros((480, 640, 3), dtype="uint8"))
    mock_cap.release = MagicMock()
    mock_cap.set = MagicMock()

    cv2_mock = types.ModuleType("cv2")
    cv2_mock.VideoCapture = MagicMock(return_value=mock_cap)
    cv2_mock.CAP_PROP_FRAME_WIDTH = 3
    cv2_mock.CAP_PROP_FRAME_HEIGHT = 4
    cv2_mock.imencode = MagicMock(return_value=(True, buf))

    import app.services.camera_manager as cam_mod
    cam_mod._CV2_AVAILABLE = True
    cam_mod.cv2 = cv2_mock
    # Reset singleton
    cam_mod._manager_instance = None

    pyttsx3_mock = types.ModuleType("pyttsx3")
    pyttsx3_mock.init = MagicMock(return_value=MagicMock())
    sys.modules.setdefault("pyttsx3", pyttsx3_mock)

    fw_mock = types.ModuleType("faster_whisper")

    class _FakeWhisper:
        def __init__(self, *a, **kw):
            pass
        def transcribe(self, *a, **kw):
            return [], MagicMock(language="fr")

    fw_mock.WhisperModel = _FakeWhisper
    sys.modules.setdefault("faster_whisper", fw_mock)

    from app.config import Settings
    import app.api.camera as cam_api_mod

    fake_settings = Settings()
    # patch settings dans le module api/camera
    with patch("app.api.camera.settings") as ms, \
         patch("app.services.camera_manager._CV2_AVAILABLE", True), \
         patch("app.services.camera_manager.cv2", cv2_mock):

        ms.camera_enabled = camera_enabled
        ms.camera_source = "0"
        ms.camera_type = "auto"
        ms.camera_rtsp_url = ""
        ms.camera_http_url = ""
        ms.camera_reconnect_delay_sec = 0
        ms.camera_fps_limit = 10
        ms.camera_save_snapshots = False
        ms.camera_frame_width = 640
        ms.camera_frame_height = 480
        ms.camera_snapshot_dir = "/tmp/snap_test"

        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        mini_app = FastAPI()
        from app.api.camera import router as cam_router
        mini_app.include_router(cam_router)

        client = TestClient(mini_app, raise_server_exceptions=True)
        return client, cam_mod, cv2_mock


# ─────────────────────────────────────────────────────────────────────────────
# 6. TestCameraAPIStatus
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraAPIStatus:
    def setup_method(self):
        # Patch léger — uniquement camera_manager + settings
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def teardown_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def _client(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = False
        mini = FastAPI()
        mini.include_router(__import__("app.api.camera", fromlist=["router"]).router)
        return TestClient(mini)

    def test_status_200(self):
        c = self._client()
        r = c.get("/api/camera/status")
        assert r.status_code == 200

    def test_status_has_state(self):
        c = self._client()
        r = c.get("/api/camera/status")
        data = r.json()
        assert "state" in data

    def test_status_cv2_available_field(self):
        c = self._client()
        r = c.get("/api/camera/status")
        data = r.json()
        assert "cv2_available" in data
        # cv2 forcé à False dans ce test
        assert data["cv2_available"] is False

    def test_status_snapshot_available_false_initially(self):
        c = self._client()
        r = c.get("/api/camera/status")
        assert r.json()["snapshot_available"] is False

    def test_status_enabled_field(self):
        c = self._client()
        r = c.get("/api/camera/status")
        assert "enabled" in r.json()


# ─────────────────────────────────────────────────────────────────────────────
# 7. TestCameraAPITest
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraAPITest:
    def setup_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def teardown_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def _client(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        mini = FastAPI()
        mini.include_router(__import__("app.api.camera", fromlist=["router"]).router)
        return TestClient(mini)

    def test_test_no_cv2_returns_false(self):
        c = self._client()
        r = c.post("/api/camera/test", json={})
        assert r.status_code == 200
        assert r.json()["ok"] is False

    def test_test_with_source_string(self):
        c = self._client()
        r = c.post("/api/camera/test", json={"source": "0"})
        assert r.status_code == 200
        data = r.json()
        assert "ok" in data

    def test_test_empty_body(self):
        c = self._client()
        r = c.post("/api/camera/test")
        assert r.status_code == 200

    def test_test_rtsp_url(self):
        c = self._client()
        r = c.post("/api/camera/test", json={"source": "rtsp://192.168.1.1:554/stream"})
        assert r.status_code == 200
        assert r.json()["ok"] is False  # cv2 = False ici

    def test_test_returns_reason_on_failure(self):
        c = self._client()
        r = c.post("/api/camera/test", json={"source": "0"})
        assert r.status_code == 200
        data = r.json()
        if not data["ok"]:
            assert "reason" in data


# ─────────────────────────────────────────────────────────────────────────────
# 8. TestCameraAPIStartStop
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraAPIStartStop:
    def setup_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def teardown_method(self):
        import app.services.camera_manager as cam_mod
        if cam_mod._manager_instance:
            cam_mod._manager_instance.stop()
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def _client(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        mini = FastAPI()
        mini.include_router(__import__("app.api.camera", fromlist=["router"]).router)
        return TestClient(mini)

    def test_start_returns_200(self):
        c = self._client()
        r = c.post("/api/camera/start")
        assert r.status_code == 200

    def test_start_returns_ok_field(self):
        c = self._client()
        r = c.post("/api/camera/start")
        assert "ok" in r.json()

    def test_stop_returns_200(self):
        c = self._client()
        r = c.post("/api/camera/stop")
        assert r.status_code == 200

    def test_stop_returns_ok_true(self):
        c = self._client()
        r = c.post("/api/camera/stop")
        assert r.json()["ok"] is True


# ─────────────────────────────────────────────────────────────────────────────
# 9. TestCameraAPISnapshot
# ─────────────────────────────────────────────────────────────────────────────


class TestCameraAPISnapshot:
    def setup_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def teardown_method(self):
        import app.services.camera_manager as cam_mod
        cam_mod._manager_instance = None
        cam_mod._CV2_AVAILABLE = False

    def _client(self):
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        mini = FastAPI()
        mini.include_router(__import__("app.api.camera", fromlist=["router"]).router)
        return TestClient(mini)

    def test_snapshot_503_when_no_frame(self):
        c = self._client()
        r = c.get("/api/camera/snapshot")
        assert r.status_code == 503

    def test_snapshot_503_detail_message(self):
        c = self._client()
        r = c.get("/api/camera/snapshot")
        assert "snapshot" in r.json()["detail"].lower() or r.status_code == 503

    def test_snapshot_with_injected_frame(self):
        """Injecte un frame directement dans le manager et vérifie la réponse."""
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = False
        s = _make_settings(camera_enabled=False)
        mgr = cam_mod.CameraManager(s)
        mgr._last_frame = b"\xff\xd8\xff\xe0\x00\x10JFIF"  # JPEG header
        mgr._status.snapshot_available = True
        cam_mod._manager_instance = mgr

        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        mini = FastAPI()
        mini.include_router(__import__("app.api.camera", fromlist=["router"]).router)
        c = TestClient(mini)

        r = c.get("/api/camera/snapshot")
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("image/jpeg")

    def test_snapshot_returns_jpeg_content_type(self):
        """Vérifie que le Content-Type est image/jpeg."""
        import app.services.camera_manager as cam_mod
        cam_mod._CV2_AVAILABLE = False
        s = _make_settings(camera_enabled=False)
        mgr = cam_mod.CameraManager(s)
        mgr._last_frame = b"\xff\xd8\xff\xe0" + b"\x00" * 50
        mgr._status.snapshot_available = True
        cam_mod._manager_instance = mgr

        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        mini = FastAPI()
        mini.include_router(__import__("app.api.camera", fromlist=["router"]).router)
        c = TestClient(mini)
        r = c.get("/api/camera/snapshot")
        if r.status_code == 200:
            assert "jpeg" in r.headers.get("content-type", "")


# ─────────────────────────────────────────────────────────────────────────────
# 10. TestLogConstants
# ─────────────────────────────────────────────────────────────────────────────


class TestLogConstants:
    def _source(self):
        path = __import__("pathlib").Path(
            __import__("os").path.dirname(__file__) + "/../app/services/camera_manager.py"
        )
        return path.read_text(encoding="utf-8")

    def test_log_source_test(self):
        assert "[CAMERA] SOURCE_TEST" in self._source()

    def test_log_connected(self):
        assert "[CAMERA] CONNECTED" in self._source()

    def test_log_failed(self):
        assert "[CAMERA] FAILED" in self._source()

    def test_log_reconnecting(self):
        assert "[CAMERA] RECONNECTING" in self._source()

    def test_log_frame_ok(self):
        assert "[CAMERA] FRAME_OK" in self._source()

    def test_log_degraded_mode(self):
        assert "[CAMERA] DEGRADED_MODE" in self._source()
