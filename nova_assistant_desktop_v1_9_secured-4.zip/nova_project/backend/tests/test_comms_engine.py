"""
tests/test_comms_engine.py — V3
Fallback log, validation, masquage password, test(), robustesse réseau.
"""

import pytest
from unittest.mock import patch, MagicMock

from app.core.comms_engine import CommsEngine
from app.core.monitoring_engine import Alert, AlertLevel, AlertType


@pytest.fixture
def engine() -> CommsEngine:
    return CommsEngine()


def make_alert(atype=AlertType.FALL_ESCALATED, level=AlertLevel.CRITICAL) -> Alert:
    return Alert(type=atype, level=level, message=f"Test {atype.value}", id=1)


# ---------------------------------------------------------------------------
# Fallback log — toujours actif
# ---------------------------------------------------------------------------

class TestLogFallback:
    def test_notify_always_logs(self, engine, tmp_path):
        with patch("app.config.settings") as s:
            s.data_path = tmp_path
            result = engine.notify(make_alert())
        assert result["channels"]["log"] == "ok"

    def test_log_file_written(self, engine, tmp_path):
        with patch("app.config.settings") as s:
            s.data_path = tmp_path
            engine._log_to_file(make_alert(AlertType.FALL_ESCALATED, AlertLevel.CRITICAL))
        log = (tmp_path / "alerts.log").read_text(encoding="utf-8")
        assert "CRITICAL" in log.upper() or "critical" in log
        assert "fall" in log

    def test_log_never_raises(self, engine, tmp_path):
        with patch("app.config.settings") as s:
            s.data_path = tmp_path
            engine._log_to_file(make_alert())  # ne doit pas lever


# ---------------------------------------------------------------------------
# Validation config
# ---------------------------------------------------------------------------

class TestValidation:
    def test_email_not_configured_by_default(self, engine):
        ok, msg = engine.validate_email_config()
        assert ok is False

    def test_partial_email_invalid(self, engine):
        engine.configure({"email": {"enabled": True, "smtp_host": "smtp.gmail.com"}})
        ok, msg = engine.validate_email_config()
        assert ok is False
        assert len(msg) > 0

    def test_complete_email_valid(self, engine):
        engine.configure({"email": {
            "enabled": True, "smtp_host": "smtp.gmail.com",
            "smtp_user": "u@g.com", "smtp_password": "pass", "recipient": "c@g.com",
        }})
        ok, _ = engine.validate_email_config()
        assert ok is True

    def test_webhook_invalid_without_url(self, engine):
        engine.configure({"webhook": {"enabled": True}})
        ok, msg = engine.validate_webhook_config()
        assert ok is False

    def test_webhook_valid_with_url(self, engine):
        engine.configure({"webhook": {"enabled": True, "url": "https://hooks.example.com"}})
        ok, _ = engine.validate_webhook_config()
        assert ok is True


# ---------------------------------------------------------------------------
# Masquage password
# ---------------------------------------------------------------------------

class TestPasswordMasking:
    def test_password_not_in_logs(self, engine):
        logged = []
        with patch("app.core.comms_engine.logger") as mock_log:
            mock_log.info.side_effect = lambda msg, *a, **k: \
                logged.append(msg % a if a else msg)
            engine.configure({"email": {
                "enabled": True, "smtp_host": "smtp.gmail.com",
                "smtp_user": "u@g.com", "smtp_password": "SECRET_PASSWORD_123",
                "recipient": "c@g.com",
            }})
        for msg in logged:
            assert "SECRET_PASSWORD_123" not in str(msg), \
                f"Mot de passe trouve dans le log : {msg}"


# ---------------------------------------------------------------------------
# test() — retourne config_status
# ---------------------------------------------------------------------------

class TestTestMethod:
    def test_returns_config_status(self, engine):
        with patch.object(engine, "_log_to_file"):
            result = engine.test()
        assert "config_status" in result
        assert result["config_status"]["log"]["configured"] is True

    def test_email_detail_when_not_configured(self, engine):
        with patch.object(engine, "_log_to_file"):
            result = engine.test()
        assert result["config_status"]["email"]["configured"] is False
        assert len(result["config_status"]["email"]["detail"]) > 0


# ---------------------------------------------------------------------------
# notify() — comportement par canal
# ---------------------------------------------------------------------------

class TestNotify:
    def test_skips_email_if_not_configured(self, engine):
        with patch.object(engine, "_log_to_file"):
            result = engine.notify(make_alert())
        assert "skipped" in result["channels"].get("email", "")

    def test_sends_email_if_configured(self, engine):
        engine.configure({"email": {
            "enabled": True, "smtp_host": "smtp.example.com",
            "smtp_user": "u@e.com", "smtp_password": "p", "recipient": "c@e.com",
        }})
        with (
            patch.object(engine, "_log_to_file"),
            patch.object(engine, "_send_email") as mock_email,
        ):
            result = engine.notify(make_alert(level=AlertLevel.CRITICAL))
            mock_email.assert_called_once()
            assert result["channels"]["email"] == "ok"

    def test_email_error_captured_not_raised(self, engine):
        engine.configure({"email": {
            "enabled": True, "smtp_host": "smtp.example.com",
            "smtp_user": "u@e.com", "smtp_password": "p", "recipient": "c@e.com",
        }})
        with (
            patch.object(engine, "_log_to_file"),
            patch.object(engine, "_send_email", side_effect=ConnectionRefusedError("refused")),
        ):
            result = engine.notify(make_alert(level=AlertLevel.CRITICAL))
        assert "error" in result["channels"]["email"]

    def test_webhook_error_captured(self, engine):
        engine.configure({"webhook": {"enabled": True, "url": "https://hooks.example.com"}})
        with (
            patch.object(engine, "_log_to_file"),
            patch.object(engine, "_send_webhook", side_effect=TimeoutError("timeout")),
        ):
            result = engine.notify(make_alert())
        assert "error" in result["channels"]["webhook"]

    def test_history_populated(self, engine):
        with patch.object(engine, "_log_to_file"):
            engine.notify(make_alert())
        assert len(engine.get_history()) >= 1

    def test_history_capped_at_200(self, engine):
        with patch.object(engine, "_log_to_file"):
            for _ in range(250):
                engine.notify(make_alert(AlertType.TEST, AlertLevel.INFO))
        assert len(engine._history) <= 200

    def test_get_history_most_recent_first(self, engine):
        """get_history() retourne le plus recent en premier."""
        with patch.object(engine, "_log_to_file"):
            engine.notify(make_alert(AlertType.TEST, AlertLevel.INFO))
            engine.notify(make_alert(AlertType.MANUAL, AlertLevel.CRITICAL))
        history = engine.get_history(limit=2)
        assert history[0]["alert_type"] == AlertType.MANUAL.value

    def test_network_error_doesnt_crash(self, engine):
        """Une erreur reseau ne doit jamais crasher notify()."""
        engine.configure({
            "email":   {"enabled": True, "smtp_host": "smtp.example.com",
                        "smtp_user": "u@e.com", "smtp_password": "p", "recipient": "c@e.com"},
            "webhook": {"enabled": True, "url": "https://hooks.example.com"},
        })
        with (
            patch.object(engine, "_log_to_file"),
            patch.object(engine, "_send_email",   side_effect=OSError("network down")),
            patch.object(engine, "_send_webhook", side_effect=OSError("network down")),
        ):
            result = engine.notify(make_alert(level=AlertLevel.CRITICAL))
        # Doit retourner un dict avec les erreurs capturees
        assert "channels" in result
        assert result["channels"]["log"] == "ok"
