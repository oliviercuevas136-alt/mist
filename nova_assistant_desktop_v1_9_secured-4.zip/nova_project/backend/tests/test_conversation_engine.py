from app.core.conversation_engine import ConversationEngine
from app.db.models import Message


def test_build_conversation_summary_text():
    engine = ConversationEngine()
    messages = [
        Message(conversation_id=1, role="user", content="Bonjour"),
        Message(conversation_id=1, role="assistant", content="Salut"),
        Message(conversation_id=1, role="user", content="Je veux organiser Nova"),
    ]

    summary = engine.build_conversation_summary_text(messages)
    # Le moteur utilise la localisation française : "Utilisateur:" et "Assistant:"
    assert "Utilisateur: Bonjour" in summary
    assert "Assistant: Salut" in summary