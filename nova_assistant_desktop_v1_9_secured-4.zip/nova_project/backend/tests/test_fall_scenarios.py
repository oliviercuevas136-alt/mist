"""
tests/test_fall_scenarios.py — Scénarios réels V4.

5 scénarios couvrant les conditions d'usage terrain :
  1. Simulation chute   — chute réelle, personne ne répond pas
  2. Personne immobile  — silence/absence prolongée sans chute
  3. Faux positif       — chute détectée mais personne répond vite
  4. Mode nuit          — caméra indisponible (obscurité), vocal seul
  5. Bruit ambiant      — signaux micro parasites sans vraie voix utile

Chaque scénario vérifie que le système :
  - déclenche les bonnes alertes (et pas les mauvaises)
  - reste dans le bon état machine
  - ne crash pas
  - respecte les garanties humaines (pas de CRITICAL sur faux positif)
"""

import time
import threading
from datetime import datetime, timedelta, timezone

import pytest

from app.core.monitoring_engine import (
    Alert, AlertLevel, AlertType, MachineState,
    MonitoringEngine, _now,
)


# ---------------------------------------------------------------------------
# Fixture engine isolée — fenêtre très courte pour les tests (0.3s)
# ---------------------------------------------------------------------------

@pytest.fixture
def engine() -> MonitoringEngine:
    e = MonitoringEngine()
    e.CONFIRM_WINDOW_S       = 0.3    # fenêtre 10-15s → 0.3s en test
    e._persist_alert_sync    = lambda a: None   # désactive SQLite
    # Délais de reset adaptés aux attentes des tests (max sleep = 0.8s)
    e._reset_idle_delay_confirm  = 0.1   # reset CONFIRM rapide
    e._reset_idle_delay_escalate = 1.5   # > 0.8s (durée max des checks d'état)
    # Cooldowns réduits pour ne pas bloquer les scénarios multi-étapes
    e.cooldowns["fall"]              = 0
    e.cooldowns["prolonged_absence"] = 0
    e.cooldowns["prolonged_silence"] = 0
    e.cooldowns["inactivity"]        = 0
    yield e
    e.stop()


def _collect(engine: MonitoringEngine):
    """Retourne une liste vide qui se remplit en temps réel."""
    received = []
    engine.register_callback(lambda a: received.append(a))
    return received


def _spoken(engine: MonitoringEngine):
    """Retourne une liste vide qui se remplit avec les messages TTS."""
    msgs = []
    engine.register_tts_callback(lambda m: msgs.append(m))
    return msgs


# ===========================================================================
# SCÉNARIO 1 — Simulation chute réelle (personne ne répond pas)
# ===========================================================================

class TestScenarioFallReal:
    """
    Chute simulée via signal_fall().
    La personne est inconsciente → aucune réponse dans la fenêtre.
    Attendu : TTS immédiat → attente → CRITICAL → ESCALATE → comms.
    """

    def test_s1_tts_immediate_on_fall(self, engine):
        """TTS prononcé immédiatement à la détection, avant tout timeout."""
        msgs = _spoken(engine)
        t0 = time.time()
        engine.signal_fall(extra={"confidence": 0.88, "frames_confirmed": 5})
        time.sleep(0.05)
        elapsed = time.time() - t0
        assert elapsed < 1.0, "TTS ne doit pas attendre la fin de la fenêtre"
        assert len(msgs) >= 1, "Au moins un TTS doit être envoyé"
        assert any(
            w in msgs[0].lower()
            for w in ["tombé", "reponds", "réponds", "bien", "aide"]
        ), f"TTS doit demander si la personne va bien, reçu: {msgs[0]}"

    def test_s1_critical_alert_after_no_response(self, engine):
        """Sans réponse → alerte CRITICAL avec type FALL_ESCALATED."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.91, "frames_confirmed": 4})
        time.sleep(0.8)   # > fenêtre 0.3s + marge

        critical = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(critical) >= 1, "Doit produire une alerte CRITICAL si pas de réponse"

        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert len(escalated) >= 1, "Type FALL_ESCALATED attendu"

    def test_s1_state_reaches_escalate(self, engine):
        """La state machine doit atteindre ALERT ou ESCALATE."""
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.8)
        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.ALERT, MachineState.ESCALATE), \
            f"État attendu ALERT/ESCALATE, obtenu: {state}"

    def test_s1_two_tts_messages(self, engine):
        """Deux TTS : 1 à la détection + 1 lors de l'escalade."""
        msgs = _spoken(engine)
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.8)
        assert len(msgs) >= 2, (
            f"Attendu ≥2 TTS (détection + escalade), reçu: {len(msgs)}"
        )

    def test_s1_comms_notified_on_escalation(self, engine):
        """L'alerte escaladée doit avoir le niveau CRITICAL pour déclencher comms."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.85})
        time.sleep(0.8)
        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert escalated, "Pas d'alerte FALL_ESCALATED"
        assert escalated[0].level == AlertLevel.CRITICAL
        # Vérifier que extra contient les données de la chute
        assert "waited_s" in escalated[0].extra or "confidence" in escalated[0].extra

    def test_s1_fall_counter_incremented(self, engine):
        """Compteur de chutes du jour incrémenté."""
        engine.signal_fall(extra={"confidence": 0.9})
        assert engine._sensors.fall_count_today == 1

    def test_s1_confidence_data_in_extra(self, engine):
        """Les données de confiance doivent être transmises à l'alerte."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.92, "frames_confirmed": 5, "ratio": 0.3})
        time.sleep(0.8)
        # L'extra de l'alerte ESCALATED doit contenir les données vision
        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert escalated
        # confidence ou frames_confirmed doit être présent
        all_extras = {k: v for a in escalated for k, v in a.extra.items()}
        assert any(k in all_extras for k in ["confidence", "frames_confirmed"]), \
            f"Données vision manquantes dans extra: {all_extras}"


# ===========================================================================
# SCÉNARIO 2 — Personne immobile (silence + absence prolongée)
# ===========================================================================

class TestScenarioStillPerson:
    """
    Personne immobile depuis longtemps.
    Aucune chute détectée — uniquement silence + absence.
    Attendu : alertes WARNING uniquement, jamais CRITICAL, jamais de chute.
    """

    def test_s2_prolonged_silence_is_warning(self, engine):
        """2h de silence → alerte WARNING PROLONGED_SILENCE."""
        received = _collect(engine)
        since = _now() - timedelta(minutes=130)
        engine._maybe_alert_silence(130.0, since)

        assert len(received) == 1
        assert received[0].type  == AlertType.PROLONGED_SILENCE
        assert received[0].level == AlertLevel.WARNING

    def test_s2_prolonged_absence_is_warning(self, engine):
        """45min d'absence caméra → alerte WARNING PROLONGED_ABSENCE."""
        received = _collect(engine)
        engine.signal_absence(extra={"minutes": 50.0, "source": "temporal_loop"})

        assert len(received) == 1
        assert received[0].type  == AlertType.PROLONGED_ABSENCE
        assert received[0].level == AlertLevel.WARNING

    def test_s2_silence_never_produces_critical(self, engine):
        """RÈGLE ABSOLUE : silence prolongé ne produit jamais CRITICAL."""
        received = _collect(engine)
        since = _now() - timedelta(minutes=200)
        engine._maybe_alert_silence(200.0, since)

        for a in received:
            assert a.level != AlertLevel.CRITICAL, \
                "Silence ne doit JAMAIS produire une alerte CRITICAL"

    def test_s2_absence_never_triggers_fall_state_machine(self, engine):
        """L'absence ne doit pas lancer la state machine de chute."""
        engine.signal_absence(extra={"minutes": 60.0})
        time.sleep(0.1)
        with engine._lock:
            state = engine._incident.machine_state
        assert state == MachineState.IDLE, \
            f"signal_absence() ne doit pas lancer la state machine (état: {state})"

    def test_s2_absence_no_tts_escalation(self, engine):
        """L'absence ne doit pas déclencher de TTS d'escalade."""
        msgs = _spoken(engine)
        engine.signal_absence(extra={"minutes": 50.0})
        # Le TTS de silence vient de _maybe_alert_silence, pas de signal_absence
        time.sleep(0.1)
        # Pas de TTS lié à une "chute" ou "escalade"
        escalation_tts = [
            m for m in msgs
            if any(w in m.lower() for w in ["secours", "appelle", "urgence", "tombe"])
        ]
        assert len(escalation_tts) == 0, \
            f"signal_absence() ne doit pas produire un TTS d'escalade: {escalation_tts}"

    def test_s2_inactivity_alert_is_warning(self, engine):
        """8h d'inactivité totale → WARNING, jamais CRITICAL."""
        received = _collect(engine)
        engine.signal_inactivity(extra={"hours": 9.0})

        assert received[0].type  == AlertType.INACTIVITY
        assert received[0].level == AlertLevel.WARNING

    def test_s2_silence_tts_is_gentle(self, engine):
        """Le TTS de silence doit être doux (pas alarmant)."""
        msgs = _spoken(engine)
        since = _now() - timedelta(minutes=130)
        engine._maybe_alert_silence(130.0, since)
        time.sleep(0.1)

        assert len(msgs) >= 1
        msg_lower = msgs[0].lower()
        # Doit être une question douce, pas une alarme
        assert any(w in msg_lower for w in ["bonjour", "bien", "entendu", "moment", "comment"]), \
            f"TTS silence trop alarmant: {msgs[0]}"
        # Ne doit pas contenir de mots d'urgence
        assert not any(w in msg_lower for w in ["urgence", "secours", "critique"]), \
            f"TTS silence ne doit pas alarmer: {msgs[0]}"


# ===========================================================================
# SCÉNARIO 3 — Faux positif (réponse rapide)
# ===========================================================================

class TestScenarioFalsePositive:
    """
    Chute détectée → personne répond dans les 10s (elle va bien).
    Attendu : WARNING seulement, jamais CRITICAL, retour à IDLE.
    C'est le scénario le plus important pour éviter les faux secours.
    """

    def test_s3_response_prevents_critical(self, engine):
        """Réponse dans la fenêtre → pas d'alerte CRITICAL."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.8, "frames_confirmed": 4})
        time.sleep(0.05)
        engine.signal_response()    # réponse immédiate
        time.sleep(0.6)

        critical = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(critical) == 0, \
            f"Faux positif avec réponse NE DOIT PAS produire CRITICAL. Reçu: {critical}"

    def test_s3_response_produces_confirmed_warning(self, engine):
        """Réponse → alerte WARNING FALL_CONFIRMED."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.6)

        confirmed = [a for a in received if a.type == AlertType.FALL_CONFIRMED]
        assert len(confirmed) == 1
        assert confirmed[0].level == AlertLevel.WARNING

    def test_s3_voice_counts_as_response(self, engine):
        """Voix détectée = réponse automatique → pas de CRITICAL."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.85})
        time.sleep(0.05)
        engine.signal_voice_activity()   # voix = réponse implicite
        time.sleep(0.6)

        critical = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(critical) == 0, "Voix reçue = réponse, ne doit pas escalader"

    def test_s3_state_returns_to_idle_after_confirm(self, engine):
        """Après confirmation, l'état revient à CONFIRM ou IDLE (jamais ALERT)."""
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.6)

        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.CONFIRM, MachineState.IDLE), \
            f"État après faux positif: {state} (attendu CONFIRM ou IDLE)"

    def test_s3_confirmed_tts_is_reassuring(self, engine):
        """TTS après confirmation = message rassurant."""
        msgs = _spoken(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.6)

        assert len(msgs) >= 2, "Au moins 2 TTS : détection + confirmation"
        last = msgs[-1].lower()
        assert any(w in last for w in ["bien", "là", "besoin", "rassur", "calme"]), \
            f"TTS confirmation pas rassurant: {msgs[-1]}"

    def test_s3_new_incident_possible_after_confirm(self, engine):
        """Après résolution, un nouvel incident peut démarrer."""
        received = _collect(engine)
        # Incident 1 → résolu
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.8)   # reset to idle

        # Incident 2
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.05)
        with engine._lock:
            state = engine._incident.machine_state
        # Le 2e incident doit être actif
        assert state in (MachineState.DETECTION, MachineState.CHECK), \
            f"2e incident bloqué après reset. État: {state}"

    def test_s3_no_escalated_alert_in_received(self, engine):
        """Jamais d'alerte FALL_ESCALATED si réponse reçue."""
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.6)

        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert len(escalated) == 0, \
            f"FALL_ESCALATED ne doit pas être émis si réponse reçue: {escalated}"


# ===========================================================================
# SCÉNARIO 4 — Mode nuit (caméra indisponible / obscurité)
# ===========================================================================

class TestScenarioNightMode:
    """
    La nuit, la caméra ne fonctionne pas (obscurité totale).
    Attendu : le monitoring vocal + temporel continue sans crash.
    La chute peut toujours être signalée (via signal_fall direct).
    Les alertes silence/inactivité fonctionnent normalement.
    """

    def test_s4_camera_off_no_crash(self, engine):
        """Caméra hors service → pas de crash, monitoring toujours actif."""
        engine.signal_camera_available(False)
        engine.start()
        time.sleep(0.05)

        state = engine.get_state()
        assert state["active"] is True
        assert state["camera_available"] is False

    def test_s4_fall_signal_works_without_camera(self, engine):
        """signal_fall() peut venir d'une autre source (accéléromètre...) sans caméra."""
        engine.signal_camera_available(False)
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.9, "source": "accelerometer"})
        time.sleep(0.8)

        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert len(escalated) >= 1, \
            "signal_fall() doit fonctionner même sans caméra"

    def test_s4_silence_alert_works_without_camera(self, engine):
        """Alerte silence fonctionne en mode nuit."""
        engine.signal_camera_available(False)
        received = _collect(engine)
        since = _now() - timedelta(minutes=130)
        engine._maybe_alert_silence(130.0, since)

        assert any(a.type == AlertType.PROLONGED_SILENCE for a in received)

    def test_s4_no_absence_alert_without_camera(self, engine):
        """Pas d'alerte absence CAMERA si caméra était déjà désactivée."""
        # signal_absence peut être appelé, mais la boucle temporelle ne
        # doit pas créer de faux positifs si la caméra n'était jamais là
        engine.signal_camera_available(False)
        received = _collect(engine)
        # La boucle temporelle ne doit pas déclencher signal_absence
        # car last_seen_at est None (caméra jamais vue)
        engine._check_temporal_rules()
        # Pas d'alerte absence sans historique caméra
        absence = [a for a in received if a.type == AlertType.PROLONGED_ABSENCE]
        assert len(absence) == 0, \
            "Pas d'alerte absence si la caméra n'a jamais détecté personne"

    def test_s4_mic_monitoring_active_night(self, engine):
        """Le micro reste actif la nuit (voix réinitialise le silence)."""
        engine.signal_camera_available(False)
        engine._sensors.silence_minutes = 180.0

        engine.signal_voice_activity()   # quelqu'un parle la nuit
        assert engine._sensors.silence_minutes == 0.0

    def test_s4_inactivity_alert_works_night(self, engine):
        """Alerte inactivité totale fonctionne même en mode nuit."""
        engine.signal_camera_available(False)
        received = _collect(engine)
        engine.signal_inactivity(extra={"hours": 10.0})

        assert any(a.type == AlertType.INACTIVITY for a in received)

    def test_s4_degraded_state_reported(self, engine):
        """L'état dégradé est correctement reporté dans get_state()."""
        engine.signal_camera_available(False)
        engine.signal_mic_available(False)
        state = engine.get_state()
        assert state["camera_available"] is False
        assert state["mic_available"] is False
        # Le système doit quand même être fonctionnel (pas d'exception)


# ===========================================================================
# SCÉNARIO 5 — Bruit ambiant (signaux micro parasites)
# ===========================================================================

class TestScenarioNoise:
    """
    Bruit de fond, télévision, bruits de ménage — signaux parasites.
    Le signal_voice_activity() est appelé à tort par le VAD.
    Attendu :
      - Le silence est réinitialisé (comportement normal du signal)
      - Jamais de chute déclenchée par des signaux voix seuls
      - Jamais de CRITICAL sur bruit seul
      - Cooldown absorbe les spams
    """

    def test_s5_noise_resets_silence_but_no_fall(self, engine):
        """Bruit voix → réinitialise silence, ne déclenche PAS de chute."""
        received = _collect(engine)
        # Simuler beaucoup de faux positifs voix
        for _ in range(20):
            engine.signal_voice_activity()
            time.sleep(0.01)

        # Aucune alerte chute
        fall_alerts = [a for a in received if a.type in (
            AlertType.FALL, AlertType.FALL_ESCALATED, AlertType.FALL_CONFIRMED
        )]
        assert len(fall_alerts) == 0, \
            "signal_voice_activity() ne doit jamais déclencher une alerte chute"

    def test_s5_noise_never_produces_critical(self, engine):
        """Bruit seul → jamais d'alerte CRITICAL."""
        received = _collect(engine)
        for _ in range(50):
            engine.signal_voice_activity()

        critical = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(critical) == 0, \
            "Le bruit ne doit jamais produire une alerte CRITICAL"

    def test_s5_noise_doesnt_trigger_state_machine(self, engine):
        """Bruit → la state machine reste en IDLE."""
        for _ in range(10):
            engine.signal_voice_activity()

        with engine._lock:
            state = engine._incident.machine_state
        assert state == MachineState.IDLE, \
            f"Bruit a changé l'état machine: {state}"

    def test_s5_noise_after_fall_resolves_incident(self, engine):
        """
        Si une chute est détectée et que le bruit est traité comme voix,
        la fenêtre de confirmation est résolue → WARNING seulement.
        (Le VAD doit être bien calibré, mais même s'il lève un faux signal,
         le résultat est un FALL_CONFIRMED WARNING, pas CRITICAL)
        """
        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        # Bruit interprété comme voix → signal_voice_activity
        engine.signal_voice_activity()  # résout l'incident
        time.sleep(0.6)

        critical = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(critical) == 0, \
            "Si le bruit résout l'incident, ne doit pas escalader en CRITICAL"

        confirmed = [a for a in received if a.type == AlertType.FALL_CONFIRMED]
        assert len(confirmed) == 1, "Doit produire FALL_CONFIRMED (WARNING)"

    def test_s5_spam_absence_blocked_by_cooldown(self, engine):
        """Spam de signal_absence (faux positifs) → un seul par cooldown."""
        engine.cooldowns["prolonged_absence"] = 60  # remettre cooldown réaliste
        received = _collect(engine)
        for _ in range(5):
            engine.signal_absence(extra={"minutes": 50})
        assert len(received) == 1, \
            "Cooldown doit bloquer le spam signal_absence"

    def test_s5_silence_spam_blocked(self, engine):
        """Spam _maybe_alert_silence → un seul par cooldown."""
        engine.cooldowns["prolonged_silence"] = 60
        received = _collect(engine)
        since = _now() - timedelta(minutes=150)
        for _ in range(5):
            engine._maybe_alert_silence(150.0, since)
        assert len(received) == 1, \
            "Cooldown doit bloquer le spam _maybe_alert_silence"

    def test_s5_concurrent_signals_no_crash(self, engine):
        """Signaux concurrents depuis plusieurs threads → pas de crash ni deadlock."""
        errors = []

        def worker():
            try:
                for _ in range(5):
                    engine.signal_voice_activity()
                    engine.signal_person_seen()
                    time.sleep(0.01)
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=2)

        assert len(errors) == 0, f"Concurrence a causé des erreurs: {errors}"
        # Le moteur doit être dans un état cohérent
        state = engine.get_state()
        assert isinstance(state, dict)


# ===========================================================================
# SCÉNARIO BONUS — Robustesse: callbacks cassés n'arrêtent pas le système
# ===========================================================================

class TestRobustness:
    """
    Tests de robustesse pour garantir qu'un composant défaillant
    ne met pas en danger la sécurité de la personne.
    """

    def test_bad_alert_callback_doesnt_stop_tts(self, engine):
        """Un callback alerte qui crash ne doit pas bloquer le TTS."""
        msgs = _spoken(engine)

        def crash_cb(a):
            raise RuntimeError("callback planté intentionnellement")

        engine.register_callback(crash_cb)
        engine.signal_manual_emergency()
        time.sleep(0.1)

        # Le TTS doit quand même avoir été envoyé
        assert len(msgs) >= 1, \
            "TTS doit fonctionner même si un callback alerte crash"

    def test_bad_tts_callback_doesnt_block_alerts(self, engine):
        """Un TTS callback qui crash ne doit pas bloquer les alertes."""
        received = _collect(engine)

        def crash_tts(m):
            raise RuntimeError("TTS planté intentionnellement")

        engine.register_tts_callback(crash_tts)
        engine.signal_manual_emergency()

        assert len(received) >= 1, \
            "L'alerte doit être enregistrée même si TTS crash"

    def test_system_still_works_after_many_incidents(self, engine):
        """Le système reste stable après plusieurs incidents successifs."""
        received = _collect(engine)
        # 3 cycles complets : chute → escalade → reset
        for i in range(3):
            engine.signal_fall(extra={"confidence": 0.9, "cycle": i})
            time.sleep(0.8)
            # Attendre le reset (Thread.Timer 60s → ici on force manuellement)
            engine._reset_incident_to_idle()

        # Vérifier qu'on est bien en IDLE et stable
        with engine._lock:
            state = engine._incident.machine_state
        assert state == MachineState.IDLE, \
            f"Après 3 cycles, état attendu IDLE, obtenu: {state}"

        # Vérifier le compteur de chutes
        assert engine._sensors.fall_count_today == 3, \
            f"Compteur chutes attendu 3, obtenu: {engine._sensors.fall_count_today}"

    def test_get_state_always_returns_dict(self, engine):
        """get_state() ne doit jamais lever d'exception quelle que soit la situation."""
        # Forcer des états extrêmes
        engine.signal_camera_available(False)
        engine.signal_mic_available(False)
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.05)

        # Ne doit jamais lever
        state = engine.get_state()
        assert isinstance(state, dict)
        assert "active" in state
        assert "incident" in state
