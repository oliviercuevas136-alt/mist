"""
tests/test_health.py — Tests du endpoint GET /api/health

Couvre :
  - Réponse nominale 200 avec tous les champs attendus
  - app_name contient "V4"
  - status est "ok" ou "degraded" (jamais une exception)
  - Ollama offline → ollama.status == "error", status global == "degraded"
  - DB unavailable → database == "error", status global == "degraded"
  - startup_checks est un dict avec les clés attendues
  - L'endpoint ne crash JAMAIS quelle que soit la configuration

Isolation : même pattern que test_safe_mode.py (TestSafeModeAPI).
Utilise la vraie DB SQLite (data/assistant.db) et les vrais imports.
"""

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


# ---------------------------------------------------------------------------
# Helpers — mini app isolée pour /api/health
# ---------------------------------------------------------------------------

def _make_health_app():
    """
    Crée une mini FastAPI avec seulement le router health.

    IMPORTANT : test_timeouts.py injecte sys.modules["app.config"] = MagicMock
    au moment de la collecte pytest. Si database.py n'est pas encore chargé, il
    va faire create_engine(MagicMock()) → ValueError.

    Solution : pre-stubber app.db.database avec une vraie connexion SQLite
    AVANT tout import qui pourrait déclencher database.py.
    """
    import types as _types

    os.makedirs("data", exist_ok=True)

    if "app.db.database" not in sys.modules:
        from sqlalchemy import create_engine as _sa_engine
        from sqlalchemy.orm import sessionmaker as _sm, declarative_base as _dbase

        _engine = _sa_engine(
            "sqlite:///./data/test_health.db",
            connect_args={"check_same_thread": False},
        )
        _SessionLocal = _sm(autocommit=False, autoflush=False, bind=_engine)
        _Base = _dbase()

        _db_mod = _types.ModuleType("app.db.database")
        _db_mod.engine = _engine
        _db_mod.SessionLocal = _SessionLocal
        _db_mod.Base = _Base
        _db_mod.get_db = MagicMock()
        sys.modules["app.db.database"] = _db_mod

    # Stub app.utils.startup_checks si app.utils a été écrasé par un autre test
    # (test_file_security.py le remplace par un types.ModuleType simple, non-package)
    _utils_pkg = sys.modules.get("app.utils")
    if _utils_pkg is None or not hasattr(_utils_pkg, "__path__"):
        # Recréer app.utils comme package pour permettre les sous-imports
        _pkg = _types.ModuleType("app.utils")
        _pkg.__path__ = []  # marque comme package
        _pkg.__package__ = "app.utils"
        sys.modules["app.utils"] = _pkg

    if "app.utils.startup_checks" not in sys.modules:
        _sc_mod = _types.ModuleType("app.utils.startup_checks")
        _sc_mod.run_startup_checks = lambda: {
            "static_exists": True,
            "data_exists": True,
            "notes_exists": True,
            "logs_exists": True,
        }
        sys.modules["app.utils.startup_checks"] = _sc_mod

    # Forcer le rechargement du router health si déjà chargé avec un mauvais état
    if "app.api.health" in sys.modules:
        del sys.modules["app.api.health"]

    from fastapi import FastAPI
    from app.api.health import router as health_router
    import app.api.health as _health_mod

    # Patcher settings dans le module health avec des valeurs réelles.
    # Nécessaire car app.config est stubbé (MagicMock) par test_timeouts.py,
    # et settings.app_name sérialisé en dict par FastAPI.
    _hs = MagicMock()
    _hs.app_name = "Local Assistant V4"
    _hs.debug = True
    _hs.static_path = Path("app/static")
    _hs.app_log_path = Path("logs/assistant.log")
    _health_mod.settings = _hs

    mini = FastAPI(title="Test Health")
    mini.include_router(health_router)
    return mini


# ---------------------------------------------------------------------------
# Fixture partagée pour TestHealthStructure
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def health_client():
    from fastapi.testclient import TestClient
    mini = _make_health_app()
    with TestClient(mini) as c:
        yield c


# ===========================================================================
# 1. Structure de base de la réponse
# ===========================================================================

class TestHealthStructure:

    def test_returns_200(self, health_client):
        """GET /api/health retourne HTTP 200."""
        resp = health_client.get("/api/health")
        assert resp.status_code == 200

    def test_response_is_json(self, health_client):
        """La réponse est bien du JSON valide."""
        resp = health_client.get("/api/health")
        data = resp.json()
        assert isinstance(data, dict)

    def test_required_fields_present(self, health_client):
        """Tous les champs obligatoires sont présents dans la réponse."""
        resp = health_client.get("/api/health")
        data = resp.json()
        required = {"app_name", "status", "database", "ollama", "startup_checks", "debug"}
        for field in required:
            assert field in data, f"Champ manquant : {field}"

    def test_app_name_contains_v4(self, health_client):
        """app_name mentionne V4 (pas V1 ou V2)."""
        resp = health_client.get("/api/health")
        data = resp.json()
        assert "V4" in data["app_name"] or "v4" in data["app_name"].lower(), (
            f"app_name devrait contenir V4 — valeur actuelle : {data['app_name']!r}"
        )

    def test_status_is_valid_value(self, health_client):
        """status est 'ok' ou 'degraded' — jamais autre chose."""
        resp = health_client.get("/api/health")
        data = resp.json()
        assert data["status"] in ("ok", "degraded"), (
            f"status inattendu : {data['status']!r}"
        )

    def test_database_field_is_ok_or_error(self, health_client):
        """database est 'ok' ou 'error'."""
        resp = health_client.get("/api/health")
        data = resp.json()
        assert data["database"] in ("ok", "error"), (
            f"database inattendu : {data['database']!r}"
        )

    def test_ollama_field_is_dict(self, health_client):
        """ollama est un objet JSON (dict)."""
        resp = health_client.get("/api/health")
        data = resp.json()
        assert isinstance(data["ollama"], dict)

    def test_ollama_has_status_field(self, health_client):
        """ollama contient le sous-champ 'status'."""
        resp = health_client.get("/api/health")
        data = resp.json()
        assert "status" in data["ollama"]

    def test_startup_checks_is_dict(self, health_client):
        """startup_checks est un dict avec au moins une clé."""
        resp = health_client.get("/api/health")
        data = resp.json()
        checks = data["startup_checks"]
        assert isinstance(checks, dict)
        assert len(checks) > 0

    def test_startup_checks_has_expected_keys(self, health_client):
        """startup_checks contient les clés de vérification attendues."""
        resp = health_client.get("/api/health")
        checks = resp.json()["startup_checks"]
        expected = {"static_exists", "data_exists", "notes_exists"}
        for key in expected:
            assert key in checks, f"Clé manquante dans startup_checks : {key}"

    def test_status_never_contains_exception_message(self, health_client):
        """Le champ 'status' ne contient jamais un traceback ou message d'exception."""
        resp = health_client.get("/api/health")
        status = resp.json()["status"]
        assert "Traceback" not in status
        assert "Error" not in status
        assert "Exception" not in status


# ===========================================================================
# 2. Ollama offline → degraded (pas de crash)
# ===========================================================================

class TestHealthOllamaOffline:

    def _client(self, health_check_return):
        """Crée un TestClient avec OllamaClient.health_check mocké."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        mini = _make_health_app()
        with patch.object(OllamaClient, "health_check", return_value=health_check_return):
            with TestClient(mini) as c:
                yield c

    @property
    def _offline_result(self):
        return {
            "status": "error", "reachable": False,
            "model_configured": "llama3.2:3b",
            "available_models": [], "model_available": False,
            "error": "Connection refused",
        }

    def test_ollama_offline_returns_200(self):
        """Ollama offline → HTTP 200 quand même (pas de 500)."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        mini = _make_health_app()
        with patch.object(OllamaClient, "health_check", return_value=self._offline_result):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        assert resp.status_code == 200

    def test_ollama_offline_status_is_degraded(self):
        """Ollama offline → status global == 'degraded'."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        mini = _make_health_app()
        with patch.object(OllamaClient, "health_check", return_value=self._offline_result):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        assert resp.json()["status"] == "degraded"

    def test_ollama_offline_error_in_response(self):
        """Ollama offline → ollama.status == 'error' dans la réponse."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        mini = _make_health_app()
        with patch.object(OllamaClient, "health_check", return_value=self._offline_result):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        assert resp.json()["ollama"]["status"] == "error"

    def test_ollama_offline_reachable_false(self):
        """Ollama offline → reachable == False dans la réponse."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        mini = _make_health_app()
        with patch.object(OllamaClient, "health_check", return_value=self._offline_result):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        assert resp.json()["ollama"]["reachable"] is False

    def test_ollama_model_missing_no_crash(self):
        """Ollama joignable mais modèle absent → réponse HTTP valide (pas crash)."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        mini = _make_health_app()
        model_missing = {
            "status": "ok", "reachable": True,
            "model_configured": "llama3.2:3b",
            "available_models": ["mistral:7b"],
            "model_available": False,
        }
        with patch.object(OllamaClient, "health_check", return_value=model_missing):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        data = resp.json()
        assert resp.status_code == 200
        assert data["status"] in ("ok", "degraded")
        assert data["ollama"]["model_available"] is False

    def test_health_check_client_never_raises(self):
        """OllamaClient.health_check() ne lève jamais d'exception réseau."""
        from app.core.llm import OllamaClient
        client = OllamaClient()
        with patch("requests.get", side_effect=Exception("Erreur réseau inattendue")):
            result = client.health_check()
        assert isinstance(result, dict)
        assert result["status"] == "error"
        assert "error" in result


# ===========================================================================
# 3. DB unavailable → degraded (pas de crash)
# ===========================================================================

class TestHealthDatabaseError:

    def _client_with_db_error(self, exc):
        """Client avec SessionLocal qui lève une exception."""
        from fastapi.testclient import TestClient
        mini = _make_health_app()
        # Patcher SessionLocal au niveau du module health
        mock_session_cls = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.__enter__ = MagicMock(side_effect=exc)
        mock_ctx.__exit__ = MagicMock(return_value=False)
        mock_session_cls.return_value = mock_ctx
        with patch("app.api.health.SessionLocal", mock_session_cls):
            with TestClient(mini) as c:
                yield c

    def test_db_error_returns_200(self):
        """DB inaccessible → HTTP 200 (mode dégradé, pas de 500)."""
        from fastapi.testclient import TestClient
        from sqlalchemy.exc import OperationalError
        mini = _make_health_app()
        mock_session_cls = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.__enter__ = MagicMock(
            side_effect=OperationalError("no such table", None, None)
        )
        mock_ctx.__exit__ = MagicMock(return_value=False)
        mock_session_cls.return_value = mock_ctx
        with patch("app.api.health.SessionLocal", mock_session_cls):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        assert resp.status_code == 200

    def test_db_error_status_degraded(self):
        """DB inaccessible → status global == 'degraded'."""
        from fastapi.testclient import TestClient
        from sqlalchemy.exc import OperationalError
        mini = _make_health_app()
        mock_session_cls = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.__enter__ = MagicMock(
            side_effect=OperationalError("no such table", None, None)
        )
        mock_ctx.__exit__ = MagicMock(return_value=False)
        mock_session_cls.return_value = mock_ctx
        with patch("app.api.health.SessionLocal", mock_session_cls):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        assert resp.json()["status"] == "degraded"

    def test_db_error_field_is_error(self):
        """DB inaccessible → champ 'database' == 'error' et database_error non nul."""
        from fastapi.testclient import TestClient
        from sqlalchemy.exc import OperationalError
        mini = _make_health_app()
        mock_session_cls = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.__enter__ = MagicMock(
            side_effect=OperationalError("no such table", None, None)
        )
        mock_ctx.__exit__ = MagicMock(return_value=False)
        mock_session_cls.return_value = mock_ctx
        with patch("app.api.health.SessionLocal", mock_session_cls):
            with TestClient(mini) as c:
                resp = c.get("/api/health")
        data = resp.json()
        assert data["database"] == "error"
        assert data["database_error"] is not None


# ===========================================================================
# 4. Robustesse totale — rien ne peut crasher /api/health
# ===========================================================================

class TestHealthRobustness:

    def test_endpoint_never_raises_on_total_failure(self):
        """Même si TOUT échoue (DB + Ollama + checks), le endpoint retourne 200."""
        from fastapi.testclient import TestClient
        from app.core.llm import OllamaClient
        from sqlalchemy.exc import OperationalError

        mini = _make_health_app()
        error_result = {
            "status": "error", "reachable": False,
            "model_configured": "llama3.2:3b",
            "available_models": [], "model_available": False,
            "error": "Total blackout",
        }
        mock_session_cls = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.__enter__ = MagicMock(
            side_effect=OperationalError("boom", None, None)
        )
        mock_ctx.__exit__ = MagicMock(return_value=False)
        mock_session_cls.return_value = mock_ctx

        with patch.object(OllamaClient, "health_check", return_value=error_result), \
             patch("app.api.health.SessionLocal", mock_session_cls), \
             patch("app.utils.startup_checks.run_startup_checks",
                   return_value={"static_exists": False, "data_exists": False}):
            with TestClient(mini) as c:
                resp = c.get("/api/health")

        assert resp.status_code == 200
        assert resp.json()["status"] in ("ok", "degraded")


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
