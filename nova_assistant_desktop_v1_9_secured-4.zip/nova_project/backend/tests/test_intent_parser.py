from app.core.intent_parser import detect_intent


def test_detect_memory_add():
    result = detect_intent("Retiens que j'aime le local")
    assert result["intent"] == "memory_add"
    assert "local" in result["content"]


def test_detect_note_create():
    result = detect_intent("Crée une note: Titre | Contenu | tag1,tag2")
    assert result["intent"] == "note_create"
    assert result["title"] == "Titre"
    assert result["content"] == "Contenu"


def test_detect_note_delete():
    result = detect_intent("Supprime la note 3")
    assert result["intent"] == "note_delete"
    assert result["note_id"] == 3


def test_detect_memory_delete():
    result = detect_intent("Supprime la mémoire 5")
    assert result["intent"] == "memory_delete"
    assert result["memory_id"] == 5


def test_detect_conversation_read():
    result = detect_intent("Lis la conversation 7")
    assert result["intent"] == "conversation_read"
    assert result["conversation_id"] == 7