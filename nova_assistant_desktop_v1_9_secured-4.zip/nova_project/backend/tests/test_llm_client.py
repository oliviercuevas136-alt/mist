"""
test_llm_client.py — Tests du client LLM Ollama.
Ne nécessite pas Ollama lancé (les appels réseau sont mockés).
"""
import sys, types
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Stubs
for mod in ["pydantic_settings", "sqlalchemy", "sqlalchemy.orm",
            "faster_whisper", "pyttsx3"]:
    if mod not in sys.modules:
        sys.modules[mod] = MagicMock()

# Stub config
cfg_mod = types.ModuleType("app.config")
cfg_mock = MagicMock()
cfg_mock.ollama_base_url = "http://127.0.0.1:11434"
cfg_mock.ollama_model    = "llama3.2:3b"
cfg_mock.ollama_timeout  = 30
cfg_mock.stt_slow_threshold_ms = 4000
cfg_mock.enable_stt = True
cfg_mock.enable_tts = True
cfg_mock.stt_warmup = False
cfg_mock.ollama_warmup = False
# Mistral fallback désactivé dans ces tests (évite que MagicMock soit truthy)
cfg_mock.use_mistral_fallback = False
cfg_mock.mistral_api_key      = ""
cfg_mock.mistral_model        = "mistral-small-latest"
cfg_mock.mistral_timeout      = 30
cfg_mod.settings = cfg_mock
sys.modules["app.config"] = cfg_mod

logger_mod = types.ModuleType("app.utils.logger")
logger_mod.get_logger = lambda n: MagicMock()
sys.modules["app.utils"] = types.ModuleType("app.utils")
sys.modules["app.utils.logger"] = logger_mod


class TestOllamaClient:

    def _make_client(self):
        from app.core.llm import OllamaClient
        client = OllamaClient()
        client._model_verified = True  # skip health check
        return client

    def test_init(self):
        client = self._make_client()
        assert client.model == "llama3.2:3b"
        assert client.base_url == "http://127.0.0.1:11434"

    def test_chat_returns_string_on_success(self):
        client = self._make_client()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"message": {"content": "Bonjour !"}}
        mock_resp.raise_for_status = MagicMock()

        with patch("requests.post", return_value=mock_resp):
            result = client.chat([{"role": "user", "content": "test"}])
        assert result == "Bonjour !"

    def test_chat_returns_error_string_on_connection_failure(self):
        client = self._make_client()
        client._model_verified = False
        with patch("requests.get", side_effect=Exception("Connection refused")):
            result = client.chat([{"role": "user", "content": "test"}])
        assert isinstance(result, str)
        assert len(result) > 0  # un message d'erreur, pas un crash

    def test_chat_returns_error_on_timeout(self):
        import requests as req_mod
        client = self._make_client()
        with patch("requests.post", side_effect=req_mod.exceptions.Timeout()):
            result = client.chat([{"role": "user", "content": "test"}])
        assert "timeout" in result.lower() or "délai" in result.lower()

    def test_chat_stream_yields_tokens(self):
        import json
        client = self._make_client()
        lines = [
            json.dumps({"message": {"content": "Bon"}, "done": False}).encode(),
            json.dumps({"message": {"content": "jour"}, "done": False}).encode(),
            json.dumps({"done": True}).encode(),
        ]
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(lines)

        with patch("requests.post", return_value=mock_resp):
            tokens = list(client.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["Bon", "jour"]

    def test_voice_options_applied(self):
        client = self._make_client()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"message": {"content": "ok"}}
        mock_resp.raise_for_status = MagicMock()
        captured = {}

        def capture_post(url, json=None, **kw):
            captured["payload"] = json
            return mock_resp

        with patch("requests.post", side_effect=capture_post):
            client.chat([{"role": "user", "content": "test"}], voice_mode=True)

        assert "options" in captured["payload"]
        assert captured["payload"]["options"]["temperature"] <= 0.3


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
