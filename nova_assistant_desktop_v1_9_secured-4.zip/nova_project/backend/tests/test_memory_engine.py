from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.database import Base
from app.core.memory_engine import MemoryEngine


def build_test_db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return TestingSessionLocal()


def test_add_and_search_memory():
    db = build_test_db()
    engine = MemoryEngine()

    created = engine.add_memory(
        db=db,
        content="Nova est un projet central",
        category="project",
        importance=4,
        source="test",
    )

    assert created.id is not None

    results = engine.search_memories(db=db, query="Nova", limit=10)
    assert len(results) >= 1
    assert "Nova" in results[0].content