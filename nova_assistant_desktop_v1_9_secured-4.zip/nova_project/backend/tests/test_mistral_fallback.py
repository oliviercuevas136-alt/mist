"""
test_mistral_fallback.py — Tests du fallback Mistral dans OllamaClient
et tests unitaires de MistralClient.

Isolation complète :
  - sys.modules stubbed en haut de fichier (pydantic_settings, sqlalchemy, etc.)
  - app.config stubbed avec use_mistral_fallback=False par défaut
  - Chaque test qui a besoin du fallback injecte directement _mistral_client
    ou utilise patch.object() — sans toucher sys.modules globalement
  - Aucun appel réseau réel
"""
import json
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest
import requests as _real_requests

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# ── Stubs dépendances lourdes ─────────────────────────────────────────────────
for _mod in ["pydantic_settings", "sqlalchemy", "sqlalchemy.orm",
             "faster_whisper", "pyttsx3"]:
    if _mod not in sys.modules:
        sys.modules[_mod] = MagicMock()

# ── Stub app.utils.logger ─────────────────────────────────────────────────────
if "app.utils.logger" not in sys.modules:
    _logger_mod = types.ModuleType("app.utils.logger")
    _logger_mod.get_logger = lambda n: MagicMock()
    sys.modules.setdefault("app.utils", types.ModuleType("app.utils"))
    sys.modules["app.utils.logger"] = _logger_mod

# ── Stub app.config — fallback DÉSACTIVÉ par défaut ──────────────────────────
# Chaque test qui veut activer le fallback utilise patch.object() localement.
if "app.config" not in sys.modules:
    _cfg_mod = types.ModuleType("app.config")
    _cfg_mock = MagicMock()
    _cfg_mock.ollama_base_url     = "http://127.0.0.1:11434"
    _cfg_mock.ollama_model        = "llama3.2:3b"
    _cfg_mock.ollama_timeout      = 30
    _cfg_mock.use_mistral_fallback = False
    _cfg_mock.mistral_api_key     = ""
    _cfg_mock.mistral_model       = "mistral-small-latest"
    _cfg_mock.mistral_timeout     = 30
    _cfg_mod.settings = _cfg_mock
    sys.modules["app.config"] = _cfg_mod


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_ollama_client():
    """Retourne un OllamaClient avec _model_verified=True (skip health check)."""
    from app.core.llm import OllamaClient
    client = OllamaClient()
    client._model_verified = True
    return client


def _make_mistral_client():
    """Retourne un MistralClient configuré pour les tests."""
    from app.services.mistral_client import MistralClient
    return MistralClient(api_key="test-key-abc", model="mistral-small-latest", timeout=10)


def _make_mock_mistral(reply="Réponse Mistral test"):
    """Retourne un MistralClient mocké (chat() → reply, chat_stream() → tokens)."""
    m = MagicMock()
    m.chat.return_value = reply
    m.chat_stream.return_value = iter(["Token", "1", " ok"])
    return m


def _sse_lines(tokens, done=True):
    """Génère des lignes SSE Mistral à partir d'une liste de tokens."""
    lines = []
    for tok in tokens:
        obj = {"choices": [{"delta": {"content": tok}}]}
        lines.append(f"data: {json.dumps(obj)}".encode())
    if done:
        lines.append(b"data: [DONE]")
    return lines


def _ollama_stream_lines(tokens, done=True):
    """Génère des lignes JSON Ollama streaming."""
    lines = []
    for tok in tokens:
        lines.append(json.dumps({"message": {"content": tok}, "done": False}).encode())
    if done:
        lines.append(json.dumps({"done": True}).encode())
    return lines


# ══════════════════════════════════════════════════════════════════════════════
# 1. Tests MistralClient — unitaires
# ══════════════════════════════════════════════════════════════════════════════

class TestMistralClientUnit:

    def test_init_requires_api_key(self):
        """MistralClient lève ValueError si api_key vide."""
        from app.services.mistral_client import MistralClient
        with pytest.raises(ValueError, match="MISTRAL_API_KEY"):
            MistralClient(api_key="", model="mistral-small-latest")

    def test_init_stores_fields(self):
        m = _make_mistral_client()
        assert m.api_key == "test-key-abc"
        assert m.model == "mistral-small-latest"
        assert m.timeout == 10

    def test_headers_contain_bearer(self):
        m = _make_mistral_client()
        h = m._headers()
        assert h["Authorization"] == "Bearer test-key-abc"
        assert h["Content-Type"] == "application/json"

    def test_chat_success_returns_content(self):
        m = _make_mistral_client()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "choices": [{"message": {"content": "Bonjour depuis Mistral !"}}]
        }
        mock_resp.raise_for_status = MagicMock()
        with patch("requests.post", return_value=mock_resp):
            result = m.chat([{"role": "user", "content": "test"}])
        assert result == "Bonjour depuis Mistral !"

    def test_chat_empty_content_raises(self):
        m = _make_mistral_client()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"choices": [{"message": {"content": ""}}]}
        mock_resp.raise_for_status = MagicMock()
        with patch("requests.post", return_value=mock_resp):
            with pytest.raises(RuntimeError, match="vide"):
                m.chat([{"role": "user", "content": "test"}])

    def test_chat_posts_to_correct_url(self):
        m = _make_mistral_client()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"choices": [{"message": {"content": "ok"}}]}
        mock_resp.raise_for_status = MagicMock()
        captured_url = {}
        def fake_post(url, **kw):
            captured_url["url"] = url
            return mock_resp
        with patch("requests.post", side_effect=fake_post):
            m.chat([{"role": "user", "content": "x"}])
        assert "mistral.ai" in captured_url["url"]
        assert "chat/completions" in captured_url["url"]

    def test_chat_http_error_propagates(self):
        m = _make_mistral_client()
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = _real_requests.exceptions.HTTPError("401")
        with patch("requests.post", return_value=mock_resp):
            with pytest.raises(_real_requests.exceptions.HTTPError):
                m.chat([{"role": "user", "content": "test"}])

    def test_stream_yields_tokens(self):
        m = _make_mistral_client()
        lines = _sse_lines(["Bon", "jour", " !"])
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(lines)
        with patch("requests.post", return_value=mock_resp):
            tokens = list(m.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["Bon", "jour", " !"]

    def test_stream_stops_at_done_marker(self):
        m = _make_mistral_client()
        lines = [
            b"data: " + json.dumps({"choices": [{"delta": {"content": "A"}}]}).encode(),
            b"data: [DONE]",
            b"data: " + json.dumps({"choices": [{"delta": {"content": "NEVER"}}]}).encode(),
        ]
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(lines)
        with patch("requests.post", return_value=mock_resp):
            tokens = list(m.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["A"]

    def test_stream_skips_empty_delta(self):
        m = _make_mistral_client()
        lines = [
            b"data: " + json.dumps({"choices": [{"delta": {"content": ""}}]}).encode(),
            b"data: " + json.dumps({"choices": [{"delta": {"content": "X"}}]}).encode(),
            b"data: [DONE]",
        ]
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(lines)
        with patch("requests.post", return_value=mock_resp):
            tokens = list(m.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["X"]

    def test_stream_model_in_payload(self):
        m = _make_mistral_client()
        captured = {}
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter([b"data: [DONE]"])
        def fake_post(url, json=None, **kw):
            captured["payload"] = json
            return mock_resp
        with patch("requests.post", side_effect=fake_post):
            list(m.chat_stream([{"role": "user", "content": "test"}]))
        assert captured["payload"]["model"] == "mistral-small-latest"
        assert captured["payload"]["stream"] is True


# ══════════════════════════════════════════════════════════════════════════════
# 2. _should_fallback — comportements
# ══════════════════════════════════════════════════════════════════════════════

class TestShouldFallback:

    def test_false_when_both_disabled(self):
        client = _make_ollama_client()
        with patch.object(type(client), "_should_fallback", return_value=False):
            assert not client._should_fallback()

    def test_true_when_enabled_and_key_present(self):
        client = _make_ollama_client()
        # Patcher les attributs de settings dans llm.py
        import app.core.llm as llm_mod
        original = llm_mod.settings
        mock_s = MagicMock()
        mock_s.use_mistral_fallback = True
        mock_s.mistral_api_key = "sk-test"
        llm_mod.settings = mock_s
        try:
            assert client._should_fallback() is True
        finally:
            llm_mod.settings = original

    def test_false_when_disabled_even_with_key(self):
        client = _make_ollama_client()
        import app.core.llm as llm_mod
        original = llm_mod.settings
        mock_s = MagicMock()
        mock_s.use_mistral_fallback = False
        mock_s.mistral_api_key = "sk-test"
        llm_mod.settings = mock_s
        try:
            assert client._should_fallback() is False
        finally:
            llm_mod.settings = original

    def test_false_when_key_empty(self):
        client = _make_ollama_client()
        import app.core.llm as llm_mod
        original = llm_mod.settings
        mock_s = MagicMock()
        mock_s.use_mistral_fallback = True
        mock_s.mistral_api_key = ""
        llm_mod.settings = mock_s
        try:
            assert client._should_fallback() is False
        finally:
            llm_mod.settings = original

    def test_false_on_attribute_error(self):
        client = _make_ollama_client()
        import app.core.llm as llm_mod
        original = llm_mod.settings
        bad_settings = object()  # pas d'attributs Mistral
        llm_mod.settings = bad_settings
        try:
            assert client._should_fallback() is False
        finally:
            llm_mod.settings = original


# ══════════════════════════════════════════════════════════════════════════════
# 3. OllamaClient.chat() — fallback activé
# ══════════════════════════════════════════════════════════════════════════════

class TestOllamaFallbackChat:
    """Tests du fallback Mistral dans chat() — injecte _mistral_client directement."""

    def _client_with_fallback(self, reply="Réponse Mistral"):
        """OllamaClient + _mistral_client mocké + _should_fallback=True."""
        client = _make_ollama_client()
        client._mistral_client = _make_mock_mistral(reply=reply)
        return client

    def test_timeout_triggers_mistral_fallback(self):
        client = self._client_with_fallback("Mistral répond OK")
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post", side_effect=_real_requests.exceptions.Timeout()):
                result = client.chat([{"role": "user", "content": "test"}])
        assert result == "Mistral répond OK"
        client._mistral_client.chat.assert_called_once()

    def test_connection_error_triggers_mistral_fallback(self):
        client = self._client_with_fallback()
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post",
                       side_effect=_real_requests.exceptions.ConnectionError("refused")):
                result = client.chat([{"role": "user", "content": "test"}])
        assert "Mistral" in result or len(result) > 0
        client._mistral_client.chat.assert_called_once()

    def test_empty_response_triggers_mistral_fallback(self):
        """Réponse vide Ollama (RuntimeError dans _try_chat) → Mistral."""
        client = self._client_with_fallback("Mistral de secours")
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"message": {"content": ""}}
        mock_resp.raise_for_status = MagicMock()
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post", return_value=mock_resp):
                result = client.chat([{"role": "user", "content": "test"}])
        assert result == "Mistral de secours"

    def test_generic_exception_triggers_mistral_fallback(self):
        client = self._client_with_fallback("Fallback générique")
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post", side_effect=RuntimeError("crash Ollama")):
                result = client.chat([{"role": "user", "content": "test"}])
        assert result == "Fallback générique"

    def test_fallback_disabled_returns_timeout_message(self):
        """Sans fallback, timeout → message d'erreur classique."""
        client = _make_ollama_client()
        with patch.object(client, "_should_fallback", return_value=False):
            with patch("requests.post", side_effect=_real_requests.exceptions.Timeout()):
                result = client.chat([{"role": "user", "content": "test"}])
        assert "timeout" in result.lower() or str(client.timeout) in result

    def test_fallback_no_key_no_mistral_call(self):
        """_should_fallback=False → Mistral jamais appelé même en cas d'erreur."""
        client = _make_ollama_client()
        mock_mistral = _make_mock_mistral()
        client._mistral_client = mock_mistral
        with patch.object(client, "_should_fallback", return_value=False):
            with patch("requests.post", side_effect=_real_requests.exceptions.Timeout()):
                client.chat([{"role": "user", "content": "test"}])
        mock_mistral.chat.assert_not_called()

    def test_ollama_ok_no_mistral_call(self):
        """Ollama répond → Mistral jamais appelé."""
        client = _make_ollama_client()
        mock_mistral = _make_mock_mistral()
        client._mistral_client = mock_mistral
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"message": {"content": "Réponse Ollama"}}
        mock_resp.raise_for_status = MagicMock()
        with patch("requests.post", return_value=mock_resp):
            result = client.chat([{"role": "user", "content": "test"}])
        assert result == "Réponse Ollama"
        mock_mistral.chat.assert_not_called()

    def test_mistral_also_fails_returns_service_unavailable(self):
        """Ollama échoue + Mistral échoue → message d'indisponibilité."""
        client = _make_ollama_client()
        mock_mistral = MagicMock()
        mock_mistral.chat.side_effect = RuntimeError("Mistral aussi en panne")
        client._mistral_client = mock_mistral
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post", side_effect=_real_requests.exceptions.Timeout()):
                result = client.chat([{"role": "user", "content": "test"}])
        assert "indisponible" in result.lower() or len(result) > 0


# ══════════════════════════════════════════════════════════════════════════════
# 4. OllamaClient.chat_stream() — fallback activé
# ══════════════════════════════════════════════════════════════════════════════

class TestOllamaFallbackStream:
    """Tests du fallback Mistral dans chat_stream()."""

    def _client_with_fallback(self, stream_tokens=None):
        client = _make_ollama_client()
        mock_mistral = MagicMock()
        mock_mistral.chat_stream.return_value = iter(stream_tokens or ["Mis", "tral"])
        client._mistral_client = mock_mistral
        return client

    def test_connection_error_before_first_token_triggers_fallback(self):
        client = self._client_with_fallback(["M", "i", "s", "t", "r", "a", "l"])
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post",
                       side_effect=_real_requests.exceptions.ConnectionError("refused")):
                tokens = list(client.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["M", "i", "s", "t", "r", "a", "l"]
        client._mistral_client.chat_stream.assert_called_once()

    def test_timeout_before_first_token_triggers_fallback(self):
        client = self._client_with_fallback(["Fallback", " ok"])
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post",
                       side_effect=_real_requests.exceptions.Timeout()):
                tokens = list(client.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["Fallback", " ok"]

    def test_ollama_ok_stream_no_fallback(self):
        client = _make_ollama_client()
        mock_mistral = MagicMock()
        client._mistral_client = mock_mistral
        lines = _ollama_stream_lines(["Bonjour", " !", " Comment ça va"])
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(lines)
        with patch("requests.post", return_value=mock_resp):
            tokens = list(client.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["Bonjour", " !", " Comment ça va"]
        mock_mistral.chat_stream.assert_not_called()

    def test_error_after_first_token_no_fallback_raises(self):
        """Erreur MI-flux (après tokens) → pas de fallback → exception propagée."""
        client = _make_ollama_client()
        mock_mistral = MagicMock()
        client._mistral_client = mock_mistral

        def _bad_response():
            mock_resp = MagicMock()
            mock_resp.__enter__ = lambda s: s
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_resp.raise_for_status = MagicMock()
            # Premier token OK, puis exception
            def _iter_lines():
                yield json.dumps({"message": {"content": "Premier"}, "done": False}).encode()
                raise _real_requests.exceptions.ConnectionError("mid-stream crash")
            mock_resp.iter_lines.return_value = _iter_lines()
            return mock_resp

        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.post", return_value=_bad_response()):
                with pytest.raises(_real_requests.exceptions.ConnectionError):
                    list(client.chat_stream([{"role": "user", "content": "test"}]))
        mock_mistral.chat_stream.assert_not_called()

    def test_ollama_unverified_triggers_fallback(self):
        """_ensure_verified() retourne erreur → Mistral immédiat."""
        client = _make_ollama_client()
        client._model_verified = False  # forcer la vérification
        mock_mistral = MagicMock()
        mock_mistral.chat_stream.return_value = iter(["Mistral", " direct"])
        client._mistral_client = mock_mistral
        with patch.object(client, "_should_fallback", return_value=True):
            with patch("requests.get", side_effect=_real_requests.exceptions.ConnectionError()):
                tokens = list(client.chat_stream([{"role": "user", "content": "test"}]))
        assert tokens == ["Mistral", " direct"]

    def test_fallback_disabled_stream_raises_on_connection_error(self):
        """fallback désactivé → ConnectionError propagée normalement."""
        client = _make_ollama_client()
        with patch.object(client, "_should_fallback", return_value=False):
            with patch("requests.post",
                       side_effect=_real_requests.exceptions.ConnectionError("refused")):
                with pytest.raises(_real_requests.exceptions.ConnectionError):
                    list(client.chat_stream([{"role": "user", "content": "test"}]))


# ══════════════════════════════════════════════════════════════════════════════
# 5. Logs — vérification des constantes textuelles dans llm.py
# ══════════════════════════════════════════════════════════════════════════════

class TestLogConstants:
    """Vérifie que les 5 chaînes de log structurés sont présentes dans le source."""

    def _source(self):
        llm_path = ROOT / "app" / "core" / "llm.py"
        return llm_path.read_text(encoding="utf-8")

    def test_ollama_ok_log_present(self):
        assert "[LLM] OLLAMA_OK" in self._source()

    def test_ollama_timeout_log_present(self):
        assert "[LLM] OLLAMA_TIMEOUT" in self._source()

    def test_mistral_fallback_log_present(self):
        assert "[LLM] MISTRAL_FALLBACK" in self._source()

    def test_mistral_ok_log_present(self):
        # MISTRAL_OK est dans mistral_client.py
        mistral_path = ROOT / "app" / "services" / "mistral_client.py"
        assert "[LLM] MISTRAL_OK" in mistral_path.read_text(encoding="utf-8")

    def test_llm_error_log_present(self):
        assert "[LLM] LLM_ERROR" in self._source()

    def test_mistral_fallback_in_mistral_client_source(self):
        mistral_path = ROOT / "app" / "services" / "mistral_client.py"
        assert "[LLM] MISTRAL_FALLBACK" in mistral_path.read_text(encoding="utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# 6. Config — nouveaux champs Mistral
# ══════════════════════════════════════════════════════════════════════════════

class TestConfigMistralFields:
    """Vérifie que app/config.py contient les 4 champs Mistral avec les bons défauts."""

    def _source(self):
        return (ROOT / "app" / "config.py").read_text(encoding="utf-8")

    def test_mistral_api_key_field_present(self):
        assert "mistral_api_key" in self._source()

    def test_mistral_model_field_present(self):
        assert "mistral_model" in self._source()

    def test_mistral_timeout_field_present(self):
        assert "mistral_timeout" in self._source()

    def test_use_mistral_fallback_field_present(self):
        assert "use_mistral_fallback" in self._source()

    def test_use_mistral_fallback_default_false(self):
        """Par sécurité, le fallback doit être désactivé par défaut."""
        src = self._source()
        # La ligne doit contenir "False"
        for line in src.splitlines():
            if "use_mistral_fallback" in line and ":" in line:
                assert "False" in line, f"use_mistral_fallback doit défaut=False : {line}"
                break

    def test_mistral_api_key_default_empty(self):
        """La clé API ne doit jamais être codée en dur (défaut = chaîne vide)."""
        src = self._source()
        for line in src.splitlines():
            if "mistral_api_key" in line and "str" in line:
                assert '""' in line or "= \"\"" in line, f"mistral_api_key doit défaut='': {line}"
                break


if __name__ == "__main__":
    import pytest as _pytest
    _pytest.main([__file__, "-v"])
