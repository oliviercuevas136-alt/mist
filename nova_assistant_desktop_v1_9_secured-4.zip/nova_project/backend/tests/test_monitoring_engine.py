"""
tests/test_monitoring_engine.py — V4
Couvre : chute réelle, faux positif, absence, urgence manuelle,
state machine, mode dégradé, cooldown, acknowledge, TTS, persistance.
"""

import time
import threading
from datetime import datetime, timedelta, timezone

import pytest

from app.core.monitoring_engine import (
    Alert, AlertLevel, AlertType, MachineState,
    MonitoringEngine, _now,
)


# ---------------------------------------------------------------------------
# Fixture : engine isolé, persistance désactivée, fenêtre réduite
# ---------------------------------------------------------------------------

@pytest.fixture
def engine() -> MonitoringEngine:
    e = MonitoringEngine()
    e.CONFIRM_WINDOW_S = 0.25           # fenêtre courte pour les tests
    e._persist_alert_sync = lambda a: None  # pas de DB en test
    e._reset_idle_delay_confirm  = 0.1   # reset rapide pour les tests
    e._reset_idle_delay_escalate = 1.5   # > 0.6s (durée max des checks d'état)
    yield e
    e.stop()


def alerts_of(engine: MonitoringEngine) -> list:
    """Enregistre et retourne toutes les alertes émises."""
    received = []
    engine.register_callback(lambda a: received.append(a))
    return received


def tts_of(engine: MonitoringEngine) -> list:
    """Enregistre et retourne tous les messages TTS."""
    spoken = []
    engine.register_tts_callback(lambda m: spoken.append(m))
    return spoken


# ===========================================================================
# 1. Chute réelle
# ===========================================================================

class TestRealFall:
    """Chute → pas de réponse → escalade critique."""

    def test_fall_launches_detection_state(self, engine):
        alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.85})
        time.sleep(0.05)
        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.DETECTION, MachineState.CHECK)

    def test_fall_sends_tts_immediately(self, engine):
        spoken = tts_of(engine)
        engine.signal_fall(extra={"confidence": 0.85})
        time.sleep(0.1)
        assert len(spoken) >= 1
        assert any(
            w in spoken[0].lower()
            for w in ["tombé", "reponds", "réponds", "aide", "besoin"]
        )

    def test_fall_escalates_without_response(self, engine):
        """Scénario chute réelle : pas de réponse → CRITICAL + ESCALATE."""
        received = alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.9, "frames_confirmed": 5})
        time.sleep(0.6)   # > CONFIRM_WINDOW_S (0.25s) + marge

        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.ALERT, MachineState.ESCALATE)

        types  = {a.type for a in received}
        assert AlertType.FALL_ESCALATED in types

        escalated = next(a for a in received if a.type == AlertType.FALL_ESCALATED)
        assert escalated.level == AlertLevel.CRITICAL

    def test_fall_escalated_tts_second_message(self, engine):
        """Deux messages TTS : 1 au DETECTION + 1 à l'ESCALATE."""
        spoken = tts_of(engine)
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.6)
        assert len(spoken) >= 2

    def test_fall_escalated_notify_true(self, engine):
        """Après escalade, l'orchestrateur doit notifier les comms."""
        received = alerts_of(engine)
        engine.signal_fall()
        time.sleep(0.6)
        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert len(escalated) >= 1
        assert escalated[0].level == AlertLevel.CRITICAL

    def test_fall_increments_counter(self, engine):
        engine.signal_fall()
        assert engine._sensors.fall_count_today == 1

    def test_fall_alert_has_unique_id(self, engine):
        received = alerts_of(engine)
        engine.CONFIRM_WINDOW_S = 0.1
        engine.signal_fall()
        time.sleep(0.4)
        engine.cooldowns["fall"] = 0
        engine.signal_fall()
        time.sleep(0.4)
        ids = [a.id for a in received]
        assert len(ids) == len(set(ids)), "Doublons d'ID dans les alertes"


# ===========================================================================
# 2. Faux positif (réponse dans la fenêtre)
# ===========================================================================

class TestFalsePositive:
    """Chute détectée → réponse reçue → WARNING seulement, pas de comms."""

    def test_response_before_timeout_goes_to_confirm(self, engine):
        alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()   # réponse dans la fenêtre
        time.sleep(0.4)

        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.CONFIRM, MachineState.IDLE)

    def test_response_produces_warning_not_critical(self, engine):
        received = alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.4)

        types = {a.type for a in received}
        assert AlertType.FALL_CONFIRMED in types
        confirmed = next(a for a in received if a.type == AlertType.FALL_CONFIRMED)
        assert confirmed.level == AlertLevel.WARNING
        assert confirmed.level != AlertLevel.CRITICAL

    def test_voice_activity_counts_as_response(self, engine):
        """Voix = réponse automatique à l'incident."""
        received = alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.85})
        time.sleep(0.05)
        engine.signal_voice_activity()
        time.sleep(0.4)

        types = {a.type for a in received}
        assert AlertType.FALL_CONFIRMED in types

    def test_false_positive_no_critical_alert(self, engine):
        """Si réponse reçue, jamais d'alerte CRITICAL."""
        received = alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.4)

        criticals = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(criticals) == 0, "Faux positif ne doit jamais produire CRITICAL"

    def test_confirmed_tts_is_reassuring(self, engine):
        """Le TTS de confirmation doit être rassurant."""
        spoken = tts_of(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()
        time.sleep(0.4)

        assert len(spoken) >= 2
        last_msg = spoken[-1].lower()
        assert any(w in last_msg for w in ["bien", "là", "besoin", "rassur"])


# ===========================================================================
# 3. Absence prolongée
# ===========================================================================

class TestProlongedAbsence:
    """Absence ≠ Chute — vérifications strictes de séparation."""

    def test_signal_absence_is_warning_not_critical(self, engine):
        received = alerts_of(engine)
        engine.signal_absence(extra={"minutes": 50.0})
        assert len(received) == 1
        assert received[0].type  == AlertType.PROLONGED_ABSENCE
        assert received[0].level == AlertLevel.WARNING

    def test_signal_absence_never_produces_fall_type(self, engine):
        """RÈGLE ABSOLUE : signal_absence() ne génère jamais AlertType.FALL."""
        received = alerts_of(engine)
        engine.signal_absence(extra={"minutes": 60.0})
        for a in received:
            assert a.type not in (
                AlertType.FALL,
                AlertType.FALL_ESCALATED,
                AlertType.FALL_CONFIRMED,
            ), f"signal_absence() a produit une alerte chute : {a.type}"

    def test_absence_never_triggers_state_machine(self, engine):
        """L'absence ne doit pas lancer la state machine de chute."""
        engine.signal_absence(extra={"minutes": 50})
        time.sleep(0.1)
        with engine._lock:
            state = engine._incident.machine_state
        assert state == MachineState.IDLE

    def test_absence_cooldown_blocks_spam(self, engine):
        received = alerts_of(engine)
        engine.signal_absence(extra={"minutes": 50})
        engine.signal_absence(extra={"minutes": 55})
        assert len(received) == 1

    def test_absence_and_fall_produce_distinct_alerts(self, engine):
        """Absence + chute simultanées → deux types différents."""
        received = alerts_of(engine)
        engine.cooldowns["fall"] = 0
        engine.cooldowns["prolonged_absence"] = 0

        engine.signal_absence(extra={"minutes": 50})
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.6)

        types = {a.type for a in received}
        assert AlertType.PROLONGED_ABSENCE in types
        fall_types = {AlertType.FALL_ESCALATED, AlertType.FALL_CONFIRMED}
        assert types & fall_types  # au moins un type chute

    def test_absence_does_not_update_fall_counter(self, engine):
        engine.signal_absence(extra={"minutes": 60})
        assert engine._sensors.fall_count_today == 0


# ===========================================================================
# 4. Urgence manuelle
# ===========================================================================

class TestManualEmergency:
    """Bouton urgence → CRITICAL immédiat, pas de cooldown, TTS immédiat."""

    def test_is_critical(self, engine):
        received = alerts_of(engine)
        engine.signal_manual_emergency()
        assert received[0].type  == AlertType.MANUAL
        assert received[0].level == AlertLevel.CRITICAL

    def test_no_cooldown(self, engine):
        """Deux urgences manuelles → deux alertes."""
        received = alerts_of(engine)
        engine.signal_manual_emergency()
        engine.signal_manual_emergency()
        assert len(received) == 2

    def test_sends_tts_immediately(self, engine):
        spoken = tts_of(engine)
        engine.signal_manual_emergency()
        time.sleep(0.1)
        assert len(spoken) >= 1
        assert any(w in spoken[0].lower() for w in ["secours", "calme", "reçu", "appel"])

    def test_does_not_launch_confirmation_window(self, engine):
        """L'urgence manuelle ne doit pas ouvrir une fenêtre de confirmation."""
        engine.signal_manual_emergency()
        time.sleep(0.1)
        with engine._lock:
            state = engine._incident.machine_state
        # L'incident ne doit pas être en CHECK (fenêtre de confirmation)
        assert state != MachineState.CHECK

    def test_has_unique_id(self, engine):
        received = alerts_of(engine)
        engine.signal_manual_emergency()
        engine.signal_manual_emergency()
        ids = [a.id for a in received]
        assert len(ids) == len(set(ids))


# ===========================================================================
# 5. State machine
# ===========================================================================

class TestStateMachine:
    """Transitions correctes de la state machine."""

    def test_initial_state_is_idle(self, engine):
        assert engine._incident.machine_state == MachineState.IDLE

    def test_fall_moves_to_detection(self, engine):
        engine.signal_fall()
        time.sleep(0.02)
        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.DETECTION, MachineState.CHECK)

    def test_no_incident_blocked_during_active(self, engine):
        """Un second incident ne peut pas démarrer pendant un incident actif."""
        spoken = tts_of(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.02)
        # Deuxième signal_fall pendant que l'incident est actif
        engine.cooldowns["fall"] = 0
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.1)
        # Un seul TTS du premier signal doit avoir été envoyé
        # (le second est ignoré car incident actif)
        assert len([m for m in spoken if "tombé" in m.lower() or "reponds" in m.lower()]) == 1

    def test_confirm_then_back_to_idle(self, engine):
        engine.signal_fall()
        time.sleep(0.02)
        engine.signal_response()
        time.sleep(0.6)   # attendre le reset_to_idle (5s dans prod, instant en test)
        # Après confirm, l'incident doit être CONFIRM ou IDLE
        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.CONFIRM, MachineState.IDLE)

    def test_escalate_then_eventually_idle(self, engine):
        engine.signal_fall()
        time.sleep(0.6)   # escalade
        with engine._lock:
            state = engine._incident.machine_state
        assert state in (MachineState.ALERT, MachineState.ESCALATE)


# ===========================================================================
# 6. Cooldown — anti-spam
# ===========================================================================

class TestCooldown:
    def test_fall_cooldown_blocks_double_tts(self, engine):
        spoken = tts_of(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        engine.signal_fall(extra={"confidence": 0.9})  # cooldown actif
        time.sleep(0.1)
        first_messages = [m for m in spoken if "tombé" in m.lower() or "reponds" in m.lower()]
        assert len(first_messages) == 1

    def test_absence_cooldown_blocks_spam(self, engine):
        received = alerts_of(engine)
        engine.signal_absence(extra={"minutes": 50})
        engine.signal_absence(extra={"minutes": 55})
        assert len(received) == 1

    def test_inactivity_cooldown(self, engine):
        received = alerts_of(engine)
        engine.signal_inactivity(extra={"hours": 9})
        engine.signal_inactivity(extra={"hours": 10})
        assert len(received) == 1

    def test_silence_cooldown(self, engine):
        received = alerts_of(engine)
        since = _now() - timedelta(minutes=130)
        engine._maybe_alert_silence(130.0, since)
        engine._maybe_alert_silence(135.0, since)
        assert len(received) == 1

    def test_manual_no_cooldown(self, engine):
        received = alerts_of(engine)
        engine.signal_manual_emergency()
        engine.signal_manual_emergency()
        assert len(received) == 2

    def test_test_no_cooldown(self, engine):
        received = alerts_of(engine)
        engine.signal_test()
        engine.signal_test()
        assert len(received) == 2

    def test_cooldown_dict_isolated_between_instances(self):
        """CRITIQUE : le dict de cooldown ne doit pas être partagé entre instances."""
        e1 = MonitoringEngine()
        e2 = MonitoringEngine()
        e1.cooldowns["fall"] = 0
        assert e2.cooldowns["fall"] != 0, \
            "BUG : cooldowns partagés entre instances (dict de classe)"


# ===========================================================================
# 7. Acknowledge
# ===========================================================================

class TestAcknowledge:
    def test_acknowledge_marks_alert(self, engine):
        received = alerts_of(engine)
        engine.signal_manual_emergency()
        alert_id = received[-1].id
        ok = engine.acknowledge_alert(alert_id)
        assert ok is True
        alerts = engine.get_alerts(limit=10)
        found   = next((a for a in alerts if a["id"] == alert_id), None)
        assert found["acknowledged"] is True

    def test_acknowledge_unknown_id(self, engine):
        assert engine.acknowledge_alert(99999) is False

    def test_unacknowledged_by_default(self, engine):
        received = alerts_of(engine)
        engine.signal_test()
        assert received[0].acknowledged is False


# ===========================================================================
# 8. TTS callbacks
# ===========================================================================

class TestTTS:
    def test_multiple_callbacks_all_called(self, engine):
        a, b = [], []
        engine.register_tts_callback(lambda m: a.append(m))
        engine.register_tts_callback(lambda m: b.append(m))
        engine.signal_manual_emergency()
        time.sleep(0.1)
        assert len(a) >= 1
        assert len(b) >= 1

    def test_callback_exception_doesnt_crash(self, engine):
        """Un callback TTS qui plante ne doit pas stopper les autres."""
        good = []
        def bad_cb(m):
            raise RuntimeError("crash intentionnel")
        engine.register_tts_callback(bad_cb)
        engine.register_tts_callback(lambda m: good.append(m))
        engine.signal_manual_emergency()
        time.sleep(0.1)
        assert len(good) >= 1


# ===========================================================================
# 9. Mode dégradé
# ===========================================================================

class TestDegradedMode:
    def test_camera_off_monitoring_continues(self, engine):
        """Sans caméra, le moteur ne crash pas et reste actif."""
        engine.signal_camera_available(False)
        engine.start()
        time.sleep(0.05)
        state = engine.get_state()
        assert state["active"] is True
        assert state["camera_available"] is False

    def test_mic_off_monitoring_continues(self, engine):
        """Sans micro, le moteur ne crash pas."""
        engine.signal_mic_available(False)
        engine.start()
        time.sleep(0.05)
        state = engine.get_state()
        assert state["active"] is True
        assert state["mic_available"] is False

    def test_signal_fall_works_without_camera(self, engine):
        """signal_fall() peut être appelé sans caméra active."""
        engine.signal_camera_available(False)
        received = alerts_of(engine)
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.6)
        types = {a.type for a in received}
        # Doit toujours escalader
        assert AlertType.FALL_ESCALATED in types

    def test_callbacks_outside_lock(self, engine):
        """Callback réentrant — ne doit pas deadlocker."""
        results = []
        def cb(alert):
            state = engine.get_state()   # appel réentrant
            results.append(state)
        engine.register_callback(cb)
        engine.signal_manual_emergency()
        assert len(results) == 1


# ===========================================================================
# 10. Signaux d'état
# ===========================================================================

class TestSensorSignals:
    def test_voice_resets_silence(self, engine):
        engine._sensors.silence_minutes = 150.0
        engine.signal_voice_activity()
        assert engine._sensors.silence_minutes == 0.0

    def test_person_seen_resets_absence(self, engine):
        engine._sensors.absence_minutes = 60.0
        engine.signal_person_seen()
        assert engine._sensors.absence_minutes == 0.0

    def test_voice_sets_mic_available(self, engine):
        engine.signal_voice_activity()
        assert engine._sensors.mic_available is True

    def test_person_seen_sets_camera_available(self, engine):
        engine.signal_person_seen()
        assert engine._sensors.camera_available is True

    def test_silence_alert_triggers_tts(self, engine):
        spoken = tts_of(engine)
        engine._maybe_alert_silence(130.0, _now() - timedelta(minutes=130))
        time.sleep(0.1)
        assert len(spoken) >= 1
