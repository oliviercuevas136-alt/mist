from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.database import Base
from app.core.note_engine import NoteEngine


def build_test_db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return TestingSessionLocal()


def test_create_update_delete_note():
    db = build_test_db()
    engine = NoteEngine()

    note = engine.create_note(
        db=db,
        title="Plan",
        content="Finaliser la V1",
        tags="v1,local",
    )

    assert note.id is not None
    assert note.title == "Plan"

    updated = engine.update_note(
        db=db,
        note_id=note.id,
        title="Plan final",
        content="Finaliser la V1 proprement",
        tags="v1,local,stable",
    )

    assert updated is not None
    assert updated.title == "Plan final"

    deleted = engine.delete_note(db=db, note_id=note.id)
    assert deleted is True