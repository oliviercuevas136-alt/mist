"""
tests/test_orchestrator.py — V4
Routage VisionEvent, probe queue, decide(), mode dégradé, emergency.
"""

import threading
import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone

from app.core.monitoring_engine import Alert, AlertLevel, AlertType, MachineState
from app.core.vision_engine import VisionEvent
from app.core.orchestrator import Orchestrator


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------

def make_alert(atype=AlertType.FALL_ESCALATED, level=AlertLevel.CRITICAL) -> Alert:
    return Alert(type=atype, level=level, message=f"Test {atype.value}", id=1)


@pytest.fixture
def orch() -> Orchestrator:
    """Orchestrateur isolé — sans singletons ni threads."""
    o = Orchestrator.__new__(Orchestrator)
    o._active       = False
    o._lock         = threading.Lock()
    o._event_log    = []
    o._probe_queue  = []
    yield o


# ===========================================================================
# 1. Routage VisionEvent (RÈGLE ABSOLUE)
# ===========================================================================

class TestVisionRouting:
    def test_fall_routes_to_signal_fall(self, orch):
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.FALL_SUSPECTED,
                                   {"confidence": 0.85, "timestamp": "now"})
            m.signal_fall.assert_called_once()
            m.signal_absence.assert_not_called()

    def test_absence_routes_to_signal_absence_never_fall(self, orch):
        """RÈGLE ABSOLUE : absence → signal_absence, JAMAIS signal_fall."""
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.ABSENCE_PROLONGED, {"minutes": 50.0})
            m.signal_absence.assert_called_once()
            m.signal_fall.assert_not_called()

    def test_presence_detected_routes_to_person_seen(self, orch):
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.PRESENCE_DETECTED, {})
            m.signal_person_seen.assert_called_once()

    def test_presence_lost_no_signal(self, orch):
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.PRESENCE_LOST, {})
            m.signal_fall.assert_not_called()
            m.signal_absence.assert_not_called()

    def test_camera_error_sets_degraded_mode(self, orch):
        """Erreur caméra → mode dégradé (signal_camera_available(False))."""
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.CAMERA_ERROR, {"camera": 0})
            m.signal_camera_available.assert_called_once_with(False)
            m.signal_fall.assert_not_called()

    def test_no_confusion_between_fall_and_absence(self, orch):
        """Deux événements différents → deux signaux distincts."""
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.FALL_SUSPECTED, {"confidence": 0.9})
            orch._on_vision_event(VisionEvent.ABSENCE_PROLONGED, {"minutes": 50})
            assert m.signal_fall.call_count   == 1
            assert m.signal_absence.call_count == 1


# ===========================================================================
# 2. TTS — on_tts callback
# ===========================================================================

class TestTTSCallback:
    def test_on_tts_enqueues_immediate(self, orch):
        with patch.object(orch, "_try_local_tts"):
            orch._on_tts("Urgence !")
        assert len(orch._probe_queue) == 1
        assert orch._probe_queue[0]["immediate"] is True
        assert orch._probe_queue[0]["message"] == "Urgence !"

    def test_on_tts_inserts_at_front(self, orch):
        """Message immédiat → en tête de file."""
        orch._probe_queue.append({"message": "normal", "immediate": False})
        with patch.object(orch, "_try_local_tts"):
            orch._on_tts("URGENT")
        assert orch._probe_queue[0]["message"] == "URGENT"

    def test_on_tts_caps_at_5(self, orch):
        with patch.object(orch, "_try_local_tts"):
            for i in range(10):
                orch._on_tts(f"msg {i}")
        assert len(orch._probe_queue) <= 5

    def test_on_tts_empty_message_ignored(self, orch):
        with patch.object(orch, "_try_local_tts"):
            orch._on_tts("")
        assert len(orch._probe_queue) == 0

    def test_on_tts_calls_local_tts(self, orch):
        with patch.object(orch, "_try_local_tts") as mock_tts:
            orch._on_tts("Test")
        mock_tts.assert_called_once_with("Test")


# ===========================================================================
# 3. Probe queue
# ===========================================================================

class TestProbeQueue:
    def test_empty_returns_none(self, orch):
        assert orch.get_pending_vocal_probe() is None

    def test_enqueue_dequeue(self, orch):
        orch._enqueue_probe("warning", "warning", "Tout va bien ?", immediate=False)
        result = orch.get_pending_vocal_probe()
        assert result["probe"] is True
        assert "Tout va bien" in result["message"]

    def test_consumed_after_get(self, orch):
        orch._enqueue_probe("warning", "warning", "Test", immediate=False)
        orch.get_pending_vocal_probe()
        assert orch.get_pending_vocal_probe() is None

    def test_fifo_order(self, orch):
        for i in range(3):
            orch._enqueue_probe("warning", "warning", f"Message {i}", immediate=False)
        first = orch.get_pending_vocal_probe()
        assert "0" in first["message"]

    def test_max_3_non_immediate(self, orch):
        for i in range(5):
            orch._enqueue_probe("info", "info", f"msg {i}", immediate=False)
        assert len(orch._probe_queue) <= 3

    def test_empty_message_not_enqueued(self, orch):
        orch._enqueue_probe("info", "info", "", immediate=False)
        assert len(orch._probe_queue) == 0


# ===========================================================================
# 4. on_alert — logique TTS / comms
# ===========================================================================

class TestOnAlert:
    def test_fall_escalated_triggers_comms(self, orch):
        alert = make_alert(AlertType.FALL_ESCALATED, AlertLevel.CRITICAL)
        with (
            patch.object(orch, "_call_decide", return_value={
                "action": "escalate", "message": "", "tts": False, "notify": True
            }),
            patch.object(orch, "_send_comms_safe") as mock_comms,
        ):
            orch._on_alert(alert)
            mock_comms.assert_called_once()

    def test_fall_no_double_tts(self, orch):
        """AlertType.FALL → pas de probe (TTS géré par monitoring_engine)."""
        alert = make_alert(AlertType.FALL, AlertLevel.WARNING)
        with (
            patch.object(orch, "_call_decide", return_value={
                "action": "confirm", "message": "", "tts": False, "notify": False
            }),
            patch.object(orch, "_send_comms_safe"),
        ):
            orch._on_alert(alert)
        # Aucun probe non-immédiat ne doit être enfilé
        non_immediate = [p for p in orch._probe_queue if not p.get("immediate")]
        assert len(non_immediate) == 0

    def test_absence_with_tts_enqueues_probe(self, orch):
        alert = make_alert(AlertType.PROLONGED_ABSENCE, AlertLevel.WARNING)
        with (
            patch.object(orch, "_call_decide", return_value={
                "action": "alert", "message": "Êtes-vous là ?", "tts": True, "notify": False
            }),
            patch.object(orch, "_send_comms_safe"),
        ):
            orch._on_alert(alert)
        assert len(orch._probe_queue) == 1

    def test_info_no_comms(self, orch):
        alert = make_alert(AlertType.TEST, AlertLevel.INFO)
        with (
            patch.object(orch, "_call_decide", return_value={
                "action": "log", "message": "", "tts": False, "notify": False
            }),
            patch.object(orch, "_send_comms_safe") as mock_comms,
        ):
            orch._on_alert(alert)
            mock_comms.assert_not_called()


# ===========================================================================
# 5. decide() — assistant central
# ===========================================================================

class TestDecide:
    def test_fallback_critical_notify_true(self, orch):
        alert = make_alert(AlertType.FALL_ESCALATED, AlertLevel.CRITICAL)
        result = orch._fallback_decide(alert)
        assert result["notify"] is True

    def test_fallback_info_no_notify(self, orch):
        alert = make_alert(AlertType.TEST, AlertLevel.INFO)
        result = orch._fallback_decide(alert)
        assert result["notify"] is False

    def test_fallback_used_when_db_unavailable(self, orch):
        alert = make_alert(AlertType.FALL_ESCALATED, AlertLevel.CRITICAL)
        with patch("app.db.database.SessionLocal", side_effect=Exception("DB down")):
            result = orch._call_decide(alert)
        assert "action" in result
        assert result["source"] == "fallback"

    def test_decide_always_returns_dict(self, orch):
        """decide() ne doit jamais lever d'exception."""
        for atype in AlertType:
            alert = make_alert(atype, AlertLevel.INFO)
            result = orch._fallback_decide(alert)
            assert isinstance(result, dict)
            assert "action" in result
            assert "notify" in result


# ===========================================================================
# 6. Emergency
# ===========================================================================

class TestEmergency:
    def test_trigger_emergency(self, orch):
        with patch("app.core.orchestrator.monitoring_engine") as m:
            result = orch.trigger_emergency()
            assert result["status"] == "emergency_triggered"
            m.signal_manual_emergency.assert_called_once()

    def test_user_response(self, orch):
        with patch("app.core.orchestrator.monitoring_engine") as m:
            result = orch.signal_user_response()
            m.signal_response.assert_called_once()
            assert result["status"] == "response_registered"


# ===========================================================================
# 7. Mode dégradé (orchestrateur)
# ===========================================================================

class TestDegradedMode:
    def test_camera_error_doesnt_stop_monitoring(self, orch):
        """Erreur caméra → mode dégradé, monitoring continue."""
        with patch("app.core.orchestrator.monitoring_engine") as m:
            orch._on_vision_event(VisionEvent.CAMERA_ERROR, {"error": "no device"})
            m.signal_camera_available.assert_called_once_with(False)
            # Le monitoring ne doit pas être arrêté
            m.stop.assert_not_called()

    def test_comms_error_doesnt_crash(self, orch):
        """Erreur comms → log, pas de crash."""
        alert = make_alert(AlertType.FALL_ESCALATED, AlertLevel.CRITICAL)
        with patch("app.core.orchestrator.comms_engine") as m:
            m.notify.side_effect = Exception("réseau coupé")
            # Ne doit pas lever d'exception
            orch._send_comms_safe(alert)


# ===========================================================================
# 8. Event log
# ===========================================================================

class TestEventLog:
    def test_log_appends_entry(self, orch):
        orch._log("test", "description", {"k": "v"})
        assert len(orch._event_log) == 1
        entry = orch._event_log[0]
        assert entry["source"] == "test"
        assert entry["description"] == "description"

    def test_log_capped_at_500(self, orch):
        for i in range(600):
            orch._log("test", f"event {i}", {})
        assert len(orch._event_log) <= 500
