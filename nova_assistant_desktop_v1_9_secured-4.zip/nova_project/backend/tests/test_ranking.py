from app.core.ranking import overlap_score, weighted_document_score, weighted_memory_score


def test_overlap_score_basic():
    assert overlap_score("nova projet", "le projet nova avance") >= 2


def test_weighted_memory_score_respects_importance():
    low = weighted_memory_score("nova", "nova central", 1)
    high = weighted_memory_score("nova", "nova central", 5)
    assert high > low


def test_weighted_document_score():
    score = weighted_document_score(
        "arkeon",
        "arkeon_notes.txt",
        "data/notes/arkeon_notes.txt",
        "Le projet Arkéon avance",
    )
    assert score > 0