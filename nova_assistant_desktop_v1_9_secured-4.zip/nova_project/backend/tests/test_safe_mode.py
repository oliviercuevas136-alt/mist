"""
tests/test_safe_mode.py — Mode safe V4.

Valide que le mode safe (vigilance renforcée) :
  - S'active / se désactive sans crash
  - Modifie bien les paramètres (seuils, fenêtre)
  - Ne change PAS le comportement humain fondamental :
      • La confirmation vocale reste obligatoire
      • Faux positif + réponse → WARNING seulement (jamais CRITICAL)
      • Absence → WARNING uniquement (jamais CRITICAL)
  - L'état est correctement reporté dans get_state()
  - La boucle temporelle utilise les bons seuils selon le mode
"""

import time
from datetime import timedelta

import pytest

from app.core.monitoring_engine import (
    AlertLevel, AlertType, MachineState,
    MonitoringEngine, _now,
)


# ---------------------------------------------------------------------------
# Fixture engine isolée — persistance désactivée
# ---------------------------------------------------------------------------

@pytest.fixture
def engine() -> MonitoringEngine:
    e = MonitoringEngine()
    e._persist_alert_sync = lambda a: None   # désactive SQLite
    e._reset_idle_delay_confirm  = 0.1   # reset rapide pour les tests
    e._reset_idle_delay_escalate = 0.2
    e.cooldowns["fall"]              = 0
    e.cooldowns["prolonged_absence"] = 0
    e.cooldowns["prolonged_silence"] = 0
    e.cooldowns["inactivity"]        = 0
    yield e
    e.stop()


def _collect(engine):
    received = []
    engine.register_callback(lambda a: received.append(a))
    return received


def _spoken(engine):
    msgs = []
    engine.register_tts_callback(lambda m: msgs.append(m))
    return msgs


# ===========================================================================
# 1. Activation / désactivation
# ===========================================================================

class TestSafeModeToggle:

    def test_safe_mode_off_by_default(self, engine):
        """Le mode safe est désactivé par défaut."""
        assert engine.safe_mode is False

    def test_enable_safe_mode(self, engine):
        """enable_safe_mode() passe safe_mode à True."""
        engine.enable_safe_mode(reason="test")
        assert engine.safe_mode is True

    def test_disable_safe_mode(self, engine):
        """disable_safe_mode() repasse à False."""
        engine.enable_safe_mode()
        engine.disable_safe_mode()
        assert engine.safe_mode is False

    def test_enable_idempotent(self, engine):
        """Double activation ne cause pas d'erreur ni de double TTS."""
        msgs = _spoken(engine)
        engine.enable_safe_mode()
        engine.enable_safe_mode()  # second appel — ignoré
        assert engine.safe_mode is True
        assert len(msgs) == 1, "Une seule annonce TTS pour l'activation"

    def test_disable_idempotent(self, engine):
        """Double désactivation ne cause pas d'erreur."""
        engine.disable_safe_mode()   # sans jamais avoir activé
        engine.disable_safe_mode()   # second appel
        assert engine.safe_mode is False  # ne crash pas


# ===========================================================================
# 2. Paramètres dynamiques
# ===========================================================================

class TestSafeModeParameters:

    def test_normal_mode_confirm_window(self, engine):
        """Mode normal : fenêtre = CONFIRM_WINDOW_S (12s)."""
        assert engine._get_confirm_window() == engine.CONFIRM_WINDOW_S

    def test_safe_mode_confirm_window_longer(self, engine):
        """Mode safe : fenêtre = SAFE_CONFIRM_WINDOW_S (15s) — plus de temps."""
        engine.enable_safe_mode()
        assert engine._get_confirm_window() == engine.SAFE_CONFIRM_WINDOW_S
        assert engine._get_confirm_window() > engine.CONFIRM_WINDOW_S

    def test_safe_mode_silence_threshold_lower(self, engine):
        """Mode safe : seuil silence plus bas (alerte plus tôt)."""
        engine.enable_safe_mode()
        assert engine._get_silence_threshold() < engine.SILENCE_ALERT_MINUTES
        assert engine._get_silence_threshold() == engine.SAFE_SILENCE_ALERT_MIN

    def test_safe_mode_absence_threshold_lower(self, engine):
        """Mode safe : seuil absence plus bas."""
        engine.enable_safe_mode()
        assert engine._get_absence_threshold() < engine.ABSENCE_ALERT_MINUTES
        assert engine._get_absence_threshold() == engine.SAFE_ABSENCE_ALERT_MIN

    def test_safe_mode_inactivity_threshold_lower(self, engine):
        """Mode safe : seuil inactivité plus bas."""
        engine.enable_safe_mode()
        assert engine._get_inactivity_threshold() < engine.INACTIVITY_ALERT_HOURS
        assert engine._get_inactivity_threshold() == engine.SAFE_INACTIVITY_ALERT_H

    def test_params_restored_after_disable(self, engine):
        """Après désactivation, les paramètres reviennent à la normale."""
        engine.enable_safe_mode()
        engine.disable_safe_mode()
        assert engine._get_confirm_window()       == engine.CONFIRM_WINDOW_S
        assert engine._get_silence_threshold()    == engine.SILENCE_ALERT_MINUTES
        assert engine._get_absence_threshold()    == engine.ABSENCE_ALERT_MINUTES
        assert engine._get_inactivity_threshold() == engine.INACTIVITY_ALERT_HOURS


# ===========================================================================
# 3. État reporté dans get_state()
# ===========================================================================

class TestSafeModeState:

    def test_get_state_reports_safe_mode_off(self, engine):
        state = engine.get_state()
        assert "safe_mode" in state
        assert state["safe_mode"] is False
        assert state["safe_mode_since"] is None

    def test_get_state_reports_safe_mode_on(self, engine):
        engine.enable_safe_mode()
        state = engine.get_state()
        assert state["safe_mode"] is True
        assert state["safe_mode_since"] is not None

    def test_get_state_confirm_window_reflects_mode(self, engine):
        """confirm_window_s dans get_state() suit le mode actif."""
        normal = engine.get_state()["confirm_window_s"]
        engine.enable_safe_mode()
        safe = engine.get_state()["confirm_window_s"]
        assert safe > normal, "Mode safe doit augmenter la fenêtre de confirmation"

    def test_get_state_thresholds_in_safe_mode(self, engine):
        """Les seuils reportés en mode safe sont inférieurs au mode normal."""
        normal = engine.get_state()
        engine.enable_safe_mode()
        safe = engine.get_state()
        assert safe["silence_threshold_m"]    < normal["silence_threshold_m"]
        assert safe["absence_threshold_m"]    < normal["absence_threshold_m"]
        assert safe["inactivity_threshold_h"] < normal["inactivity_threshold_h"]


# ===========================================================================
# 4. Garanties humaines inchangées en mode safe
# ===========================================================================

class TestSafeModeHumanGuarantees:
    """
    RÈGLES ABSOLUES : le mode safe ne change pas le comportement humain.
    La sécurité de la personne reste identique.
    """

    def test_safe_mode_false_positive_still_warning_only(self, engine):
        """
        Mode safe + faux positif + réponse rapide → WARNING seulement.
        JAMAIS CRITICAL même en mode vigilance renforcée.
        """
        engine.CONFIRM_WINDOW_S      = 0.3
        engine.SAFE_CONFIRM_WINDOW_S = 0.4
        engine.enable_safe_mode()

        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.8})
        time.sleep(0.05)
        engine.signal_response()    # répond vite
        time.sleep(0.7)

        critical = [a for a in received if a.level == AlertLevel.CRITICAL]
        assert len(critical) == 0, \
            "Mode safe + réponse reçue NE DOIT PAS produire CRITICAL"

        confirmed = [a for a in received if a.type == AlertType.FALL_CONFIRMED]
        assert len(confirmed) == 1
        assert confirmed[0].level == AlertLevel.WARNING

    def test_safe_mode_real_fall_still_escalates(self, engine):
        """
        Mode safe + chute réelle + pas de réponse → CRITICAL + ESCALATE.
        La vigilance renforcée ne doit pas bloquer les vraies alertes.
        """
        engine.CONFIRM_WINDOW_S      = 0.2
        engine.SAFE_CONFIRM_WINDOW_S = 0.3
        engine.enable_safe_mode()

        received = _collect(engine)
        engine.signal_fall(extra={"confidence": 0.9})
        time.sleep(0.8)   # > SAFE_CONFIRM_WINDOW_S

        escalated = [a for a in received if a.type == AlertType.FALL_ESCALATED]
        assert len(escalated) >= 1, "Chute réelle doit escalader même en mode safe"
        assert escalated[0].level == AlertLevel.CRITICAL

    def test_safe_mode_absence_still_warning(self, engine):
        """Absence en mode safe → WARNING (jamais CRITICAL)."""
        engine.enable_safe_mode()
        received = _collect(engine)
        engine.signal_absence(extra={"minutes": 25.0})   # > SAFE_ABSENCE_ALERT_MIN

        assert len(received) == 1
        assert received[0].level == AlertLevel.WARNING, \
            "Absence en mode safe doit rester WARNING"

    def test_safe_mode_temporal_rules_use_safe_thresholds(self, engine):
        """La boucle temporelle utilise les seuils safe quand le mode est actif."""
        engine.enable_safe_mode()
        received = _collect(engine)

        # Simuler 65 minutes de silence (> SAFE_SILENCE_ALERT_MIN=60, < SILENCE_ALERT_MINUTES=120)
        since = _now() - timedelta(minutes=65)
        engine._sensors.last_voice_at = since
        engine._sensors.mic_available = True
        engine._sensors.silence_minutes = 65.0

        engine._check_temporal_rules()

        silence_alerts = [a for a in received if a.type == AlertType.PROLONGED_SILENCE]
        assert len(silence_alerts) >= 1, \
            "En mode safe, l'alerte silence doit se déclencher dès 60min (pas 120min)"


# ===========================================================================
# 5. Preuve : signal_fall() ne deadlock jamais
# ===========================================================================

class TestSignalFallNoDeadlock:
    """
    RÈGLE CRITIQUE : signal_fall() doit retourner rapidement.
    Le Lock n'est pas réentrant — _get_confirm_window() doit être lu
    AVANT l'acquisition du verrou principal.
    """

    def test_signal_fall_returns_quickly(self, engine):
        """
        signal_fall() doit retourner en < 1s.
        Si _get_confirm_window() était appelé DANS le verrou,
        ce test pendrait indéfiniment.
        """
        import concurrent.futures
        engine.CONFIRM_WINDOW_S = 0.2   # fenêtre courte

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
            future = ex.submit(engine.signal_fall, {"confidence": 0.85})
            # Lève concurrent.futures.TimeoutError si bloqué plus d'1s
            future.result(timeout=1.0)

        # Arriver ici = pas de deadlock
        assert True

    def test_signal_fall_concurrent_calls_no_deadlock(self, engine):
        """
        Deux appels simultanés à signal_fall() ne doivent pas deadlocker.
        Le deuxième est ignoré (incident déjà actif), sans blocage.
        """
        import concurrent.futures
        engine.CONFIRM_WINDOW_S = 0.2
        engine.cooldowns["fall"] = 0

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
            f1 = ex.submit(engine.signal_fall, {"confidence": 0.8})
            f2 = ex.submit(engine.signal_fall, {"confidence": 0.8})
            # Les deux doivent se terminer sans bloquer
            f1.result(timeout=1.0)
            f2.result(timeout=1.0)

        assert True

    def test_enable_safe_mode_during_active_incident_no_deadlock(self, engine):
        """
        Activer le mode safe pendant un incident actif ne doit pas deadlocker.
        enable_safe_mode() et signal_fall() acquièrent le même verrou — OK
        car ils ne s'imbriquent pas.
        """
        import concurrent.futures
        engine.CONFIRM_WINDOW_S = 0.3

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
            f1 = ex.submit(engine.signal_fall, {"confidence": 0.8})
            time.sleep(0.05)
            f2 = ex.submit(engine.enable_safe_mode, "test concurrent")
            f1.result(timeout=1.0)
            f2.result(timeout=1.0)

        assert True


# ===========================================================================
# 6. Preuve : timers de reset sont daemon=True
# ===========================================================================

class TestTimersDaemon:
    """
    Les threading.Timer de reset IDLE doivent être daemon=True.
    Sinon, le shutdown du process peut rester bloqué à attendre ces timers.
    """

    def test_confirm_reset_timer_is_daemon(self, engine):
        """
        Le timer de reset après CONFIRM est daemon.
        Vérifié en capturant l'instance threading.Timer créée.
        """
        import threading
        captured = []
        real_Timer = threading.Timer

        class CapturingTimer(real_Timer):
            def __init__(self, interval, fn, *args, **kwargs):
                super().__init__(interval, fn, *args, **kwargs)
                captured.append(self)

        threading.Timer = CapturingTimer
        try:
            engine._reset_idle_delay_confirm = 0.05
            engine._handle_fall_confirmed({})
            time.sleep(0.15)
        finally:
            threading.Timer = real_Timer

        assert len(captured) >= 1, "Un Timer de reset doit avoir été créé"
        for t in captured:
            assert t.daemon is True, (
                f"Timer {t.name!r} doit être daemon=True "
                f"(actuel: daemon={t.daemon})"
            )

    def test_escalate_reset_timer_is_daemon(self, engine):
        """
        Le timer de reset après ESCALATE est daemon.
        """
        import threading
        captured = []
        real_Timer = threading.Timer

        class CapturingTimer(real_Timer):
            def __init__(self, interval, fn, *args, **kwargs):
                super().__init__(interval, fn, *args, **kwargs)
                captured.append(self)

        threading.Timer = CapturingTimer
        try:
            engine._reset_idle_delay_escalate = 0.05
            engine._handle_fall_escalated({})
            time.sleep(0.15)
        finally:
            threading.Timer = real_Timer

        assert len(captured) >= 1, "Un Timer de reset escalade doit avoir été créé"
        for t in captured:
            assert t.daemon is True, (
                f"Timer escalade doit être daemon=True "
                f"(actuel: daemon={t.daemon})"
            )

    def test_persist_thread_is_daemon(self, engine):
        """
        Le thread de persistance SQLite (persist-worker) est daemon.
        """
        assert engine._persist_thread.daemon is True, \
            "Le thread persist-worker doit être daemon=True"

    def test_monitoring_thread_is_daemon(self, engine):
        """
        Le thread principal de surveillance est daemon après démarrage.
        """
        engine.start()
        time.sleep(0.05)
        assert engine._thread is not None
        assert engine._thread.daemon is True, \
            "Le thread monitoring-engine doit être daemon=True"
        engine.stop()


# ===========================================================================
# 7. Tests API : GET/POST /api/monitoring/safe-mode
#               GET /api/monitoring/events
# ===========================================================================

@pytest.fixture(scope="module")
def api_client():
    """
    Client HTTP pour tester les endpoints FastAPI de surveillance.

    On crée une mini-app de test qui n'inclut que le router monitoring,
    évitant les dépendances optionnelles (pyttsx3, whisper, OpenCV…)
    qui ne sont pas installées en environnement de test.
    """
    import os
    import tempfile
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from sqlalchemy import create_engine as sa_create_engine
    from sqlalchemy.orm import sessionmaker

    # DB SQLite en mémoire pour les tests
    test_db_url = "sqlite:///./data/assistant.db"

    # Créer le répertoire data si absent (nécessaire pour SQLite)
    os.makedirs("data", exist_ok=True)

    # Initialiser les tables
    from app.db.database import Base
    import app.db.models  # noqa: enregistre les modèles dans Base.metadata
    test_engine = sa_create_engine(test_db_url, connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=test_engine)

    # Isolation inter-modules : test_ws_bridge._make_db_stubs() peut avoir remplacé
    # app.db.database.engine/SessionLocal par un engine SQLite :memory: SANS StaticPool.
    # Un engine :memory: sans StaticPool crée une base vide pour chaque nouvelle connexion,
    # ce qui fait échouer les requêtes dans le monitoring router (lazy-import de SessionLocal).
    # Solution : pendant toute la durée du fixture, on redirige app.db.database.SessionLocal
    # vers une session liée au test_engine fichier (persistant) qui contient toutes les tables.
    import app.db.database as _db_mod
    from sqlalchemy.orm import sessionmaker as _sessionmaker
    _orig_engine = _db_mod.engine
    _orig_session = _db_mod.SessionLocal
    _db_mod.engine = test_engine
    _db_mod.SessionLocal = _sessionmaker(bind=test_engine, autocommit=False, autoflush=False)

    # Mini-app sans les modules audio/vidéo
    mini_app = FastAPI(title="Test Monitoring API")
    from app.api.monitoring import router as monitoring_router
    mini_app.include_router(monitoring_router)

    with TestClient(mini_app) as client:
        yield client

    # Teardown : restaurer l'engine et la session d'origine (stub ou réel)
    _db_mod.engine = _orig_engine
    _db_mod.SessionLocal = _orig_session


class TestSafeModeAPI:
    """Tests de l'API REST /api/monitoring/safe-mode."""

    def test_get_safe_mode_returns_200(self, api_client):
        """GET /api/monitoring/safe-mode retourne 200 avec les champs attendus."""
        resp = api_client.get("/api/monitoring/safe-mode")
        assert resp.status_code == 200
        data = resp.json()
        assert "safe_mode" in data
        assert "confirm_window_s" in data
        assert "silence_threshold_m" in data
        assert "absence_threshold_m" in data
        assert "inactivity_threshold_h" in data

    def test_post_safe_mode_enable(self, api_client):
        """POST /api/monitoring/safe-mode {enabled: true} active le mode."""
        resp = api_client.post(
            "/api/monitoring/safe-mode",
            json={"enabled": True, "reason": "test_api"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["safe_mode"] is True

    def test_post_safe_mode_disable(self, api_client):
        """POST /api/monitoring/safe-mode {enabled: false} désactive le mode."""
        # Activer d'abord
        api_client.post("/api/monitoring/safe-mode", json={"enabled": True})
        # Puis désactiver
        resp = api_client.post(
            "/api/monitoring/safe-mode",
            json={"enabled": False},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["safe_mode"] is False

    def test_post_safe_mode_without_reason(self, api_client):
        """POST sans champ reason ne doit pas crasher (reason est optionnel)."""
        resp = api_client.post(
            "/api/monitoring/safe-mode",
            json={"enabled": True},
        )
        assert resp.status_code == 200

    def test_get_safe_mode_reflects_post(self, api_client):
        """
        GET après POST doit retourner l'état cohérent.
        Le moteur global reflète le changement d'état.
        """
        api_client.post("/api/monitoring/safe-mode", json={"enabled": True, "reason": "nuit"})
        resp = api_client.get("/api/monitoring/safe-mode")
        assert resp.status_code == 200
        data = resp.json()
        assert data["safe_mode"] is True
        # Fenêtre plus grande en mode safe
        assert data["confirm_window_s"] == 15


class TestEventsAPI:
    """Tests de l'API REST /api/monitoring/events (journal SQLite)."""

    def test_get_events_returns_200(self, api_client):
        """GET /api/monitoring/events retourne 200."""
        resp = api_client.get("/api/monitoring/events")
        assert resp.status_code == 200

    def test_get_events_has_required_fields(self, api_client):
        """La réponse contient les champs structurels attendus."""
        resp = api_client.get("/api/monitoring/events")
        data = resp.json()
        assert "events" in data, "Champ 'events' absent"
        assert "total" in data, "Champ 'total' absent"
        assert "limit" in data, "Champ 'limit' absent"
        assert isinstance(data["events"], list)

    def test_get_events_filter_by_source(self, api_client):
        """Le filtre source ne doit pas crasher même si aucun résultat."""
        for source in ("vision", "voice", "system", "alert", "unknown_source"):
            resp = api_client.get(f"/api/monitoring/events?source={source}")
            assert resp.status_code == 200, f"source={source} ne doit pas crasher"
            data = resp.json()
            assert "events" in data

    def test_get_events_limit_param(self, api_client):
        """Le paramètre limit est respecté."""
        resp = api_client.get("/api/monitoring/events?limit=5")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["events"]) <= 5

    def test_get_events_never_crashes_on_empty_db(self, api_client):
        """
        Même si la table est vide (première exécution),
        l'endpoint retourne une liste vide — jamais 500.
        """
        resp = api_client.get("/api/monitoring/events")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data["events"], list)
        # Pas d'erreur fatale dans la réponse
        assert "error" not in data or data.get("error") is None
