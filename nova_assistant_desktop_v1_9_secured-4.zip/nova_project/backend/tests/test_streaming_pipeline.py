"""
test_streaming_pipeline.py — Pipeline streaming vocal V4.5

Vérifie :
  1. speak_sentence_queue → joue chaque phrase séquentiellement
  2. Vrai streaming LLM → tokens reçus progressivement (pas via list())
  3. t_first_token_ms mesuré au PREMIER token, pas au dernier
  4. TTS progressif : phrases envoyées dès qu'elles sont complètes
  5. Timeout LLM → fallback propre
  6. stop_event respecté par le thread TTS
  7. _find_segment : découpage propre sur . ! ?
  8. Pipeline /stream : tokens SSE émis, métriques présentes
"""

import asyncio
import queue
import sys
import threading
import time
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ── sys.path projet ──────────────────────────────────────────────────────────

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


# ── Stubs feuilles injectés avant tout import ────────────────────────────────
# NE PAS stubber app, app.core, app.api — ce sont de vrais packages sur sys.path

def _stub_if_absent(name, obj=None):
    if name not in sys.modules:
        sys.modules[name] = obj or MagicMock()


_stub_if_absent("pyttsx3")
_stub_if_absent("faster_whisper")

# pydantic_settings léger (requis par app.config)
if "pydantic_settings" not in sys.modules:
    _ps = types.ModuleType("pydantic_settings")

    class _BaseSettings:
        model_config = {}
        def __init__(self, **kw):
            for k, v in kw.items():
                setattr(self, k, v)

    _ps.BaseSettings = _BaseSettings
    _ps.SettingsConfigDict = dict
    sys.modules["pydantic_settings"] = _ps

# Stub app.config si absent
if "app.config" not in sys.modules:
    _cfg = MagicMock()
    _cfg.enable_tts             = True
    _cfg.enable_stt             = True
    _cfg.ollama_base_url        = "http://127.0.0.1:11434"
    _cfg.ollama_model           = "llama3.2:3b"
    _cfg.ollama_timeout         = 30
    _cfg.stt_slow_threshold_ms  = 4000
    _cfg.stt_fast_mode          = True
    _cfg.stt_language           = "fr"
    _cfg.stt_device             = "cpu"
    _cfg.stt_compute_type       = "int8"
    _cfg.whisper_model_size     = "tiny"
    _cfg.voice_keep_audio_files = 10
    _cfg.voice_input_path       = Path("/tmp/voice_test_streaming")
    _cfg_mod = types.ModuleType("app.config")
    _cfg_mod.settings = _cfg
    sys.modules["app.config"] = _cfg_mod

# logger stub
if "app.utils.logger" not in sys.modules:
    _log_mod = types.ModuleType("app.utils.logger")
    _log_mod.get_logger = lambda n: MagicMock()
    sys.modules.setdefault("app.utils", types.ModuleType("app.utils"))
    sys.modules["app.utils.logger"] = _log_mod


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_pyttsx3_mock():
    """Crée un mock pyttsx3 engine avec say/runAndWait trackables."""
    mock_engine = MagicMock()
    mock_engine.say = MagicMock()
    mock_engine.runAndWait = MagicMock()
    mock_engine.setProperty = MagicMock()
    pyttsx3_mod = sys.modules["pyttsx3"]
    pyttsx3_mod.init = MagicMock(return_value=mock_engine)
    return mock_engine


def _make_tts_engine():
    """Instancie TTSEngine avec pyttsx3 mocké."""
    mock_pyttsx3 = _make_pyttsx3_mock()
    # Forcer le rechargement pour avoir le mock frais
    if "app.core.tts_engine" in sys.modules:
        del sys.modules["app.core.tts_engine"]
    from app.core.tts_engine import TTSEngine
    engine = TTSEngine()
    engine._mock_pyttsx3 = mock_pyttsx3
    return engine


def _run_queue_in_thread(engine, sentences, timeout=3.0):
    """Remplit une queue, lance speak_sentence_queue en thread, attend."""
    q = queue.Queue()
    for s in sentences:
        q.put(s)
    q.put(None)

    result = {}

    def _run():
        result["ms"] = engine.speak_sentence_queue(q, timeout_total=timeout)

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    t.join(timeout=timeout + 1.0)
    return result.get("ms", -1)


# ═══════════════════════════════════════════════════════════════════════════════
# 1. speak_sentence_queue — lecture séquentielle
# ═══════════════════════════════════════════════════════════════════════════════

class TestSpeakSentenceQueue:
    """speak_sentence_queue() joue chaque phrase via pyttsx3.say()."""

    def setup_method(self):
        self.tts = _make_tts_engine()

    def test_single_sentence_played(self):
        """1 phrase → say() appelé 1 fois avec le bon texte."""
        _run_queue_in_thread(self.tts, ["Bonjour."])
        self.tts._mock_pyttsx3.say.assert_called_once_with("Bonjour.")
        self.tts._mock_pyttsx3.runAndWait.assert_called_once()

    def test_three_sentences_in_order(self):
        """3 phrases → say() appelé 3 fois dans l'ordre."""
        _run_queue_in_thread(self.tts, ["Un.", "Deux.", "Trois."])
        calls = [c.args[0] for c in self.tts._mock_pyttsx3.say.call_args_list]
        assert calls == ["Un.", "Deux.", "Trois."]

    def test_empty_segments_skipped(self):
        """Segments vides ignorés — say() appelé seulement pour les non-vides."""
        _run_queue_in_thread(self.tts, ["", "   ", "Bonjour.", ""])
        self.tts._mock_pyttsx3.say.assert_called_once_with("Bonjour.")

    def test_sentinel_stops_loop(self):
        """None sentinel arrête le thread même si des éléments suivent."""
        q = queue.Queue()
        q.put("Bonjour.")
        q.put(None)  # sentinel
        q.put("Jamais joué.")

        result = {}
        t = threading.Thread(
            target=lambda: result.update(
                {"ms": self.tts.speak_sentence_queue(q, timeout_total=5.0)}
            ),
            daemon=True,
        )
        t.start()
        t.join(timeout=3.0)

        calls = [c.args[0] for c in self.tts._mock_pyttsx3.say.call_args_list]
        assert "Jamais joué." not in calls

    def test_returns_nonnegative_int(self):
        """Retourne un entier >= 0."""
        ms = _run_queue_in_thread(self.tts, ["Test."])
        assert isinstance(ms, int)
        assert ms >= 0

    def test_stop_event_interrupts(self):
        """stop_event arrête le thread proprement."""
        q = queue.Queue()
        started = threading.Event()

        def slow_runAndWait():
            started.set()
            time.sleep(0.3)

        self.tts._mock_pyttsx3.runAndWait.side_effect = slow_runAndWait

        q.put("Phrase lente.")
        q.put("Ne doit pas jouer.")

        def _run():
            self.tts.speak_sentence_queue(q, timeout_total=5.0)

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        started.wait(timeout=1.0)

        self.tts.stop()  # demander arrêt
        q.put(None)      # libérer l'attente queue

        t.join(timeout=2.0)
        assert not t.is_alive(), "Thread TTS doit s'arrêter après stop()"

    def test_tts_disabled_skips_all(self):
        """enable_tts=False → aucune phrase jouée."""
        settings = sys.modules["app.config"].settings
        old = settings.enable_tts
        settings.enable_tts = False
        try:
            _run_queue_in_thread(self.tts, ["Bonjour."])
            self.tts._mock_pyttsx3.say.assert_not_called()
        finally:
            settings.enable_tts = old

    def test_timeout_exits_cleanly(self):
        """Queue vide + timeout court → thread termine proprement."""
        q = queue.Queue()  # jamais de sentinel

        result = {}
        t = threading.Thread(
            target=lambda: result.update(
                {"ms": self.tts.speak_sentence_queue(q, timeout_total=0.1)}
            ),
            daemon=True,
        )
        t.start()
        t.join(timeout=1.0)
        assert not t.is_alive()

    def test_lock_serializes_two_threads(self):
        """Deux threads sur speak_sentence_queue → lecture séquentielle (pas simultanée)."""
        call_order = []
        lock = threading.Lock()

        def recording_say(text):
            with lock:
                call_order.append(text)

        self.tts._mock_pyttsx3.say.side_effect = recording_say

        q1 = queue.Queue()
        q2 = queue.Queue()
        q1.put("Premier."); q1.put(None)
        q2.put("Deuxième."); q2.put(None)

        t1 = threading.Thread(target=self.tts.speak_sentence_queue, args=(q1,), daemon=True)
        t2 = threading.Thread(target=self.tts.speak_sentence_queue, args=(q2,), daemon=True)
        t1.start(); t2.start()
        t1.join(timeout=3.0); t2.join(timeout=3.0)

        assert "Premier." in call_order
        assert "Deuxième." in call_order
        assert len(call_order) == 2  # Pas de double-jeu


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Bridge call_soon_threadsafe : générateur sync → asyncio.Queue
# ═══════════════════════════════════════════════════════════════════════════════

class TestCallSoonThreadsafeBridge:
    """
    Le bridge thread→asyncio doit livrer les tokens dans l'ordre
    et progressivement (pas en bloc après la fin du générateur).
    """

    def test_tokens_delivered_in_order(self):
        """Tokens poussés via call_soon_threadsafe → reçus dans l'ordre."""
        tokens = ["Bon", "jour", " à", " vous"]

        async def run():
            loop = asyncio.get_running_loop()
            tok_q: asyncio.Queue = asyncio.Queue()

            def _push():
                for tok in tokens:
                    loop.call_soon_threadsafe(tok_q.put_nowait, ("tok", tok))
                loop.call_soon_threadsafe(tok_q.put_nowait, ("end", None))

            threading.Thread(target=_push, daemon=True).start()

            received = []
            while True:
                kind, val = await asyncio.wait_for(tok_q.get(), timeout=2.0)
                if kind == "end":
                    break
                received.append(val)
            return received

        result = asyncio.run(run())
        assert result == tokens

    def test_first_token_arrives_incrementally(self):
        """
        Premier token mesuré au PREMIER arrivant (pas après le dernier).
        Avec 4 tokens à 30ms chacun, t_first < t_last - 50ms.
        """
        DELAY = 0.03  # 30ms
        N = 4

        async def run():
            loop = asyncio.get_running_loop()
            tok_q: asyncio.Queue = asyncio.Queue()

            def _push():
                for i in range(N):
                    time.sleep(DELAY)
                    loop.call_soon_threadsafe(tok_q.put_nowait, ("tok", f"t{i}"))
                loop.call_soon_threadsafe(tok_q.put_nowait, ("end", None))

            t0 = time.perf_counter()
            threading.Thread(target=_push, daemon=True).start()

            t_first = None
            count = 0
            while True:
                kind, val = await asyncio.wait_for(tok_q.get(), timeout=5.0)
                if kind == "end":
                    break
                if t_first is None:
                    t_first = time.perf_counter() - t0
                count += 1

            t_last = time.perf_counter() - t0
            return t_first, t_last, count

        first, last, count = asyncio.run(run())
        assert count == N
        assert first is not None
        # Premier token arrive bien AVANT la fin du stream (pas un bloc)
        assert first < last - (DELAY * (N - 2)), (
            f"t_first={first*1000:.0f}ms doit précéder t_last={last*1000:.0f}ms"
        )

    def test_error_in_generator_propagates(self):
        """Erreur dans le thread LLM → event ('err', ...) reçu dans la queue."""
        async def run():
            loop = asyncio.get_running_loop()
            tok_q: asyncio.Queue = asyncio.Queue()

            def _push():
                # Simule le bridge réel : try/except/finally sur un générateur
                # qui lève une exception (Ollama mort, réseau coupé, etc.)
                try:
                    def _bad_gen():
                        raise RuntimeError("Ollama mort")
                        yield  # pragma: no cover
                    for _ in _bad_gen():
                        pass
                except Exception as e:
                    loop.call_soon_threadsafe(tok_q.put_nowait, ("err", str(e)))
                finally:
                    loop.call_soon_threadsafe(tok_q.put_nowait, ("end", None))

            threading.Thread(target=_push, daemon=True).start()

            kinds = []
            while True:
                kind, val = await asyncio.wait_for(tok_q.get(), timeout=2.0)
                kinds.append(kind)
                if kind == "end":
                    break
            return kinds

        kinds = asyncio.run(run())
        assert "err" in kinds

    def test_empty_generator_ends_cleanly(self):
        """Générateur vide → seul event 'end' reçu."""
        async def run():
            loop = asyncio.get_running_loop()
            tok_q: asyncio.Queue = asyncio.Queue()

            def _push():
                loop.call_soon_threadsafe(tok_q.put_nowait, ("end", None))

            threading.Thread(target=_push, daemon=True).start()
            kind, _ = await asyncio.wait_for(tok_q.get(), timeout=2.0)
            return kind

        assert asyncio.run(run()) == "end"


# ═══════════════════════════════════════════════════════════════════════════════
# 3. TTS progressif : phrases envoyées avant la fin du LLM
# ═══════════════════════════════════════════════════════════════════════════════

class TestProgressiveTTS:
    """
    Le TTS progressif doit envoyer chaque phrase à la queue TTS
    dès qu'elle est complète, SANS attendre la fin du stream LLM.
    """

    def _simulate_pipeline(self, tokens, token_delay=0.01):
        """
        Simule la consommation de tokens + segmentation + mise en queue TTS.
        Retourne (tts_put_times, llm_end_time, phrases_sent).
        """
        import re
        _SEG_RE = re.compile(r'[.!?](?:\s|$)')

        def _find_seg(buf, min_chars=4):
            if len(buf) < min_chars:
                return "", buf
            m = _SEG_RE.search(buf)
            if m:
                return buf[:m.end()].strip(), buf[m.end():].strip()
            if len(buf) > 80:
                sp = buf[:80].rfind(" ")
                if sp > 20:
                    return buf[:sp].strip(), buf[sp + 1:]
            return "", buf

        tts_put_times = []
        tts_q = queue.Queue()
        sentence_buf = ""

        for tok in tokens:
            time.sleep(token_delay)
            sentence_buf += tok
            seg, sentence_buf = _find_seg(sentence_buf, min_chars=4)
            if seg:
                tts_put_times.append(time.perf_counter())
                tts_q.put(seg)

        if sentence_buf.strip():
            tts_put_times.append(time.perf_counter())
            tts_q.put(sentence_buf.strip())

        llm_end = time.perf_counter()
        tts_q.put(None)
        return tts_put_times, llm_end, list(tts_q.queue)

    def test_first_phrase_before_llm_end(self):
        """
        La 1ère phrase TTS est mise en queue avant la fin du stream LLM.
        """
        TOKENS = ["Bon", "jour", ".", " Comment", " allez", "-vous", " ?"]
        put_times, llm_end, _ = self._simulate_pipeline(TOKENS, token_delay=0.01)

        assert len(put_times) >= 1, "Au moins une phrase doit être envoyée"
        # La première phrase arrive avant la fin du LLM (ou simultanément)
        assert put_times[0] <= llm_end + 0.005

    def test_two_sentences_both_queued(self):
        """
        "Bonjour. Au revoir." → 2 phrases envoyées au TTS.
        """
        TOKENS = ["Bon", "jour", ".", " Au", " re", "voir", "."]
        put_times, _, phrases = self._simulate_pipeline(TOKENS, token_delay=0.005)
        # Retirer le sentinel None
        phrases_text = [p for p in phrases if p is not None]
        assert len(phrases_text) == 2

    def test_no_punctuation_flushes_buffer(self):
        """
        Sans ponctuation → buffer résiduel flush en fin de stream.
        """
        TOKENS = ["Bonjour", " tout", " le", " monde"]
        put_times, _, phrases = self._simulate_pipeline(TOKENS, token_delay=0.005)
        phrases_text = [p for p in phrases if p is not None]
        assert len(phrases_text) == 1
        assert "Bonjour" in phrases_text[0]

    def test_tts_does_not_wait_for_full_response(self):
        """
        Dans un stream de 6 tokens (3 par phrase), le TTS de la phrase 1
        est déclenché après ~3 tokens, PAS après tous les 6.
        """
        TOKENS = ["Phrase", " un", ".", " Phrase", " deux", "."]
        DELAY = 0.02  # 20ms par token

        t_start = time.perf_counter()
        put_times, llm_end, _ = self._simulate_pipeline(TOKENS, token_delay=DELAY)

        assert len(put_times) >= 2

        # Temps attendu pour avoir 3 tokens (1ère phrase) = ~60ms
        t_first_phrase = put_times[0] - t_start
        # Temps pour tous les 6 tokens = ~120ms
        t_all_tokens = llm_end - t_start

        # La 1ère phrase doit arriver bien avant la fin
        assert t_first_phrase < t_all_tokens * 0.8, (
            f"1ère phrase à {t_first_phrase*1000:.0f}ms, fin LLM à {t_all_tokens*1000:.0f}ms — "
            f"le TTS doit démarrer avant la fin du LLM"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# 4. _find_segment — découpage propre sur . ! ?
# ═══════════════════════════════════════════════════════════════════════════════

class TestFindSegment:
    """Vérifie la fonction _find_segment de app.api.voice."""

    # Modules que ce fixture peut injecter — à restaurer après le test
    _STUBS_TO_RESTORE = [
        "app.core.voice_memory", "app.core.voice_commands",
        "app.core.voice_engine",
    ]

    @pytest.fixture(autouse=True)
    def _setup(self):
        """Import _find_segment depuis le module voice réel."""
        # Sauvegarder l'état actuel pour restauration propre
        _saved = {k: sys.modules.get(k) for k in self._STUBS_TO_RESTORE}

        # Stubs nécessaires pour importer app.api.voice
        for mod in [
            "app.db", "app.db.database", "app.db.models",
            "app.core.voice_memory", "app.core.voice_commands",
            "app.core.voice_engine", "sqlalchemy",
            "sqlalchemy.orm",
        ]:
            sys.modules.setdefault(mod, MagicMock())

        sys.modules["app.db.database"].get_db = MagicMock()

        if "app.api.voice" not in sys.modules:
            import app.api.voice as _v
        else:
            _v = sys.modules["app.api.voice"]
        self.find_seg = _v._find_segment

        yield  # exécution du test

        # Restaurer les modules stubés pour ne pas polluer les tests suivants
        for k, v in _saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v

    def test_period_cut(self):
        seg, rest = self.find_seg("Bonjour. Comment allez-vous ?", min_chars=4)
        assert seg == "Bonjour."
        assert "Comment" in rest

    def test_question_cut(self):
        seg, rest = self.find_seg("Ça va ? Oui.", min_chars=4)
        assert seg == "Ça va ?"

    def test_exclamation_cut(self):
        seg, rest = self.find_seg("Parfait ! Continuons.", min_chars=4)
        assert seg == "Parfait !"

    def test_no_punct_returns_empty(self):
        seg, rest = self.find_seg("Bonjour", min_chars=4)
        assert seg == ""
        assert rest == "Bonjour"

    def test_too_short_returns_empty(self):
        seg, rest = self.find_seg("Hi.", min_chars=4)
        assert seg == ""

    def test_long_no_punct_cuts_at_space(self):
        """> 80 chars sans ponctuation → coupe au dernier espace."""
        long_text = "un deux trois " * 8  # > 80 chars
        seg, rest = self.find_seg(long_text, min_chars=4)
        assert len(seg) > 0

    def test_multiple_sentences_first_only(self):
        seg, rest = self.find_seg("Un. Deux. Trois.", min_chars=4)
        assert seg == "Un."
        assert "Deux" in rest

    def test_empty_string(self):
        seg, rest = self.find_seg("", min_chars=4)
        assert seg == ""
        assert rest == ""


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Pipeline /stream : SSE events + métriques
# ═══════════════════════════════════════════════════════════════════════════════

class TestStreamEndpoint:
    """
    Tests du endpoint /api/voice/stream avec LLM mocké.
    Vérifie les events SSE et les métriques de latence.
    """

    @pytest.fixture(autouse=True)
    def _setup_app(self):
        """
        Construit une app FastAPI minimale avec le router voice.

        Robuste à l'ordre d'exécution des tests :
        - Ne re-importe pas voice si déjà chargé (évite re-init des singletons)
        - Patch WhisperModel avec une vraie classe (pas MagicMock) pour éviter
          InvalidSpecError quand settings est un MagicMock post-209-tests
        - Injecte les mocks directement dans les attributs du module
        """
        # ── 1. Fixer faster_whisper.WhisperModel avec une vraie classe ─────────
        # Évite : InvalidSpecError quand settings.whisper_model_size est MagicMock
        class _FakeWhisperModel:
            def __init__(self, *args, **kwargs):
                pass
            def transcribe(self, *args, **kwargs):
                return [], MagicMock()

        _fw_mod = sys.modules.get("faster_whisper")
        if _fw_mod is None:
            import types as _t
            _fw_mod = _t.ModuleType("faster_whisper")
            sys.modules["faster_whisper"] = _fw_mod
        _fw_mod.WhisperModel = _FakeWhisperModel

        # ── 2. pyttsx3 mock ────────────────────────────────────────────────────
        _make_pyttsx3_mock()

        # ── 3. Stubs DB ────────────────────────────────────────────────────────
        for mod in ["app.db", "app.db.database", "app.db.models",
                    "sqlalchemy", "sqlalchemy.orm"]:
            sys.modules.setdefault(mod, MagicMock())
        sys.modules["app.db.database"].get_db = MagicMock()

        # ── 4. Fixer settings pour que VoiceEngine() ne crashe pas ─────────────
        cfg_mod = sys.modules.get("app.config")
        if cfg_mod is not None:
            s = cfg_mod.settings
            # Forcer les attributs à être des scalaires (pas MagicMock)
            for attr, val in [
                ("whisper_model_size", "tiny"), ("stt_device", "cpu"),
                ("stt_compute_type", "int8"), ("stt_fast_mode", True),
                ("stt_language", "fr"), ("stt_slow_threshold_ms", 4000),
                ("voice_keep_audio_files", 10), ("enable_tts", True),
                ("enable_stt", True),
            ]:
                try:
                    if not isinstance(getattr(s, attr, None), type(val)):
                        setattr(s, attr, val)
                except Exception:
                    pass

        # ── 5. Importer voice_mod (sans re-init si déjà chargé) ───────────────
        # Si app.api.voice est déjà dans sys.modules, on patche ses attributs
        # sans le supprimer — évite re-création des singletons module-level
        if "app.api.voice" not in sys.modules:
            # Premier import : stubs voice_engine/tts_engine/llm au niveau module
            for mod in ["app.core.tts_engine", "app.core.llm",
                        "app.core.voice_engine", "app.core.voice_memory",
                        "app.core.voice_commands"]:
                if mod in sys.modules:
                    del sys.modules[mod]

        import app.api.voice as voice_mod

        # ── 6. Injecter les mocks dans le module chargé ────────────────────────
        mock_tts = MagicMock()
        mock_tts.speak_voice_mode.return_value = 30
        mock_tts._stop_event = threading.Event()
        mock_tts.speak_sentence_queue.return_value = 0

        mock_vm = MagicMock()
        mock_vm.as_messages.return_value = [{"role": "user", "content": "test"}]
        mock_vm.summary.return_value = "empty"
        mock_vm.add = MagicMock()

        mock_vc = MagicMock()
        mock_vc.match_local.return_value = None  # pas de commande locale

        voice_mod.tts_engine   = mock_tts
        voice_mod.voice_memory = mock_vm
        voice_mod.voice_commands = mock_vc
        voice_mod._fallback_idx = 0

        self.voice_mod = voice_mod
        self.mock_tts  = mock_tts

        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        app = FastAPI()
        app.include_router(voice_mod.router)
        self.client = TestClient(app)

    def _post_stream(self, message):
        return self.client.post("/api/voice/stream", json={"message": message})

    def _make_llm(self, tokens):
        m = MagicMock()
        m.model = "test"
        m._model_verified = True
        m.chat_stream.return_value = iter(tokens)
        self.voice_mod._llm = m
        return m

    def test_token_events_emitted(self):
        """Des events 'token' sont émis pour chaque token LLM."""
        self._make_llm(["Très", " bien", "."])
        # Message neutre (pas dans _INSTANT_REPLIES ni _ACK_MAP simple)
        r = self._post_stream("racontez-moi quelque chose")
        token_events = [l for l in r.text.split("\n")
                        if '"t":' in l and "data:" in l]
        assert len(token_events) >= 1

    def test_metrics_event_present(self):
        """L'event 'metrics' est toujours émis avec les champs attendus."""
        self._make_llm(["OK."])
        r = self._post_stream("test")
        assert "metrics" in r.text
        assert "time_to_first_feedback_ms" in r.text
        assert "time_to_first_token_ms" in r.text
        assert "full_turn_total_ms" in r.text

    def test_done_event_present(self):
        """L'event 'done' est toujours émis en fin de stream LLM."""
        self._make_llm(["Très", " bien", "."])
        # Message neutre qui passe par le pipeline LLM complet (pas instant)
        r = self._post_stream("pouvez-vous m'expliquer")
        assert "done" in r.text

    def test_instant_reply_no_llm_call(self):
        """Message de salutation → réponse instantanée, LLM non appelé."""
        mock_llm = MagicMock()
        self.voice_mod._llm = mock_llm
        r = self._post_stream("bonjour")
        mock_llm.chat_stream.assert_not_called()
        assert "instant" in r.text

    def test_empty_message_returns_400(self):
        """Message vide → 400 Bad Request."""
        r = self.client.post("/api/voice/stream", json={"message": ""})
        assert r.status_code == 400

    def test_fallback_on_llm_error(self):
        """Erreur LLM → event fallback émis, pas de 500."""
        mock_llm = MagicMock()
        mock_llm.model = "test"
        mock_llm._model_verified = True
        mock_llm.chat_stream.side_effect = RuntimeError("Ollama mort")
        self.voice_mod._llm = mock_llm

        r = self._post_stream("test erreur LLM")
        assert r.status_code in (200, 500)
        if r.status_code == 200:
            assert "fallback" in r.text or "done" in r.text

    def test_ack_event_before_token_event(self):
        """L'event 'ack' précède les events 'token' dans le stream."""
        self._make_llm(["Très", " bien."])
        r = self._post_stream("je ne sais pas quoi faire")

        lines = r.text.split("\n")
        event_order = []
        for line in lines:
            if line.startswith("event:"):
                event_order.append(line.replace("event:", "").strip())

        # ack doit précéder token (ou instant peut tout bypasser)
        if "ack" in event_order and "token" in event_order:
            assert event_order.index("ack") < event_order.index("token")


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
