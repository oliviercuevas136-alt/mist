"""
tests/test_timeouts.py — Tests de comportement en cas de timeout.

Couvre :
  - LLM chat() timeout → retourne message d'erreur (pas crash)
  - LLM chat_stream() timeout réseau → levée RequestException propagée
  - OllamaClient._ensure_verified() ConnectionError → message d'erreur clair
  - OllamaClient._ensure_verified() modèle absent → message explicite
  - OllamaClient.warmup() offline → retourne ok=False (pas crash)
  - VoiceEngine : fichier trop petit → retour immédiat sans transcription
  - VoiceEngine : ffmpeg timeout → conversion retourne False (pas crash)
  - VoiceEngine : transcription retourne toujours un dict bien formé
  - Pipeline /api/voice/speak : timeout TTS → retourne warning (pas 500)
"""

import json
import sys
import time
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# ---------------------------------------------------------------------------
# Stubs isolés
# ---------------------------------------------------------------------------

def _stub_if_absent(name, obj=None):
    if name not in sys.modules:
        sys.modules[name] = obj or MagicMock()

_stub_if_absent("pyttsx3")
_stub_if_absent("faster_whisper")

# Stub config LLM
_cfg = MagicMock()
_cfg.ollama_base_url = "http://127.0.0.1:11434"
_cfg.ollama_model    = "llama3.2:3b"
_cfg.ollama_timeout  = 5
_cfg.stt_slow_threshold_ms = 4000
_cfg.stt_fast_mode   = True
_cfg.stt_language    = "fr"
_cfg.whisper_model_size = "tiny"
_cfg.stt_device      = "cpu"
_cfg.stt_compute_type = "int8"
_cfg.voice_keep_audio_files = 5
_cfg.voice_input_path = Path("/tmp/voice_test_timeouts")

_cfg_mod = types.ModuleType("app.config")
_cfg_mod.settings = _cfg
sys.modules.setdefault("app.config", _cfg_mod)

_logger_mod = types.ModuleType("app.utils.logger")
_logger_mod.get_logger = lambda n: MagicMock()
sys.modules.setdefault("app.utils", types.ModuleType("app.utils"))
sys.modules.setdefault("app.utils.logger", _logger_mod)


# ===========================================================================
# 1. LLM — timeouts et erreurs réseau
# ===========================================================================

class TestLLMTimeouts:
    """OllamaClient résiste aux timeouts et erreurs réseau."""

    def _client(self, verified=True):
        from app.core.llm import OllamaClient
        c = OllamaClient()
        c._model_verified = verified
        return c

    def test_chat_timeout_returns_string(self):
        """chat() avec Timeout → retourne une chaîne lisible, pas une exception."""
        import requests
        c = self._client()
        with patch("requests.post", side_effect=requests.exceptions.Timeout()):
            result = c.chat([{"role": "user", "content": "bonjour"}])
        assert isinstance(result, str)
        assert len(result) > 0

    def test_chat_timeout_message_readable(self):
        """Le message de timeout est compréhensible (contient 'timeout' ou le délai)."""
        import requests
        c = self._client()
        with patch("requests.post", side_effect=requests.exceptions.Timeout()):
            result = c.chat([{"role": "user", "content": "bonjour"}])
        assert "timeout" in result.lower() or str(c.timeout) in result

    def test_chat_connection_error_returns_string(self):
        """chat() avec ConnectionError → retourne chaîne, pas exception."""
        import requests
        c = self._client(verified=False)
        with patch("requests.get", side_effect=requests.exceptions.ConnectionError()):
            result = c.chat([{"role": "user", "content": "bonjour"}])
        assert isinstance(result, str)
        assert len(result) > 0

    def test_chat_connection_error_message_mentions_ollama(self):
        """Le message d'erreur de connexion mentionne Ollama."""
        import requests
        c = self._client(verified=False)
        with patch("requests.get", side_effect=requests.exceptions.ConnectionError()):
            result = c.chat([{"role": "user", "content": "bonjour"}])
        assert "ollama" in result.lower() or "indisponible" in result.lower()

    def test_chat_unexpected_exception_returns_string(self):
        """chat() avec exception inattendue → retourne chaîne (pas re-raise)."""
        c = self._client()
        with patch("requests.post", side_effect=RuntimeError("Erreur bizarre")):
            result = c.chat([{"role": "user", "content": "bonjour"}])
        assert isinstance(result, str)

    def test_chat_http_404_fallback_generate(self):
        """chat() reçoit 404 → essaie /api/generate en fallback."""
        import requests

        c = self._client()

        # Premier appel /api/chat → 404
        mock_404 = MagicMock()
        mock_404.status_code = 404
        http_err = requests.exceptions.HTTPError(response=mock_404)
        mock_404.raise_for_status.side_effect = http_err

        # Fallback /api/generate → succès
        mock_ok = MagicMock()
        mock_ok.json.return_value = {"response": "Réponse de secours"}
        mock_ok.raise_for_status = MagicMock()

        call_count = {"n": 0}

        def fake_post(url, **kw):
            call_count["n"] += 1
            if "/api/chat" in url:
                return mock_404
            return mock_ok

        with patch("requests.post", side_effect=fake_post):
            result = c.chat([{"role": "user", "content": "test"}])

        assert result == "Réponse de secours"

    def test_chat_stream_raises_on_connection_error(self):
        """chat_stream() avec connexion impossible → lève RuntimeError (ensure_verified)."""
        import requests
        c = self._client(verified=False)
        with patch("requests.get", side_effect=requests.exceptions.ConnectionError()):
            with pytest.raises(RuntimeError):
                list(c.chat_stream([{"role": "user", "content": "test"}]))

    def test_ensure_verified_model_absent_message(self):
        """_ensure_verified() modèle absent → message explicite avec 'ollama pull'."""
        import requests
        c = self._client(verified=False)

        # GET /api/tags → OK mais modèle absent
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"models": [{"name": "mistral:7b"}]}

        with patch("requests.get", return_value=mock_resp):
            err = c._ensure_verified()

        assert err is not None
        assert "ollama pull" in err.lower() or "pull" in err.lower()

    def test_warmup_offline_returns_ok_false(self):
        """warmup() Ollama offline → retourne ok=False (pas de crash)."""
        import requests
        c = self._client()
        with patch("requests.post", side_effect=requests.exceptions.ConnectionError()):
            result = c.warmup()
        assert result["ok"] is False
        assert "warmup_ms" in result
        assert "error" in result

    def test_warmup_always_returns_dict(self):
        """warmup() retourne toujours un dict, quelle que soit l'erreur."""
        c = self._client()
        with patch("requests.post", side_effect=Exception("Erreur critique")):
            result = c.warmup()
        assert isinstance(result, dict)
        assert "ok" in result


# ===========================================================================
# 2. VoiceEngine — limites et timeouts
# ===========================================================================

class TestVoiceEngineTimeouts:
    """VoiceEngine résiste aux fichiers invalides et aux erreurs ffmpeg."""

    def _make_engine(self):
        """Construit un VoiceEngine avec Whisper mocké."""
        stub_cfg = MagicMock()
        stub_cfg.whisper_model_size = "tiny"
        stub_cfg.stt_device         = "cpu"
        stub_cfg.stt_compute_type   = "int8"
        stub_cfg.stt_language       = "fr"
        stub_cfg.stt_fast_mode      = True
        stub_cfg.stt_slow_threshold_ms = 4000
        stub_cfg.voice_keep_audio_files = 5
        stub_cfg.voice_input_path   = Path("/tmp/voice_test_timeouts")

        cfg_mod = types.ModuleType("app.config")
        cfg_mod.settings = stub_cfg
        sys.modules["app.config"] = cfg_mod

        from app.core.voice_engine import VoiceEngine
        engine = VoiceEngine()
        return engine

    def test_file_too_small_returns_immediately(self):
        """Fichier < 500 octets → retour immédiat sans appel Whisper."""
        engine = self._make_engine()
        t0 = time.perf_counter()
        result = engine.transcribe_bytes(b"x" * 100, "tiny.webm")
        elapsed = time.perf_counter() - t0

        assert result["is_empty"] is True
        assert result["text"] == ""
        assert elapsed < 0.1, f"Retour trop lent pour fichier trop petit: {elapsed:.3f}s"

    def test_file_too_small_stt_time_zero(self):
        """Fichier < 500 octets → stt_time_ms == 0 (pas de traitement)."""
        engine = self._make_engine()
        result = engine.transcribe_bytes(b"x" * 499, "tiny.webm")
        assert result["stt_time_ms"] == 0

    def test_file_size_reported_correctly(self):
        """file_size dans le résultat correspond à la taille réelle."""
        engine = self._make_engine()
        data = b"x" * 200
        result = engine.transcribe_bytes(data, "test.webm")
        assert result["file_size"] == len(data)

    def test_transcribe_returns_dict_always(self):
        """transcribe_bytes retourne toujours un dict avec les clés attendues."""
        engine = self._make_engine()
        result = engine.transcribe_bytes(b"x" * 50, "test.webm")
        for key in ("text", "is_empty", "file_size", "stt_time_ms"):
            assert key in result, f"Clé manquante : {key}"

    def test_ffmpeg_timeout_returns_false(self):
        """Si ffmpeg timeout → _convert_to_wav retourne False (non bloquant)."""
        import subprocess
        from app.core.voice_engine import _convert_to_wav

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("ffmpeg", 10)):
            result = _convert_to_wav(Path("/tmp/test.webm"), Path("/tmp/test.wav"))
        assert result is False

    def test_ffmpeg_absent_returns_false(self):
        """Si ffmpeg absent (FileNotFoundError) → _convert_to_wav retourne False."""
        from app.core.voice_engine import _convert_to_wav

        with patch("subprocess.run", side_effect=FileNotFoundError("ffmpeg not found")):
            result = _convert_to_wav(Path("/tmp/test.webm"), Path("/tmp/test.wav"))
        assert result is False

    def test_ffmpeg_generic_error_returns_false(self):
        """Toute erreur ffmpeg → _convert_to_wav retourne False (non bloquant)."""
        from app.core.voice_engine import _convert_to_wav

        with patch("subprocess.run", side_effect=Exception("Erreur inconnue")):
            result = _convert_to_wav(Path("/tmp/test.webm"), Path("/tmp/test.wav"))
        assert result is False

    def test_transcribe_bytes_empty_data_safe(self):
        """transcribe_bytes(b'') ne lève pas d'exception."""
        engine = self._make_engine()
        result = engine.transcribe_bytes(b"", "empty.webm")
        assert result["is_empty"] is True


# ===========================================================================
# 3. API /api/voice/speak — timeout TTS
# ===========================================================================

class TestSpeakEndpointTimeout:
    """L'endpoint /speak retourne une réponse HTTP même si TTS timeout."""

    @pytest.fixture
    def speak_client(self):
        """
        Mini app pour /speak.
        app.api.voice dépend de app.db.database — on le stub avant import.
        """
        import os
        import types as _types
        os.makedirs("data", exist_ok=True)

        # Stub app.db.database si pas encore importé (évite create_engine avec mock settings)
        if "app.db.database" not in sys.modules:
            db_stub = _types.ModuleType("app.db.database")
            db_stub.get_db = MagicMock()
            db_stub.SessionLocal = MagicMock()
            db_stub.Base = MagicMock()
            sys.modules["app.db.database"] = db_stub

        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        tts_stub = MagicMock()
        tts_stub.speak_voice_mode = MagicMock(return_value=100)
        tts_stub.stop = MagicMock()
        voice_stub = MagicMock()
        vm_stub = MagicMock()
        vm_stub.as_messages = MagicMock(return_value=[
            {"role": "system", "content": "Tu es un assistant"},
            {"role": "user", "content": "test"},
        ])
        vm_stub.summary = MagicMock(return_value="Mémoire: 0 échanges")

        mini = FastAPI()

        import app.api.voice as voice_mod
        _orig_tts = voice_mod.tts_engine
        _orig_ve  = voice_mod.voice_engine
        _orig_vm  = voice_mod.voice_memory

        voice_mod.tts_engine   = tts_stub
        voice_mod.voice_engine = voice_stub
        voice_mod.voice_memory = vm_stub

        mini.include_router(voice_mod.router)

        with TestClient(mini, raise_server_exceptions=False) as c:
            yield c, tts_stub

        voice_mod.tts_engine   = _orig_tts
        voice_mod.voice_engine = _orig_ve
        voice_mod.voice_memory = _orig_vm

    def test_speak_normal_returns_200(self, speak_client):
        """POST /api/voice/speak normal → 200."""
        c, _ = speak_client
        resp = c.post("/api/voice/speak", json={"text": "Bonjour"})
        assert resp.status_code == 200

    def test_speak_empty_text_returns_200(self, speak_client):
        """POST /api/voice/speak texte vide → 200 (pas de crash)."""
        c, _ = speak_client
        resp = c.post("/api/voice/speak", json={"text": ""})
        assert resp.status_code == 200
        data = resp.json()
        assert data["spoken"] is False

    def test_speak_tts_timeout_returns_warning(self, speak_client):
        """POST /api/voice/speak avec TTS timeout → 200 avec warning (pas 500)."""
        import asyncio
        c, tts = speak_client
        tts.speak_voice_mode.side_effect = asyncio.TimeoutError()
        resp = c.post("/api/voice/speak", json={"text": "test timeout"})
        # Doit retourner 200 avec spoken=False ou warning, jamais 500
        assert resp.status_code == 200

    def test_speak_tts_exception_returns_500_or_warning(self, speak_client):
        """POST /api/voice/speak avec exception TTS → réponse HTTP (pas de crash serveur)."""
        c, tts = speak_client
        tts.speak_voice_mode.side_effect = RuntimeError("TTS crash")
        resp = c.post("/api/voice/speak", json={"text": "test crash"})
        # 200 ou 500 mais HTTP valide (pas de crash uvicorn)
        assert resp.status_code in (200, 500)

    def test_speak_long_text_truncated(self, speak_client):
        """Texte > 500 chars → tronqué (protection contre textes infinis)."""
        c, tts = speak_client
        long_text = "A" * 1000
        resp = c.post("/api/voice/speak", json={"text": long_text})
        assert resp.status_code == 200
        # Le TTS n'aurait dû recevoir qu'au plus 500 chars
        if tts.speak_voice_mode.called:
            called_text = tts.speak_voice_mode.call_args[0][0]
            assert len(called_text) <= 500


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
