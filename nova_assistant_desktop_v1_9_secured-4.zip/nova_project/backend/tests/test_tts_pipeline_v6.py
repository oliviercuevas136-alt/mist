"""
tests/test_tts_pipeline_v6.py — Suite de tests v4.6 (30 tests)

Couvre :
  1. TestSmartSegmentation   — _find_segment : max_chars, comma fallback, ellipse (8)
  2. TestStopImmediate        — stop() appelle engine.stop(), VOICE_INTERRUPTED      (6)
  3. TestNewLogEvents         — 4 nouveaux logs VOICE_SEGMENT_*                      (8)
  4. TestRequestCounter       — compteur requêtes, stop sur 2e requête               (4)
  5. TestMaxCharsEdgeCases    — max_chars=140 vs 80, transition douce                (4)

Isolation : mêmes patterns que test_streaming_pipeline.py
  - _stub_if_absent()
  - _make_pyttsx3_mock() / _make_tts_engine()
  - Sauvegarde + restauration des modules stubés
"""
from __future__ import annotations

import queue
import sys
import threading
import time
import types
from pathlib import Path
from queue import Queue
from threading import Event
from typing import Any
from unittest.mock import MagicMock, call, patch

import pytest

# ── Stubs de bas niveau (avant tout import applicatif) ────────────────────────

def _stub_if_absent(name: str, obj: Any = None) -> None:
    if name not in sys.modules:
        sys.modules[name] = obj or MagicMock()


_stub_if_absent("pyttsx3")
_stub_if_absent("faster_whisper")

# pydantic_settings léger
if "pydantic_settings" not in sys.modules:
    _ps = types.ModuleType("pydantic_settings")

    class _BaseSettings:
        model_config = {}
        def __init__(self, **kw):
            for k, v in kw.items():
                setattr(self, k, v)

    _ps.BaseSettings = _BaseSettings
    _ps.SettingsConfigDict = dict
    sys.modules["pydantic_settings"] = _ps

# app.config stub
if "app.config" not in sys.modules:
    _cfg = MagicMock()
    _cfg.enable_tts             = True
    _cfg.enable_stt             = True
    _cfg.ollama_base_url        = "http://127.0.0.1:11434"
    _cfg.ollama_model           = "llama3.2:3b"
    _cfg.ollama_timeout         = 30
    _cfg.stt_slow_threshold_ms  = 4000
    _cfg.stt_fast_mode          = True
    _cfg.stt_language           = "fr"
    _cfg.stt_device             = "cpu"
    _cfg.stt_compute_type       = "int8"
    _cfg.whisper_model_size     = "tiny"
    _cfg.voice_keep_audio_files = 10
    _cfg.voice_input_path       = Path("/tmp/voice_test_v6")
    _cfg_mod = types.ModuleType("app.config")
    _cfg_mod.settings = _cfg
    sys.modules["app.config"] = _cfg_mod

# logger stub
if "app.utils.logger" not in sys.modules:
    _log_mod = types.ModuleType("app.utils.logger")
    _log_mod.get_logger = lambda n: MagicMock()
    sys.modules.setdefault("app.utils", types.ModuleType("app.utils"))
    sys.modules["app.utils.logger"] = _log_mod

# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_pyttsx3_mock():
    """Crée un mock pyttsx3 engine avec say/runAndWait/stop trackables."""
    mock_engine = MagicMock()
    mock_engine.say         = MagicMock()
    mock_engine.runAndWait  = MagicMock()
    mock_engine.setProperty = MagicMock()
    mock_engine.stop        = MagicMock()
    pyttsx3_mod = sys.modules["pyttsx3"]
    pyttsx3_mod.init = MagicMock(return_value=mock_engine)
    return mock_engine


def _make_tts_engine():
    """Instancie TTSEngine avec pyttsx3 mocké (réimport forcé)."""
    mock_pyttsx3 = _make_pyttsx3_mock()
    if "app.core.tts_engine" in sys.modules:
        del sys.modules["app.core.tts_engine"]
    from app.core.tts_engine import TTSEngine
    engine = TTSEngine()
    engine._mock_pyttsx3 = mock_pyttsx3
    return engine


# ─ Stubs partagés pour voice.py ──────────────────────────────────────────────
_VOICE_SIDE_STUBS = [
    "app.db", "app.db.database", "app.db.models",
    "app.core.voice_memory", "app.core.voice_commands",
    "app.core.voice_engine", "sqlalchemy", "sqlalchemy.orm",
]

_VOICE_RESTORE_STUBS = [
    "app.core.voice_memory", "app.core.voice_commands",
    "app.core.voice_engine",
]


def _setup_voice_stubs():
    saved = {k: sys.modules.get(k) for k in _VOICE_RESTORE_STUBS}
    for mod in _VOICE_SIDE_STUBS:
        sys.modules.setdefault(mod, MagicMock())
    sys.modules["app.db.database"].get_db = MagicMock()
    return saved


def _teardown_voice_stubs(saved):
    for k, v in saved.items():
        if v is None:
            sys.modules.pop(k, None)
        else:
            sys.modules[k] = v


def _get_voice_module():
    if "app.api.voice" not in sys.modules:
        import app.api.voice as _v  # noqa: F401
    return sys.modules["app.api.voice"]


# ═══════════════════════════════════════════════════════════════════════════════
# 1. TestSmartSegmentation — _find_segment avec max_chars + comma fallback + …
# ═══════════════════════════════════════════════════════════════════════════════

class TestSmartSegmentation:
    """_find_segment v4.6 : max_chars param, comma fallback, ellipse."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        saved = _setup_voice_stubs()
        _v = _get_voice_module()
        self.find_seg = _v._find_segment
        yield
        _teardown_voice_stubs(saved)

    # ── backward compat ───────────────────────────────────────────────────────

    def test_period_still_splits(self):
        """v4.6 ne casse pas la séparation sur point."""
        seg, rest = self.find_seg("Bonjour. Comment allez-vous ?", min_chars=4)
        assert seg == "Bonjour."
        assert "Comment" in rest

    def test_default_max_80_still_cuts_long_text(self):
        """Appel sans max_chars → défaut=80 → coupe texte 100 chars."""
        text = "a " * 50  # 100 chars
        seg, rest = self.find_seg(text, min_chars=4)
        assert len(seg) > 0, "doit couper avec défaut=80 sur texte de 100 chars"

    # ── ellipse ───────────────────────────────────────────────────────────────

    def test_ellipsis_char_triggers_split(self):
        """Le caractère … (U+2026) déclenche une coupe."""
        seg, rest = self.find_seg("Je réfléchis… Donnez-moi un instant.", min_chars=4)
        assert "réfléchis" in seg
        # le segment s'arrête à la position de la coupe
        assert len(seg) < len("Je réfléchis… Donnez-moi un instant.")

    def test_three_dots_via_regex_space(self):
        """'.' seul suivi d'espace déclenche coupe (unchanged)."""
        seg, rest = self.find_seg("Oui. Non.", min_chars=4)
        assert seg == "Oui."

    # ── max_chars configurable ────────────────────────────────────────────────

    def test_max_chars_140_no_cut_at_100_chars(self):
        """100 chars sans ponctuation → PAS de coupe avec max_chars=140."""
        text = "x " * 50  # 100 chars (< 140)
        seg, rest = self.find_seg(text, min_chars=4, max_chars=140)
        assert seg == "", f"ne doit pas couper < 140 chars, seg={seg!r}"

    def test_max_chars_140_cuts_at_150_chars(self):
        """150 chars sans ponctuation → coupe avec max_chars=140."""
        text = "un deux " * 19  # 152 chars
        seg, rest = self.find_seg(text, min_chars=4, max_chars=140)
        assert len(seg) > 0, "doit couper à 140 chars"
        assert len(seg) <= 140

    # ── comma fallback ────────────────────────────────────────────────────────

    def test_comma_fallback_before_max_chars(self):
        """Virgule dans la 2ème moitié de la fenêtre → coupe à la virgule."""
        # 'abc' * 30 = 90 chars, virgule à la position 60 → dans [max_chars//3, max_chars]
        text = "a" * 30 + ", " + "b" * 50
        seg, rest = self.find_seg(text, min_chars=4, max_chars=80)
        # La virgule est à pos 30, max_chars//3 = 26 → 30 > 26 → coupe à la virgule
        assert "," not in seg or seg.endswith(",") is False  # virgule supprimée du segment
        assert len(seg) > 0

    def test_comma_fallback_beats_space_fallback(self):
        """Si virgule disponible, on coupe à la virgule plutôt qu'à l'espace."""
        # Texte 90 chars : mot+virgule à mi-chemin
        text = "mot " * 10 + ", " + "autre " * 10  # ~72 chars + ", " + 60 chars
        full = text[:100]
        seg, rest = self.find_seg(full, min_chars=4, max_chars=80)
        if "," in full[:80]:
            # La coupe devrait être à la virgule ou à l'espace
            assert len(seg) > 0


# ═══════════════════════════════════════════════════════════════════════════════
# 2. TestStopImmediate — stop() appelle engine.stop() + log VOICE_INTERRUPTED
# ═══════════════════════════════════════════════════════════════════════════════

class TestStopImmediate:
    """stop() v4.6 : engine.stop() appelé + log VOICE_INTERRUPTED."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        self.tts = _make_tts_engine()

    def test_stop_sets_stop_event(self):
        self.tts.stop()
        assert self.tts._stop_event.is_set()

    def test_stop_calls_engine_stop(self):
        """Nouveau v4.6 : engine.stop() doit être appelé pour interrompre runAndWait."""
        self.tts.stop()
        self.tts._mock_pyttsx3.stop.assert_called_once()

    def test_stop_graceful_when_engine_none(self):
        """stop() ne doit pas crasher si engine est None."""
        self.tts.engine = None
        try:
            self.tts.stop()
        except Exception as e:
            pytest.fail(f"stop() avec engine=None a levé: {e}")

    def test_stop_graceful_when_engine_stop_raises(self):
        """stop() continue même si engine.stop() lève une exception."""
        self.tts._mock_pyttsx3.stop.side_effect = RuntimeError("pyttsx3 busy")
        try:
            self.tts.stop()
        except Exception as e:
            pytest.fail(f"stop() ne doit pas propager l'erreur: {e}")
        # _stop_event quand même levé
        assert self.tts._stop_event.is_set()

    def test_stop_logs_voice_interrupted(self):
        """stop() logue [VOICE_INTERRUPTED]."""
        import app.core.tts_engine as _tts_mod
        log_calls: list[str] = []
        mock_logger = MagicMock()
        mock_logger.info.side_effect = lambda msg, *a: log_calls.append(
            msg % a if a else msg
        )
        original_logger = _tts_mod.logger
        _tts_mod.logger = mock_logger
        try:
            self.tts.stop()
        finally:
            _tts_mod.logger = original_logger

        assert any("VOICE_INTERRUPTED" in m for m in log_calls), \
            f"VOICE_INTERRUPTED non trouvé dans les logs: {log_calls}"

    def test_stop_idempotent(self):
        """Appels multiples à stop() ne crashent pas."""
        for _ in range(3):
            self.tts.stop()
        assert self.tts._stop_event.is_set()


# ═══════════════════════════════════════════════════════════════════════════════
# 3. TestNewLogEvents — VOICE_SEGMENT_READY, VOICE_SPOKEN, VOICE_INTERRUPTED,
#                       VOICE_QUEUE_SIZE
# ═══════════════════════════════════════════════════════════════════════════════

class TestNewLogEvents:
    """Vérifie l'émission des 4 nouveaux logs structurés."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        self.tts = _make_tts_engine()

    def _capture_tts_logs(self) -> list[str]:
        """Retourne un log_calls partagé + patche le logger du module tts_engine."""
        import app.core.tts_engine as _tts_mod
        log_calls: list[str] = []
        mock_logger = MagicMock()

        def _record(msg, *a):
            log_calls.append(msg % a if a else msg)

        mock_logger.info.side_effect    = _record
        mock_logger.warning.side_effect = _record
        mock_logger.debug.side_effect   = _record
        mock_logger.error.side_effect   = _record
        return log_calls, mock_logger, _tts_mod

    # ── VOICE_SEGMENT_SPOKEN ─────────────────────────────────────────────────

    def test_voice_segment_spoken_logged(self):
        """VOICE_SEGMENT_SPOKEN est loggé après chaque segment joué."""
        log_calls, mock_logger, _tts_mod = self._capture_tts_logs()
        original_logger = _tts_mod.logger
        _tts_mod.logger = mock_logger

        try:
            tts_q: Queue = Queue()
            tts_q.put("Bonjour !")
            tts_q.put(None)
            self.tts.speak_sentence_queue(tts_q)
        finally:
            _tts_mod.logger = original_logger

        assert any("VOICE_SEGMENT_SPOKEN" in m for m in log_calls), \
            f"VOICE_SEGMENT_SPOKEN manquant: {log_calls}"

    def test_voice_segment_spoken_once_per_segment(self):
        """VOICE_SEGMENT_SPOKEN est loggé une fois par segment."""
        log_calls, mock_logger, _tts_mod = self._capture_tts_logs()
        original_logger = _tts_mod.logger
        _tts_mod.logger = mock_logger

        try:
            tts_q: Queue = Queue()
            tts_q.put("Phrase un.")
            tts_q.put("Phrase deux.")
            tts_q.put(None)
            self.tts.speak_sentence_queue(tts_q)
        finally:
            _tts_mod.logger = original_logger

        spoken_count = sum(1 for m in log_calls if "VOICE_SEGMENT_SPOKEN" in m)
        assert spoken_count == 2, f"Attendu 2 VOICE_SEGMENT_SPOKEN, eu {spoken_count}"

    def test_voice_segment_spoken_contains_seg_ms(self):
        """VOICE_SEGMENT_SPOKEN contient seg_ms."""
        log_calls, mock_logger, _tts_mod = self._capture_tts_logs()
        original_logger = _tts_mod.logger
        _tts_mod.logger = mock_logger

        try:
            tts_q: Queue = Queue()
            tts_q.put("Test timing.")
            tts_q.put(None)
            self.tts.speak_sentence_queue(tts_q)
        finally:
            _tts_mod.logger = original_logger

        spoken_logs = [m for m in log_calls if "VOICE_SEGMENT_SPOKEN" in m]
        assert len(spoken_logs) >= 1
        assert "seg_ms=" in spoken_logs[0], f"seg_ms manquant: {spoken_logs[0]}"

    # ── VOICE_INTERRUPTED dans queue loop ────────────────────────────────────

    def test_voice_interrupted_logged_on_stop_event(self):
        """VOICE_INTERRUPTED est loggé dans la boucle queue quand stop_event set après lock."""
        import app.core.tts_engine as _tts_mod
        log_calls: list[str] = []
        mock_logger = MagicMock()

        def _rec(msg, *a):
            log_calls.append(msg % a if a else msg)

        mock_logger.info.side_effect    = _rec
        mock_logger.warning.side_effect = _rec
        mock_logger.debug.side_effect   = _rec

        original_logger = _tts_mod.logger
        _tts_mod.logger = mock_logger

        try:
            # runAndWait() pour le 1er segment → set stop_event
            # Le 2ème segment sera récupéré, lock acquis, puis inner check → VOICE_INTERRUPTED
            call_count = [0]

            def _runAndWait_side_effect():
                call_count[0] += 1
                if call_count[0] == 1:
                    self.tts._stop_event.set()  # set pendant runAndWait du 1er seg

            self.tts._mock_pyttsx3.runAndWait.side_effect = _runAndWait_side_effect

            tts_q: Queue = Queue()
            tts_q.put("Phrase un.")
            tts_q.put("Phrase deux.")
            tts_q.put(None)
            self.tts.speak_sentence_queue(tts_q)
        finally:
            _tts_mod.logger = original_logger

        # Le chemin VOICE_INTERRUPTED est déclenché :
        # soit par stop() (si stop() est appelé) soit par inner check (stop_event dans try block)
        has_interrupted = any("VOICE_INTERRUPTED" in m for m in log_calls)
        assert has_interrupted, (
            f"VOICE_INTERRUPTED non trouvé dans les logs:\n  " +
            "\n  ".join(log_calls)
        )

    # ── _current_seg ─────────────────────────────────────────────────────────

    def test_current_seg_set_during_speak(self):
        """_current_seg est mis à jour pendant la lecture."""
        spoken_segs: list[str] = []
        original_runAndWait = self.tts._mock_pyttsx3.runAndWait

        def _track_runAndWait():
            spoken_segs.append(self.tts._current_seg)

        self.tts._mock_pyttsx3.runAndWait.side_effect = _track_runAndWait

        tts_q: Queue = Queue()
        tts_q.put("Vérification segment actuel.")
        tts_q.put(None)
        self.tts.speak_sentence_queue(tts_q)

        assert len(spoken_segs) == 1
        assert "Vérification" in spoken_segs[0]

    def test_current_seg_cleared_after_speak(self):
        """_current_seg est vidé après lecture."""
        tts_q: Queue = Queue()
        tts_q.put("Phrase test.")
        tts_q.put(None)
        self.tts.speak_sentence_queue(tts_q)
        assert self.tts._current_seg == ""

    # ── VOICE_SEGMENT_READY et VOICE_QUEUE_SIZE (voice.py) ───────────────────

    def test_voice_segment_ready_constant_exists(self):
        """La constante _SEGMENT_MAX_CHARS existe dans voice.py."""
        saved = _setup_voice_stubs()
        try:
            _v = _get_voice_module()
            assert hasattr(_v, "_SEGMENT_MAX_CHARS"), \
                "_SEGMENT_MAX_CHARS manquant dans voice.py"
            assert _v._SEGMENT_MAX_CHARS == 140
        finally:
            _teardown_voice_stubs(saved)

    def test_request_counter_attribute_exists(self):
        """_request_counter et _request_counter_lock existent dans voice.py."""
        saved = _setup_voice_stubs()
        try:
            _v = _get_voice_module()
            assert hasattr(_v, "_request_counter"), "_request_counter manquant"
            assert hasattr(_v, "_request_counter_lock"), "_request_counter_lock manquant"
        finally:
            _teardown_voice_stubs(saved)


# ═══════════════════════════════════════════════════════════════════════════════
# 4. TestRequestCounter — compteur + stop() sur 2e requête
# ═══════════════════════════════════════════════════════════════════════════════

class TestRequestCounter:
    """v4.6 : compteur de requêtes + interruption automatique."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        saved = _setup_voice_stubs()
        self._v = _get_voice_module()
        # Reset counter avant chaque test
        self._v._request_counter = 0
        yield
        # Reset après
        self._v._request_counter = 0
        _teardown_voice_stubs(saved)

    def test_counter_increments_per_call(self):
        """_request_counter s'incrémente à chaque appel simulé."""
        _v = self._v
        initial = _v._request_counter
        with _v._request_counter_lock:
            _v._request_counter += 1
        assert _v._request_counter == initial + 1

    def test_counter_increments_thread_safe(self):
        """Incrément thread-safe depuis plusieurs threads."""
        _v = self._v
        _v._request_counter = 0
        results: list[int] = []

        def _inc():
            with _v._request_counter_lock:
                _v._request_counter += 1
                results.append(_v._request_counter)

        threads = [threading.Thread(target=_inc) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=2.0)

        assert _v._request_counter == 10
        assert len(set(results)) == 10  # toutes les valeurs uniques

    def test_stop_called_on_second_request(self):
        """Quand req_num > 1, tts_engine.stop() doit être appelé."""
        _v = self._v
        mock_tts = MagicMock()
        original_tts = _v.tts_engine
        _v.tts_engine = mock_tts

        try:
            # Simuler la logique du début de generate()
            _v._request_counter = 5  # déjà > 1
            with _v._request_counter_lock:
                _v._request_counter += 1
                req_num = _v._request_counter
            if req_num > 1:
                mock_tts.stop()
                mock_tts._stop_event = MagicMock()
                mock_tts._stop_event.clear()

            mock_tts.stop.assert_called()
        finally:
            _v.tts_engine = original_tts

    def test_no_stop_on_first_request(self):
        """Première requête (req_num == 1) → pas d'appel à tts_engine.stop()."""
        _v = self._v
        mock_tts = MagicMock()
        original_tts = _v.tts_engine
        _v.tts_engine = mock_tts

        try:
            _v._request_counter = 0
            with _v._request_counter_lock:
                _v._request_counter += 1
                req_num = _v._request_counter
            if req_num > 1:
                mock_tts.stop()

            mock_tts.stop.assert_not_called()
        finally:
            _v.tts_engine = original_tts


# ═══════════════════════════════════════════════════════════════════════════════
# 5. TestMaxCharsEdgeCases — comportements limites de _find_segment v4.6
# ═══════════════════════════════════════════════════════════════════════════════

class TestMaxCharsEdgeCases:
    """Cas limites de _find_segment avec max_chars."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        saved = _setup_voice_stubs()
        _v = _get_voice_module()
        self.find_seg = _v._find_segment
        yield
        _teardown_voice_stubs(saved)

    def test_exactly_at_max_chars_boundary(self):
        """Texte exactement max_chars sans ponctuation → pas de coupe."""
        text = "a " * 40  # 80 chars exactement
        seg, rest = self.find_seg(text, min_chars=4, max_chars=80)
        # len == 80 → pas > max_chars → pas de coupe
        assert seg == ""

    def test_one_char_over_max_triggers_cut(self):
        """Texte de max_chars+1 → coupe."""
        text = "mot " * 21  # 84 chars > 80
        seg, rest = self.find_seg(text, min_chars=4, max_chars=80)
        assert len(seg) > 0

    def test_comma_not_in_first_third_no_comma_fallback(self):
        """Virgule dans le premier tiers → on ignore et on coupe à l'espace."""
        # max_chars=90, max_chars//3=30 → virgule à pos 10 ne déclenche PAS comma fallback
        text = "ab," + "x " * 44  # virgule en pos 2 (< 30) → ignorée
        seg, rest = self.find_seg(text, min_chars=4, max_chars=90)
        if len(text) > 90:
            assert len(seg) > 0  # coupe à l'espace
            # seg ne doit pas finir à la virgule en pos 2
            assert len(seg) > 5

    def test_segment_max_chars_value_in_voice_module(self):
        """_SEGMENT_MAX_CHARS == 140 dans voice.py."""
        saved = _setup_voice_stubs()
        try:
            _v = _get_voice_module()
            assert _v._SEGMENT_MAX_CHARS == 140, \
                f"Attendu 140, eu {_v._SEGMENT_MAX_CHARS}"
        finally:
            _teardown_voice_stubs(saved)
