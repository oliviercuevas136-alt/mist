"""
Tests unitaires pour la couche voix.
Isolés de faster_whisper, pyttsx3 et pydantic_settings via sys.modules mocking.
"""
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


# ---------------------------------------------------------------------------
# Stubs d'isolation — injectés avant tout import des modules testés
# ---------------------------------------------------------------------------

def _stub_faster_whisper():
    mod = types.ModuleType("faster_whisper")
    mod.WhisperModel = MagicMock
    sys.modules["faster_whisper"] = mod


def _stub_pydantic_settings():
    mod = types.ModuleType("pydantic_settings")

    class _Base:
        model_config = {}
        def __init__(self, **kw):
            for k, v in kw.items():
                setattr(self, k, v)

    mod.BaseSettings = _Base
    mod.SettingsConfigDict = dict
    sys.modules["pydantic_settings"] = mod


def _stub_pyttsx3():
    mod = types.ModuleType("pyttsx3")
    mod.init = MagicMock(return_value=MagicMock())
    sys.modules["pyttsx3"] = mod


def _make_settings_stub():
    """Settings minimal sans pydantic_settings."""
    from pathlib import Path as P
    s = MagicMock()
    s.whisper_model_size = "tiny"
    s.enable_tts = True
    s.enable_stt = True
    s.voice_input_path = P("/tmp/voice_test_inputs")
    # Attributs scalaires nécessaires dans voice_engine (évite MagicMock vs int)
    s.voice_keep_audio_files = 20
    s.stt_fast_mode = True
    s.stt_language = "fr"
    s.stt_slow_threshold_ms = 4000
    return s


# Injecter les stubs une seule fois à la collection du module
_stub_faster_whisper()
_stub_pydantic_settings()
_stub_pyttsx3()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_segment(text: str):
    seg = MagicMock()
    seg.text = text
    return seg


def _make_info(duration: float = 2.0):
    info = MagicMock()
    info.duration = duration
    return info


# ---------------------------------------------------------------------------
# VoiceEngine — logique de transcription (sans vrai Whisper)
# ---------------------------------------------------------------------------

class TestVoiceEngineTranscribeLogic:

    def _build_engine(self, segments, duration=2.0, settings_stub=None):
        """Construit un VoiceEngine avec modèle mocké."""
        stub_settings = settings_stub or _make_settings_stub()

        # Patch app.config.settings avant import
        config_mod = types.ModuleType("app.config")
        config_mod.settings = stub_settings
        sys.modules["app.config"] = config_mod

        # Patch logger
        logger_mod = types.ModuleType("app.utils.logger")
        logger_mod.get_logger = lambda name: MagicMock()
        sys.modules["app.utils"] = types.ModuleType("app.utils")
        sys.modules["app.utils.logger"] = logger_mod

        # Forcer re-import propre
        sys.modules.pop("app.core.voice_engine", None)
        from app.core.voice_engine import VoiceEngine

        engine = VoiceEngine()
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (iter(segments), _make_info(duration))
        engine.model = mock_model   # ← attribut public (self.model dans VoiceEngine)
        return engine

    def test_transcription_normale(self, tmp_path):
        audio = tmp_path / "test.webm"
        audio.write_bytes(b"x" * 5000)

        engine = self._build_engine([_make_segment("Bonjour"), _make_segment("comment allez-vous")])
        result = engine.transcribe_file(audio)

        assert result["text"] == "Bonjour comment allez-vous"
        assert result["is_empty"] is False
        assert result["file_size"] > 0

    def test_transcription_vide_segments_vides(self, tmp_path):
        audio = tmp_path / "silence.webm"
        audio.write_bytes(b"x" * 5000)

        engine = self._build_engine([_make_segment(""), _make_segment("  ")])
        result = engine.transcribe_file(audio)

        assert result["text"] == ""
        assert result["is_empty"] is True

    def test_transcription_ignoree_fichier_trop_petit(self, tmp_path):
        audio = tmp_path / "tiny.webm"
        audio.write_bytes(b"x" * 10)  # < 500 octets

        engine = self._build_engine([])
        result = engine.transcribe_file(audio)

        assert result["is_empty"] is True
        assert result["text"] == ""
        # Le modèle ne doit pas avoir été appelé
        assert engine.model.transcribe.call_count == 0

    def test_save_uploaded_audio_cree_fichier(self, tmp_path):
        stub = _make_settings_stub()
        stub.voice_input_path = tmp_path

        engine = self._build_engine([], settings_stub=stub)
        path = engine.save_uploaded_audio("recording.webm", b"audio_data")

        assert path.exists()
        assert path.read_bytes() == b"audio_data"
        assert "recording.webm" in path.name


# ---------------------------------------------------------------------------
# Format de réponse — is_empty bien exposé
# ---------------------------------------------------------------------------

class TestVoiceApiResponseFormat:

    def _build_engine(self, segments, settings_stub=None):
        stub_settings = settings_stub or _make_settings_stub()
        config_mod = types.ModuleType("app.config")
        config_mod.settings = stub_settings
        sys.modules["app.config"] = config_mod
        logger_mod = types.ModuleType("app.utils.logger")
        logger_mod.get_logger = lambda name: MagicMock()
        sys.modules["app.utils.logger"] = logger_mod
        sys.modules.pop("app.core.voice_engine", None)
        from app.core.voice_engine import VoiceEngine
        engine = VoiceEngine()
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (iter(segments), _make_info())
        engine.model = mock_model   # ← attribut public (self.model dans VoiceEngine)
        return engine

    def test_retourne_is_empty_true_sur_silence(self, tmp_path):
        audio = tmp_path / "silence.webm"
        audio.write_bytes(b"x" * 5000)
        engine = self._build_engine([_make_segment("")])
        result = engine.transcribe_file(audio)
        assert "is_empty" in result
        assert result["is_empty"] is True

    def test_retourne_is_empty_false_sur_parole(self, tmp_path):
        audio = tmp_path / "speech.webm"
        audio.write_bytes(b"x" * 5000)
        engine = self._build_engine([_make_segment("test réussi")])
        result = engine.transcribe_file(audio)
        assert result["is_empty"] is False
        assert result["text"] == "test réussi"

    def test_retourne_file_size(self, tmp_path):
        audio = tmp_path / "sample.webm"
        audio.write_bytes(b"x" * 8000)
        engine = self._build_engine([_make_segment("ok")])
        result = engine.transcribe_file(audio)
        assert result["file_size"] == 8000


# ---------------------------------------------------------------------------
# TTS — robustesse sans dépendance réelle
# ---------------------------------------------------------------------------

class TestTTSRobustesse:

    def _build_tts(self, pyttsx3_init_side_effect=None):
        stub_settings = _make_settings_stub()
        config_mod = types.ModuleType("app.config")
        config_mod.settings = stub_settings
        sys.modules["app.config"] = config_mod
        logger_mod = types.ModuleType("app.utils.logger")
        logger_mod.get_logger = lambda name: MagicMock()
        sys.modules["app.utils.logger"] = logger_mod
        sys.modules.pop("app.core.tts_engine", None)

        mock_engine = MagicMock()
        if pyttsx3_init_side_effect:
            sys.modules["pyttsx3"].init = MagicMock(side_effect=pyttsx3_init_side_effect)
        else:
            sys.modules["pyttsx3"].init = MagicMock(return_value=mock_engine)

        from app.core.tts_engine import TTSEngine
        tts = TTSEngine()
        return tts, mock_engine

    def test_speak_texte_vide_ne_crash_pas(self):
        tts, mock_engine = self._build_tts()
        tts.speak("")
        tts.speak("   ")
        mock_engine.say.assert_not_called()

    def test_speak_appelle_say_si_texte_valide(self):
        tts, mock_engine = self._build_tts()
        tts.speak("Bonjour le monde")
        mock_engine.say.assert_called_once_with("Bonjour le monde")

    def test_speak_resilient_si_init_echoue(self):
        tts, _ = self._build_tts(pyttsx3_init_side_effect=Exception("no audio device"))
        assert tts._available is False
        # Ne doit pas lever d'exception
        tts.speak("test silencieux")
