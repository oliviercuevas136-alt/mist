"""test_voice_memory.py — Tests de la mémoire conversationnelle vocale."""
import sys
from pathlib import Path
from unittest.mock import MagicMock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

for mod in ["pydantic_settings", "sqlalchemy", "sqlalchemy.orm",
            "faster_whisper", "pyttsx3", "app.config"]:
    if mod not in sys.modules:
        sys.modules[mod] = MagicMock()

import types
logger_mod = types.ModuleType("app.utils.logger")
logger_mod.get_logger = lambda n: MagicMock()
sys.modules["app.utils"] = types.ModuleType("app.utils")
sys.modules["app.utils.logger"] = logger_mod


class TestVoiceMemory:

    def _make(self, max_exchanges=3):
        from app.core.voice_memory import VoiceMemory
        return VoiceMemory(max_exchanges=max_exchanges)

    def test_add_and_len(self):
        vm = self._make()
        vm.add("user", "Bonjour")
        vm.add("assistant", "Bonjour à vous !")
        assert len(vm) == 2

    def test_max_exchanges_respected(self):
        vm = self._make(max_exchanges=2)  # max 4 messages
        for i in range(6):
            vm.add("user" if i % 2 == 0 else "assistant", f"message {i}")
        assert len(vm) <= 4

    def test_as_messages_includes_system(self):
        vm = self._make()
        vm.add("user", "test")
        messages = vm.as_messages(system_prompt="Système")
        assert messages[0] == {"role": "system", "content": "Système"}

    def test_as_messages_current_user_last(self):
        vm = self._make()
        vm.add("user", "ancien message")
        vm.add("assistant", "ancienne réponse")
        messages = vm.as_messages(current_user_message="nouveau message")
        assert messages[-1] == {"role": "user", "content": "nouveau message"}

    def test_clear_resets_memory(self):
        vm = self._make()
        vm.add("user", "test")
        vm.add("assistant", "réponse")
        vm.clear()
        assert len(vm) == 0

    def test_invalid_role_ignored(self):
        vm = self._make()
        vm.add("system", "injection")  # rôle invalide
        assert len(vm) == 0

    def test_empty_content_ignored(self):
        vm = self._make()
        vm.add("user", "   ")
        assert len(vm) == 0

    def test_summary_returns_string(self):
        vm = self._make()
        vm.add("user", "test")
        assert isinstance(vm.summary(), str)


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
