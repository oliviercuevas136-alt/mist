"""
test_ws_bridge.py — Tests du pont WebSocket Nova (/ws)

Tests isolés : pas de caméra réelle, pas d'Ollama, pas de réseau.
Couvre les helpers JSON store, les helpers DB, et la logique
_build_llm_messages sans démarrer un vrai serveur WebSocket.
"""
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch, call

# ── sys.path ─────────────────────────────────────────────────────────────────
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ── Helpers DB isolation ──────────────────────────────────────────────────────
def _make_db_stubs():
    """Pre-stub la base de données en mémoire avant l'import de ws."""
    import sqlalchemy
    from sqlalchemy.orm import declarative_base, sessionmaker

    engine = sqlalchemy.create_engine(
        "sqlite:///:memory:", connect_args={"check_same_thread": False}
    )
    Base = declarative_base()

    class Conversation(Base):
        __tablename__ = "conversations"
        id         = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
        title      = sqlalchemy.Column(sqlalchemy.String, default="Session")
        summary    = sqlalchemy.Column(sqlalchemy.Text, default="")
        created_at = sqlalchemy.Column(
            sqlalchemy.DateTime,
            default=lambda: __import__("datetime").datetime.utcnow(),
        )
        updated_at = sqlalchemy.Column(
            sqlalchemy.DateTime,
            default=lambda: __import__("datetime").datetime.utcnow(),
        )

    class Message(Base):
        __tablename__ = "messages"
        id              = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
        conversation_id = sqlalchemy.Column(sqlalchemy.Integer)
        role            = sqlalchemy.Column(sqlalchemy.String)
        content         = sqlalchemy.Column(sqlalchemy.Text)
        created_at      = sqlalchemy.Column(
            sqlalchemy.DateTime,
            default=lambda: __import__("datetime").datetime.utcnow(),
        )

    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)

    import app.db.database as _db_mod
    import app.db.models as _models_mod

    _db_mod.engine       = engine
    _db_mod.SessionLocal = Session
    _db_mod.Base         = Base

    _models_mod.Conversation = Conversation
    _models_mod.Message       = Message

    return Session, Conversation, Message


# ── Import ws après stub DB ───────────────────────────────────────────────────
_Session, _Conv, _Msg = _make_db_stubs()

# Patch OllamaClient avant import ws
with patch("app.core.llm.OllamaClient.__init__", return_value=None):
    from app.api import ws as ws_module


# ══════════════════════════════════════════════════════════════════════════════
class TestJsonStore(unittest.TestCase):
    """Tests des helpers load/save JSON (settings + projects)."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # Rediriger NOVA_DATA_DIR vers tmpdir
        self._orig_env = os.environ.get("NOVA_DATA_DIR")
        os.environ["NOVA_DATA_DIR"] = self.tmpdir

    def tearDown(self):
        if self._orig_env is None:
            os.environ.pop("NOVA_DATA_DIR", None)
        else:
            os.environ["NOVA_DATA_DIR"] = self._orig_env

    # ── _data_dir ─────────────────────────────────────────────────────────────
    def test_data_dir_returns_env(self):
        self.assertEqual(ws_module._data_dir(), self.tmpdir)

    def test_data_dir_creates_directory(self):
        subdir = os.path.join(self.tmpdir, "sub")
        os.environ["NOVA_DATA_DIR"] = subdir
        ws_module._data_dir()
        self.assertTrue(os.path.isdir(subdir))

    # ── _load_json / _save_json ────────────────────────────────────────────────
    def test_load_json_missing_file_returns_default(self):
        result = ws_module._load_json("nonexistent.json", {"default": True})
        self.assertEqual(result, {"default": True})

    def test_load_json_reads_written_data(self):
        path = os.path.join(self.tmpdir, "test.json")
        with open(path, "w") as f:
            json.dump({"key": "value"}, f)
        result = ws_module._load_json("test.json", {})
        self.assertEqual(result["key"], "value")

    def test_save_json_then_load(self):
        ws_module._save_json("roundtrip.json", {"x": 42})
        result = ws_module._load_json("roundtrip.json", {})
        self.assertEqual(result["x"], 42)

    def test_load_json_corrupt_returns_default(self):
        path = os.path.join(self.tmpdir, "corrupt.json")
        with open(path, "w") as f:
            f.write("{not valid json")
        result = ws_module._load_json("corrupt.json", "fallback")
        self.assertEqual(result, "fallback")

    # ── load_settings / save_settings ─────────────────────────────────────────
    def test_load_settings_returns_defaults(self):
        s = ws_module.load_settings()
        self.assertIn("provider", s)
        self.assertEqual(s["provider"], "ollama")
        self.assertIn("theme", s)

    def test_save_and_load_settings(self):
        ws_module.save_settings({"provider": "ollama", "theme": "matrix", "model": "mistral"})
        s = ws_module.load_settings()
        self.assertEqual(s["theme"], "matrix")
        self.assertEqual(s["model"], "mistral")

    def test_load_settings_merges_with_defaults(self):
        ws_module.save_settings({"theme": "gold"})
        s = ws_module.load_settings()
        self.assertIn("provider", s)   # default présent
        self.assertEqual(s["theme"], "gold")  # override appliqué

    # ── load_projects / save_projects ─────────────────────────────────────────
    def test_load_projects_returns_default(self):
        projects = ws_module.load_projects()
        self.assertIsInstance(projects, list)
        self.assertGreater(len(projects), 0)
        self.assertIn("id", projects[0])
        self.assertIn("name", projects[0])

    def test_save_and_load_projects(self):
        data = [{"id": 1, "name": "Projet Alpha"}, {"id": 2, "name": "Projet Beta"}]
        ws_module.save_projects(data)
        result = ws_module.load_projects()
        self.assertEqual(len(result), 2)
        names = [p["name"] for p in result]
        self.assertIn("Projet Alpha", names)

    def test_load_projects_creates_default_file(self):
        ws_module.load_projects()
        expected = os.path.join(self.tmpdir, "nova_projects.json")
        self.assertTrue(os.path.exists(expected))


# ══════════════════════════════════════════════════════════════════════════════
class TestDbHelpers(unittest.TestCase):
    """Tests des helpers DB (conversations, messages)."""

    def test_db_create_conversation_default_title(self):
        conv = ws_module.db_create_conversation("Test conv")
        self.assertIsNotNone(conv.id)
        self.assertEqual(conv.title, "Test conv")

    def test_db_create_conversation_empty_title(self):
        conv = ws_module.db_create_conversation("")
        self.assertEqual(conv.title, "Nouvelle session")

    def test_db_get_chats_returns_list(self):
        ws_module.db_create_conversation("Chat pour get test")
        chats = ws_module.db_get_chats(project_id=1)
        self.assertIsInstance(chats, list)
        titles = [c["title"] for c in chats]
        self.assertIn("Chat pour get test", titles)

    def test_db_get_chats_schema(self):
        ws_module.db_create_conversation("Schema check")
        chats = ws_module.db_get_chats(project_id=42)
        self.assertGreater(len(chats), 0)
        chat = chats[0]
        self.assertIn("id", chat)
        self.assertIn("title", chat)
        self.assertIn("project_id", chat)
        self.assertEqual(chat["project_id"], 42)

    def test_db_save_message_and_get(self):
        conv = ws_module.db_create_conversation("Msg test")
        ws_module.db_save_message(conv.id, "user", "Bonjour Nova")
        ws_module.db_save_message(conv.id, "assistant", "Bonjour !")
        msgs = ws_module.db_get_messages(conv.id)
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0]["role"], "user")
        self.assertEqual(msgs[0]["content"], "Bonjour Nova")
        self.assertEqual(msgs[1]["role"], "assistant")

    def test_db_get_messages_schema(self):
        conv = ws_module.db_create_conversation("Schema msg")
        ws_module.db_save_message(conv.id, "user", "Test")
        msgs = ws_module.db_get_messages(conv.id)
        msg = msgs[0]
        self.assertIn("id", msg)
        self.assertIn("role", msg)
        self.assertIn("content", msg)

    def test_db_get_messages_empty(self):
        conv = ws_module.db_create_conversation("Empty conv")
        msgs = ws_module.db_get_messages(conv.id)
        self.assertEqual(msgs, [])

    def test_db_get_messages_unknown_conv(self):
        msgs = ws_module.db_get_messages(99999)
        self.assertEqual(msgs, [])


# ══════════════════════════════════════════════════════════════════════════════
class TestBuildLlmMessages(unittest.TestCase):
    """Tests de _build_llm_messages."""

    def setUp(self):
        self.conv = ws_module.db_create_conversation("LLM build test")

    def test_includes_system_prompt(self):
        msgs = ws_module._build_llm_messages(self.conv.id, "Bonjour")
        self.assertEqual(msgs[0]["role"], "system")
        self.assertIn("Nova", msgs[0]["content"])

    def test_last_message_is_user(self):
        msgs = ws_module._build_llm_messages(self.conv.id, "Ma question")
        self.assertEqual(msgs[-1]["role"], "user")
        self.assertEqual(msgs[-1]["content"], "Ma question")

    def test_includes_history(self):
        ws_module.db_save_message(self.conv.id, "user", "msg1")
        ws_module.db_save_message(self.conv.id, "assistant", "rep1")
        msgs = ws_module._build_llm_messages(self.conv.id, "msg2")
        roles = [m["role"] for m in msgs]
        self.assertIn("system", roles)
        self.assertIn("user", roles)
        self.assertIn("assistant", roles)

    def test_history_truncated_to_max_context(self):
        for i in range(25):
            ws_module.db_save_message(self.conv.id, "user", f"question {i}")
            ws_module.db_save_message(self.conv.id, "assistant", f"réponse {i}")
        msgs = ws_module._build_llm_messages(self.conv.id, "finale")
        # system (1) + max MAX_CONTEXT_MESSAGES history (default 6) + user (1) = max 8
        # MagicMock fallback also caps at 6 → assertLessEqual(len(msgs), 8)
        self.assertLessEqual(len(msgs), 8)
        self.assertGreaterEqual(len(msgs), 2)  # au moins system + user
        self.assertEqual(msgs[-1]["role"], "user")
        self.assertEqual(msgs[-1]["content"], "finale")

    def test_empty_conv_just_system_and_user(self):
        msgs = ws_module._build_llm_messages(self.conv.id, "Première question")
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0]["role"], "system")
        self.assertEqual(msgs[1]["role"], "user")

    def test_system_prompt_in_french(self):
        msgs = ws_module._build_llm_messages(self.conv.id, "test")
        system = msgs[0]["content"]
        self.assertTrue(
            any(word in system.lower() for word in ["français", "bienveillant", "nova"]),
            "Le prompt système doit mentionner Nova, être en français ou bienveillant"
        )


# ══════════════════════════════════════════════════════════════════════════════
class TestRouterRegistration(unittest.TestCase):
    """Vérifie que le router est bien une instance APIRouter avec /ws."""

    def test_router_exists(self):
        self.assertIsNotNone(ws_module.router)

    def test_router_has_ws_route(self):
        # Le router FastAPI expose ses routes via .routes
        routes = ws_module.router.routes
        paths = [getattr(r, "path", "") for r in routes]
        self.assertIn("/ws", paths)

    def test_router_type(self):
        from fastapi import APIRouter
        self.assertIsInstance(ws_module.router, APIRouter)


if __name__ == "__main__":
    unittest.main(verbosity=2)
