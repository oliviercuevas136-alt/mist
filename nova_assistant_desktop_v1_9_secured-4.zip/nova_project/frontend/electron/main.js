/**
 * Nova Assistant Desktop — Electron main process
 *
 * Adapté depuis Jarvis (MIT) par Olivier Cuevas Garcia.
 * Modifications :
 *   - Port backend : 8000 (Local Assistant V4.8 FastAPI)
 *   - Backend path : ../backend/ avec app.main:app
 *   - Titre : Nova Assistant
 *   - Supprimé : openExternal URLs Jarvis (remplacées par URL génériques sécurisées)
 *   - Ajouté : NOVA_DATA_DIR env var transmis au backend
 */

const { app, BrowserWindow, ipcMain, shell, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const net = require('net');
const { spawn } = require('child_process');

const BACKEND_PORT = process.env.NOVA_BACKEND_PORT || '8000';
const BACKEND_URL = `http://127.0.0.1:${BACKEND_PORT}`;

let backendProcess = null;
let mainWindow = null;
let splashWindow = null;
let tray = null;
let isQuitting = false;

// ── Persistance position fenêtre ──────────────────────────────────────────

function userDataFile(name) {
  return path.join(app.getPath('userData'), name);
}

function readWindowState() {
  try {
    const raw = fs.readFileSync(userDataFile('nova-window-state.json'), 'utf8');
    return JSON.parse(raw);
  } catch {
    return { width: 1220, height: 760 };
  }
}

function saveWindowState(win) {
  if (!win || win.isDestroyed()) return;
  const bounds = win.getBounds();
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  fs.writeFileSync(
    userDataFile('nova-window-state.json'),
    JSON.stringify(bounds, null, 2)
  );
}

// ── Résolution Python ──────────────────────────────────────────────────────

function resolvePythonCommand() {
  if (process.env.NOVA_PYTHON) return process.env.NOVA_PYTHON;
  const projectRoot = path.join(__dirname, '..', '..');
  const localPython = process.platform === 'win32'
    ? path.join(projectRoot, 'backend', '.venv', 'Scripts', 'python.exe')
    : path.join(projectRoot, 'backend', '.venv', 'bin', 'python');
  if (fs.existsSync(localPython)) return localPython;
  return process.platform === 'win32' ? 'python' : 'python3';
}

// ── Démarrage backend FastAPI ──────────────────────────────────────────────
//
// Garanties :
//   1. JAMAIS de spawn si /health répond déjà sur 127.0.0.1:8000
//      → évite Errno 10048 (port déjà utilisé) sur Windows
//   2. Maximum 3 tentatives de démarrage avec cooldown 5s
//   3. Pas de boucle infinie de restart
//   4. Logs structurés : BACKEND_ALREADY_RUNNING / BACKEND_START /
//                        BACKEND_START_FAILED / BACKEND_GAVE_UP

const MAX_BACKEND_RESTARTS = 3;
const RESTART_COOLDOWN_MS  = 5000;
let backendStartAttempts   = 0;
let backendGivenUp         = false;
let backendExternal        = false;   // true si un backend externe gère le port

/**
 * Démarre uvicorn UNIQUEMENT après avoir vérifié que /health ne répond pas.
 * Si /health répond déjà → aucun spawn, on réutilise le backend existant.
 *
 * Renvoie une Promise<'started' | 'reused' | 'failed' | 'given_up'>
 */
async function ensureBackend() {
  // Étape 1 — probe ROBUSTE (5×1s) avant tout spawn.
  // Objectif : ne JAMAIS conclure "backend absent" si un backend
  // est simplement en train de démarrer (FastAPI startup, DB init, etc.).
  if (await probeBackendThorough()) {
    backendExternal = backendProcess === null;
    console.log(`[nova] BACKEND_ALREADY_RUNNING port=${BACKEND_PORT} (pas de spawn)`);
    return 'reused';
  }

  // Étape 2 — déjà donné après MAX tentatives ?
  if (backendGivenUp) {
    console.error('[nova] BACKEND_GAVE_UP attempts=' + backendStartAttempts);
    return 'given_up';
  }

  // Étape 3 — déjà un process en vol ? (ne pas re-spawn)
  if (backendProcess) {
    console.log('[nova] Backend spawn déjà en cours — attente.');
    return 'started';
  }

  // Étape 4 — Garde anti-Errno 10048 : tester le PORT TCP avant spawn.
  //
  // Si /health ne répond pas mais que le port est occupé, cela signifie
  // qu'un Python orphelin (instance Nova précédente qui n'a pas mouru),
  // un état TIME_WAIT, ou une autre application tient le port.
  // Spawner uvicorn dans ce cas garantit Errno 10048.
  if (await isPortInUse(BACKEND_PORT)) {
    console.error(
      `[nova] BACKEND_PORT_BUSY port=${BACKEND_PORT} occupé mais /health silencieux.`
    );
    console.error(
      `[nova] Cause probable : process Python orphelin d'une instance Nova précédente, ` +
      `ou autre application sur le port ${BACKEND_PORT}.`
    );
    console.error(
      `[nova] Action requise : sous Windows, tuer le processus python.exe ` +
      `qui occupe ${BACKEND_PORT} (Gestionnaire des tâches), ` +
      `OU changer NOVA_BACKEND_PORT.`
    );
    backendGivenUp = true;   // ne pas tenter de relancer en boucle
    return 'failed';
  }

  // Étape 5 — DERNIÈRE garde : un probe rapide juste avant spawn.
  // Quelqu'un a pu démarrer un backend entre la fin de probe-1 et maintenant
  // (cas : utilisateur lance python manuellement pendant les 5s de probe).
  if (await isBackendAlive(2000)) {
    console.log('[nova] BACKEND_ALREADY_RUNNING (apparu pendant probe) — pas de spawn.');
    backendExternal = true;
    return 'reused';
  }

  // Étape 6 — spawn
  backendStartAttempts++;
  console.log(`[nova] BACKEND_START attempt=${backendStartAttempts}/${MAX_BACKEND_RESTARTS}`);

  const python = resolvePythonCommand();
  const backendDir = path.join(__dirname, '..', '..', 'backend');
  const args = [
    '-m', 'uvicorn',
    'app.main:app',
    '--host', '127.0.0.1',
    '--port', BACKEND_PORT,
    '--log-level', 'warning',
  ];

  console.log(`[nova] cmd: ${python} ${args.join(' ')}`);
  console.log(`[nova] cwd: ${backendDir}`);

  try {
    backendProcess = spawn(python, args, {
      cwd: backendDir,
      env: {
        ...process.env,
        NOVA_DATA_DIR: path.join(app.getPath('userData'), 'nova-data'),
        PYTHONUNBUFFERED: '1',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
  } catch (err) {
    console.error('[nova] BACKEND_START_FAILED spawn error: ' + err.message);
    backendProcess = null;
    return 'failed';
  }

  backendProcess.stdout.on('data', chunk =>
    console.log(`[backend] ${chunk.toString().trim()}`)
  );
  backendProcess.stderr.on('data', chunk => {
    const txt = chunk.toString().trim();
    console.error(`[backend] ${txt}`);
    // Détection précoce du conflit port Windows
    if (txt.includes('10048') || txt.includes('address already in use')) {
      console.error('[nova] BACKEND_START_FAILED port conflict (Errno 10048) — un autre backend occupe ' + BACKEND_PORT);
    }
  });

  backendProcess.on('exit', code => {
    console.log(`[nova] Backend exited: code=${code}`);
    const wasProcess = backendProcess;
    backendProcess = null;

    // Si on quitte volontairement → rien à faire
    if (isQuitting) return;
    if (!wasProcess) return;

    // Exit normal (code 0) = arrêt voulu, ne pas relancer
    if (code === 0) return;

    // Avant tout retry : refaire un probe COMPLET.
    // Si un backend externe a pris le port (manuel ou apparu pendant qu'on tournait),
    // on arrête immédiatement toute tentative.
    probeBackendThorough().then(alive => {
      if (alive) {
        console.log('[nova] BACKEND_ALREADY_RUNNING (externe détecté après exit) — pas de redémarrage.');
        backendExternal = true;
        return;
      }

      // Plafond de tentatives — pas de boucle infinie
      if (backendStartAttempts >= MAX_BACKEND_RESTARTS) {
        backendGivenUp = true;
        console.error(
          `[nova] BACKEND_GAVE_UP après ${MAX_BACKEND_RESTARTS} tentatives. ` +
          `Vérifiez les logs backend, le port ${BACKEND_PORT}, et l'installation Python.`
        );
        return;
      }

      console.log(`[nova] Restart backend dans ${RESTART_COOLDOWN_MS / 1000}s ` +
                  `(tentative ${backendStartAttempts + 1}/${MAX_BACKEND_RESTARTS})`);

      // Pendant le cooldown : si un backend OK apparaît, on annule.
      // Cela évite de respawn si l'utilisateur démarre manuellement uvicorn
      // pendant l'attente.
      setTimeout(async () => {
        if (await isBackendAlive(2000)) {
          console.log('[nova] BACKEND_ALREADY_RUNNING (apparu pendant cooldown) — restart annulé.');
          backendExternal = true;
          return;
        }
        ensureBackend();
      }, RESTART_COOLDOWN_MS);
    });
  });

  return 'started';
}

// ── Attendre que le backend réponde réellement /health ─────────────────────
//
// Important : on ne considère JAMAIS le backend prêt simplement parce que
// le processus Python est lancé. uvicorn peut tourner 5-60s sur Windows lent
// avant que FastAPI ne réponde 200 (DB init, startup checks, Whisper warmup,
// Ollama keep-alive, semantic modules, watchdogs, etc.).
//
// v1.9.10 — corrigé : 1 probe / 1000 ms, max 60 essais (≈60s), guard contre
// le double-callback (error + timeout sur même requête) qui faisait 1007
// essais en 30s dans les versions précédentes.
function waitForBackend(opts = {}) {
  const intervalMs = opts.intervalMs || 1000;
  const maxAttempts = opts.maxAttempts || 60;
  const requestTimeoutMs = opts.requestTimeoutMs || 2500;
  const onProgress = typeof opts.onProgress === 'function'
    ? opts.onProgress : () => {};

  const started = Date.now();
  let attempts = 0;
  let cancelled = false;

  return new Promise((resolve, reject) => {
    const finish = (err) => {
      if (cancelled) return;          // déjà résolu/rejeté
      cancelled = true;
      if (err) reject(err);
      else resolve({ attempts, elapsedMs: Date.now() - started });
    };

    const check = () => {
      if (cancelled) return;
      attempts++;

      // Garde anti-fuite : si le process est mort, ne plus probe
      if (backendProcess && backendProcess.exitCode !== null) {
        return finish(new Error(
          `Backend process exited with code ${backendProcess.exitCode} ` +
          `après ${attempts} essai(s), ${Date.now() - started}ms`
        ));
      }

      // Vérification : nombre max d'essais
      if (attempts > maxAttempts) {
        return finish(new Error(
          `Backend pas prêt après ${attempts - 1} essai(s) ` +
          `(${Math.round((Date.now() - started) / 1000)}s) — timeout`
        ));
      }

      // Guard double-callback : un seul retry par tentative.
      // Sans ça, error + timeout peuvent déclencher 2× retry → boucle exponentielle.
      let attemptDone = false;
      const safeRetry = (reason) => {
        if (attemptDone || cancelled) return;
        attemptDone = true;
        onProgress({
          phase: 'probing', attempts, elapsedMs: Date.now() - started, reason,
        });
        setTimeout(check, intervalMs);
      };

      // v1.9.11 — Construction d'URL robuste (évite Invalid URL si BACKEND_URL
      // contient un trailing slash ou est mal formé).
      let healthUrl;
      try {
        healthUrl = new URL('/health', BACKEND_URL).toString();
      } catch (err) {
        return finish(new Error(
          `BACKEND_URL invalide (${BACKEND_URL}): ${err.message}`
        ));
      }
      const req = http.get(healthUrl, res => {
        // Drainer la réponse pour libérer le socket
        res.resume();
        if (attemptDone || cancelled) return;
        attemptDone = true;
        if (res.statusCode === 200) {
          console.log(
            `[nova] HEALTH_OK attempt=${attempts} elapsed=${Date.now() - started}ms`
          );
          onProgress({ phase: 'healthy', attempts, elapsedMs: Date.now() - started });
          finish(null);
        } else {
          setTimeout(check, intervalMs);
        }
      });

      req.on('error', (err) => safeRetry(err.code || err.message || 'error'));
      req.setTimeout(requestTimeoutMs, () => {
        req.destroy();
        safeRetry('request_timeout');
      });
    };

    onProgress({ phase: 'start', attempts: 0, elapsedMs: 0 });
    check();
  });
}

function isBackendAlive(timeoutMs = 1500) {
  return new Promise(resolve => {
    // v1.9.11 — Construction d'URL robuste
    let healthUrl;
    try {
      healthUrl = new URL('/health', BACKEND_URL).toString();
    } catch (err) {
      // BACKEND_URL mal formé → on signale honnêtement
      console.error('[nova] BACKEND_URL invalide :', BACKEND_URL, err.message);
      return resolve(false);
    }
    const req = http.get(healthUrl, res => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(timeoutMs, () => { req.destroy(); resolve(false); });
  });
}

/**
 * Vérifie si le port TCP est occupé, indépendamment du protocole HTTP.
 *
 * Critique pour distinguer :
 *   - Port libre → spawn uvicorn sera safe
 *   - Port occupé par /health 200 → backend Nova réutilisable
 *   - Port occupé par autre chose (Python orphelin, TIME_WAIT, antivirus,
 *     autre app sur 8000) → spawn provoquerait Errno 10048
 *
 * Méthode : on tente un `bind()` éphémère via net.createServer.listen().
 * Si EADDRINUSE → port occupé. Sinon → libre.
 */
function isPortInUse(port = BACKEND_PORT, host = '127.0.0.1') {
  return new Promise(resolve => {
    const tester = net.createServer()
      .once('error', err => {
        if (err.code === 'EADDRINUSE' || err.code === 'EACCES') resolve(true);
        else resolve(false);
      })
      .once('listening', () => {
        tester.close(() => resolve(false));
      })
      .listen(Number(port), host);
  });
}

/**
 * Détection ROBUSTE du backend, conçue pour ne JAMAIS conclure
 * "backend absent" alors qu'un backend est en cours de démarrage.
 *
 * - 5 tentatives espacées de 1s (total ≥ 10s)
 * - Chaque tentative : timeout 2s
 * - Renvoie true dès qu'une tentative répond HTTP 200
 * - Si une tentative dit 200 → on arrête le polling immédiatement
 *
 * Distinction clé vs isBackendAlive :
 *   - isBackendAlive = sonde rapide (utilisée APRÈS spawn, dans waitForBackend)
 *   - probeBackendThorough = sonde lente AVANT décision de spawn
 *
 * Cette fonction est la seule à utiliser pour décider "faut-il spawn ?"
 */
async function probeBackendThorough() {
  const ATTEMPTS = 5;
  const DELAY_BETWEEN_MS = 1000;
  const PER_ATTEMPT_TIMEOUT_MS = 2000;

  let healthUrlForLog;
  try {
    healthUrlForLog = new URL('/health', BACKEND_URL).toString();
  } catch (err) {
    console.error(`[nova] BACKEND_URL invalide : ${BACKEND_URL} (${err.message})`);
    return false;
  }
  console.log(`[nova] Probe backend sur ${healthUrlForLog} (${ATTEMPTS} essais, ~${ATTEMPTS}s max)...`);

  for (let i = 1; i <= ATTEMPTS; i++) {
    const alive = await isBackendAlive(PER_ATTEMPT_TIMEOUT_MS);
    if (alive) {
      console.log(`[nova] Probe #${i}/${ATTEMPTS} → backend répond.`);
      return true;
    }
    if (i < ATTEMPTS) {
      console.log(`[nova] Probe #${i}/${ATTEMPTS} → pas de réponse, retry dans ${DELAY_BETWEEN_MS}ms...`);
      await new Promise(r => setTimeout(r, DELAY_BETWEEN_MS));
    }
  }
  console.log(`[nova] Probe complet : aucun backend détecté après ${ATTEMPTS} essais.`);
  return false;
}

// ── Fenêtres ──────────────────────────────────────────────────────────────

function createSplashWindow() {
  splashWindow = new BrowserWindow({
    width: 420,
    height: 280,
    frame: false,
    resizable: false,
    show: false,
    backgroundColor: '#0d1117',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
    },
  });
  splashWindow.loadFile(
    path.join(__dirname, '..', 'renderer', 'splash.html')
  );
  splashWindow.once('ready-to-show', () => splashWindow.show());
}

function createMainWindow() {
  const state = readWindowState();
  // Windows ne supporte pas SVG pour les icônes natives — utiliser PNG
  const iconPath = path.join(
    __dirname, '..', 'renderer', 'assets', 'nova-logo.png'
  );
  mainWindow = new BrowserWindow({
    width: state.width || 1220,
    height: state.height || 760,
    x: state.x,
    y: state.y,
    minWidth: 920,
    minHeight: 620,
    title: 'Nova Assistant',
    icon: iconPath,
    backgroundColor: '#0d1117',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.loadFile(
    path.join(__dirname, '..', 'renderer', 'index.html')
  );

  // Intercepter les liens target="_blank" — ouvrir dans le navigateur système
  // (sans ça, Electron ouvre une fenêtre vide)
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    const ALLOWED = ['https://ollama.com', 'https://github.com'];
    if (ALLOWED.some(prefix => url.startsWith(prefix))) {
      shell.openExternal(url);
    }
    return { action: 'deny' };  // toujours bloquer l'ouverture dans Electron
  });

  mainWindow.once('ready-to-show', () => {
    // v1.9.10 — NE PAS fermer le splash ici. Le splash reste visible
    // tant que le backend n'a pas répondu /health 200. La fermeture
    // est déclenchée par waitForBackend().then() dans app.whenReady().
    // Si le backend est déjà ready (reused), broadcastStartupPhase
    // a déjà notifié le splash qui peut se fermer de lui-même.
    mainWindow.show();
  });
  mainWindow.on('close', () => saveWindowState(mainWindow));
}

function createTray() {
  // Tray Windows : doit être PNG (SVG non supporté par nativeImage sur Windows)
  const trayIconPath = path.join(
    __dirname, '..', 'renderer', 'assets', 'nova-tray.png'
  );
  const fallbackPath = path.join(
    __dirname, '..', 'renderer', 'assets', 'nova-logo.png'
  );
  const resolvedIcon = fs.existsSync(trayIconPath) ? trayIconPath : fallbackPath;
  const icon = nativeImage.createFromPath(resolvedIcon);
  tray = new Tray(icon);
  tray.setToolTip('Nova Assistant');
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: 'Ouvrir Nova', click: () => mainWindow && mainWindow.show() },
      { type: 'separator' },
      {
        label: 'Quitter',
        click: () => { isQuitting = true; app.quit(); },
      },
    ])
  );
  tray.on('click', () => {
    if (mainWindow) mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
  });
}

// ── IPC ───────────────────────────────────────────────────────────────────

// URL du WebSocket backend
ipcMain.handle('app:backendUrl', () => BACKEND_URL.replace('http', 'ws'));
// URL HTTP backend (pour les appels REST caméra/monitoring)
ipcMain.handle('app:backendHttpUrl', () => BACKEND_URL);

// Ouverture externe sécurisée (allowlist stricte)
const ALLOWED_URLS = [
  'https://github.com',
  'https://ollama.com',
];
ipcMain.handle('app:openExternal', async (_event, url) => {
  const safe = ALLOWED_URLS.some(prefix => url.startsWith(prefix));
  if (safe) await shell.openExternal(url);
});

// ── Lifecycle ─────────────────────────────────────────────────────────────

/**
 * v1.9.10 — Notifie splash (et main window si dispo) d'une phase startup.
 * Centralise les broadcasts IPC pour ne pas crasher si une fenêtre est null.
 */
function broadcastStartupPhase(payload) {
  const safePayload = { ...payload, ts: Date.now() };
  for (const win of [splashWindow, mainWindow]) {
    if (win && !win.isDestroyed() && win.webContents) {
      try { win.webContents.send('nova:startup-phase', safePayload); }
      catch (e) { /* ignore */ }
    }
  }
}

app.whenReady().then(async () => {
  app.setName('Nova Assistant');
  createSplashWindow();
  console.log('[nova] STARTUP_BEGIN');

  // v1.9.10 — Décision : sync ou async ?
  //   Si backend déjà présent (reused) → on attend, c'est instantané.
  //   Si on doit le spawner → on n'attend PAS avant d'ouvrir la main window :
  //   l'utilisateur voit Nova "démarre..." pendant que le backend boot derrière.
  const result = await ensureBackend();

  if (result === 'reused') {
    console.log('[nova] BACKEND_READY (réutilisé)');
    broadcastStartupPhase({ phase: 'reused' });
    createMainWindow();
    createTray();
    // Backend déjà prêt → fermer le splash dès que la main est visible.
    // Délai 800ms pour que l'utilisateur voie quand même le statut "Nova prêt".
    setTimeout(() => {
      if (splashWindow && !splashWindow.isDestroyed()) {
        try { splashWindow.close(); } catch (e) {}
      }
    }, 800);
    return;
  }

  if (result === 'started') {
    console.log('[nova] BACKEND_PROCESS_LAUNCHED — main window ouverte en parallèle');
    broadcastStartupPhase({ phase: 'process_launched' });

    // Ouvrir la main window TOUT DE SUITE — elle affichera son loading screen.
    // L'utilisateur peut interagir avec l'interface dès que le DOM est prêt.
    createMainWindow();
    createTray();

    // Attendre /health en arrière-plan SANS bloquer.
    // Timeout généreux : 90s (Whisper + Ollama + watchdogs + caméra).
    waitForBackend({
      intervalMs:      1000,     // 1 probe / seconde
      maxAttempts:     90,       // ≈ 90s max
      requestTimeoutMs: 2500,
      onProgress: (info) => {
        // Throttle : log que toutes les 5 attemps pour ne pas spammer
        if (info.attempts && info.attempts % 5 === 0) {
          console.log(
            `[nova] WAITING_HEALTH attempt=${info.attempts} ` +
            `elapsed=${Math.round(info.elapsedMs / 1000)}s reason=${info.reason || '?'}`
          );
        }
        broadcastStartupPhase(info);
      },
    })
      .then((info) => {
        console.log(
          `[nova] BACKEND_READY attempts=${info.attempts} elapsed=${info.elapsedMs}ms`
        );
        broadcastStartupPhase({
          phase: 'ready', attempts: info.attempts, elapsedMs: info.elapsedMs,
        });
        // Le splash se ferme déjà sur main:ready-to-show, mais s'il est
        // encore là (cas rare), forcer la fermeture maintenant.
        if (splashWindow && !splashWindow.isDestroyed()) {
          try { splashWindow.close(); } catch (e) {}
        }
      })
      .catch((err) => {
        console.error(`[nova] BACKEND_TIMEOUT ${err.message}`);
        broadcastStartupPhase({
          phase: 'timeout', error: err.message, elapsedMs: 0,
        });
        // On NE FERME PAS la main window : l'utilisateur reste avec
        // l'interface, qui pourra retry plus tard via reconnexion WS.
      });
    return;
  }

  // result === 'failed' ou autre
  console.error('[nova] BACKEND_UNAVAILABLE — main window ouverte sans IA');
  broadcastStartupPhase({
    phase: 'timeout', error: 'backend indisponible', elapsedMs: 0,
  });
  createMainWindow();
  createTray();
  // Fermer le splash après 3s pour que l'utilisateur voie le message d'erreur
  setTimeout(() => {
    if (splashWindow && !splashWindow.isDestroyed()) {
      try { splashWindow.close(); } catch (e) {}
    }
  }, 3000);
});

app.on('before-quit', () => {
  isQuitting = true;
  if (mainWindow) saveWindowState(mainWindow);
  // On ne tue QUE le backend qu'on a démarré nous-mêmes.
  // Si backendExternal=true, backendProcess est null → rien à tuer,
  // on laisse l'instance externe poursuivre.
  if (backendProcess) {
    console.log('[nova] Stopping backend (spawned by Nova)...');
    backendProcess.kill();
  } else if (backendExternal) {
    console.log('[nova] Backend externe laissé en vie.');
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
});
