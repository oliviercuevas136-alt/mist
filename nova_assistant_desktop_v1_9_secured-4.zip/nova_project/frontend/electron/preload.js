/**
 * Nova Assistant Desktop — Preload script
 * Expose les API Electron au renderer via contextBridge (CSP-safe).
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('jarvisShell', {
  // URL WebSocket backend (ex: "ws://127.0.0.1:8000")
  backendWsUrl:   () => ipcRenderer.invoke('app:backendUrl'),
  // URL HTTP backend  (ex: "http://127.0.0.1:8000")
  backendHttpUrl: () => ipcRenderer.invoke('app:backendHttpUrl'),
  // Ouvrir un lien externe (allowlist dans main.js)
  openExternal:   url => ipcRenderer.invoke('app:openExternal', url),
});

// v1.9.10 — canal startup (utilisé par splash.html + index.html optionnel)
contextBridge.exposeInMainWorld('nova', {
  onStartupPhase: (callback) => {
    if (typeof callback !== 'function') return;
    ipcRenderer.on('nova:startup-phase', (_event, payload) => {
      try { callback(payload); } catch (e) {}
    });
  },
});
