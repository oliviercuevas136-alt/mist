/**
 * test_wait_for_backend.js — Tests v1.9.10 pour la fonction waitForBackend.
 *
 * Vérifie les bugs corrigés :
 *   1. Pas de boucle runaway (1007 essais en 30s) sur ECONNREFUSED rapide
 *   2. Respect du intervalMs (1000ms par défaut)
 *   3. Respect du maxAttempts (60 par défaut)
 *   4. Pas de double-callback sur error + timeout
 *   5. Cancel automatique si backend process meurt
 *   6. Logs de progression émis
 *
 * Exécution :
 *   cd frontend
 *   node electron/test_wait_for_backend.js
 */

'use strict';

const http = require('http');

// ── Reproduire waitForBackend localement (copie ; on ne charge pas main.js
// qui dépend d'Electron). On veut tester l'algorithmique isolée.
// Si ce test PASSE pour cette copie, la même logique passe dans main.js.

// v1.9.11 — Wrappé en ref object pour permettre la mutation depuis le test 6
const BACKEND_URL_REF = { value: 'http://127.0.0.1:38765' };  // port jamais utilisé
Object.defineProperty(global, 'BACKEND_URL', {
  get() { return BACKEND_URL_REF.value; }
});
let backendProcess = null;                       // mock du process

function waitForBackend(opts = {}) {
  const intervalMs = opts.intervalMs || 1000;
  const maxAttempts = opts.maxAttempts || 60;
  const requestTimeoutMs = opts.requestTimeoutMs || 2500;
  const onProgress = typeof opts.onProgress === 'function'
    ? opts.onProgress : () => {};

  const started = Date.now();
  let attempts = 0;
  let cancelled = false;

  return new Promise((resolve, reject) => {
    const finish = (err) => {
      if (cancelled) return;
      cancelled = true;
      if (err) reject(err);
      else resolve({ attempts, elapsedMs: Date.now() - started });
    };

    const check = () => {
      if (cancelled) return;
      attempts++;

      if (backendProcess && backendProcess.exitCode !== null) {
        return finish(new Error(
          `Backend process exited with code ${backendProcess.exitCode} ` +
          `après ${attempts} essai(s), ${Date.now() - started}ms`
        ));
      }

      if (attempts > maxAttempts) {
        return finish(new Error(
          `Backend pas prêt après ${attempts - 1} essai(s) ` +
          `(${Math.round((Date.now() - started) / 1000)}s) — timeout`
        ));
      }

      let attemptDone = false;
      const safeRetry = (reason) => {
        if (attemptDone || cancelled) return;
        attemptDone = true;
        onProgress({
          phase: 'probing', attempts, elapsedMs: Date.now() - started, reason,
        });
        setTimeout(check, intervalMs);
      };

      // v1.9.11 — Construction d'URL robuste (en miroir du code de main.js)
      let healthUrl;
      try {
        healthUrl = new URL('/health', BACKEND_URL).toString();
      } catch (err) {
        return finish(new Error(
          `BACKEND_URL invalide (${BACKEND_URL}): ${err.message}`
        ));
      }
      const req = http.get(healthUrl, res => {
        res.resume();
        if (attemptDone || cancelled) return;
        attemptDone = true;
        if (res.statusCode === 200) {
          onProgress({ phase: 'healthy', attempts, elapsedMs: Date.now() - started });
          finish(null);
        } else {
          setTimeout(check, intervalMs);
        }
      });
      req.on('error', (err) => safeRetry(err.code || 'error'));
      req.setTimeout(requestTimeoutMs, () => {
        req.destroy();
        safeRetry('request_timeout');
      });
    };

    onProgress({ phase: 'start', attempts: 0, elapsedMs: 0 });
    check();
  });
}

// ── Test runner minimal ────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

async function test(name, fn) {
  process.stdout.write(`  ${name} ... `);
  const t0 = Date.now();
  try {
    await fn();
    const elapsed = Date.now() - t0;
    console.log(`OK (${elapsed}ms)`);
    passed++;
  } catch (e) {
    console.log(`FAIL: ${e.message}`);
    failed++;
  }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

// ── Tests ──────────────────────────────────────────────────────────────────

async function main() {
  console.log('Tests v1.9.10 — waitForBackend\n');

  // 1. Sur port refusé : doit timeout proprement après maxAttempts
  await test('Port refusé → timeout après maxAttempts (PAS de runaway)', async () => {
    backendProcess = null;
    let progressCount = 0;
    const t0 = Date.now();
    try {
      await waitForBackend({
        intervalMs:      50,
        maxAttempts:     5,
        requestTimeoutMs: 100,
        onProgress: () => progressCount++,
      });
      throw new Error('aurait dû timeout');
    } catch (e) {
      const elapsed = Date.now() - t0;
      assert(e.message.includes('timeout'), `mauvais message: ${e.message}`);
      // 5 attempts × 50ms d'intervalle ≈ 250-400ms. Pas plus.
      assert(elapsed < 1500, `trop lent : ${elapsed}ms`);
      // Pas plus de ~6 progress events (start + 5 probing)
      assert(progressCount <= 8,
        `runaway détecté ! ${progressCount} progress events`);
    }
  });

  // 2. Intervalle respecté : 5 attempts × 200ms = ~1s
  await test('intervalMs respecté (5 × 200ms ≈ 1000ms)', async () => {
    backendProcess = null;
    const t0 = Date.now();
    try {
      await waitForBackend({
        intervalMs:      200,
        maxAttempts:     5,
        requestTimeoutMs: 100,
      });
    } catch (e) {
      const elapsed = Date.now() - t0;
      // Min : 4 × 200 = 800ms (le 5e attempt fail avant timeout)
      // Max : 5 × 300ms (avec marge) = 1500ms
      assert(elapsed >= 600 && elapsed < 2000,
        `timing hors plage : ${elapsed}ms (attendu 600-2000)`);
    }
  });

  // 3. Si backend devient ready entre deux probes → resolve
  await test('Backend devient ready → resolve avec attempts > 0', async () => {
    backendProcess = null;
    // Démarrer un serveur HTTP local après 300ms
    const server = http.createServer((req, res) => {
      if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end('{"ok":true}');
      } else {
        res.writeHead(404); res.end();
      }
    });
    await new Promise(r => server.listen(38765, '127.0.0.1', r));

    try {
      const info = await waitForBackend({
        intervalMs:      100,
        maxAttempts:     20,
        requestTimeoutMs: 500,
      });
      assert(info.attempts >= 1, `attempts=${info.attempts}`);
      assert(info.elapsedMs < 2000, `trop lent : ${info.elapsedMs}ms`);
    } finally {
      server.close();
    }
  });

  // 4. backendProcess.exitCode défini → reject immédiat
  await test('Backend process mort → reject immédiat (pas de probes)', async () => {
    backendProcess = { exitCode: 1 };
    let progressCount = 0;
    const t0 = Date.now();
    try {
      await waitForBackend({
        intervalMs:      1000,
        maxAttempts:     60,
        onProgress: () => progressCount++,
      });
      throw new Error('aurait dû reject');
    } catch (e) {
      const elapsed = Date.now() - t0;
      assert(e.message.includes('exited'), `mauvais message: ${e.message}`);
      assert(elapsed < 200, `pas immédiat : ${elapsed}ms`);
    } finally {
      backendProcess = null;
    }
  });

  // 5. Régression : reproduire le bug 1007/30s (sans le fix)
  // Note : on ne peut pas tester la BUG version dans le même fichier sans
  // dupliquer. Mais on peut prouver que la nouvelle version ne le fait pas :
  // 30s de probing à 50ms d'intervalle = 600 attempts max. On lance avec
  // intervalMs court et on vérifie qu'on ne dépasse pas le compteur.
  await test('Anti-runaway : 30 attempts × 50ms ≤ ~2s wall time', async () => {
    backendProcess = null;
    const t0 = Date.now();
    try {
      await waitForBackend({
        intervalMs:      50,
        maxAttempts:     30,
        requestTimeoutMs: 200,
      });
    } catch (e) {
      const elapsed = Date.now() - t0;
      // Doit absolument être borné par maxAttempts × (intervalMs + requestTimeoutMs)
      // = 30 × (50 + 200) = 7.5s max. Mais sur ECONNREFUSED instantané :
      // ≈ 30 × 50ms = 1.5s
      assert(elapsed < 3000, `runaway : ${elapsed}ms`);
    }
  });

  // 6. v1.9.11 — BACKEND_URL malformé ne doit PAS crasher, mais reject proprement
  await test('BACKEND_URL invalide → reject proprement (pas de crash)', async () => {
    backendProcess = null;
    // Patcher temporairement BACKEND_URL pour ce test
    const original = BACKEND_URL_REF.value;
    BACKEND_URL_REF.value = 'pas-une-url';
    try {
      await waitForBackend({
        intervalMs:      100,
        maxAttempts:     5,
        requestTimeoutMs: 200,
      });
      throw new Error('aurait dû reject');
    } catch (e) {
      assert(e.message.toLowerCase().includes('invalide')
              || e.message.toLowerCase().includes('invalid'),
        `message inattendu: ${e.message}`);
    } finally {
      BACKEND_URL_REF.value = original;
    }
  });

  console.log(`\n${passed}/${passed + failed} tests OK\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch(e => {
  console.error('Test runner crash:', e);
  process.exit(2);
});
