/**
 * Nova Assistant Desktop — Renderer script
 *
 * Adapté depuis Jarvis (MIT) — modifications :
 *   - URL WebSocket dynamique via Electron IPC (jarvisShell.backendWsUrl)
 *   - URL HTTP backend via jarvisShell.backendHttpUrl
 *   - Polling caméra (GET /api/camera/status) toutes les 5s
 *   - Commandes caméra (test, start, stop, snapshot)
 *   - Polling monitoring (GET /api/monitoring/status) toutes les 10s
 *   - Textes en français
 *   - Branding NOVA (pas JARVIS)
 */
(function () {
  'use strict';

  // ── État global ───────────────────────────────────────────────────────────
  var state = {
    ws: null,
    settings: {},
    projects: [],
    chats: [],
    messages: [],
    currentProjectId: null,
    currentChatId: null,
    assistantBuffer: '',
    reconnectTimer: null,
    isStreaming: false,
    recognition: null,
    connected: false,
    voiceMode: false,
    detectedModels: {},
    isDetecting: false,
    backendWsUrl: 'ws://127.0.0.1:8000',
    backendHttpUrl: 'http://127.0.0.1:8000',
    cameraPollingTimer: null,
    // ── Mode vocal MediaRecorder ─────────────────────────────────────────
    mediaRecorder:   null,
    mediaStream:     null,
    audioChunks:     [],
    isRecording:     false,
    // ── v1.9.6 : Mode vocal continu + VAD + métriques ────────────────────
    continuousMode:        false,     // boucle automatique on/off
    vadEnabled:            true,      // détection silence frontend
    vadAudioCtx:           null,
    vadAnalyser:           null,
    vadSourceNode:         null,
    vadCheckInterval:      null,
    vadSilenceStartedAt:   0,
    vadVoiceDetectedAt:    0,
    vadRmsSamples:         [],        // pour calibration bruit ambiant
    vadNoiseFloor:         0.01,
    vadConfig: {
      silenceMs:           1500,      // arrêt enregistrement après 1.5s de silence
      minVoiceMs:          400,       // ignorer si < 400ms de voix
      sampleEveryMs:       100,
      voiceMultiplier:     2.5,       // seuil = noise_floor × N
      maxRecordMs:         15000,     // sécurité : arrêter si trop long
    },
    voiceTimings:          {},        // record_ms, stt_ms, llm_ms, tts_ms, total_ms
    interruptionRequested: false,
    isAssistantSpeaking:   false,     // true entre assistant_start et assistant_end
    monitoringPollingTimer: null,
  };

  var els = {};

  // ── Init ──────────────────────────────────────────────────────────────────
  async function init() {
    try {
      console.log('Nova: Démarrage...');
      cacheElements();
      loadSettings();
      loadTheme();
      bindEvents();
      initSpeech();

      // Récupérer les URLs backend depuis Electron IPC
      if (window.jarvisShell) {
        try {
          var wsBase = await window.jarvisShell.backendWsUrl();
          if (wsBase) state.backendWsUrl = wsBase;
          var httpBase = await window.jarvisShell.backendHttpUrl();
          if (httpBase) state.backendHttpUrl = httpBase;
        } catch (e) {
          console.warn('Nova: IPC unavailable, using defaults');
        }
      }

      connect();
      startClock();
      startCameraPolling();
      startMonitoringPolling();
      showToast('Nova prêt');
    } catch (e) {
      showError('Erreur init: ' + e.message);
    }
  }

  function $(id) { return document.getElementById(id); }

  function cacheElements() {
    var ids = [
      'connectionStatus', 'projectList', 'chatList', 'messages', 'messageInput',
      'micBtn', 'sendBtn', 'newChatBtn', 'newProjectBtn', 'settingsBtn',
      'settingsPanel', 'providerSetting', 'modelSetting', 'refreshModelsBtn',
      'quickModelSelect', 'voiceSetting', 'closeSettingsBtn', 'saveSettingsBtn',
      'coreStatus', 'currentTime', 'aiProvider', 'toast', 'statusText',
      'chatMode', 'voiceMode', 'voiceStatus', 'voiceCutBtn', 'modelStatus',
      'themeGrid',
      // v1.9.6 — Mode vocal continu
      'continuousBtn', 'continuousBtnMain', 'voiceMachineState', 'voiceTimings',
      // Nova
      'cameraBtn', 'cameraPanel', 'closeCameraBtn',
      'camState', 'camSource', 'camFps', 'camError',
      'camTestBtn', 'camStartBtn', 'camStopBtn', 'camSnapshotBtn', 'camAnalyzeBtn',
      'snapshotArea', 'snapshotImg', 'snapshotTime', 'camLog',
      'cameraStatVal',
      // Sidebar status
      'sysBackend', 'sysCam', 'sysDb',
      // Perf debug panel
      'perfBtn', 'perfPanel', 'closePerfBtn',
      'perfFirstToken', 'perfTotal', 'perfOllama', 'perfTokens', 'perfSpeed',
      'perfModel', 'perfBackend',
    ];
    ids.forEach(function (id) { els[id] = $(id); });
  }

  // ── Paramètres localStorage ───────────────────────────────────────────────
  function loadSettings() {
    try {
      var saved = localStorage.getItem('nova_settings');
      if (saved) Object.assign(state.settings, JSON.parse(saved));
    } catch (e) {}
  }

  function saveSettingsToStorage() {
    try {
      localStorage.setItem('nova_settings', JSON.stringify(state.settings));
    } catch (e) {}
  }

  // ── Événements ────────────────────────────────────────────────────────────
  function bindEvents() {
    if (els.sendBtn)      els.sendBtn.onclick    = function () { sendMessage(); };
    if (els.messageInput) els.messageInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') sendMessage();
    });

    if (els.newChatBtn) els.newChatBtn.onclick = function () {
      send('create_chat', { projectId: state.currentProjectId, title: 'Nouvelle session' });
    };
    if (els.newProjectBtn) els.newProjectBtn.onclick = function () {
      var name = prompt('Nom du projet :');
      if (name && name.trim()) send('create_project', { name: name.trim() });
    };

    if (els.settingsBtn)      els.settingsBtn.onclick      = function () { els.settingsPanel.hidden = false; };
    if (els.closeSettingsBtn) els.closeSettingsBtn.onclick = function () { els.settingsPanel.hidden = true; };
    if (els.saveSettingsBtn)  els.saveSettingsBtn.onclick  = function () { saveSettings(); };

    if (els.providerSetting) {
      els.providerSetting.onchange = function () {
        autoDetectModels(this.value);
      };
    }
    if (els.modelSetting) {
      els.modelSetting.onchange = function () { changeModel(this.value); };
    }
    if (els.quickModelSelect) {
      els.quickModelSelect.onchange = function () { changeModel(this.value); };
      els.quickModelSelect.onclick  = function (e) { e.stopPropagation(); };
    }
    if (els.refreshModelsBtn) {
      els.refreshModelsBtn.onclick = function () {
        autoDetectModels(els.providerSetting ? els.providerSetting.value : 'ollama');
      };
    }

    // Thèmes
    document.querySelectorAll('.theme-btn').forEach(function (btn) {
      btn.onclick = function () { applyTheme(this.dataset.theme); };
    });

    // Onglets settings
    document.querySelectorAll('.modal-tabs .tab').forEach(function (tab) {
      tab.onclick = function () {
        var name = this.dataset.tab;
        document.querySelectorAll('.modal-tabs .tab').forEach(function (t) {
          t.classList.toggle('active', t.dataset.tab === name);
        });
        document.querySelectorAll('.tab-content').forEach(function (p) {
          p.classList.toggle('active', p.dataset.page === name);
        });
      };
    });

    // Micro / vocal
    if (els.micBtn)      els.micBtn.onclick      = function () { state.voiceMode ? stopVoiceMode() : startVoiceMode(); };
    if (els.voiceCutBtn) els.voiceCutBtn.onclick = function () { stopVoiceMode(); };
    // v1.9.6 — Mode vocal continu (toggle depuis 2 emplacements UI)
    if (els.continuousBtn) {
      els.continuousBtn.onclick = function () {
        state.continuousMode ? stopContinuousVoiceMode() : startContinuousVoiceMode();
      };
    }
    if (els.continuousBtnMain) {
      els.continuousBtnMain.onclick = function () {
        state.continuousMode ? stopContinuousVoiceMode() : startContinuousVoiceMode();
      };
    }

    // Caméra
    if (els.perfBtn)       els.perfBtn.onclick       = togglePerfPanel;
    if (els.closePerfBtn)  els.closePerfBtn.onclick  = togglePerfPanel;
    if (els.cameraBtn)     els.cameraBtn.onclick     = toggleCameraPanel;
    if (els.closeCameraBtn) els.closeCameraBtn.onclick = toggleCameraPanel;
    if (els.camTestBtn)    els.camTestBtn.onclick     = cameraTest;
    if (els.camStartBtn)   els.camStartBtn.onclick    = cameraStart;
    if (els.camStopBtn)    els.camStopBtn.onclick     = cameraStop;
    if (els.camSnapshotBtn) els.camSnapshotBtn.onclick = cameraSnapshot;
    if (els.camAnalyzeBtn)  els.camAnalyzeBtn.onclick  = cameraAnalyzeNow;

    // Escape
    document.onkeydown = function (e) {
      if (e.key === 'Escape') {
        if (els.settingsPanel) els.settingsPanel.hidden = true;
        stopVoiceMode();
        if (els.cameraPanel) els.cameraPanel.style.display = 'none';
        if (els.chatMode)    els.chatMode.style.display    = 'flex';
      }
    };
  }

  // ── WebSocket ─────────────────────────────────────────────────────────────
  function connect() {
    var wsUrl = state.backendWsUrl + '/ws';
    try {
      state.ws = new WebSocket(wsUrl);
    } catch (e) {
      showError('Impossible de se connecter au backend');
      scheduleReconnect();
      return;
    }

    state.ws.onopen = function () {
      state.connected = true;
      if (els.connectionStatus) els.connectionStatus.textContent = 'SYSTÈME EN LIGNE';
      if (els.coreStatus)       els.coreStatus.textContent       = 'NOMINAL';
      if (els.statusText)       els.statusText.textContent       = 'En ligne. Prêt.';
      if (els.sysBackend)       els.sysBackend.textContent       = 'OK';
      updateHeaderModel();
    };

    state.ws.onmessage = function (e) {
      try {
        var m = JSON.parse(e.data);
        handleMessage(m.type, m.payload || {});
      } catch (err) { console.error('WS parse error', err); }
    };

    state.ws.onclose = function () {
      state.connected = false;
      if (els.connectionStatus) els.connectionStatus.textContent = 'DÉCONNECTÉ';
      if (els.sysBackend)       els.sysBackend.textContent       = 'DÉCO';
      scheduleReconnect();
    };

    state.ws.onerror = function () { showError('Erreur de connexion'); };
  }

  function scheduleReconnect() {
    if (state.reconnectTimer) clearTimeout(state.reconnectTimer);
    state.reconnectTimer = setTimeout(function () {
      if (!state.connected) connect();
    }, 3000);
  }

  function send(type, payload) {
    if (!state.ws || state.ws.readyState !== WebSocket.OPEN) return false;
    try {
      state.ws.send(JSON.stringify({ type: type, payload: payload || {} }));
      return true;
    } catch (e) { return false; }
  }

  // ── Handlers messages WS ──────────────────────────────────────────────────
  function handleMessage(type, payload) {
    switch (type) {
      case 'bootstrap':       loadBootstrap(payload);           break;
      case 'project_created':
        state.projects.unshift(payload.project);
        state.chats = [payload.chat];
        state.messages = [];
        state.currentProjectId = payload.project.id;
        state.currentChatId    = payload.chat.id;
        renderAll();
        showSuccess('Nouveau projet créé');
        break;
      case 'chat_created':
        state.chats.unshift(payload);
        state.currentChatId = payload.id;
        state.messages = [];
        renderAll();
        break;
      case 'chat_loaded':
        state.currentProjectId = payload.projectId;
        state.currentChatId    = payload.chatId;
        state.chats            = payload.chats    || [];
        state.messages         = payload.messages || [];
        renderAll();
        break;
      case 'settings':
        state.settings = Object.assign(state.settings, payload);
        applySettings();
        saveSettingsToStorage();
        updateHeaderModel();
        break;
      case 'assistant_start':
        startStream();
        // v1.9.6 — marquer assistant en train de parler (pour interruption VAD)
        state.isAssistantSpeaking = true;
        if (state.voiceTimings && state.voiceTimings.llm_start) {
          state.voiceTimings.assistant_start_ms = Date.now() - state.voiceTimings.llm_start;
        }
        break;
      case 'assistant_token':
        // En mode continu, si une interruption a été demandée → ignorer les tokens
        if (state.continuousMode && state.interruptionRequested) break;
        addToken(payload.token || '');
        break;
      case 'assistant_end':
        endStream(payload);
        // v1.9.6 — finaliser timings + relancer prochain tour si mode continu
        state.isAssistantSpeaking = false;
        if (state.voiceTimings && state.voiceTimings.llm_start) {
          state.voiceTimings.llm_ms   = Date.now() - state.voiceTimings.llm_start;
          state.voiceTimings.total_ms = Date.now() - (state.voiceTimings.record_start || state.voiceTimings.llm_start);
          _logVoiceTimings();
        }
        if (state.continuousMode) {
          if (state.interruptionRequested) {
            _setVoiceMachineState('interrupted');
            state.interruptionRequested = false;
          }
          // Court délai pour laisser l'UI/TTS se calmer avant nouvelle écoute
          setTimeout(function () {
            if (state.continuousMode) _continuousNextTurn();
          }, 300);
        }
        break;
      case 'models_detected':
        state.isDetecting = false;
        if (els.refreshModelsBtn) els.refreshModelsBtn.classList.remove('loading');
        handleModelsDetected(payload);
        break;
      case 'error': showError(payload.message || 'Erreur');     break;
      case 'perf_stats': updatePerfPanel(payload);              break;
    }
  }

  function loadBootstrap(payload) {
    if (payload.settings) {
      state.settings = Object.assign({}, state.settings, payload.settings);
    }
    state.projects          = payload.projects  || [];
    state.chats             = payload.chats     || [];
    state.messages          = payload.messages  || [];
    state.currentProjectId  = payload.currentProjectId;
    state.currentChatId     = payload.currentChatId;
    applySettings();
    renderAll();
    updateHeaderModel();
    // Détecter les modèles Ollama au démarrage
    send('detect_models', { provider: 'ollama' });
  }

  // ── Rendu UI ──────────────────────────────────────────────────────────────
  function renderAll() { renderProjects(); renderChats(); renderMessages(); }

  function renderProjects() {
    if (!els.projectList) return;
    els.projectList.innerHTML = '';
    state.projects.forEach(function (p) {
      var b = document.createElement('button');
      b.textContent = p.name;
      b.className = p.id === state.currentProjectId ? 'active' : '';
      b.onclick = function () { send('load_project', { projectId: p.id }); };
      els.projectList.appendChild(b);
    });
  }

  function renderChats() {
    if (!els.chatList) return;
    els.chatList.innerHTML = '';
    state.chats.slice(0, 50).forEach(function (c) {
      var b = document.createElement('button');
      b.textContent = c.title || 'Session';
      b.className = c.id === state.currentChatId ? 'active' : '';
      b.onclick = function () {
        send('load_chat', { projectId: c.project_id, chatId: c.id });
      };
      els.chatList.appendChild(b);
    });
  }

  // ── Sécurité XSS — échappement HTML ─────────────────────────────────────
  // Neutralise tous les caractères HTML spéciaux avant tout affichage.
  // Appliqué sur toute donnée utilisateur/backend avant insertion via innerHTML.
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Rendu markdown minimal sur texte déjà échappé.
  // Les balises produites (<pre>, <code>, <br>) sont les nôtres uniquement.
  function renderMarkdown(raw) {
    if (!raw) return '';
    var escaped = escapeHtml(raw);
    // Code blocks : ```...``` → <pre><code>...</code></pre>
    escaped = escaped.replace(/```([\s\S]*?)```/g, function (_, code) {
      return '<pre><code>' + code + '</code></pre>';
    });
    // Inline code : `...` → <code>...</code>
    escaped = escaped.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Sauts de ligne → <br>
    escaped = escaped.replace(/\n/g, '<br>');
    return escaped;
  }

  function renderMessages() {
    if (!els.messages) return;
    els.messages.innerHTML = '';
    state.messages.slice(-50).forEach(function (m) {
      var d = document.createElement('div');
      d.className = 'message ' + m.role;
      d.innerHTML = renderMarkdown(m.content);
      els.messages.appendChild(d);
    });
    els.messages.scrollTop = els.messages.scrollHeight;
  }

  // ── Envoi message ─────────────────────────────────────────────────────────
  function sendMessage(text) {
    var input = text || (els.messageInput ? els.messageInput.value.trim() : '');
    if (!input || state.isStreaming) return;
    if (!text && els.messageInput) els.messageInput.value = '';
    state.messages.push({ role: 'user', content: input });
    renderMessages();
    send('user_message', {
      projectId: state.currentProjectId,
      chatId:    state.currentChatId,
      text:      input,
    });
  }

  // ── Streaming ─────────────────────────────────────────────────────────────
  function startStream() {
    state.isStreaming    = true;
    state.assistantBuffer = '';
    if (els.statusText) {
      els.statusText.innerHTML =
        'Réflexion<span class="thinking-dots"><span></span><span></span><span></span></span>';
    }
    var reactorDisplay = document.querySelector('.reactor-display');
    var reactor        = document.querySelector('.jarvis-reactor');
    if (reactorDisplay) reactorDisplay.classList.add('thinking');
    if (reactor)        reactor.classList.add('thinking');

    var d = document.createElement('div');
    d.className       = 'message assistant';
    d.dataset.streaming = 'true';
    els.messages.appendChild(d);
    els.messages.scrollTop = els.messages.scrollHeight;
  }

  function addToken(t) {
    state.assistantBuffer += t;
    var s = els.messages ? els.messages.querySelector('[data-streaming="true"]') : null;
    if (s) {
      s.innerHTML =
        renderMarkdown(state.assistantBuffer) +
        '<span class="typing-cursor"></span>';
    }
    els.messages.scrollTop = els.messages.scrollHeight;

    if (state.assistantBuffer.length > 3) {
      var reactorDisplay = document.querySelector('.reactor-display');
      var reactor        = document.querySelector('.jarvis-reactor');
      if (reactorDisplay && reactorDisplay.classList.contains('thinking')) {
        reactorDisplay.classList.replace('thinking', 'replying');
      }
      if (reactor && reactor.classList.contains('thinking')) {
        reactor.classList.replace('thinking', 'replying');
      }
      if (els.statusText) els.statusText.textContent = 'Réponse en cours...';
    }
  }

  function endStream(payload) {
    state.isStreaming = false;
    if (els.statusText) els.statusText.textContent = 'En ligne. Prêt.';
    var reactorDisplay = document.querySelector('.reactor-display');
    var reactor        = document.querySelector('.jarvis-reactor');
    if (reactorDisplay) reactorDisplay.classList.remove('thinking', 'replying');
    if (reactor)        reactor.classList.remove('thinking', 'replying');

    var s = els.messages ? els.messages.querySelector('[data-streaming="true"]') : null;
    if (s) {
      var cursor = s.querySelector('.typing-cursor');
      if (cursor) cursor.remove();
      delete s.dataset.streaming;
    }
    state.chats    = payload.chats    || state.chats;
    state.messages = payload.messages || state.messages;
    renderAll();
    speakResponse();
  }

  function speakResponse() {
    if (!window.speechSynthesis) return;
    var last = state.messages[state.messages.length - 1];
    if (!last || last.role !== 'assistant') return;
    var text  = last.content.substring(0, 400);
    var utt   = new SpeechSynthesisUtterance(text);
    var lang  = (state.settings.voice || 'fr-FR').substring(0, 5);
    utt.lang  = lang;
    utt.rate  = 1.05;
    window.speechSynthesis.speak(utt);
  }

  // ── Mode vocal — MediaRecorder + backend /api/voice/transcribe ────────────
  //
  // Flux complet :
  //   1. clic micro      → getUserMedia → MediaRecorder.start()
  //   2. clic ARRÊTER    → MediaRecorder.stop() → Blob audio
  //   3. POST FormData   → /api/voice/transcribe (champ "file")
  //   4. transcription   → injecté dans le chat via sendMessage(text)
  //   5. réponse Nova    → streaming WebSocket normal (assistant_token)
  //
  // Logs console (préfixés [VOICE]) :
  //   RECORD_START / RECORD_STOP / AUDIO_BLOB_SIZE
  //   VOICE_UPLOAD_START / VOICE_UPLOAD_END / TRANSCRIPT_RECEIVED

  function _vlog(tag, data) {
    try { console.log('[VOICE] ' + tag, data || ''); } catch (e) {}
  }

  function _setVoiceStatus(text) {
    if (els.voiceStatus) els.voiceStatus.textContent = text;
  }

  async function startVoiceMode() {
    if (state.isRecording) return;

    // Vérifier la disponibilité de l'API MediaRecorder
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      showError('Enregistrement audio non disponible dans cet environnement.');
      return;
    }

    // Bascule UI vers le mode vocal AVANT d'attendre le micro
    state.voiceMode = true;
    if (els.chatMode)  els.chatMode.style.display  = 'none';
    if (els.voiceMode) els.voiceMode.style.display = 'flex';
    if (els.micBtn)    els.micBtn.classList.add('active');
    _setVoiceStatus('Activation du micro...');

    // Demande d'accès micro
    var stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      _vlog('MIC_DENIED', err && err.name);
      if (err && err.name === 'NotAllowedError') {
        showError('Accès au micro refusé. Autorisez Nova dans les paramètres système.');
      } else if (err && err.name === 'NotFoundError') {
        showError('Aucun micro détecté.');
      } else {
        showError('Impossible d\'accéder au micro : ' + (err && err.message ? err.message : err));
      }
      _resetVoiceUI();
      return;
    }

    // Choisir un mimeType supporté (Electron/Chromium : webm/opus en priorité)
    var mimeType = '';
    var candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    for (var i = 0; i < candidates.length; i++) {
      if (MediaRecorder.isTypeSupported(candidates[i])) { mimeType = candidates[i]; break; }
    }

    var recorder;
    try {
      recorder = mimeType ? new MediaRecorder(stream, { mimeType: mimeType })
                          : new MediaRecorder(stream);
    } catch (err) {
      _vlog('RECORDER_INIT_FAIL', err && err.message);
      showError('Impossible d\'initialiser l\'enregistrement audio.');
      stream.getTracks().forEach(function (t) { t.stop(); });
      _resetVoiceUI();
      return;
    }

    state.mediaStream    = stream;
    state.mediaRecorder  = recorder;
    state.audioChunks    = [];
    state.isRecording    = true;

    recorder.ondataavailable = function (e) {
      if (e.data && e.data.size > 0) state.audioChunks.push(e.data);
    };

    recorder.onstop = function () {
      _vlog('RECORD_STOP');
      // Libérer le micro immédiatement
      if (state.mediaStream) {
        state.mediaStream.getTracks().forEach(function (t) { t.stop(); });
        state.mediaStream = null;
      }

      var mt = recorder.mimeType || mimeType || 'audio/webm';
      var blob = new Blob(state.audioChunks, { type: mt });
      _vlog('AUDIO_BLOB_SIZE', blob.size + ' bytes (' + mt + ')');

      if (!blob.size || blob.size < 800) {
        showError('Aucun son enregistré. Parlez plus longtemps.');
        _resetVoiceUI();
        return;
      }

      _uploadAndTranscribe(blob, mt);
    };

    recorder.onerror = function (e) {
      _vlog('RECORDER_ERROR', e && e.error);
      showError('Erreur d\'enregistrement audio.');
      _resetVoiceUI();
    };

    _vlog('RECORD_START', { mimeType: recorder.mimeType });
    _setVoiceStatus('Écoute en cours... Parlez puis cliquez ARRÊTER.');
    recorder.start();
  }

  function stopVoiceMode() {
    // Si on est en train d'enregistrer → déclencher stop (uploadera ensuite)
    if (state.isRecording && state.mediaRecorder && state.mediaRecorder.state !== 'inactive') {
      _setVoiceStatus('Transcription en cours...');
      try {
        state.mediaRecorder.stop();      // déclenche recorder.onstop
        state.isRecording = false;
      } catch (e) {
        _vlog('STOP_FAIL', e && e.message);
        _resetVoiceUI();
      }
      return;
    }
    // Sinon : simple fermeture UI
    _resetVoiceUI();
  }

  function _resetVoiceUI() {
    state.isRecording  = false;
    state.voiceMode    = false;
    state.audioChunks  = [];
    if (state.mediaStream) {
      try { state.mediaStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
      state.mediaStream = null;
    }
    state.mediaRecorder = null;
    if (els.voiceMode)   els.voiceMode.style.display = 'none';
    if (els.chatMode)    els.chatMode.style.display  = 'flex';
    if (els.voiceStatus) els.voiceStatus.textContent = '';
    if (els.micBtn)      els.micBtn.classList.remove('active');
  }

  async function _uploadAndTranscribe(blob, mimeType) {
    var ext = (mimeType.indexOf('webm') !== -1) ? 'webm'
            : (mimeType.indexOf('ogg')  !== -1) ? 'ogg'
            : (mimeType.indexOf('mp4')  !== -1) ? 'm4a' : 'webm';
    var filename = 'voice_' + Date.now() + '.' + ext;
    var url = state.backendHttpUrl + '/api/voice/transcribe';

    var fd = new FormData();
    fd.append('file', blob, filename);

    _vlog('VOICE_UPLOAD_START', { url: url, filename: filename, size: blob.size });
    _setVoiceStatus('Envoi audio (' + Math.round(blob.size / 1024) + ' Ko)...');

    var data;
    try {
      var t0 = Date.now();
      var resp = await fetch(url, { method: 'POST', body: fd });
      _vlog('VOICE_UPLOAD_END', { status: resp.status, ms: Date.now() - t0 });

      if (resp.status === 400) {
        showError('STT désactivé côté backend. Activez ENABLE_STT dans .env.');
        _resetVoiceUI();
        return;
      }
      if (!resp.ok) {
        var errTxt = '';
        try { errTxt = await resp.text(); } catch (e) {}
        showError('Endpoint vocal indisponible (' + resp.status + ').');
        _vlog('VOICE_UPLOAD_HTTP_ERR', errTxt.substring(0, 200));
        _resetVoiceUI();
        return;
      }
      data = await resp.json();
    } catch (err) {
      _vlog('VOICE_UPLOAD_NETWORK_ERR', err && err.message);
      showError('Backend vocal injoignable : ' + (err && err.message ? err.message : err));
      _resetVoiceUI();
      return;
    }

    _vlog('TRANSCRIPT_RECEIVED', data);

    var text = (data && data.text || '').trim();
    if (!text || data.is_empty) {
      showError('Transcription vide. Parlez plus fort ou plus longtemps.');
      _resetVoiceUI();
      return;
    }

    // Vérifier WebSocket prêt avant d'envoyer
    if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
      showError('Connexion au chat IA perdue. Réessayez.');
      _resetVoiceUI();
      return;
    }

    _setVoiceStatus('Compris : ' + text);
    // Injecter la transcription dans le chat (réponse Nova arrivera via WS)
    sendMessage(text);

    // Fermer le mode vocal après envoi — la réponse s'affichera dans le chat
    setTimeout(_resetVoiceUI, 600);
  }

  // initSpeech conservé pour compatibilité d'appel (no-op : remplacé par MediaRecorder)
  function initSpeech() {
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      console.warn('[VOICE] MediaRecorder indisponible — mode vocal désactivé.');
    } else {
      console.log('[VOICE] MediaRecorder disponible — mode vocal prêt.');
    }
  }

  // ────────────────────────────────────────────────────────────────────────
  // v1.9.6 : MODE VOCAL CONTINU + VAD frontend + INTERRUPTION + LATENCE
  // ────────────────────────────────────────────────────────────────────────
  //
  // Le mode "continu" est une boucle automatique :
  //   1. activer (bouton dédié)
  //   2. ouvrir le micro
  //   3. VAD attend la voix
  //   4. enregistre tant que la voix parle
  //   5. coupe automatiquement après _vadConfig.silenceMs de silence
  //   6. envoie au backend, attend réponse
  //   7. si réponse Nova en streaming + voix utilisateur détectée → interrupt
  //   8. retour à l'étape 3 jusqu'à désactivation
  //
  // Indépendant du mode one-shot existant (clic ARRÊTER manuel).

  function startContinuousVoiceMode() {
    if (state.continuousMode) return;
    state.continuousMode = true;
    state.interruptionRequested = false;
    _vlog('CONTINUOUS_MODE_START');
    if (els.continuousBtn) {
      els.continuousBtn.classList.add('active');
      els.continuousBtn.textContent = 'ARRÊTER ÉCOUTE CONTINUE';
    }
    _continuousNextTurn();
  }

  function stopContinuousVoiceMode() {
    if (!state.continuousMode) return;
    state.continuousMode = false;
    _vlog('CONTINUOUS_MODE_STOP');
    _stopVADCheck();
    // Si on était en train d'enregistrer → arrêter proprement
    if (state.isRecording && state.mediaRecorder && state.mediaRecorder.state !== 'inactive') {
      try { state.mediaRecorder.stop(); } catch (e) {}
    }
    _resetVoiceUI();
    if (els.continuousBtn) {
      els.continuousBtn.classList.remove('active');
      els.continuousBtn.textContent = 'ÉCOUTE CONTINUE';
    }
  }

  async function _continuousNextTurn() {
    if (!state.continuousMode) return;
    state.voiceTimings = { record_start: Date.now() };

    // UI : passer en mode "listening"
    _setVoiceMachineState('listening');
    _setVoiceStatus('🎤 J\'écoute... parlez');

    // Préparer le micro si pas déjà fait
    if (!state.mediaStream) {
      try {
        state.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch (err) {
        _vlog('CONTINUOUS_MIC_ERR', err && err.name);
        if (err && err.name === 'NotAllowedError') {
          showError('Accès micro refusé. Mode continu désactivé.');
        } else if (err && err.name === 'NotFoundError') {
          showError('Aucun micro détecté. Mode continu désactivé.');
        } else {
          showError('Micro indisponible : ' + (err && err.message ? err.message : err));
        }
        stopContinuousVoiceMode();
        return;
      }
    }

    // Calibrer noise floor sur 300ms si pas encore fait
    if (state.vadRmsSamples.length === 0) {
      await _calibrateNoiseFloor();
    }

    // Démarrer enregistrement + VAD
    _startRecordingWithVAD();
  }

  function _startRecordingWithVAD() {
    state.audioChunks = [];

    var mimeType = '';
    var candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    for (var i = 0; i < candidates.length; i++) {
      if (MediaRecorder.isTypeSupported(candidates[i])) { mimeType = candidates[i]; break; }
    }
    var recorder;
    try {
      recorder = mimeType ? new MediaRecorder(state.mediaStream, { mimeType: mimeType })
                          : new MediaRecorder(state.mediaStream);
    } catch (err) {
      _vlog('CONTINUOUS_RECORDER_FAIL', err && err.message);
      stopContinuousVoiceMode();
      return;
    }
    state.mediaRecorder = recorder;
    state.isRecording = true;
    state.vadSilenceStartedAt = 0;
    state.vadVoiceDetectedAt = 0;

    recorder.ondataavailable = function (e) {
      if (e.data && e.data.size > 0) state.audioChunks.push(e.data);
    };
    recorder.onstop = function () {
      _vlog('CONTINUOUS_RECORD_STOP');
      var mt = recorder.mimeType || mimeType || 'audio/webm';
      var blob = new Blob(state.audioChunks, { type: mt });
      state.voiceTimings.record_ms = Date.now() - (state.voiceTimings.record_start || Date.now());
      state.isRecording = false;
      _stopVADCheck();

      // Si l'utilisateur a coupé le mode pendant l'enregistrement → ne pas uploader
      if (!state.continuousMode) {
        _vlog('CONTINUOUS_DISCARDED', { reason: 'mode_stopped' });
        return;
      }

      // Si pas de voix détectée → recommencer un tour sans uploader
      var voiceMs = state.vadVoiceDetectedAt
        ? Math.max(0, state.vadSilenceStartedAt || Date.now()) - state.vadVoiceDetectedAt
        : 0;
      if (voiceMs < state.vadConfig.minVoiceMs) {
        _vlog('CONTINUOUS_NOVOICE', { voiceMs: voiceMs, size: blob.size });
        // Pause courte pour ne pas tourner en boucle CPU si silence complet
        setTimeout(_continuousNextTurn, 200);
        return;
      }
      if (!blob.size || blob.size < 800) {
        _vlog('CONTINUOUS_TINY_BLOB', { size: blob.size });
        setTimeout(_continuousNextTurn, 200);
        return;
      }
      _continuousUpload(blob, mt);
    };

    recorder.onerror = function (e) {
      _vlog('CONTINUOUS_RECORDER_ERROR', e && e.error);
      stopContinuousVoiceMode();
    };

    recorder.start();
    _vlog('CONTINUOUS_RECORD_START', { mimeType: recorder.mimeType });

    // Lancer la boucle VAD
    _startVADCheck();
  }

  // ── VAD côté frontend (RMS via AnalyserNode) ────────────────────────────

  async function _calibrateNoiseFloor() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { state.vadEnabled = false; return; }
      if (!state.vadAudioCtx) state.vadAudioCtx = new AC();
      if (!state.vadSourceNode) {
        state.vadSourceNode = state.vadAudioCtx.createMediaStreamSource(state.mediaStream);
      }
      if (!state.vadAnalyser) {
        state.vadAnalyser = state.vadAudioCtx.createAnalyser();
        state.vadAnalyser.fftSize = 512;
        state.vadSourceNode.connect(state.vadAnalyser);
      }
      // Échantillonner 300ms avant que l'utilisateur parle
      var samples = [];
      var t0 = Date.now();
      var buf = new Uint8Array(state.vadAnalyser.fftSize);
      while (Date.now() - t0 < 300) {
        state.vadAnalyser.getByteTimeDomainData(buf);
        samples.push(_rmsFromBuffer(buf));
        await new Promise(function (r) { setTimeout(r, 30); });
      }
      // Médiane
      samples.sort(function (a, b) { return a - b; });
      state.vadNoiseFloor = samples[Math.floor(samples.length / 2)] || 0.01;
      state.vadRmsSamples = samples;
      _vlog('VAD_CALIB', { noise_floor: state.vadNoiseFloor.toFixed(4) });
    } catch (e) {
      _vlog('VAD_CALIB_FAIL', e && e.message);
      state.vadEnabled = false;
    }
  }

  function _rmsFromBuffer(uint8Buf) {
    // uint8Buf : 0..255 centré sur 128
    var sum = 0;
    for (var i = 0; i < uint8Buf.length; i++) {
      var v = (uint8Buf[i] - 128) / 128;
      sum += v * v;
    }
    return Math.sqrt(sum / uint8Buf.length);
  }

  function _startVADCheck() {
    if (!state.vadEnabled || !state.vadAnalyser) return;
    var buf = new Uint8Array(state.vadAnalyser.fftSize);
    var threshold = state.vadNoiseFloor * state.vadConfig.voiceMultiplier;
    var recordStartedAt = Date.now();

    state.vadCheckInterval = setInterval(function () {
      if (!state.isRecording) {
        _stopVADCheck();
        return;
      }
      // Sécurité : max record
      if (Date.now() - recordStartedAt > state.vadConfig.maxRecordMs) {
        _vlog('VAD_MAX_RECORD');
        _stopRecorderSafe();
        return;
      }
      state.vadAnalyser.getByteTimeDomainData(buf);
      var rms = _rmsFromBuffer(buf);
      var now = Date.now();

      if (rms > threshold) {
        // Voix détectée
        if (!state.vadVoiceDetectedAt) state.vadVoiceDetectedAt = now;
        state.vadSilenceStartedAt = 0;

        // INTERRUPTION : si Nova parle et qu'on détecte de la voix → couper Nova
        if (state.isAssistantSpeaking && !state.interruptionRequested) {
          state.interruptionRequested = true;
          _requestVoiceInterrupt();
        }
      } else {
        // Silence
        if (state.vadVoiceDetectedAt && !state.vadSilenceStartedAt) {
          state.vadSilenceStartedAt = now;
        }
        if (state.vadSilenceStartedAt && (now - state.vadSilenceStartedAt) >= state.vadConfig.silenceMs) {
          // Couper après N ms de silence post-voix
          _vlog('VAD_SILENCE_REACHED', {
            voice_ms: state.vadSilenceStartedAt - state.vadVoiceDetectedAt,
            silence_ms: now - state.vadSilenceStartedAt,
          });
          _stopRecorderSafe();
        }
      }
    }, state.vadConfig.sampleEveryMs);
  }

  function _stopVADCheck() {
    if (state.vadCheckInterval) {
      clearInterval(state.vadCheckInterval);
      state.vadCheckInterval = null;
    }
  }

  function _stopRecorderSafe() {
    _stopVADCheck();
    if (state.mediaRecorder && state.mediaRecorder.state !== 'inactive') {
      try { state.mediaRecorder.stop(); } catch (e) {}
    }
  }

  // ── Upload + chaîne LLM en mode continu ────────────────────────────────

  async function _continuousUpload(blob, mimeType) {
    _setVoiceMachineState('thinking');
    _setVoiceStatus('💭 Transcription...');

    var ext = (mimeType.indexOf('webm') !== -1) ? 'webm'
            : (mimeType.indexOf('ogg')  !== -1) ? 'ogg'
            : (mimeType.indexOf('mp4')  !== -1) ? 'm4a' : 'webm';
    var fd = new FormData();
    fd.append('file', blob, 'voice_cont_' + Date.now() + '.' + ext);

    var url = state.backendHttpUrl + '/api/voice/transcribe';
    var t0 = Date.now();
    var data;
    try {
      var resp = await fetch(url, { method: 'POST', body: fd });
      state.voiceTimings.stt_ms = Date.now() - t0;
      if (resp.status === 400) {
        showError('STT désactivé côté backend.');
        stopContinuousVoiceMode();
        return;
      }
      if (!resp.ok) {
        showError('Endpoint vocal indisponible (' + resp.status + ').');
        stopContinuousVoiceMode();
        return;
      }
      data = await resp.json();
    } catch (err) {
      _vlog('CONTINUOUS_STT_FAIL', err && err.message);
      if (state.continuousMode) {
        // Recovery : retry après pause
        setTimeout(_continuousNextTurn, 1000);
      }
      return;
    }

    var text = (data && data.text || '').trim();
    _vlog('CONTINUOUS_STT_RESULT', {
      text: text.substring(0, 80),
      wake_matched: data.wake_matched,
      stt_ms: state.voiceTimings.stt_ms,
    });

    // STT vide → retour à l'écoute sans rien dire
    if (!text || data.is_empty) {
      _vlog('CONTINUOUS_EMPTY_STT');
      _continuousNextTurn();
      return;
    }

    // Wake word strict : si activé et non matché → ignorer silencieusement
    if (data.wake_matched === false) {
      _vlog('CONTINUOUS_WAKE_MISS', { text: text });
      _setVoiceStatus('(ignoré : pas de wake-word)');
      setTimeout(_continuousNextTurn, 500);
      return;
    }

    // Si wake-word matché et command vide (juste "Nova") → relancer écoute
    var toSend = data.wake_command || text;
    if (data.wake_matched === true && !toSend) {
      _vlog('CONTINUOUS_WAKE_NO_COMMAND');
      _setVoiceStatus('Oui ?');
      setTimeout(_continuousNextTurn, 500);
      return;
    }

    // Envoyer via WebSocket — la réponse arrivera en streaming
    if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
      showError('Connexion chat IA perdue.');
      stopContinuousVoiceMode();
      return;
    }

    _setVoiceMachineState('speaking');
    _setVoiceStatus('🗣️ Nova : ' + toSend.substring(0, 50));
    state.voiceTimings.llm_start = Date.now();
    state.interruptionRequested = false;
    sendMessage(toSend);
    // _continuousNextTurn() sera appelé à l'arrivée de assistant_end (voir hook plus bas)
  }

  function _requestVoiceInterrupt() {
    _vlog('VOICE_INTERRUPT_REQUEST');
    // v1.9.6 : utiliser l'alias /api/voice/interrupt (la consigne le demande)
    // Stoppe aussi le TTS local navigateur si actif.
    try {
      if (window.speechSynthesis && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
        _vlog('VOICE_INTERRUPT_LOCAL_TTS_CANCELLED');
      }
    } catch (e) {}
    var url = state.backendHttpUrl + '/api/voice/interrupt';
    fetch(url, { method: 'POST' })
      .then(function () { _vlog('VOICE_INTERRUPT_SENT'); })
      .catch(function (e) { _vlog('VOICE_INTERRUPT_FAIL', e && e.message); });
  }

  function _setVoiceMachineState(s) {
    // s : listening | thinking | speaking | interrupted | idle
    var label = '';
    if (s === 'listening')  label = '🎤 ÉCOUTE';
    else if (s === 'thinking')   label = '💭 RÉFLEXION';
    else if (s === 'speaking')   label = '🗣️ RÉPONSE';
    else if (s === 'interrupted')label = '✋ INTERROMPU';
    else                          label = '⚪ INACTIF';
    if (els.voiceMachineState) {
      els.voiceMachineState.textContent = label;
      els.voiceMachineState.dataset.state = s;
    }
  }

  function _logVoiceTimings() {
    var t = state.voiceTimings || {};
    var parts = [];
    if (t.record_ms != null) parts.push('rec ' + t.record_ms + 'ms');
    if (t.stt_ms != null)    parts.push('stt ' + t.stt_ms + 'ms');
    if (t.llm_ms != null)    parts.push('llm ' + t.llm_ms + 'ms');
    if (t.tts_ms != null)    parts.push('tts ' + t.tts_ms + 'ms');
    if (t.total_ms != null)  parts.push('tot ' + t.total_ms + 'ms');
    var line = parts.join(' · ');
    console.log('[VOICE_TIMING] ' + line);
    if (els.voiceTimings) els.voiceTimings.textContent = line;
  }

  // ── Paramètres et modèles ─────────────────────────────────────────────────
  function applySettings() {
    var p = state.settings.provider || 'ollama';
    if (els.providerSetting) els.providerSetting.value = p;
    if (els.voiceSetting)    els.voiceSetting.value    = state.settings.voice || 'fr-FR-HenriNeural';
    loadTheme();
    document.querySelectorAll('.theme-btn').forEach(function (btn) {
      btn.classList.toggle('active', btn.dataset.theme === (state.settings.theme || 'jarvis'));
    });
    updateHeaderModel();
  }

  function saveSettings() {
    var p     = els.providerSetting ? els.providerSetting.value : 'ollama';
    var voice = els.voiceSetting    ? els.voiceSetting.value    : 'fr-FR-HenriNeural';
    var patch = {
      provider: p,
      model:    els.modelSetting ? els.modelSetting.value : (state.settings.model || ''),
      voice:    voice,
      onboarding_completed: 'true',
    };
    state.settings = patch;
    saveSettingsToStorage();
    send('settings_update', patch);
    if (els.settingsPanel) els.settingsPanel.hidden = true;
    showToast('Paramètres sauvegardés');
    applySettings();
  }

  function changeModel(model) {
    if (!model) return;
    state.settings.model = model;
    saveSettingsToStorage();
    updateHeaderModel();
    if (els.modelSetting    && els.modelSetting.value    !== model) els.modelSetting.value    = model;
    if (els.quickModelSelect && els.quickModelSelect.value !== model) els.quickModelSelect.value = model;
    send('settings_update', { model: model });
    showToast('Modèle : ' + model);
  }

  function autoDetectModels(provider) {
    if (state.isDetecting) return;
    state.isDetecting = true;
    if (els.refreshModelsBtn) els.refreshModelsBtn.classList.add('loading');
    send('detect_models', { provider: provider || 'ollama' });
  }

  function handleModelsDetected(payload) {
    if (payload.ok && payload.models && payload.models.length > 0) {
      var models = payload.models;
      state.detectedModels['ollama'] = models;
      if (els.modelSetting) {
        els.modelSetting.innerHTML = '';
        els.modelSetting.disabled  = false;
        models.forEach(function (m) {
          var opt     = document.createElement('option');
          opt.value   = m;
          opt.textContent = m;
          if (m === state.settings.model) opt.selected = true;
          els.modelSetting.appendChild(opt);
        });
        if (!state.settings.model || models.indexOf(state.settings.model) === -1) {
          state.settings.model = models[0];
          els.modelSetting.value = models[0];
          saveSettingsToStorage();
        }
      }
      updateHeaderModel();
    } else if (payload.error) {
      showError(payload.error);
    }
  }

  function updateHeaderModel() {
    if (!els.aiProvider) return;
    var model = state.settings.model || '';
    var short = model ? model.split(':')[0] : 'LOCAL';
    els.aiProvider.textContent = short.toUpperCase();

    if (els.quickModelSelect) {
      var models = state.detectedModels['ollama'] || [];
      if (models.length > 0) {
        els.quickModelSelect.innerHTML = '';
        models.forEach(function (m) {
          var opt = document.createElement('option');
          opt.value = m; opt.textContent = m;
          if (m === model) opt.selected = true;
          els.quickModelSelect.appendChild(opt);
        });
      }
    }
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    state.settings.theme = theme;
    saveSettingsToStorage();
    document.querySelectorAll('.theme-btn').forEach(function (btn) {
      btn.classList.toggle('active', btn.dataset.theme === theme);
    });
  }

  function loadTheme() {
    document.documentElement.setAttribute('data-theme', state.settings.theme || 'jarvis');
  }

  // ── Caméra ────────────────────────────────────────────────────────────────
  // ── Panneau Debug Performances IA ────────────────────────────────────────
  function togglePerfPanel() {
    var panel = els.perfPanel;
    if (!panel) return;
    var visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'flex';
  }

  function updatePerfPanel(stats) {
    if (!stats) return;
    // Mise à jour des valeurs dans le panneau
    var set = function (el, val, unit) {
      if (!el) return;
      el.textContent = (val !== null && val !== undefined) ? (val + (unit || '')) : 'n/a';
    };
    set(els.perfFirstToken, stats.time_to_first_token_ms, ' ms');
    set(els.perfTotal,      stats.total_response_ms,      ' ms');
    set(els.perfOllama,     stats.ollama_call_ms,         ' ms');
    set(els.perfTokens,     stats.token_count,            '');
    set(els.perfSpeed,      stats.tokens_per_second,      ' tok/s');
    set(els.perfModel,      stats.model,                  '');
    set(els.perfBackend,    stats.backend,                '');
    // Ouvrir le panneau automatiquement si fermé (1ère réponse)
    if (els.perfPanel && els.perfPanel.style.display === 'none') {
      // Ne pas ouvrir automatiquement — respecter le choix user
    }
  }

  function toggleCameraPanel() {
    var panel    = els.cameraPanel;
    var chatMode = els.chatMode;
    if (!panel) return;
    var visible = panel.style.display !== 'none';
    panel.style.display    = visible ? 'none' : 'flex';
    chatMode.style.display = visible ? 'flex'  : 'none';
    if (!visible) fetchCameraStatus(); // refresh on open
  }

  function startCameraPolling() {
    fetchCameraStatus();
    state.cameraPollingTimer = setInterval(fetchCameraStatus, 5000);
  }

  function fetchCameraStatus() {
    fetch(state.backendHttpUrl + '/api/camera/status')
      .then(function (r) { return r.json(); })
      .then(function (d) { updateCameraUI(d); })
      .catch(function () { updateCameraUI(null); });
  }

  function updateCameraUI(d) {
    if (!d) {
      if (els.cameraStatVal) { els.cameraStatVal.textContent = 'ERR'; els.cameraStatVal.className = 'stat-value nova-camera-stat nova-stat-err'; }
      if (els.camState)  els.camState.textContent  = 'Backend inaccessible';
      if (els.sysCam)    els.sysCam.textContent     = 'ERR';
      return;
    }
    var state_val = (d.state || 'unknown').toUpperCase();
    var ok        = state_val === 'CONNECTED';
    if (els.cameraStatVal) {
      els.cameraStatVal.textContent = ok ? 'ON' : state_val;
      els.cameraStatVal.className   = 'stat-value nova-camera-stat ' + (ok ? 'nova-stat-ok' : 'nova-stat-warn');
    }
    if (els.camState)  els.camState.textContent  = state_val;
    if (els.camSource) els.camSource.textContent = d.source_active || d.source || '—';
    if (els.camFps)    els.camFps.textContent    = d.fps_current ? d.fps_current.toFixed(1) : '—';
    if (els.camError)  els.camError.textContent  = d.last_error || '—';
    if (els.sysCam)    els.sysCam.textContent    = ok ? 'OK' : state_val;
  }

  function cameraTest() {
    camLog('Test de la caméra...');
    fetch(state.backendHttpUrl + '/api/camera/test', { method: 'POST' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var msg = d.success ? '✓ Caméra disponible — ' + (d.source || '') : '✗ ' + (d.error || 'Caméra non disponible');
        camLog(msg);
        showToast(msg);
        fetchCameraStatus();
      })
      .catch(function (e) { camLog('Erreur : ' + e.message); });
  }

  function cameraStart() {
    camLog('Démarrage caméra...');
    fetch(state.backendHttpUrl + '/api/camera/start', { method: 'POST' })
      .then(function (r) { return r.json(); })
      .then(function (d) { camLog(d.message || JSON.stringify(d)); fetchCameraStatus(); })
      .catch(function (e) { camLog('Erreur : ' + e.message); });
  }

  function cameraStop() {
    camLog('Arrêt caméra...');
    fetch(state.backendHttpUrl + '/api/camera/stop', { method: 'POST' })
      .then(function (r) { return r.json(); })
      .then(function (d) { camLog(d.message || JSON.stringify(d)); fetchCameraStatus(); })
      .catch(function (e) { camLog('Erreur : ' + e.message); });
  }

  function cameraSnapshot() {
    camLog('Capture snapshot...');
    fetch(state.backendHttpUrl + '/api/camera/snapshot')
      .then(function (r) {
        if (!r.ok) throw new Error('Snapshot non disponible (caméra inactive ?)');
        return r.blob();
      })
      .then(function (blob) {
        var url = URL.createObjectURL(blob);
        if (els.snapshotImg)  els.snapshotImg.src      = url;
        if (els.snapshotTime) els.snapshotTime.textContent = new Date().toLocaleTimeString('fr-FR');
        if (els.snapshotArea) els.snapshotArea.style.display = 'block';
        camLog('Snapshot capturé ✓');
      })
      .catch(function (e) { camLog('Erreur snapshot : ' + e.message); });
  }

  // ── Analyse caméra à la demande ────────────────────────────────────────────
  //
  // Action ponctuelle, déclenchée par l'utilisateur via le bouton ANALYSER.
  // Le backend prend le dernier snapshot et délègue à un module d'analyse
  // local s'il existe. Sinon retourne "analyse visuelle non encore disponible".
  //
  // Aucune invention, aucune surveillance permanente activée.
  function cameraAnalyzeNow() {
    camLog('Analyse caméra...');
    if (els.camAnalyzeBtn) els.camAnalyzeBtn.disabled = true;

    fetch(state.backendHttpUrl + '/api/camera/analyze', { method: 'POST' })
      .then(function (r) {
        if (r.status === 503) {
          throw new Error('Caméra non démarrée — cliquez DÉMARRER d\'abord.');
        }
        if (!r.ok) throw new Error('Endpoint analyse indisponible (' + r.status + ').');
        return r.json();
      })
      .then(function (data) {
        // data : { ok, text, snapshot_size, analyzer_used, elapsed_ms }
        var size = data.snapshot_size ? ' [' + Math.round(data.snapshot_size / 1024) + ' Ko]' : '';

        if (data.ok && data.analyzer_used) {
          // Module d'analyse local présent et fonctionnel
          camLog('Analyse ✓ via ' + data.analyzer_used + size + ' (' + data.elapsed_ms + 'ms)');
          camLog('→ ' + data.text);
          // Injection dans le chat comme message utilisateur, encadré
          // pour que Nova sache que ça vient d'une analyse machine, pas d'une
          // observation humaine inventive.
          var prompt = 'Analyse de ma caméra à l\'instant (' +
            new Date().toLocaleTimeString('fr-FR') + ') : ' + data.text;
          if (state.ws && state.ws.readyState === WebSocket.OPEN) {
            sendMessage(prompt);
          }
        } else {
          // Pas d'analyseur disponible OU analyseur a échoué
          camLog('Analyse : ' + data.text + size);
        }
      })
      .catch(function (e) {
        camLog('Erreur analyse : ' + e.message);
      })
      .then(function () {
        // finally — réactiver le bouton dans tous les cas
        if (els.camAnalyzeBtn) els.camAnalyzeBtn.disabled = false;
      });
  }

  function camLog(msg) {
    if (!els.camLog) return;
    var line = document.createElement('div');
    line.className   = 'nova-cam-log-line';
    line.textContent = '[' + new Date().toLocaleTimeString('fr-FR') + '] ' + msg;
    els.camLog.insertBefore(line, els.camLog.firstChild);
    if (els.camLog.children.length > 20) els.camLog.lastChild.remove();
  }

  // ── Monitoring ────────────────────────────────────────────────────────────
  function startMonitoringPolling() {
    fetchMonitoringStatus();
    state.monitoringPollingTimer = setInterval(fetchMonitoringStatus, 10000);
  }

  function fetchMonitoringStatus() {
    fetch(state.backendHttpUrl + '/api/monitoring/status')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (els.sysDb) els.sysDb.textContent = d.db_size || d.status || 'OK';
      })
      .catch(function () {});
  }

  // ── Toasts ────────────────────────────────────────────────────────────────
  function showToast(msg, type) {
    if (!els.toast) return;
    els.toast.textContent  = msg;
    els.toast.className    = 'toast show' + (type ? ' ' + type : '');
    setTimeout(function () { els.toast.classList.remove('show'); }, 4000);
  }

  function showError(msg) { console.error(msg); showToast(msg, 'error'); }
  function showSuccess(msg) { showToast(msg, 'success'); }

  // ── Horloge ───────────────────────────────────────────────────────────────
  function startClock() {
    function update() {
      if (els.currentTime) {
        els.currentTime.textContent = new Date().toLocaleTimeString('fr-FR', { hour12: false });
      }
    }
    update();
    setInterval(update, 1000);
  }

  // ── Boot ──────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
