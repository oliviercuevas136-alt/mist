@echo off
setlocal enabledelayedexpansion
REM Nova Assistant Desktop -- Installation (Windows 10+)

echo.
echo  ==========================================
echo   Nova Assistant Desktop -- Installation
echo  ==========================================
echo.

REM -- Verifications prealables -------------------------------------------

where python >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python non trouve. Installez Python 3.11 depuis https://python.org
    pause & exit /b 1
)

REM -- Verification version Python (3.11 recommande, 3.13 deconseille) ----

set PY_VER=inconnu
set PY_MAJOR=0
set PY_MINOR=0
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PY_VER=%%v
for /f "tokens=1,2 delims=." %%a in ("%PY_VER%") do (
    set PY_MAJOR=%%a
    set PY_MINOR=%%b
)

REM Valeurs par defaut si non parsees
if "%PY_MAJOR%"=="0" (
    echo [AVERTISSEMENT] Impossible de detecter la version Python ^(%PY_VER%^).
    echo                 Assurez-vous d'utiliser Python 3.11.x.
    goto :skip_py_version_check
)
if "%PY_MAJOR%"=="3" (
    if %PY_MINOR% LSS 11 (
        echo [ERREUR] Python %PY_VER% detecte. Nova requiert Python 3.11+.
        echo          Installez Python 3.11 : https://python.org/downloads/release/python-3119/
        pause & exit /b 1
    )
    if %PY_MINOR% GEQ 13 (
        echo [AVERTISSEMENT] Python %PY_VER% detecte ^(version trop recente^).
        echo                 Python 3.13+ peut etre incompatible avec les modules IA/vocal.
        echo                 Version recommandee : Python 3.11.x
        echo                 https://python.org/downloads/release/python-3119/
        echo.
        set /p CONTINUE="Continuer quand meme ? (O/N) : "
        if /i not "!CONTINUE!"=="O" (pause & exit /b 1)
    )
)
:skip_py_version_check
echo [OK] Python %PY_VER% detecte.

where node >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Node.js non trouve. Installez Node.js depuis https://nodejs.org
    pause & exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] npm non trouve. Reinstallez Node.js depuis https://nodejs.org
    pause & exit /b 1
)

REM -- Etape 1 : venv Python -----------------------------------------------

echo [1/4] Creation du venv Python dans backend\.venv...
cd /d "%~dp0..\backend"
python -m venv .venv
if errorlevel 1 (
    echo [ERREUR] Echec creation du venv
    pause & exit /b 1
)

REM -- Etape 2 : dependances Python ----------------------------------------

echo [2/4] Installation des dependances Python...
.venv\Scripts\pip install --upgrade pip -q
.venv\Scripts\pip install -r requirements.txt
if errorlevel 1 (
    echo [ERREUR] Echec pip install
    pause & exit /b 1
)

REM -- Etape 3 : dependances Node.js / Electron ----------------------------

echo [3/4] Installation des dependances Node.js (Electron)...
cd /d "%~dp0..\frontend"
npm install
if errorlevel 1 (
    echo [ERREUR] Echec npm install
    pause & exit /b 1
)

REM -- Etape 4 : copie .env.example ----------------------------------------

echo [4/4] Copie du .env.example -> backend\.env (si absent)...
if not exist "%~dp0..\backend\.env" (
    copy "%~dp0..\.env.example" "%~dp0..\backend\.env"
    echo      -> .env cree. Editez backend\.env pour configurer Ollama/Mistral.
) else (
    echo      -> .env deja present, non ecrase.
)

echo.
echo  ==========================================
echo   [OK] Installation terminee !
echo  ==========================================
echo.
echo  Prochaines etapes :
echo    1. Assurez-vous qu'Ollama est lance : ollama serve
echo    2. Tirez le modele                 : ollama pull llama3.2:3b
echo    3. Lancez Nova                     : scripts\start.bat
echo.
pause
