@echo off
REM ── Nova — Backend uniquement (dev/debug) ─────────────────────────────────
chcp 65001 > nul
set BACKEND_DIR=%~dp0..\backend

if exist "%BACKEND_DIR%\.venv\Scripts\python.exe" (
    set PYTHON=%BACKEND_DIR%\.venv\Scripts\python.exe
) else (
    set PYTHON=python
)

echo [NOVA] Démarrage backend FastAPI sur http://127.0.0.1:8000
echo [NOVA] Docs : http://127.0.0.1:8000/docs
echo [NOVA] WS   : ws://127.0.0.1:8000/ws
echo.

cd /d "%BACKEND_DIR%"
%PYTHON% -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
