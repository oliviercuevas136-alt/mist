@echo off
REM =========================================================================
REM  Nova Assistant Desktop -- Lancement (Windows 10+)
REM
REM  Electron est SEUL responsable du demarrage du backend FastAPI.
REM  Ce script se contente de lancer l'interface Electron.
REM  Ne PAS ajouter ici une commande uvicorn : le backend serait demarre deux fois.
REM =========================================================================
setlocal

set FRONTEND_DIR=%~dp0..\frontend

REM =========================================================================
REM  Verifier que Node / npm sont disponibles
REM =========================================================================
where npm > nul 2>&1
if errorlevel 1 (
    echo [NOVA] ERREUR : npm introuvable.
    echo         Installez Node.js depuis https://nodejs.org puis relancez.
    pause
    exit /b 1
)

REM =========================================================================
REM  Verifier que node_modules existe (sinon rappeler install.bat)
REM =========================================================================
if not exist "%FRONTEND_DIR%\node_modules\" (
    echo [NOVA] ERREUR : dependances Electron manquantes.
    echo         Executez d'abord :  scripts\install.bat
    pause
    exit /b 1
)

echo.
echo [NOVA] Lancement de Nova Assistant Desktop...
echo [NOVA] Le backend FastAPI sera demarre automatiquement par Electron.
echo.

cd /d "%FRONTEND_DIR%"
npm start

echo.
echo [NOVA] Nova Assistant Desktop ferme.
endlocal
